/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

class PolygonSet {
public:

  typedef std::vector<std::pair<Unit, std::pair<Unit, int> > >::const_iterator iterator;

  /// default constructor
  PolygonSet();

  /// default constructor
  PolygonSet(Orientation2D orient);

  /// constructor from an iterator pair over polygons
  template <class T>
  PolygonSet(Orientation2D orient, T inputBegin, T inputEnd);

  /// constructor from a Rectangle
  template <class T>
  PolygonSet(Orientation2D orient, const RectangleImpl<T>& rect);

  /// constructor from a Polygon
  template <class T>
  PolygonSet(Orientation2D orient, const PolygonImpl<T>& polygon);

  /// constructor from a PolygonWithHoles
  template <class T>
  PolygonSet(Orientation2D orient, const PolygonWithHolesImpl<T>& polyWithHoles);
   
  /// copy constructor
  PolygonSet(const PolygonSet& that);

  /// copy with orientation change constructor
  PolygonSet(Orientation2D orient, const PolygonSet& that);

  /// destructor
  ~PolygonSet();

  /// assignement operator
  PolygonSet& operator=(const PolygonSet& that);

  /// equivilence operator 
  bool operator==(const PolygonSet& p) const;

  /// inequivilence operator 
  bool operator!=(const PolygonSet& p) const;

    /// comparison operator
  bool operator<(const PolygonSet& b) const; 

  /// comparison operator
  bool operator<=(const PolygonSet& b) const { return !(*this > b); }

  /// comparison operator
  bool operator>(const PolygonSet& b) const { return b < (*this); }

  /// comparison operator
  bool operator>=(const PolygonSet& b) const { return !(*this < b); }

  /// append to the container cT 
  template <class cT>
  unsigned int get(cT& container, bool fractureHoles = false) const;

  /// append to the container cT with polygons (holes will be fractured along orientation)
  template <class cT>
  unsigned int getPolygons(cT& container) const;

  /// append to the container cT with PolygonWithHoles objects
  template <class cT>
  unsigned int getPolygonsWithHoles(cT& container) const;

  /// append to the container cT with rectangles sliced along orientation
  template <class cT>
  unsigned int getRectangles(cT& container) const;

  /// append to the container cT with all maximal rectangles that cover the set
  template <class cT>
  unsigned int getMaxRectangles(cT& container) const;

  /// append to the container cT with the minimum number of rectangles that cover the set
  template <class cT>
  unsigned int getMinRectangles(cT& container, bool heuristic = true) const;

  /// get iterator to begin vertex data
  iterator begin() const;

  /// get iterator to end vertex data
  iterator end() const;

  /// clear the contents of the PolygonSet
  void clear() { data_.clear(); dirty_ = unsorted_ = false; }

  /// find out if Polygon set is empty
  bool empty() const { return data_.empty(); }

  /// get the scanline orientation of the polygon set
  Orientation2D orient() const { return orient_; }

  /// insert polygons
  template <class T>
  PolygonSet& insert(T inputBegin, T inputEnd); 

  /// insert holes
  template <class T>
  PolygonSet& insertHoles(T inputBegin, T inputEnd); 

  /// insert polygon
  template <class T>
  PolygonSet& insert(const PolygonImpl<T>& poly, bool isHole = false);

  /// insert hole
  template <class T>
  PolygonSet& insertHole(const PolygonImpl<T>& hole); 

  /// insert polygon with holes
  template <class T>
  PolygonSet& insert(const PolygonWithHolesImpl<T>& polyWithHoles);

  /// insert Rectangle
  template <class T>
  PolygonSet& insert(const RectangleImpl<T>& rect);
  
  /// insert Rectangle
  template <class T>
  PolygonSet& insertHole(const RectangleImpl<T>& rect);
  
  /// insert edge
  PolygonSet& insert(Unit coordinate, const std::pair<Interval, int>& edge);

  /// insert polygon set
  PolygonSet& insert(const PolygonSet& polygonSet);

  /// get the external boundary rectangle
  Rectangle extents() const;

  /// | & + * - ^ binary operators
  PolygonSet operator|(const PolygonSet& b) const;
  PolygonSet operator&(const PolygonSet& b) const;
  PolygonSet operator+(const PolygonSet& b) const;
  PolygonSet operator*(const PolygonSet& b) const;
  PolygonSet operator-(const PolygonSet& b) const;
  PolygonSet operator^(const PolygonSet& b) const;

  /// |= &= += *= -= ^= binary operators
  PolygonSet& operator|=(const PolygonSet& b);
  PolygonSet& operator&=(const PolygonSet& b);
  PolygonSet& operator+=(const PolygonSet& b);
  PolygonSet& operator*=(const PolygonSet& b);
  PolygonSet& operator-=(const PolygonSet& b);
  PolygonSet& operator^=(const PolygonSet& b);

  /// | & + * - ^ binary operators
  template <class T2>
  PolygonSet operator|(const PolygonImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator&(const PolygonImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator+(const PolygonImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator*(const PolygonImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator-(const PolygonImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator^(const PolygonImpl<T2>& b) const;

  /// |= &= += *= -= ^= binary operators
  template <class T2>
  PolygonSet& operator|=(const PolygonImpl<T2>& b);
  template <class T2>
  PolygonSet& operator&=(const PolygonImpl<T2>& b);
  template <class T2>
  PolygonSet& operator+=(const PolygonImpl<T2>& b);
  template <class T2>
  PolygonSet& operator*=(const PolygonImpl<T2>& b);
  template <class T2>
  PolygonSet& operator-=(const PolygonImpl<T2>& b);
  template <class T2>
  PolygonSet& operator^=(const PolygonImpl<T2>& b);

//   /// | & + * - ^ binary operators
//   template <class T2>
//   PolygonSet operator|(const PolygonWithHolesImpl<T2>& b) const;
//   template <class T2>
//   PolygonSet operator&(const PolygonWithHolesImpl<T2>& b) const;
//   template <class T2>
//   PolygonSet operator+(const PolygonWithHolesImpl<T2>& b) const;
//   template <class T2>
//   PolygonSet operator*(const PolygonWithHolesImpl<T2>& b) const;
//   template <class T2>
//   PolygonSet operator-(const PolygonWithHolesImpl<T2>& b) const;
//   template <class T2>
//   PolygonSet operator^(const PolygonWithHolesImpl<T2>& b) const;

//   /// |= &= += *= -= ^= binary operators
//   template <class T2>
//   PolygonSet& operator|=(const PolygonWithHolesImpl<T2>& b);
//   template <class T2>
//   PolygonSet& operator&=(const PolygonWithHolesImpl<T2>& b);
//   template <class T2>
//   PolygonSet& operator+=(const PolygonWithHolesImpl<T2>& b);
//   template <class T2>
//   PolygonSet& operator*=(const PolygonWithHolesImpl<T2>& b);
//   template <class T2>
//   PolygonSet& operator-=(const PolygonWithHolesImpl<T2>& b);
//   template <class T2>
//   PolygonSet& operator^=(const PolygonWithHolesImpl<T2>& b);

  /// | & + * - ^ binary operators
  template <class T2>
  PolygonSet operator|(const RectangleImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator&(const RectangleImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator+(const RectangleImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator*(const RectangleImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator-(const RectangleImpl<T2>& b) const;
  template <class T2>
  PolygonSet operator^(const RectangleImpl<T2>& b) const;

  /// |= &= += *= -= ^= binary operators
  template <class T2>
  PolygonSet& operator|=(const RectangleImpl<T2>& b);
  template <class T2>
  PolygonSet& operator&=(const RectangleImpl<T2>& b);
  template <class T2>
  PolygonSet& operator+=(const RectangleImpl<T2>& b);
  template <class T2>
  PolygonSet& operator*=(const RectangleImpl<T2>& b);
  template <class T2>
  PolygonSet& operator-=(const RectangleImpl<T2>& b);
  template <class T2>
  PolygonSet& operator^=(const RectangleImpl<T2>& b);

  /// resizing operations
  PolygonSet operator+(Unit delta) const;
  PolygonSet& operator+=(Unit delta);
  PolygonSet operator-(Unit delta) const;
  PolygonSet& operator-=(Unit delta);

  /// shrink the PolygonSet specified by orient by shrinking amount
  PolygonSet& shrink(Orientation2D orient, UnsignedUnit shrinking);

  /// shrink the PolygonSet specified by orient by low and high delta values
  PolygonSet& shrink(Orientation2D orient, UnsignedUnit lowDelta,
                     UnsignedUnit highDelta);

  /// shrink the PolygonSet by shrinking
  PolygonSet& shrink(UnsignedUnit shrinking);

  /// shrink the PolygonSet cooresponding by bloating in dir direction
  PolygonSet& shrink(Direction2D dir, UnsignedUnit shrinking);

  /// shrink the PolygonSet cooresponding directional values
  PolygonSet& shrink(UnsignedUnit westDelta,
                     UnsignedUnit eastDelta,
                     UnsignedUnit southDelta,
                     UnsignedUnit northDelta);
   
  /// bloat the PolygonSet specified by orient by bloating amount
  PolygonSet& bloat(Orientation2D orient, UnsignedUnit bloating);

  /// bloat the PolygonSet specified by orient by low and high delta values
  PolygonSet& bloat(Orientation2D orient, UnsignedUnit lowDelta,
                    UnsignedUnit highDelta);

  /// bloat the PolygonSet by bloating
  PolygonSet& bloat(UnsignedUnit bloating);

  /// bloat the PolygonSet cooresponding by bloating in dir direction
  PolygonSet& bloat(Direction2D dir, UnsignedUnit bloating);

  /// bloat the PolygonSet cooresponding directional values
  PolygonSet& bloat(UnsignedUnit westDelta,
                    UnsignedUnit eastDelta,
                    UnsignedUnit southDelta,
                    UnsignedUnit northDelta);

  /// get the area of the set 
  UnsignedLongUnit area() const;

  /// transform set
  PolygonSet& transform(const AxisTransform& atr);
    
  /// transform set
  PolygonSet& transform(const Transform& tr);

  /// scale set
  PolygonSet& scaleUp(UnsignedUnit factor);
  PolygonSet& scaleDown(UnsignedUnit factor);

  /// grow each polygon in the set then compute all intersection points between grown polygons
  PolygonSet& growAnd(UnsignedUnit westDelta,
                      UnsignedUnit eastDelta,
                      UnsignedUnit southDelta,
                      UnsignedUnit northDelta);

  /// grow each polygon in the set then compute all intersection points between grown polygons
  PolygonSet& growAnd(Direction2D dir, UnsignedUnit bloating);

  /// grow each polygon in the set then compute all intersection points between grown polygons
  PolygonSet& growAnd(UnsignedUnit bloating);

  /// grow each polygon in the set then compute all intersection points between grown polygons
  PolygonSet& growAnd(Orientation2D orient, UnsignedUnit lowDelta,
                      UnsignedUnit highDelta);

  /// grow each polygon in the set then compute all intersection points between grown polygons
  PolygonSet& growAnd(Orientation2D orient, UnsignedUnit bloating);

   /// the portions of the polygon set that intersect or touch the argument set will be retained
   PolygonSet& interact(const PolygonSet& that);
      
   /// returns the portions of the polygon set that intersect or touch the argument set
   PolygonSet interaction(const PolygonSet& that);

   /// compute the self intersection of the polygon set
   PolygonSet& selfIntersect();
      
   /// compute the self intersection of the polygon set
   PolygonSet selfIntersection();

   /// discard all polygons that do not fall within the range of specified criteria
   PolygonSet& keep(UnsignedLongUnit minArea, UnsignedLongUnit maxArea, 
                    UnsignedUnit minWidth, UnsignedUnit maxWidth, 
                    UnsignedUnit minHeight, UnsignedUnit maxHeight);

private:
   Orientation2D orient_;
   typedef std::vector<std::pair<Unit, std::pair<Unit, int> > > PolygonVectorData;
   mutable PolygonVectorData data_;
   mutable bool dirty_;
   mutable bool unsorted_;

private:
   void clean_() const;
   void sort_() const;
   /// append to the container cT with PolygonWithHoles objects

   friend std::ostream& operator<<(std::ostream& o, const PolygonSet& p);
   friend std::istream& operator>>(std::istream& i, PolygonSet& p);

};

std::ostream& operator<< (std::ostream& o, const PolygonSet& p);

std::istream& operator>> (std::istream& i, PolygonSet& p);

//PropertyMerge computes the regions in which the set of properties from input geometries with
//associated properties are unique, giving the A, B and AB regions of inputs with A and B properties.
template <typename PropertyType>
class PropertyMerge {
private:
  //typename merge_scanline<Unit, PropertyType, PolygonSet>::property_merge_data pmd_;
  std::vector<std::pair<property_merge_point<Unit>, std::pair<PropertyType, int> > > pmd_;
public:
  inline PropertyMerge() {}
  inline PropertyMerge(const PropertyMerge& that) : pmd_(that.pmd_) {}
  inline PropertyMerge& operator=(const PropertyMerge& that) { pmd_ = that.pmd_; }
  inline void insert(const PolygonSet& ps, const PropertyType& property) {
    merge_scanline<Unit, PropertyType, PolygonSet>::populate_property_merge_data(pmd_, ps.begin(), ps.end(), property, ps.orient());
  }
  template <class GeoObjT>
  inline void insert(const GeoObjT& geoObj, const PropertyType& property) {
    PolygonSet ps;
    ps.insert(geoObj);
    insert(ps, property);
  }
  //merge properties of input geometries and store the resulting geometries of regions
  //with unique sets of merged properties to polygons sets in a map keyed by sets of properties
  // T = std::map<std::set<PropertyType>, PolygonSet>  or
  // T = std::map<std::vector<PropertyType>, PolygonSet>
  template <typename ResultType> 
  inline void merge(ResultType& result) {
    merge_scanline<Unit, PropertyType, PolygonSet, typename ResultType::key_type> ms;
    ms.perform_merge(result, pmd_);
  }
//   template <typename GraphType>
//   inline void extract(GraphType& graph) {
//     merge_scanline<PropertyType, PolygonSet, std::set<PropertyType> > ms;
//     ms.performExtract(graph, pmd_);
//   }
};

//ConnectivityExtraction computes the graph of connectivity between rectangle, polygon and
//polygon set graph nodes where an edge is created whenever the geometry in two nodes overlap
class ConnectivityExtraction {
private:
  TouchSetData tsd_;
  unsigned int nodeCount_;
public:
  inline ConnectivityExtraction() : nodeCount_(0) {}
  inline ConnectivityExtraction(const ConnectivityExtraction& that) : tsd_(that.tsd_),
    nodeCount_(that.nodeCount_) {}
  inline ConnectivityExtraction& operator=(const ConnectivityExtraction& that) { 
    tsd_ = that.tsd_; 
    nodeCount_ = that.nodeCount_; {}
    return *this;
  }

  //insert a polygon set graph node, the value returned is the id of the graph node
  inline unsigned int insert(const PolygonSet& ps) {
    populateTouchSetData(tsd_, ps.begin(), ps.end(), nodeCount_);
    return nodeCount_++;
  }

  //insert a polygon or rectangle graph node, the value returned is the id of the graph node
  template <class GeoObjT>
  inline unsigned int insert(const GeoObjT& geoObj) {
    PolygonSet ps;
    ps.insert(geoObj);
    return insert(ps);
  }

  //extract connectivity and store the edges in the graph
  //graph must be indexable by graph node id and the indexed value must be a std::set of
  //graph node id
  template <class GraphT>
  inline void extract(GraphT& graph) {
    performTouch(graph, tsd_);
  }
};
