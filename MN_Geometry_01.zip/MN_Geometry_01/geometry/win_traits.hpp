// ============================================================================
// win_traits.hpp                                 (C)2005 Michael Andersen Nexo
// ============================================================================
// Specializes the as_iterator and xyz_traits for the Windows system API
// structs POINT and SIZE, enabling using these structures as representation
// classes in geom::vector and geom::point (e.g. geom::vector<LONG,2,SIZE>).
// Obviously, reinterpreting these structs as 2D-arrays might break on
// compilers with very strange structure packing, but it seems highly unlikely.

#ifndef WIN_TRAITS_H
#define WIN_TRAITS_H

#ifdef _WINDOWS_

#include "traits.hpp"

namespace geom
{
	// Specialization for POINT
	template <>
	struct as_iterator<POINT>
	{
		typedef LONG* iterator;
		typedef LONG const* const_iterator;
		static iterator cast(POINT& p) { return reinterpret_cast<LONG*>(&p); }
		static const_iterator cast(POINT const& p) { return reinterpret_cast<LONG const*>(&p); }
	};

	template<> struct xyz_traits<POINT, 2>
	{
		static LONG & x(POINT& p) { return p.x; }
		static LONG const& x(POINT const& p) { return p.x; }
		static LONG& y(POINT& p) { return p.y; }
		static LONG const& y(POINT const& p) { return p.y; }
	};

	// Specialization for SIZE
	template<> struct as_iterator<SIZE>
	{
		typedef LONG* iterator;
		typedef LONG const* const_iterator;
		static iterator cast(SIZE& s) { return reinterpret_cast<LONG*>(&s); }
		static const_iterator cast(SIZE const& s) { reinterpret_cast<LONG const*>(&s); }
	};

	template<> struct xyz_traits<SIZE, 2>
	{
		static LONG & x(SIZE& s) { return s.cx; }
		static LONG const& x(SIZE const& s) { return s.cx; }
		static LONG& y(SIZE& s) { return s.cy; }
		static LONG const& y(SIZE const& s) { return s.cy; }
	};


#ifdef __ATLTYPES_H__
	template <>	struct as_iterator<CPoint> : public as_iterator<POINT>
	{
	};

	template<> struct xyz_traits<CPoint,2> : public xyz_traits<POINT,2>
	{
	};

	template <>	struct as_iterator<CSize> : public as_iterator<SIZE>
	{
	};

	template<> struct xyz_traits<CSize,2> : public xyz_traits<SIZE,2>
	{
	};
#endif //__ATLTYPES_H__

}

#endif //_WINDOWS_
#endif //WIN_TRAITS_H
