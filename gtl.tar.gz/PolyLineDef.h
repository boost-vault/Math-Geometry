/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
const int VERTICAL_HEAD = 1, HEAD_TO_TAIL = 2, TAIL_TO_TAIL = 4, SOLID_TO_RIGHT = 8;

//EVERY FUNCTION in this DEF file should be explicitly defined as inline

//microsoft compiler improperly warns whenever you cast an integer to bool
//call this function on an integer to convert it to bool without a warning
template <class T>
inline bool to_bool(const T& val) { return val != 0; }

//default constructor (for preallocation)
inline PolyLine::PolyLine() : headp_(0), tailp_(0), state_(-1) {}

//constructor
inline PolyLine::PolyLine(Orientation2D orient, Unit coord, Side side) : 
  ptdata_(1, coord),
  headp_(0),
  tailp_(0),
  state_(orient.toInt() +
         (side << 3)) {}

//copy constructor
inline PolyLine::PolyLine(const PolyLine& pline) : ptdata_(pline.ptdata_),
                                                   headp_(pline.headp_),
                                                   tailp_(pline.tailp_),
                                                   state_(pline.state_) {}

//destructor
inline PolyLine::~PolyLine() {
  //clear out data just in case it is read later
  headp_ = tailp_ = 0;
  state_ = 0;
}

inline PolyLine& PolyLine::operator=(const PolyLine& that) {
  if(!(this == &that)) {
    headp_ = that.headp_;
    tailp_ = that.tailp_;
    ptdata_ = that.ptdata_;
    state_ = that.state_;
  }
  return *this;
}

inline bool PolyLine::operator==(const PolyLine& b) const {
  return this == &b || (state_ == b.state_ &&
                        headp_ == b.headp_ &&
                        tailp_ == b.tailp_);
}

//valid PolyLine
inline bool PolyLine::isValid() const { 
  return state_ > -1; }

//first coordinate is an X value
//first segment is vertical
inline bool PolyLine::verticalHead() const {
  return state_ & VERTICAL_HEAD;
}

//retrun true is PolyLine has odd number of coordiantes
inline bool PolyLine::oddLength() const {
  return to_bool((ptdata_.size()-1) % 2);
}

//last coordiante is an X value
//last segment is vertical
inline bool PolyLine::verticalTail() const {
  return to_bool(verticalHead() ^ oddLength());
}
     
inline Orientation2D PolyLine::tailOrient() const {
  return predicated_value(verticalTail(), VERTICAL, HORIZONTAL);
}

inline Orientation2D PolyLine::headOrient() const {
  return predicated_value(verticalHead(), VERTICAL, HORIZONTAL);
}

inline End PolyLine::endConnectivity(End end) const {
  //Tail should be defined as true
  if(end) { return tailToTail(); }
  return headToTail();
}

inline bool PolyLine::headToTail() const {
  return to_bool(state_ & HEAD_TO_TAIL);
}

inline bool PolyLine::headToHead() const {
  return to_bool(!headToTail());
}

inline bool PolyLine::tailToHead() const {
  return to_bool(!tailToTail());
}
     
inline bool PolyLine::tailToTail() const {
  return to_bool(state_ & TAIL_TO_TAIL);
}

inline Side PolyLine::solidSide() const { 
  return solidToRight(); }
      
inline bool PolyLine::solidToRight() const {
  return to_bool(state_ & SOLID_TO_RIGHT) != 0;
}

inline bool PolyLine::active() const {
  return !to_bool(tailp_);
}

inline PolyLine& PolyLine::pushCoordinate(Unit coord) {
  ptdata_.push_back(coord);
  return *this;
}

inline PolyLine& PolyLine::popCoordinate() {
  ptdata_.pop_back();
  return *this;
}

inline PolyLine& PolyLine::pushPoint(const Point& point) {
  Point endPt = getEndPoint();
  //vertical is true, horizontal is false
  if(predicated_value(tailOrient().toInt(), point.y() == endPt.y(), point.x() == endPt.x())) {
    //we were pushing a colinear segment
    return popCoordinate();
  }
  return pushCoordinate(predicated_value(tailOrient().toInt(), point.y(), point.x()));
}

inline PolyLine& PolyLine::extendTail(Unit delta) {
  ptdata_.back() += delta;
  return *this;
}

//private member function that creates a link from this PolyLine to that
inline PolyLine& PolyLine::joinTo_(End thisEnd, PolyLine& that, End end) {
  if(thisEnd){
    tailp_ = &that;
    state_ &= ~TAIL_TO_TAIL; //clear any previous state_ of bit (for safety)
    state_ |= (end << 2); //place bit into mask
  } else {
    headp_ = &that;
    state_ &= ~HEAD_TO_TAIL; //clear any previous state_ of bit (for safety)
    state_ |= (end << 1); //place bit into mask
  }
  return *this;
}

//join two PolyLines (both ways of the association)
inline PolyLine& PolyLine::joinTo(End thisEnd, PolyLine& that, End end) {
  joinTo_(thisEnd, that, end);
  that.joinTo_(end, *this, thisEnd);
  return *this;
}

//convenience functions for joining PolyLines
inline PolyLine& PolyLine::joinToTail(PolyLine& that, End end) {
  return joinTo(TAIL, that, end);
}
inline PolyLine& PolyLine::joinToHead(PolyLine& that, End end) {
  return joinTo(HEAD, that, end);
}
inline PolyLine& PolyLine::joinHeadToHead(PolyLine& that) {
  return joinToHead(that, HEAD);
}
inline PolyLine& PolyLine::joinHeadToTail(PolyLine& that) {
  return joinToHead(that, TAIL);
}
inline PolyLine& PolyLine::joinTailToHead(PolyLine& that) {
  return joinToTail(that, HEAD);
}
inline PolyLine& PolyLine::joinTailToTail(PolyLine& that) {
  return joinToTail(that, TAIL);
}

inline PolyLine& PolyLine::disconnectTails() {
   next(TAIL)->state_ &= !TAIL_TO_TAIL;
   next(TAIL)->tailp_ = 0;
   state_ &= !TAIL_TO_TAIL;
   tailp_ = 0;
   return *this;
}

inline Unit PolyLine::getEndCoord(End end) const {
  if(end)
    return ptdata_.back();
  return ptdata_.front();
}

inline Orientation2D PolyLine::segmentOrient(unsigned int index) const {
  return predicated_value(to_bool((unsigned int)verticalHead() ^ (index % 2)), VERTICAL, HORIZONTAL);
}

inline Point PolyLine::getPoint(unsigned int index) const {
  //assert(isValid() && headp_->isValid()) ("PolyLine: headp_ must be valid");
  Point pt;
  pt.x(ptdata_[index]);
  pt.y(ptdata_[index]);
  Unit prevCoord;
  if(index == 0) {
    prevCoord = headp_->getEndCoord(headToTail());
  } else {
    prevCoord = ptdata_[index-1];
  }
  pt.set(segmentOrient(index), prevCoord);
  return pt;
}

inline Point PolyLine::getEndPoint(End end) const {
  return getPoint(predicated_value(end, numSegments() - 1, (unsigned int)0));
}

inline Unit PolyLine::operator[] (unsigned int index) const {
  //assert(ptdata_.size() > index) ("PolyLine: out of bounds index");
  return ptdata_[index];
}

inline unsigned int PolyLine::numSegments() const {
  return ptdata_.size();
}

inline PolyLine* PolyLine::next(End end) const {
  return predicated_value(end, tailp_, headp_);
}

inline ActiveTail::ActiveTail() : tailp_(0), otherTailp_(0) {}

inline ActiveTail::ActiveTail(Orientation2D orient, Unit coord, Side solidToRight, ActiveTail* otherTailp) {
  tailp_ = createPolyLine(orient, coord, solidToRight);
  otherTailp_ = otherTailp;
}

inline ActiveTail::ActiveTail(PolyLine* active, ActiveTail* otherTailp) : 
  tailp_(active), otherTailp_(otherTailp) {}

//copy constructor
inline ActiveTail::ActiveTail(const ActiveTail& that) : tailp_(that.tailp_), otherTailp_(that.otherTailp_)  {}

//destructor
inline ActiveTail::~ActiveTail() { 
  //clear them in case the memory is read later
  tailp_ = 0; otherTailp_ = 0; 
}

inline ActiveTail& ActiveTail::operator=(const ActiveTail& that) {
  //self assignment is safe in this case
  tailp_ = that.tailp_;
  otherTailp_ = that.otherTailp_;
  return *this;
}

inline bool ActiveTail::operator==(const ActiveTail& b) const {
  return tailp_ == b.tailp_ && otherTailp_ == b.otherTailp_;
}

inline bool ActiveTail::operator<(const ActiveTail& b) const {
  return tailp_->getEndPoint().y() < b.tailp_->getEndPoint().y();
}

inline bool ActiveTail::operator<=(const ActiveTail& b) const { 
  return !(*this > b); }
   
inline bool ActiveTail::operator>(const ActiveTail& b) const { 
  return b < (*this); }
   
inline bool ActiveTail::operator>=(const ActiveTail& b) const { 
  return !(*this < b); }

inline PolyLine* ActiveTail::getTail() const { 
  return tailp_; }

inline PolyLine* ActiveTail::getOtherTail() const { 
  return otherTailp_->tailp_; }

inline ActiveTail* ActiveTail::getOtherActiveTail() const { 
  return otherTailp_; }

inline bool ActiveTail::isOtherTail(const ActiveTail& b) {
  //       assert( (tailp_ == b.getOtherTail() && getOtherTail() == b.tailp_) ||
  //                     (tailp_ != b.getOtherTail() && getOtherTail() != b.tailp_)) 
  //         ("ActiveTail: Active tails out of sync");
  return otherTailp_ == &b;
}

inline ActiveTail& ActiveTail::updateTail(PolyLine* newTail) {
  tailp_ = newTail;
  return *this;
}

inline ActiveTail* ActiveTail::addHole(ActiveTail* hole, bool fractureHoles) {
  if(!fractureHoles){
    holesList_.push_back(hole);
    copyHoles(*hole);
    copyHoles(*(hole->getOtherActiveTail()));
    return this;
  }
  ActiveTail* h, *v;
  ActiveTail* other = hole->getOtherActiveTail();
  if(other->getOrient() == VERTICAL) {
    //assert that hole.getOrient() == HORIZONTAL
    //this case should never happen
    h = hole;  
    v = other;
  } else {
    //assert that hole.getOrient() == VERTICAL
    h = other;
    v = hole;
  }
  h->pushCoordinate(v->getCoordinate());
  //assert that h->getOrient() == VERTICAL
  //v->pushCoordinate(getCoordinate());
  //assert that v->getOrient() == VERTICAL
  //I can't close a figure by adding a hole, so pass zero for xMin and yMin
  UnitVector tmpVec;
  ActiveTail::joinChains(this, h, false, tmpVec);
  return v;
}

inline const std::list<ActiveTail*>& ActiveTail::getHoles() const {
  return holesList_;
}

inline void ActiveTail::copyHoles(ActiveTail& that) {
  holesList_.splice(holesList_.end(), that.holesList_); //splice the two lists together
}

inline bool ActiveTail::solidToRight() const { 
  return getTail()->solidToRight(); }

inline Unit ActiveTail::getCoord() const { 
  return getTail()->getEndCoord(); }
 
inline Unit ActiveTail::getCoordinate() const { 
  return getCoord(); } 

inline Orientation2D ActiveTail::getOrient() const { 
  return getTail()->tailOrient(); }

inline void ActiveTail::pushCoordinate(Unit coord) { 
  //appropriately handle any co-linear polyline segments by calling push point internally
  Point p;
  p.x(coord);
  p.y(coord);
  //if we are vertical assign the last coordinate (an X) to p.x, else to p.y
  p.set(getOrient().getPerpendicular(), getCoordinate());
  tailp_->pushPoint(p);
}


//global utility functions
inline PolyLine* createPolyLine(Orientation2D orient, Unit coord, Side side) {
  return new PolyLine(orient, coord, side);
}

inline void destroyPolyLine(PolyLine* pLine) {
  delete pLine;
}

inline ActiveTail* createActiveTail() {
  //consider replacing system allocator with ActiveTail memory pool
  return new ActiveTail();
}

inline void destroyActiveTail(ActiveTail* aTail) {
  delete aTail;
}


//no recursion, to prevent max recursion depth errors
inline void ActiveTail::destroyContents() {
  tailp_->disconnectTails();
  PolyLine* nextPolyLinep = tailp_->next(HEAD);
  End end = tailp_->endConnectivity(HEAD);
  destroyPolyLine(tailp_);
  while(nextPolyLinep) {
    End nextEnd = nextPolyLinep->endConnectivity(!end); //get the direction of next polyLine
    PolyLine* nextNextPolyLinep = nextPolyLinep->next(!end); //get the next polyline
    destroyPolyLine(nextPolyLinep); //destroy the current polyline
    end = nextEnd;
    nextPolyLinep = nextNextPolyLinep;
  }
}

inline ActiveTail::iterator ActiveTail::begin(bool isHole, Orientation2D orient) const {
   return iterator(this, isHole, orient);
}

inline ActiveTail::iterator ActiveTail::end() const {
   return iterator();
}

inline ActiveTail::iteratorHoles ActiveTail::beginHoles() const {
   return holesList_.begin();
}

inline ActiveTail::iteratorHoles ActiveTail::endHoles() const {
   return holesList_.end();
}

inline void ActiveTail::writeOutFigureItrs(iterator& beginOut, iterator& endOut, bool isHole, Orientation2D orient) const {
   beginOut = begin(isHole, orient);
   endOut = end();
}

inline void ActiveTail::writeOutFigureHoleItrs(iteratorHoles& beginOut, iteratorHoles& endOut) const {
   beginOut = beginHoles();
   endOut = endHoles();
}

inline void ActiveTail::writeOutFigure(UnitVector& outVec, bool isHole) const {
  //we start writing out the polyLine that this active tail points to at its tail
  unsigned int size = outVec.size();
  outVec.push_back(0); //place holder for size
  PolyLine* nextPolyLinep = 0;
  if(!isHole){
    nextPolyLinep = otherTailp_->tailp_->writeOut(outVec);
  } else {
    nextPolyLinep = tailp_->writeOut(outVec);
  }
  Unit firsty = outVec[size + 1];
  if(getOrient() == HORIZONTAL ^ !isHole) {
    //our first coordinate is a y value, so we need to rotate it to the end
    UnitVector::iterator tmpItr = outVec.begin();
	tmpItr += size; 
    outVec.erase(++tmpItr); //erase the 2nd element
  }
  End startEnd = tailp_->endConnectivity(HEAD);
  if(isHole) startEnd = otherTailp_->tailp_->endConnectivity(HEAD);
  while(nextPolyLinep) {
    bool nextStartEnd = nextPolyLinep->endConnectivity(!startEnd);
    nextPolyLinep = nextPolyLinep->writeOut(outVec, startEnd); 
    startEnd = nextStartEnd;
  }      
  if(getOrient() == HORIZONTAL ^ !isHole) {
    //we want to push the y value onto the end since we ought to have ended with an x
    outVec.push_back(firsty); //should never be executed because we want first value to be an x
  }
  //the vector contains the coordinates of the linked list of PolyLines in the correct order
  //first element is supposed to be the size
  outVec[size] = outVec.size() - 1 - size;  //number of coordinates in vector
  //assert outVec[size] % 2 == 0 //it should be even
  //make the size negative for holes
  outVec[size] *= predicated_value(isHole, -1, 1);
}

//no recursion to prevent max recursion depth errors
inline PolyLine* PolyLine::writeOut(UnitVector& outVec, End startEnd) const {
  if(startEnd == HEAD){
    //forward order
    outVec.insert(outVec.end(), ptdata_.begin(), ptdata_.end());
    return tailp_;
  }else{
    //reverse order
    //do not reserve because we expect outVec to be large enough already
    for(int i = ptdata_.size() - 1; i >= 0; --i){
      outVec.push_back(ptdata_[i]);
    }
    //NT didn't know about this version of the API....
    //outVec.insert(outVec.end(), ptdata_.rbegin(), ptdata_.rend());
    return headp_;
  }
}

inline void writeOutRect(UnitVector& outVec, const Rectangle& rect) {
  Unit rectpts[9] = { 4,
                      rect.xl(), rect.yl(), 
                      rect.xh(), rect.yl(),
                      rect.xh(), rect.yh(),
                      rect.xl(), rect.yh()
  };
  outVec.insert(outVec.end(), rectpts, rectpts + 9);
}

//solid indicates if it was joined by a solit or a space
inline ActiveTail* ActiveTail::joinChains(ActiveTail* at1, ActiveTail* at2, bool solid, UnitVector& outBufferTmp) 
{
  //checks to see if we closed a figure
  if(at1->isOtherTail(*at2)){
    //value of solid tells us if we closed solid or hole
    //and output the solid or handle the hole appropriately
    //if the hole needs to fracture across horizontal partition boundary we need to notify
    //the calling context to do so
    if(solid) {
      //the chains are being joined because there is solid to the right
      //this means that if the figure is closed at this point it must be a hole
      //because otherwise it would have to have another vertex to the right of this one
      //and would not be closed at this point
      return at1;
    } else {    
      //assert pG != 0
      //the figure that was closed is a shell
      at1->writeOutFigure(outBufferTmp);
      //process holes of the polygon
      at1->copyHoles(*at2); //there should not be holes on at2, but if there are, copy them over
      const std::list<ActiveTail*>& holes = at1->getHoles();
      for(std::list<ActiveTail*>::const_iterator litr = holes.begin(); litr != holes.end(); ++litr) {
        (*litr)->writeOutFigure(outBufferTmp, true);
        //delete the hole
        (*litr)->destroyContents();
        destroyActiveTail((*litr)->getOtherActiveTail());
        destroyActiveTail((*litr));
      }
      //delete the polygon
      at1->destroyContents();
      //at2 contents are the same as at1, so it should not destroy them
      destroyActiveTail(at1);
      destroyActiveTail(at2);
    }
    return 0;
  }
  //join the two partial polygons into one large partial polygon
  at1->getTail()->joinTailToTail(*(at2->getTail()));
  *(at1->getOtherActiveTail()) = ActiveTail(at1->getOtherTail(), at2->getOtherActiveTail());
  *(at2->getOtherActiveTail()) = ActiveTail(at2->getOtherTail(), at1->getOtherActiveTail());
  at1->getOtherActiveTail()->copyHoles(*at1);
  at1->getOtherActiveTail()->copyHoles(*at2);
  destroyActiveTail(at1);
  destroyActiveTail(at2);
  return 0;
}

//solid indicates if it was joined by a solit or a space
template <bool orientT>
inline ActiveTail* ActiveTail::joinChains(ActiveTail* at1, ActiveTail* at2, bool solid, 
                                          typename std::vector<PolyLinePolygonData<orientT> >& outBufferTmp) {
  //checks to see if we closed a figure
  if(at1->isOtherTail(*at2)){
    //value of solid tells us if we closed solid or hole
    //and output the solid or handle the hole appropriately
    //if the hole needs to fracture across horizontal partition boundary we need to notify
    //the calling context to do so
    if(solid) {
      //the chains are being joined because there is solid to the right
      //this means that if the figure is closed at this point it must be a hole
      //because otherwise it would have to have another vertex to the right of this one
      //and would not be closed at this point
      return at1;
    } else {    
      //assert pG != 0
      //the figure that was closed is a shell
      outBufferTmp.push_back(at1);
      at1->copyHoles(*at2); //there should not be holes on at2, but if there are, copy them over
    }
    return 0;
  }
  //join the two partial polygons into one large partial polygon
  at1->getTail()->joinTailToTail(*(at2->getTail()));
  *(at1->getOtherActiveTail()) = ActiveTail(at1->getOtherTail(), at2->getOtherActiveTail());
  *(at2->getOtherActiveTail()) = ActiveTail(at2->getOtherTail(), at1->getOtherActiveTail());
  at1->getOtherActiveTail()->copyHoles(*at1);
  at1->getOtherActiveTail()->copyHoles(*at2);
  destroyActiveTail(at1);
  destroyActiveTail(at2);
  return 0;
}

template <class TKey, class T> inline typename std::map<TKey, T>::iterator findAtNext(std::map<TKey, T>& theMap, 
                                                                                      typename std::map<TKey, T>::iterator pos, const TKey& key) 
{
  if(pos == theMap.end()) return theMap.find(key);
  //if they match the mapItr is pointing to the correct position
  if(pos->first < key) {
    return theMap.find(key);
  }
  if(pos->first > key) {
    return theMap.end();
  } 
  //else they are equal and no need to do anything to the iterator
  return pos;
}

// createActiveTailsAsPair is called in these two end cases of geometry
// 1. lower left concave corner
//         ###| 
//         ###|
//         ###|### 
//         ###|###
// 2. lower left convex corner
//            |###          
//            |###         
//            |            
//            |     
// In case 1 there may be a hole propigated up from the bottom.  If the fracture option is enabled
// the two active tails that form the filament fracture line edges can become the new active tail pair
// by pushing x and y onto them.  Otherwise the hole simply needs to be associated to one of the new active tails
// with add hole
inline std::pair<ActiveTail*, ActiveTail*> createActiveTailsAsPair(Unit x, Unit y, bool solid, ActiveTail* phole, bool fractureHoles) {
  ActiveTail* at1;
  ActiveTail* at2;
  if(!phole || !fractureHoles){
    at1 = createActiveTail();
    at2 = createActiveTail();
    (*at1) = ActiveTail(VERTICAL, x, solid, at2);
    (*at2) = ActiveTail(HORIZONTAL, y, !solid, at1);
    //provide a function through activeTail class to provide this
    at1->getTail()->joinHeadToHead(*(at2->getTail()));
    if(phole) 
      at1->addHole(phole, fractureHoles); //assert fractureHoles == false
    return std::pair<ActiveTail*, ActiveTail*>(at1, at2);
  }
  //assert phole is not null
  //assert fractureHoles is true
  if(phole->getOrient() == VERTICAL) {
    at2 = phole;
  } else {
    at2 = phole->getOtherActiveTail(); //should never be executed since orientation is expected to be vertical
  }
  //assert solid == false, we should be creating a corner with solid below and to the left if there was a hole
  at1 = at2->getOtherActiveTail();
  //assert at1 is horizontal
  at1->pushCoordinate(x);
  //assert at2 is vertical
  at2->pushCoordinate(y);
  return std::pair<ActiveTail*, ActiveTail*>(at1, at2);
}
 
//Process edges connects vertical input edges (right or left edges of figures) to horizontal edges stored as member
//data of the scanline object.  It also creates now horizontal edges as needed to construct figures from edge data.
//
//There are only 12 geometric end cases where the scanline intersects a horizontal edge and even fewer unique 
//actions to take:
// 1. Solid on both sides of the vertical partition after the current position and space on both sides before
//         ###|###          
//         ###|###         
//            |            
//            |            
//    This case does not need to be handled because there is no vertical edge at the current x coordinate.
//
// 2. Solid on both sides of the vertical partition before the current position and space on both sides after
//            |            
//            |            
//         ###|###          
//         ###|###         
//    This case does not need to be handled because there is no vertical edge at the current x coordinate.
//
// 3. Solid on the left of the vertical partition after the current position and space elsewhere
//         ###|          
//         ###|         
//            |            
//            |     
//    The horizontal edge from the left is found and turns upward because of the vertical right edge to become
//    the currently active vertical edge.
//
// 4. Solid on the left of the vertical partion before the current position and space elsewhere
//            |            
//            |            
//         ###| 
//         ###|
//    The horizontal edge from the left is found and joined to the currently active vertical edge.
//
// 5. Solid to the right above and below and solid to the left above current position.
//         ###|###          
//         ###|###         
//            |###            
//            |###            
//    The horizontal edge from the left is found and joined to the currently active vertical edge,
//    potentially closing a hole.
//
// 6. Solid on the left of the vertical partion before the current position and solid to the right above and below
//            |###
//            |###            
//         ###|### 
//         ###|###
//    The horizontal edge from the left is found and turns upward because of the vertical right edge to become
//    the currently active vertical edge.
//
// 7. Solid on the right of the vertical partition after the current position and space elsewhere
//            |###          
//            |###         
//            |            
//            |     
//    Create two new ActiveTails, one is added to the horizontal edges and the other becomes the vertical currentTail
//
// 8. Solid on the right of the vertical partion before the current position and space elsewhere
//            |            
//            |            
//            |### 
//            |###
//    The currentTail vertical edge turns right and is added to the horizontal edges data
//
// 9. Solid to the right above and solid to the left above and below current position.
//         ###|###          
//         ###|###         
//         ###| 
//         ###|
//    The currentTail vertical edge turns right and is added to the horizontal edges data
//
// 10. Solid on the left of the vertical partion above and below the current position and solid to the right below
//         ###| 
//         ###|
//         ###|### 
//         ###|###
//    Create two new ActiveTails, one is added to the horizontal edges data and the other becomes the vertical currentTail
//
// 11. Solid to the right above and solid to the left below current position.
//            |### 
//            |###
//         ###| 
//         ###|
//    The currentTail vertical edge joins the horizontal edge from the left (may close a polygon)
//    Create two new ActiveTails, one is added to the horizontal edges data and the other becomes the vertical currentTail
//
// 12. Solid on the left of the vertical partion above the current position and solid to the right below
//         ###| 
//         ###|
//            |### 
//            |###
//    The currentTail vertical edge turns right and is added to the horizontal edges data.
//    The horizontal edge from the left turns upward and becomes the currentTail vertical edge
//
/*
inline void ScanLineToPolygons::processEdges(UnitVector& outBufferTmp, Unit currentX, 
                                             std::vector<Interval>& leftEdges, std::vector<Interval>& rightEdges) 
{
  std::map<Unit, ActiveTail*>::iterator nextMapItr = tailMap.begin();
  //foreach edge
  unsigned int leftIndex = 0;
  unsigned int rightIndex = 0;
  bool bottomAlreadyProcessed = false;
  ActiveTail* currentTail = 0;
  bool holePassThrough = false;
  while(leftIndex < leftEdges.size() || rightIndex < rightEdges.size()) {
    Interval edges[2] = {Interval(UnitMax, UnitMax), Interval(UnitMax, UnitMax)};
    if(leftIndex < leftEdges.size())
      edges[0] = leftEdges[leftIndex];
    if(rightIndex < rightEdges.size())
      edges[1] = rightEdges[rightIndex];
    bool trailingEdge = edges[1].get(LOW) < edges[0].get(LOW);
    Interval& edge = edges[trailingEdge];
    Interval& nextEdge = edges[!trailingEdge];
    //process this edge
    if(!bottomAlreadyProcessed) {
      //assert currentTail = 0 || holePassThrough == true

      //process the bottom end of this edge
      std::map<Unit, ActiveTail*>::iterator thisMapItr = findAtNext(tailMap, nextMapItr, edge.get(LOW));
      if(thisMapItr != tailMap.end()) {
        //there is an edge in the map at the low end of this edge
        //it needs to turn upward and become the current tail
        ActiveTail* tail = thisMapItr->second;
        if(currentTail) {
          //assert holePassThrough == true
          //stitch currentTail into this tail
          currentTail = tail->addHole(currentTail, fractureHoles_);
          holePassThrough = false;
          if(!fractureHoles_)
            currentTail->pushCoordinate(currentX);
        } else {
          currentTail = tail;
          currentTail->pushCoordinate(currentX);
        }
        //assert currentTail->getOrient() == VERTICAL
        nextMapItr = thisMapItr; //set nextMapItr to the next position after this one
        ++nextMapItr;
        //remove thisMapItr from the map
        tailMap.erase(thisMapItr);
      } else {
        //there is no edge in the map at the low end of this edge
        //we need to create one and another one to be the current vertical tail
        //if this is a trailing edge then there is space to the right of the vertical edge
        //so pass the inverse of trailingEdge to indicate solid to the right
        std::pair<ActiveTail*, ActiveTail*> tailPair = 
          createActiveTailsAsPair(currentX, edge.get(LOW), !trailingEdge, currentTail, fractureHoles_);
        currentTail = tailPair.first;
        tailMap.insert(nextMapItr, std::pair<Unit, ActiveTail*>(edge.get(LOW), tailPair.second));
        // leave nextMapItr unchanged
      }

    }
    if(edge.get(HIGH) == nextEdge.get(LOW)) {
      //the top of this edge is equal to the bottom of the next edge, process them both
      bottomAlreadyProcessed = true;
      std::map<Unit, ActiveTail*>::iterator thisMapItr = findAtNext(tailMap, nextMapItr, edge.get(HIGH));
      if(thisMapItr == tailMap.end()) //assert this should never happen
        return;
      if(trailingEdge) {
        //geometry at this position
        //   |##
        //   |##
        // -----
        // ##|
        // ##|
        //current tail should join thisMapItr tail
        ActiveTail* tail = thisMapItr->second;
        //pass false because they are being joined because space is to the right and it will close a solid figure
        ActiveTail::joinChains(currentTail, tail, false, outBufferTmp);
        //two new tails are created, the vertical becomes current tail, the horizontal becomes thisMapItr tail
        //pass true becuase they are created at the lower left corner of some solid
        //pass null because there is no hole pointer possible
        std::pair<ActiveTail*, ActiveTail*> tailPair = 
          createActiveTailsAsPair(currentX, edge.get(HIGH), true, 0, fractureHoles_);
        currentTail = tailPair.first;
        thisMapItr->second = tailPair.second;
      } else {
        //geometry at this position
        // ##|
        // ##|
        // -----
        //   |##
        //   |##
        //current tail should turn right
        currentTail->pushCoordinate(edge.get(HIGH));
        //thisMapItr tail should turn up
        thisMapItr->second->pushCoordinate(currentX);
        //thisMapItr tail becomes current tail and current tail becomes thisMapItr tail
        std::swap(currentTail, thisMapItr->second);
      }
      nextMapItr = thisMapItr; //set nextMapItr to the next position after this one
      ++nextMapItr;
    } else {
      //there is a gap between the top of this edge and the bottom of the next, process the top of this edge
      bottomAlreadyProcessed = false;
      //process the top of this edge
      std::map<Unit, ActiveTail*>::iterator thisMapItr = findAtNext(tailMap, nextMapItr, edge.get(HIGH));
      if(thisMapItr != tailMap.end()) {
        //thisMapItr is pointing to a horizontal edge in the map at the top of this vertical edge
        //we need to join them and potentially close a figure
        //assert currentTail != 0
        //assert holePassThrough = false
        ActiveTail* tail = thisMapItr->second;
        //pass the opositve of trailing edge to mean that they are joined because of solid to the right
        currentTail = ActiveTail::joinChains(currentTail, tail, !trailingEdge, outBufferTmp);
        nextMapItr = thisMapItr; //set nextMapItr to the next position after this one
        ++nextMapItr;
        if(currentTail) {
          Unit nextItrY = UnitMax;
          if(nextMapItr != tailMap.end()) {
            nextItrY = nextMapItr->first;
          }
          //for it to be a hole this must have been a left edge
          Unit leftY = UnitMax;
          if(leftIndex + 1 < leftEdges.size())
            leftY = leftEdges[leftIndex+1].get(LOW);
          Unit rightY = nextEdge.get(LOW);
          if(nextItrY < leftY && nextItrY < rightY) {
            //we need to add it to the next edge above it in the map
            tail = nextMapItr->second;
            tail = tail->addHole(currentTail, fractureHoles_);
            if(fractureHoles_) {
              //some small additional work stitching in the filament
              tail->pushCoordinate(nextItrY);
              nextMapItr->second = tail;
            }
            //set current tail to null
            currentTail = 0;
          }
        }  
        //delete thisMapItr from the map
        tailMap.erase(thisMapItr);
      } else {
        //currentTail must turn right and be added into the map
        currentTail->pushCoordinate(edge.get(HIGH));
        //assert currentTail->getOrient() == HORIZONTAL
        tailMap.insert(nextMapItr, std::pair<Unit, ActiveTail*>(edge.get(HIGH), currentTail));
        //set currentTail to null
        currentTail = 0;
        //leave nextMapItr unchanged, it is still next
      }
    }
 
    //increment index
    leftIndex += !trailingEdge;
    rightIndex += trailingEdge;
  } //end while
      
} //end function
*/
template <bool orientT>
inline void ScanLineToPolygonItrs<orientT>::
processEdges(iterator& beginOutput, iterator& endOutput, 
             Unit currentX, std::vector<Interval>& leftEdges, 
             std::vector<Interval>& rightEdges) {
  clearOutput_();
  std::map<Unit, ActiveTail*>::iterator nextMapItr = tailMap_.begin();
  //foreach edge
  unsigned int leftIndex = 0;
  unsigned int rightIndex = 0;
  bool bottomAlreadyProcessed = false;
  ActiveTail* currentTail = 0;
  bool holePassThrough = false;
  while(leftIndex < leftEdges.size() || rightIndex < rightEdges.size()) {
    Interval edges[2] = {Interval(UnitMax, UnitMax), Interval(UnitMax, UnitMax)};
    bool haveNextEdge = true;
    if(leftIndex < leftEdges.size())
      edges[0] = leftEdges[leftIndex];
    else
      haveNextEdge = false;
    if(rightIndex < rightEdges.size())
      edges[1] = rightEdges[rightIndex];
    else
      haveNextEdge = false;
    bool trailingEdge = edges[1].get(LOW) < edges[0].get(LOW);
    Interval& edge = edges[trailingEdge];
    Interval& nextEdge = edges[!trailingEdge];
    //process this edge
    if(!bottomAlreadyProcessed) {
      //assert currentTail = 0 || holePassThrough == true

      //process the bottom end of this edge
      std::map<Unit, ActiveTail*>::iterator thisMapItr = findAtNext(tailMap_, nextMapItr, edge.get(LOW));
      if(thisMapItr != tailMap_.end()) {
        //there is an edge in the map at the low end of this edge
        //it needs to turn upward and become the current tail
        ActiveTail* tail = thisMapItr->second;
        if(currentTail) {
          //assert holePassThrough == true
          //stitch currentTail into this tail
          currentTail = tail->addHole(currentTail, fractureHoles_);
          holePassThrough = false;
          if(!fractureHoles_)
            currentTail->pushCoordinate(currentX);
        } else {
          currentTail = tail;
          currentTail->pushCoordinate(currentX);
        }
        //assert currentTail->getOrient() == VERTICAL
        nextMapItr = thisMapItr; //set nextMapItr to the next position after this one
        ++nextMapItr;
        //remove thisMapItr from the map
        tailMap_.erase(thisMapItr);
      } else {
        //there is no edge in the map at the low end of this edge
        //we need to create one and another one to be the current vertical tail
        //if this is a trailing edge then there is space to the right of the vertical edge
        //so pass the inverse of trailingEdge to indicate solid to the right
        std::pair<ActiveTail*, ActiveTail*> tailPair = 
          createActiveTailsAsPair(currentX, edge.get(LOW), !trailingEdge, currentTail, fractureHoles_);
        currentTail = tailPair.first;
        tailMap_.insert(nextMapItr, std::pair<Unit, ActiveTail*>(edge.get(LOW), tailPair.second));
        // leave nextMapItr unchanged
      }

    }
    if(haveNextEdge && edge.get(HIGH) == nextEdge.get(LOW)) {
      //the top of this edge is equal to the bottom of the next edge, process them both
      bottomAlreadyProcessed = true;
      std::map<Unit, ActiveTail*>::iterator thisMapItr = findAtNext(tailMap_, nextMapItr, edge.get(HIGH));
      if(thisMapItr == tailMap_.end()) //assert this should never happen
        return;
      if(trailingEdge) {
        //geometry at this position
        //   |##
        //   |##
        // -----
        // ##|
        // ##|
        //current tail should join thisMapItr tail
        ActiveTail* tail = thisMapItr->second;
        //pass false because they are being joined because space is to the right and it will close a solid figure
        ActiveTail::joinChains(currentTail, tail, false, outputPolygons_);
        //two new tails are created, the vertical becomes current tail, the horizontal becomes thisMapItr tail
        //pass true becuase they are created at the lower left corner of some solid
        //pass null because there is no hole pointer possible
        std::pair<ActiveTail*, ActiveTail*> tailPair = 
          createActiveTailsAsPair(currentX, edge.get(HIGH), true, 0, fractureHoles_);
        currentTail = tailPair.first;
        thisMapItr->second = tailPair.second;
      } else {
        //geometry at this position
        // ##|
        // ##|
        // -----
        //   |##
        //   |##
        //current tail should turn right
        currentTail->pushCoordinate(edge.get(HIGH));
        //thisMapItr tail should turn up
        thisMapItr->second->pushCoordinate(currentX);
        //thisMapItr tail becomes current tail and current tail becomes thisMapItr tail
        std::swap(currentTail, thisMapItr->second);
      }
      nextMapItr = thisMapItr; //set nextMapItr to the next position after this one
      ++nextMapItr;
    } else {
      //there is a gap between the top of this edge and the bottom of the next, process the top of this edge
      bottomAlreadyProcessed = false;
      //process the top of this edge
      std::map<Unit, ActiveTail*>::iterator thisMapItr = findAtNext(tailMap_, nextMapItr, edge.get(HIGH));
      if(thisMapItr != tailMap_.end()) {
        //thisMapItr is pointing to a horizontal edge in the map at the top of this vertical edge
        //we need to join them and potentially close a figure
        //assert currentTail != 0
        //assert holePassThrough = false
        ActiveTail* tail = thisMapItr->second;
        //pass the opositve of trailing edge to mean that they are joined because of solid to the right
        currentTail = ActiveTail::joinChains(currentTail, tail, !trailingEdge, outputPolygons_);
        nextMapItr = thisMapItr; //set nextMapItr to the next position after this one
        ++nextMapItr;
        if(currentTail) {
          Unit nextItrY = UnitMax;
          if(nextMapItr != tailMap_.end()) {
            nextItrY = nextMapItr->first;
          }
          //for it to be a hole this must have been a left edge
          Unit leftY = UnitMax;
          if(leftIndex + 1 < leftEdges.size())
            leftY = leftEdges[leftIndex+1].get(LOW);
          Unit rightY = nextEdge.get(LOW);
          if(!haveNextEdge || (nextItrY < leftY && nextItrY < rightY)) {
            //we need to add it to the next edge above it in the map
            tail = nextMapItr->second;
            tail = tail->addHole(currentTail, fractureHoles_);
            if(fractureHoles_) {
              //some small additional work stitching in the filament
              tail->pushCoordinate(nextItrY);
              nextMapItr->second = tail;
            }
            //set current tail to null
            currentTail = 0;
          }
        }  
        //delete thisMapItr from the map
        tailMap_.erase(thisMapItr);
      } else {
        //currentTail must turn right and be added into the map
        currentTail->pushCoordinate(edge.get(HIGH));
        //assert currentTail->getOrient() == HORIZONTAL
        tailMap_.insert(nextMapItr, std::pair<Unit, ActiveTail*>(edge.get(HIGH), currentTail));
        //set currentTail to null
        currentTail = 0;
        //leave nextMapItr unchanged, it is still next
      }
    }
 
    //increment index
    leftIndex += !trailingEdge;
    rightIndex += trailingEdge;
  } //end while
  beginOutput = outputPolygons_.begin();
  endOutput = outputPolygons_.end();
} //end function

template<bool orientT>
inline void ScanLineToPolygonItrs<orientT>::clearOutput_() {
   for(unsigned int i = 0; i < outputPolygons_.size(); ++i) {
      ActiveTail* at1 = outputPolygons_[i].yield();
      const std::list<ActiveTail*>& holes = at1->getHoles();
      for(std::list<ActiveTail*>::const_iterator litr = holes.begin(); litr != holes.end(); ++litr) {
        //delete the hole
        (*litr)->destroyContents();
        destroyActiveTail((*litr)->getOtherActiveTail());
        destroyActiveTail((*litr));
      }
      //delete the polygon
      at1->destroyContents();
      //at2 contents are the same as at1, so it should not destroy them
      destroyActiveTail((at1)->getOtherActiveTail());
      destroyActiveTail(at1);
   }
   outputPolygons_.clear();
}
