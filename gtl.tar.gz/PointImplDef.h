/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T, class T2>
class lessPoint
  : public std::binary_function<const PointImpl<T>&, const PointImpl<T2>&, bool>
{
private:
  AxisTransform atr_; // we want to compare along this orientation
public:
  inline lessPoint() {;} // allow data member to take default value
  inline lessPoint(AxisTransform atr) : atr_(atr) {;}
  inline lessPoint(Direction2D dir) : atr_(dir) {;}
  inline lessPoint(Orientation2D orient) : atr_(orient) {;}
  inline bool operator () (const PointImpl<T>& a,
                           const PointImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessPoint<T, T2>::operator () (const PointImpl<T>& a,
                               const PointImpl<T2>& b) const {
  PointImpl<T> a_(a);
  PointImpl<T2> b_(b);
  atr_.transform2D (a_);
  atr_.transform2D (b_);
  return a_ < b_;
}
  
template<class T> template <class T2>
inline bool 
PointImpl<T>::operator<(const PointImpl<T2>& b) const {
  return (y() < b.y()) | ((y() == b.y()) & (x() < b.x()));
}

template <class T> template <class T2>
PointImpl<T>::PointImpl(const PointImpl<T2>& that) {
  *this = that;
}

template<class T> template<class T2>
const PointImpl<T>& 
PointImpl<T>::operator=(const PointImpl<T2>& that) {
  x(that.x());
  y(that.y());
  return *this;
}

template<class T> 
const PointImpl<T>& 
PointImpl<T>::operator=(const PointImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T>
const PointImpl<T>& 
PointImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T> template <class T2>
inline bool 
PointImpl<T>::operator==(const PointImpl<T2>& b) const {
  return (x() == b.x()) & (y() == b.y());
}

template<class T> template <class T2>
inline bool 
PointImpl<T>::operator!=(const PointImpl<T2>& b) const {
  //apply Demorgans theorem in case compiler doesn't
  return (x() != b.x()) | (y() != b.y());
}

template<class T>
inline bool 
PointImpl<T>::isValid(void) const {
  return (x() != std::numeric_limits<Unit>::min() || y() != std::numeric_limits<Unit>::min());
}

template<class T> template <class T2>
inline PointImpl<T>& 
PointImpl<T>::operator+=(const PointImpl<T2>& p) {
  x(x() + p.x());
  y(y() + p.y());
  return *this;
}
    
template<class T> template <class T2>
inline PointImpl<T> 
PointImpl<T>::operator+(const PointImpl<T2>& p) const {
  PointImpl retval(*this);
  return retval+=p;
}
     
template<class T> template <class T2>
inline PointImpl<T>& 
PointImpl<T>::operator-=(const PointImpl<T2>& p){
  x(x() - p.x());
  y(y() - p.y());
  return *this;
}
    
template<class T> template <class T2>
inline PointImpl<T> 
PointImpl<T>::operator-(const PointImpl<T2>& p) const {
  PointImpl retval(*this);
  return retval-=p;
}

template<class T>
inline PointImpl<T>& 
PointImpl<T>::set(Orientation2D orient, Unit value) {
  set_(orient, value); return *this;
}

template<class T> template <class T2>
inline PointImpl<T>& 
PointImpl<T>::convolve(const PointImpl<T2>& p) {
  return *this += p;
}

template<class T> template <class T2>
inline PointImpl<T>& 
PointImpl<T>::deconvolve(const PointImpl<T2>& p) {
  return *this -= p;
}

template<class T>
inline PointImpl<T>& 
PointImpl<T>::transform(const AxisTransform& atr) {
  Unit coords[2] = {x(), y()};
  atr.transform2D(coords[0], coords[1]);
  x(coords[0]);
  y(coords[1]);
  return *this;
}
    
template<class T>
inline PointImpl<T>& 
PointImpl<T>::transform(const Transform& tr) {
  Unit coords[2] = {x(), y()};
  tr.transform2D(coords[0], coords[1]);
  x(coords[0]);
  y(coords[1]);
  return *this;
}

template<class T>
inline PointImpl<T>& 
PointImpl<T>::scaleUp(UnsignedUnit factor) {
  Unit coords[2] = {x(), y()};
  coords[0] *= (Unit)factor;
  coords[1] *= (Unit)factor;
  x(coords[0]);
  y(coords[1]);
  return *this;
}

template<class T>
inline PointImpl<T>& 
PointImpl<T>::scaleDown(UnsignedUnit factor) {
  double coords[2] = {x(), y()};
  coords[0] /= (double)factor;
  coords[1] /= (double)factor;
  x((Unit)lround(coords[0]));
  y((Unit)lround(coords[1]));
  return *this;
}

template<class T> template <class T2>
inline UnsignedUnit 
PointImpl<T>::distance(const PointImpl<T2>& p, 
                       Orientation2D orient) const {
  UnsignedUnit d = abs(get(orient)-p.get(orient));
  return d;
}

template<class T> template <class T2>
inline UnsignedUnit 
PointImpl<T>::manhattanDistance(const PointImpl<T2>& p) const {
  return distance(p, HORIZONTAL) +
    distance(p, VERTICAL);
}

template<class T> template <class T2>
inline UnsignedLongUnit 
PointImpl<T>::squareEuclidianDistance(const PointImpl<T2>& p) const {
  UnsignedUnit xd = distance(p, HORIZONTAL);
  UnsignedUnit yd = distance(p, VERTICAL);
  return ((UnsignedLongUnit)xd)*xd + ((UnsignedLongUnit)yd)*yd;
}

template<class T> template <class T2>
inline double 
PointImpl<T>::euclidianDistance(const PointImpl<T2>& p) const {
  return sqrt((double)squareEuclidianDistance(p));
} 

/// set dir to the direction that p is from 'this' point
/// if p has no coordinate in common with this, return false
/// and leave dir unchanged
template<class T> template <class T2>
inline bool 
PointImpl<T>::toward(const PointImpl<T2>& p, Direction2D& dir) const {
  Direction2D dira[2][2] = {{WEST,
                             EAST},
                            {SOUTH,
                             NORTH}};
  bool cond1 = x()==p.x();
  bool cond2 = y()==p.y();
  bool index2[2] = {y() < p.y(), x() < p.x()};
  bool retval = cond1^cond2;
  dir = predicated_value(retval, dira[cond1][index2[cond1]], 
                         (Direction2D)(dir));
  return retval;
}
    
template<class T> template <class T2>
inline bool 
PointImpl<T>::aligned(const PointImpl<T2>& p, 
                      Orientation2D orient) const {
  return get(orient.getPerpendicular()) == p.get(orient.getPerpendicular());
}

/// returns true if they are aligned and p is in direction dir from 'this' 
/// if considerTouch is true return true if they are equal
template<class T> template <class T2>
inline bool 
PointImpl<T>::alignedAndToward(const PointImpl<T2>& p, 
                               Direction2D dir, 
                               bool considerTouch) const {
  Direction2D towardDir;
  bool towardResult = toward(p, towardDir);
  if((towardResult & dir == towardDir) | 
     ((*this) == p & considerTouch)){
    return aligned(p, Orientation2D(dir));
  }
  return false;
}

template<class T> template <class T2, class T3>
inline int 
PointImpl<T>::crossProduct(const PointImpl<T2>& p1, 
                           const PointImpl<T3>& p2) const {
  double r1 = p1.distance(*this, HORIZONTAL);
  r1 *= p2.distance(*this, VERTICAL);
  double r2 = p2.distance(*this, HORIZONTAL);
  r2 *= p1.distance(*this, VERTICAL);
  return predicated_value((r1 > r2), -1, 1);
}

template<class T> template <class T2, class T3>
inline bool 
PointImpl<T>::between(const PointImpl<T2>& p1, const PointImpl<T3>& p2) const {
  return (equivalent(p1.x(), x(), p2.x()) & 
          (inOrder(p1.y(), y(), p2.y()) | inOrder(p2.y(), y(), p1.y()))) | 
    (equivalent(p1.y(), y(), p2.y()) & 
     (inOrder(p1.x(), x(), p2.x()) | inOrder(p2.x(), x(), p1.x())));
}

template <class T>
std::ostream& operator << (std::ostream& o, const PointImpl<T>& p)
{
  return o << p.x() << GTL_SEP << p.y();
}

template <class T>
std::istream& operator >> (std::istream& i, PointImpl<T>& p)
{
  Unit x, y;
  i >> x >> y;
  p.x(x); p.y(y);
  return i;
}

