/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T, class T2>
class lessPoint3D
  : public std::binary_function<const Point3DImpl<T>&, const Point3DImpl<T2>&, bool>
{
private:
  AxisTransform atr_; // we want to compare along this orientation
public:
  inline lessPoint3D() {;} // allow data member to take default value
  inline lessPoint3D(AxisTransform atr) : atr_(atr) {;}
  inline lessPoint3D(Direction3D dir) : atr_(dir) {;}
  inline lessPoint3D(Orientation3D orient) : atr_(orient) {;}
  inline bool operator () (const Point3DImpl<T>& a,
                           const Point3DImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessPoint3D<T, T2>::operator () (const Point3DImpl<T>& a,
                                 const Point3DImpl<T2>& b) const {
  Point3DImpl<T> a_(a);
  Point3DImpl<T2> b_(b);
  a_.transform(atr_);
  b_.transform(atr_);
  return a_ < b_;
}
  
template<class T> template<class T2>
inline bool 
Point3DImpl<T>::operator<(const Point3DImpl<T2>& b) const {
  return (z() < b.z()) | ((z() == b.z()) &&
                        mimicConstPoint() < b.mimicConstPoint());
}

//   template<class T> template<class T2>
//   inline const Point3DImpl<T>& 
//   Point3DImpl<T>::operator=(const Point3DImpl<T2>& that) {
//     x(that.x());
//     y(that.y());
//     z(that.z());
//     return *this;
//   }


//   template <class T> template <class T2>
//   inline Point3DImpl<T>::Point3DImpl<T>(const Point3DImpl<T2>& that) {
//     *this = that;
//   }

template<class T> template<class T2>
inline bool 
Point3DImpl<T>::operator==(const Point3DImpl<T2>& b) const {
  return (x() == b.x()) & (y() == b.y()) & (z() == b.z());
}

template<class T> template<class T2>
inline bool 
Point3DImpl<T>::operator!=(const Point3DImpl<T2>& b) const {
  //apply demorgans theorem to achieve two level logic
  return x() != b.x() | y() != b.y() | z() != b.z();
}

template<class T> template<class T2>
inline Point3DImpl<T>& 
Point3DImpl<T>::operator+=(const Point3DImpl<T2>& p){
  x(x() + p.x());
  y(y() + p.y());
  z(z() + p.z());
  return *this;
} 
    
template<class T> template<class T2>
inline Point3DImpl<T>
Point3DImpl<T>::operator+(const Point3DImpl<T2>& p) const {
  Point3DImpl retval(*this);
  return retval+=p;
}

template<class T> template<class T2>
inline Point3DImpl<T>& 
Point3DImpl<T>::operator-=(const Point3DImpl<T2>& p){
  x(x() - p.x());
  y(y() - p.y());
  z(z() - p.z());
  return *this;
}
    
template<class T> template<class T2>
inline Point3DImpl<T>
Point3DImpl<T>::operator-(const Point3DImpl<T2>& p) const {
  Point3DImpl retval(*this);
  return retval-=p;
}

template<class T>
inline
Point3DImpl<T>::operator PointImpl<PointData>() const {
  return PointImpl<PointData>(x(), y());
}

template<class T> template<class T2>
inline Point3DImpl<T>&
Point3DImpl<T>::convolve(const Point3DImpl<T2>& p) {
  return *this += p;
}

template<class T> template<class T2>
inline Point3DImpl<T>&
Point3DImpl<T>::deconvolve(const Point3DImpl<T2>& p) {
  return *this -= p;
}

template<class T>
inline PointImpl<T>& 
Point3DImpl<T>::mimicPoint() {
  return reinterpret_cast<PointImpl<T>&>(yield());
}

template<class T>
inline const PointImpl<T>& 
Point3DImpl<T>::mimicConstPoint() const {
  return reinterpret_cast<const PointImpl<T>&>(yieldConst());
}

//   template<class T>
//   inline void 
//   Point3DImpl<T>::set(Orientation3D orient, Unit value) {
//     set_(orient, value);
//   }

template<class T>
inline Point3DImpl<T>& 
Point3DImpl<T>::transform(const AxisTransform& atr) {
  Unit coords[3] = {x(), y(), z()};
  atr.transform(coords[0], coords[1], coords[2]);
  x(coords[0]);
  y(coords[1]);
  z(coords[2]);
  return *this;
}
    
template<class T>
inline Point3DImpl<T>& 
Point3DImpl<T>::transform(const Transform& tr) {
  Unit coords[3] = {x(), y(), z()};
  tr.transform(coords[0], coords[1], coords[2]);
  x(coords[0]);
  y(coords[1]);
  z(coords[2]);
  return *this;
}

template<class T>
inline Point3DImpl<T>& 
Point3DImpl<T>::go(Direction3D dir, Unit dist) {
  return set(static_cast<Orientation3D>(dir), get(static_cast<Orientation3D>(dir)) + dist * dir.getSign());
}

template<class T> template<class T2>
inline UnsignedUnit 
Point3DImpl<T>::distance(const Point3DImpl<T2>& p, Orientation3D orient) const {
  UnsignedUnit d = abs(get(orient)-p.get(orient));
  return d;
}

template<class T> template<class T2>
inline UnsignedLongUnit 
Point3DImpl<T>::manhattanDistance(const Point3DImpl<T2>& p) const {
  return ((UnsignedLongUnit)distance(p, HORIZONTAL)) +
    distance(p, VERTICAL) +
    distance(p, PROXIMAL);
}

template<class T> template<class T2>
inline double 
Point3DImpl<T>::euclidianDistance(const Point3DImpl<T2>& p) const {
  UnsignedUnit xd = distance(p, HORIZONTAL);
  UnsignedUnit yd = distance(p, VERTICAL);
  UnsignedUnit zd = distance(p, PROXIMAL);
  double planard = sqrt(((double)xd)*xd + ((double)yd)*yd);
  return sqrt(planard * planard + ((double)zd)*zd);
} 

/// if 'this' and p are colinear, set dir to the direction from
/// 'this' to p, else return false and leave dir unchanged
template<class T> template<class T2>
inline bool 
Point3DImpl<T>::toward(const Point3DImpl<T2>& p, Direction3D& dir) const {
  Direction3D dira[3][2] = {{DOWN,
                             UP},
                            {SOUTH,
                             NORTH},
                            {WEST,
                             EAST}};
  int cond1 = x()==p.x();
  int cond2 = y()==p.y();
  int cond3 = z()==p.z();
  bool index2[3] = {z() < p.z(), y() < p.y(), x() < p.x()};
  int index1 = -1;
  index1 += cond2;
  index1 += cond3 << 1;
  //if cond1 and cond2 index1 equals 0
  //if cond1 and cond3 index1 equals 1
  //if cond2 and cond3 index1 equals 2
  //any other condition is don't care
  //return true if and only if 2 out of 3 conditions are valid
  bool retval = (cond1 + cond2 + cond3 == 2);
  dir = predicated_value(retval, dira[index1][index2[index1]], dir);
  return retval;
}
    
/// return true if 'this' and p differ only in the coordinate
/// corresponding to orient
template<class T> template<class T2>
inline bool 
Point3DImpl<T>::aligned(const Point3DImpl<T2>& p, Orientation3D orient) const {
  bool xe = x() == p.x();
  bool ye = y() == p.y();
  bool ze = z() == p.z();
  bool a[3] = {ye & ze, xe & ze, xe & ye};
  return a[orient.toInt()];
}

/// return true if 'this' and p are aligned on the orientation cooresponding
/// to dir and p is in dir direction from 'this', if considerTouch is true
/// return true in the case that they are equal
template<class T> template<class T2>
inline bool 
Point3DImpl<T>::alignedAndToward(const Point3DImpl<T2>& p, 
                                 Direction3D dir, 
                                 bool considerTouch) const {
  Direction3D towardDir;
  bool towardResult = toward(p, towardDir);
  if((towardResult & dir == towardDir) | 
     ((*this) == p & considerTouch)){
    return aligned(p, Orientation3D(dir));
  }
  return false;
}

template<class T> template<class T2, class T3>
inline bool 
Point3DImpl<T>::between(const Point3DImpl<T2>& p1, 
                        const Point3DImpl<T3>& p2) const {
  Direction3D d1, d2;
  bool towards = toward(p1, d1) & toward(p2, d2);
  return predicated_value(towards, d1 == d2.backward(), false);
}

template <class T>
std::ostream& operator << (std::ostream& o, const Point3DImpl<T>& p)
{
  return o << p.x() << GTL_SEP << p.y() << GTL_SEP << p.z();
}

template <class T>
std::istream& operator >> (std::istream& i, Point3DImpl<T>& p)
{
  Unit x, y, z;
  i >> x >> y >> z;
  p.x(x); p.y(y); p.z(z);
  return i;
}

