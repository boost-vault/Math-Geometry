// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <cassert>

// Boost.Geom
#include <boost/geom/point.hpp>
#include <boost/geom/point_xyz.hpp>
// Including std_complex.hpp gives std::complex<> ``point interface''
#include <boost/geom/std_complex.hpp>

// Handy IOStream overload that permits to output points, easily
template<class Char, class Traits, class PointImpl>
std::basic_ostream<Char, Traits>&
operator<<(std::basic_ostream<Char, Traits>& os, const boost::geom::point<PointImpl>& pt)
{ return os<<'('<<pt.x()<<','<<pt.y()<<','<<pt.z()<<')'; }

int main()
{
	// This implementation object is a point with X,Y
	// and Z properties represented as doubles
	typedef boost::geom::point_xyz<double> point_xyz;

	// This implementation object is a point with X,Y
	// Z properties represented as doubles. But it doesn't
	// actually reserve space for a Z attribute, because the Z of
	// point_xy is always zero.
	typedef boost::geom::point_xy<double> point_xy;

	typedef boost::geom::point<point_xyz> point3D;
	typedef boost::geom::point<point_xy> point2D;

	// The origine (X: 0, Y: 0, Z: 0)
	const point3D origin=point_xyz(0, 0, 0);
	std::cout<<origin<<std::endl;

	std::cout<<origin.rho()<<std::endl; // Gives zero !
	
	// std::polar() gets you an std::complex<>, which has point
	// interface (<boost/geom/std_complex.hpp>), hence the
	// initialization.
	//
	point3D pt=std::polar(3.4, 3.141592654);

	// Note that complex numbers are always on the Z=0 plan
	assert(pt.z()==0);
	std::cout<<pt<<std::endl; // Should give ~ (-3.4,0,0)

	point2D pt2=point_xy(3, 5);

	// Here pt is a point3D, and pt2 is point2D which is the same
	// thing except that a point2D don't need to store its Z. Thus
	// this operation will affect only the X and Y of pt;
	pt+=pt2;
	std::cout<<pt<<' '<<pt2<<std::endl;

	// Make pt ``turn'' around the z'Oz line, by an angle of PI/2
	std::cout<<"Before turning pt:"<<pt<<" rho(pt):"<<pt.rho()<<std::endl;
	pt.theta()+=3.141592654/2;
	std::cout<<"After turning pt:"<<pt<<" rho(pt):"<<pt.rho()<<std::endl;
	
	// A point that is implemented using an std::complex<>
	boost::geom::point< std::complex<float> > pt_cplx;

	// And still able to pass the std::complex<> that is inside
	// pt_cplx to some standard function (impl() is zero cost)
	std::cout<<std::abs(pt_cplx.impl())<<std::endl;
}


