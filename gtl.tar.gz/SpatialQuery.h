

template <class T>
class SpatialQuery {
public:
  typedef T DataType;
  typedef typename query::QTOLD<T>::FPtr DataPointer;

  template <class T2>
  explicit SpatialQuery(const RectangleImpl<T2>& domain);

  SpatialQuery(const SpatialQuery& rhs);

  bool empty() const;

  void insert(const DataPointer& dataObject);

  template <class InputIterator>
  void insert(InputIterator inputBegin, InputIterator inputEnd);

  bool query(const DataPointer& dataObject) const;

  //InsertIterator is an insertion iterator of type DataPointer
  template <class InsertIterator, class T2>
  void query(InsertIterator i, const RectangleImpl<T2>& queryRegion, 
             bool considerTouch = true) const;

  template <class T2>
  void query(std::vector<DataPointer>& outputObjects, 
             const RectangleImpl<T2>& queryRegion, 
             bool considerTouch = true) const;

  // remove the data pointer from the query tree (if it exists)
  void remove(const DataPointer& dataObject);

  // removes fruits that are in queryRegion
  // appends their pointers to removedFruits list
  template <class InsertIterator, class T2>
  void remove(InsertIterator removedObjects, 
              const RectangleImpl<T2>& queryRegion, 
              bool considerTouch = true);

  template<class T2>
  void remove(std::vector<DataPointer>& removedObjects, 
              const RectangleImpl<T2>& queryRegion, 
              bool considerTouch = true);

  // removes first data pointer in queryRegion from query tree
  // does not delete it from memory
  // returns the victim or null
  template <class T2>
  DataPointer removeFirst(const RectangleImpl<T2>& queryRegion, 
                          bool considerTouch = true);

  // finds first fruit pointer in queryRegion, returns it
  // or null if nothing found
  template <class T2>
  DataPointer
  queryFirst(const RectangleImpl<T2>& queryRegion, 
             bool considerTouch = true) const;

  // reset tree to be empty (delete all memory associated with it)
  // do not reset parameters
  void clear();

  // return size of tree (number of entries in tree)
  unsigned int size() const;

private:
  typename query::QTOLD<T> qt_;
};

template <class T>
template <class T2>
inline SpatialQuery<T>::SpatialQuery(const RectangleImpl<T2>& domain) : qt_(domain) {}

template <class T>
inline SpatialQuery<T>::SpatialQuery(const SpatialQuery& rhs) : qt_(rhs) {}

template <class T>
inline bool SpatialQuery<T>::empty() const { return qt_.empty(); }

template <class T>
inline void SpatialQuery<T>::insert(const DataPointer& dataObject) { qt_.insert(dataObject); }

template <class T>
template <class InputIterator>
inline void SpatialQuery<T>::insert(InputIterator inputBegin, InputIterator inputEnd) {
  while(inputBegin != inputEnd) insert(*(inputBegin++)); }

template <class T>
inline bool SpatialQuery<T>::query(const DataPointer& dataObject) const { 
  return qt_.query(dataObject); }

//InsertIterator is an insertion iterator of type DataPointer
template <class T>
template <class InsertIterator, class T2>
inline void SpatialQuery<T>::query(InsertIterator i, const RectangleImpl<T2>& queryRegion, 
           bool considerTouch) const {
  return qt_.query(i, queryRegion, considerTouch); }

template <class T>
template <class T2>
inline void SpatialQuery<T>::query(std::vector<DataPointer>& outputObjects, 
           const RectangleImpl<T2>& queryRegion, 
           bool considerTouch) const {
  return qt_.query(outputObjects, queryRegion, considerTouch); }

// remove the data pointer from the query tree (if it exists)
template <class T>
inline void SpatialQuery<T>::remove(const DataPointer& dataObject) { qt_.remove(dataObject); }

// removes fruits that are in queryRegion
// appends their pointers to removedFruits list
template <class T>
template <class InsertIterator, class T2>
inline void SpatialQuery<T>::remove(InsertIterator removedObjects, 
            const RectangleImpl<T2>& queryRegion, 
            bool considerTouch) {
  qt_.removeInBBox(removedObjects, queryRegion, considerTouch); }

template <class T>
template<class T2>
inline void SpatialQuery<T>::remove(std::vector<DataPointer>& removedObjects, 
            const RectangleImpl<T2>& queryRegion, bool considerTouch) {
  qt_.removeInBBox(removedObjects, queryRegion, considerTouch); }

// removes first data pointer in queryRegion from query tree
// does not delete it from memory
// returns the victim or null
template <class T>
template <class T2>
inline typename SpatialQuery<T>::DataPointer 
SpatialQuery<T>::removeFirst(const RectangleImpl<T2>& queryRegion, 
                             bool considerTouch) { 
  return qt_.removeFirstInBBox(queryRegion, considerTouch); }

// finds first fruit pointer in queryRegion, returns it
// or null if nothing found
template <class T>
template <class T2>
inline typename SpatialQuery<T>::DataPointer
SpatialQuery<T>::queryFirst(const RectangleImpl<T2>& queryRegion, bool considerTouch) const { 
  return qt_.findFirstInBBox(); }

// reset tree to be empty (delete all memory associated with it)
// do not reset parameters
template <class T>
inline void SpatialQuery<T>::clear() { qt_.clear(); }

// return size of tree (number of entries in tree)
template <class T>
inline unsigned int SpatialQuery<T>::size() const { return qt_.size(); }
