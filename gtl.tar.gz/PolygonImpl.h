/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

template<class T>
class PolygonWithHolesImpl;

/// PolygonImpl implements all Polygon functions on top of polygon type T

/// PolygonImpl inherits from polygon type T and accesses the data owned
/// by T through the PolygonInterface<T> class
template <class T>
class PolygonImpl : public T{
public:

  typedef typename PolygonInterface<T>::iterator iterator;

  template <class iT>
  class iteratorPointsT {
  private:
     iT iter_;
     iT iterEnd_;
     PointImpl<PointData> pt_;
     Unit firstX_;
     Orientation2D orient_;
  public:
    typedef std::forward_iterator_tag iterator_category;
    typedef PointImpl<PointData> value_type;
    typedef std::ptrdiff_t difference_type;
    typedef const value_type* pointer; //immutable
    typedef const value_type& reference; //immutable

     inline iteratorPointsT() {}
     inline iteratorPointsT(iT iter, iT iterEnd) : 
       iter_(iter), iterEnd_(iterEnd), orient_(HORIZONTAL) {
        if(iter_ != iterEnd_) {
           pt_.x(firstX_ = *iter_);
           ++iter_;
           if(iter_ != iterEnd_) {
              pt_.y(*iter_);
           }
        }
     }
     //use bitwise copy and assign provided by the compiler
     inline iteratorPointsT& operator++() {
        iT tmp = iter_++;
        if(iter_ == iterEnd_) {
           if(pt_.x() != firstX_) {
              iter_ = tmp;
              pt_.x(firstX_);
           }
        } else {
           pt_.set(orient_, *iter_);
           orient_.turn90();
        }
        return *this;
     }
     inline iteratorPointsT operator++(int) {
        iteratorPointsT tmp(*this);
        ++(*this);
        return tmp;
     }
     inline bool operator==(const iteratorPointsT& that) const {
        return (iter_ == that.iter_);
     }
     inline bool operator!=(const iteratorPointsT& that) const {
        return (iter_ != that.iter_);
     }
     inline PointImpl<PointData> operator*() { return pt_; }
  };
  typedef iteratorPointsT<iterator> iteratorPoints;

  template <class iT>
  class iterPointsToCoords {
  private:
     iT iter_;
     Orientation2D orient_;
  public:
     inline iterPointsToCoords() {}
     inline iterPointsToCoords(iT iter) : iter_(iter), orient_(HORIZONTAL) {}
     inline iterPointsToCoords(const iterPointsToCoords& that) : 
       iter_(that.iter_), orient_(that.orient_) {}
     //use bitwise copy and assign provided by the compiler
     inline iterPointsToCoords& operator++() {
        ++iter_;
        orient_.turn90();
        return *this;
     }
     inline iterPointsToCoords operator++(int) {
        iterator tmp(*this);
        ++(*this);
        return tmp;
     }
     inline bool operator==(const iterPointsToCoords& that) const {
        return (iter_ == that.iter_);
     }
     inline bool operator!=(const iterPointsToCoords& that) const {
        return (iter_ != that.iter_);
     }
     inline Unit operator*() { return (*iter_).get(orient_); }
  };

  template <class iT>
  class iteratorEdgesT {
  private:
    PointImpl<PointData> prevPt_;
    iT first_;
    iT iter_;
    iT iterEnd_;
  public:
    inline iteratorEdgesT() {}
    inline iteratorEdgesT(iT iter, iT iterEnd) : 
      first_(iter), iter_(iter), iterEnd_(iterEnd) {
      if(iter_ != iterEnd_) {
        prevPt_ = *iter_;
        ++iter_;
      }
    }
    //use bitwise copy and assign provided by the compiler
    inline iteratorEdgesT& operator++() {
      if(iter_ == first_) {
        iter_ = iterEnd_;
        return *this;
      }
      prevPt_ = *iter_;
      ++iter_;
      if(iter_ == iterEnd_) {
        if(*first_ != prevPt_) {
          iter_ = first_;
        }
      } 
      return *this;
    }
    inline iteratorEdgesT operator++(int) {
      iteratorEdges tmp(*this);
      ++(*this);
      return tmp;
    }
    inline bool operator==(const iteratorEdgesT& that) const {
      return (iter_ == that.iter_);
    }
    inline bool operator!=(const iteratorEdgesT& that) const {
      return (iter_ != that.iter_);
    }
    inline SegmentImpl<SegmentData> operator*() { 
      return SegmentImpl<SegmentData>(prevPt_, *iter_); 
    }
  };
  typedef iteratorEdgesT<iteratorPoints> iteratorEdges;
  
  /// get a reference of PolygonImpl type given a data object
  static inline PolygonImpl& mimic(T& t) { return static_cast<PolygonImpl&>(t); }

  /// get a reference of PolygonImpl type given a data object
  static inline const PolygonImpl& mimicConst(const T& t) { 
    return static_cast<const PolygonImpl&>(t); }

  /// construct a polygon from an iterator over unique x and y values
  template<class iT>
  inline PolygonImpl(iT inputBegin, iT inputEnd) { set(inputBegin, inputEnd); }

  template<class T2>
  inline PolygonImpl(const RectangleImpl<T2>& rect) {
     set(rect);
  }

  /// default constructor
  inline PolygonImpl() {}

  /// assignment operator
  template <class T2>
  inline PolygonImpl& operator=(const PolygonWithHolesImpl<T2>& that);  

  /// assignment operator
  template <class T2>
  inline PolygonImpl& operator=(const PolygonImpl<T2>& that) { 
     set(that.begin(), that.end()); return *this;}
  
  /// assignment operator
  inline PolygonImpl& operator=(const PolygonImpl<T>& that) { 
    yield() = that; return *this; }

//   /// assignment operator
//    inline PolygonImpl& operator=(const T& that) { yield() = that; return *this; }

   /// copy constructor
   template <class T2>
   inline PolygonImpl(const PolygonWithHolesImpl<T2>& that); 

   /// copy constructor
   template <class T2>
   inline PolygonImpl(const PolygonImpl<T2>& that) { set(that.begin(), that.end()); }

  /// copy constructor
  inline PolygonImpl(const T& that) : T(that) {;}

//   /// equivalence operator
//   template <class T2>
//   inline bool operator==(const PolygonImpl<T2>& b) const;

//   /// inequivalence operator
//   template <class T2>
//   inline bool operator!=(const PolygonImpl<T2>& b) const { return !(*this == b); }

  /// yield payload
  inline T& yield() { return *this; }

  /// yield const payload
  inline const T& yieldConst() const { return *this; }

//   /// check for validity
//   inline bool isValid(void) const;

  /// set with coordinates
  template<class iT>
  inline PolygonImpl& set(iT inputBegin, iT inputEnd) {
     set_(inputBegin, inputEnd);
     return *this;
  }

  template<class T2>
  inline PolygonImpl& set(const RectangleImpl<T2>& rect) {
     Unit coords[4] = {rect.xl(), rect.yl(), rect.xh(), rect.yh()};
     return set(coords, coords+4);
  }
   
   template<class iT>
   inline PolygonImpl& setPoints(iT beginPoint, iT endPoint) {
      set(iterPointsToCoords<iT>(beginPoint),
          iterPointsToCoords<iT>(endPoint));
      return *this;
   }

   inline iterator begin() const {
      return begin_();
   }

   inline iterator end() const {
      return end_();
   }

   inline iteratorPoints beginPoints() const {
      return iteratorPoints(begin(), end());
   }

   inline iteratorPoints endPoints() const {
      return iteratorPoints(end(), end());
   }

   inline iteratorEdges beginEdges() const {
      return iteratorEdges(beginPoints(), endPoints());
   }

   inline iteratorEdges endEdges() const {
      return iteratorEdges(endPoints(), endPoints());
   }

   std::size_t size() const {
      return size_();
   }

  inline Direction1D winding() const {
    WindingDirection wd = winding_();
    if(wd != WindingDirection::unknown()) {
      return predicated_value(wd == WindingDirection::clockwise(),
                              LOW, HIGH);
    }
    return point_sequence_area(beginPoints(), endPoints()) < 0 ? HIGH : LOW;
  }

//   template<class iT>
//   inline PolygonImpl& setVerticies(iT inputBegin, iT inputEnd);


   /// transform polygon
  inline PolygonImpl& transform(const AxisTransform& atr) {
    std::vector<Point> pts;
    pts.reserve(size());
    for(iteratorPoints iter = beginPoints(); iter != endPoints(); ++iter) {
      pts.push_back(*iter);
      pts.back().transform(atr);
    }
    return setPoints(pts.begin(), pts.end());
  }
    
  /// transform polygon
  inline PolygonImpl& transform(const Transform& tr) {
    std::vector<Point> pts;
    pts.reserve(size());
    for(iteratorPoints iter = beginPoints(); iter != endPoints(); ++iter) {
      pts.push_back(*iter);
      pts.back().transform(tr);
    }
    return setPoints(pts.begin(), pts.end());
  }

//   /// get the distance between 'this' and p along orientation orient
//   template <class T2>
//   inline UnsignedUnit distance(const PolygonImpl<T2>& p, 
//                                Orientation2D orient) const;

//   /// get the manhatton distance between 'this' and p 
//   template <class T2>
//   inline UnsignedUnit manhattanDistance(const PolygonImpl<T2>& p) const;

//   /// get the square equclidian distance between 'this' and p 
//   template <class T2>
//   inline UnsignedLongUnit squareEuclidianDistance(const PolygonImpl<T2>& p) const;

//   /// get the euclidian distance between 'this' and p
//   template <class T2>
//   inline double euclidianDistance(const PolygonImpl<T2>& p) const;

//   /// get the bounding box of the polygon
//   inline RectangleImpl<RectangleData> boundingBox() const;

//   /// get the magnitude of the interval range depending on orient
//   inline UnsignedUnit delta(Orientation2D orient) const;

   /// get the bounding box of the polygon
   inline Rectangle boundingBox() const {
      Unit xmin = UnitMax;
      Unit ymin = UnitMax;
      Unit xmax = UnitMin;
      Unit ymax = UnitMin;
      for(iterator itr = begin(); itr != end(); ++itr) {
         Unit x = *itr;
         ++itr;
         xmin = min(xmin, x);
         xmax = max(xmax, x);
         Unit y = *itr;
         ymin = min(ymin, y);
         ymax = max(ymax, y);
      }
      return Rectangle(xmin, ymin, xmax, ymax);
   }

   /// get the area of the polygon
   inline UnsignedLongUnit area() const {
      //for (long i = 2; i < _size; i += 2) res += ((double)_vertex[i-1])*((double)(_vertex[i-2] - _vertex[i]));
      LongUnit retval = 0;
      iterator itr = begin();
      Unit firstx = *itr;
      Unit prevx = *itr;
      ++itr;
      Unit prevy = *itr;
      ++itr;
      for( ; itr != end(); ++itr) {
         Unit x = *itr;
         ++itr;
         Unit y = *itr;
         retval += ((LongUnit)prevy * ((LongUnit)prevx -  (LongUnit)x));
         prevy = y;
         prevx = x;
      }
      retval += ((LongUnit)prevy * ((LongUnit)prevx - (LongUnit)firstx));
      return abs(retval);
   }

//   /// returns the orientation of the longer delta
//   inline Orientation2D guessOrientation(void) const;

//   /// get the perimeter of the rectangle
//   inline UnsignedLongUnit perimeter() const;

//   /// check if Polygon b is inside `this` Polygon
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if b touches the boundary
//   //  [ret]    .         true if `t` contains b
//   template <class T2>
//   inline bool contains(const PolygonImpl<T2>& b, 
//                        bool considerTouch = true) const;

   /// check if Point p is inside `this` Polygon
   template <class T2>
   inline bool contains(const PointImpl<T2>& p, 
                        bool considerTouch = true) const {
      iteratorPoints iter, iterEnd;
      iterEnd = endPoints();
      iter = beginPoints();
      Point prevPt = *iter;
      unsigned int num = size();
      unsigned int counts[2] = {0, 0};
      for(unsigned int i = 0; i < num; ++i) {
         if(i == num-1) iter = beginPoints();
         else ++iter;
         Point currentPt = *iter;
         if(currentPt.x() == prevPt.x()) {
            unsigned int index = currentPt.x() > p.x();
            unsigned int increment = 0;
            Interval ivl(currentPt.y(), prevPt.y());
            if(ivl.contains(p.y(), true)) {
               if(currentPt.x() == p.x()) return considerTouch;
               ++increment;
               if((currentPt.y() != p.y() &&
                  prevPt.y() != p.y())) {
                  ++increment;
               } 
               counts[index] += increment;
            }
         }
         prevPt = currentPt;
      }
      //odd count implies boundary condition
      if(counts[0] % 2 || counts[1] % 2) return considerTouch;
      //an odd number of edges to the left implies interior pt
      return counts[0] % 4; 
   }

  template <class pT>
  inline PointImpl<PointData> project(const PointImpl<pT>& point) const {
    PointImpl<PointData> returnVal;
    iteratorEdges iter = beginEdges();
    iteratorEdges iterEnd = endEdges();
    double dist = ((double)UnitMax) * 2;
    for( ; iter != iterEnd; ++iter) {
      PointImpl<PointData> segmentPoint = (*iter).project(point);
      double segDist = point.euclidianDistance(segmentPoint);
      if(segDist < dist) {
        dist = segDist;
        returnVal = segmentPoint;
      }
    }
    return returnVal;
  }
  
  template <class pT1, class pT2>
  inline bool project(PointImpl<pT1>& result, const PointImpl<pT2>& point,
                      Direction2D dir) const {
    iteratorEdges iter = beginEdges();
    iteratorEdges iterEnd = endEdges();
    double dist = ((double)UnitMax) * 2;
    bool found = false;
    for( ; iter != iterEnd; ++iter) {
      PointImpl<PointData> segmentPoint;
      if((*iter).project(segmentPoint, point, dir)) {
        found = true;
        double segDist = point.euclidianDistance(segmentPoint);
        if(segDist < dist) {
          dist = segDist;
          result = segmentPoint;
        }
      }
    }
    return found;
  }

   inline PolygonImpl& move(Unit xDisplacement, Unit yDisplacement) {
      std::vector<Unit> coords;
      coords.reserve(size());
      bool pingpong = true;
      for(iterator iter = begin(); iter != end(); ++iter) {
         coords.push_back((*iter) + predicated_value(pingpong, xDisplacement, yDisplacement));
         pingpong = !pingpong;
      }
      return set(coords.begin(), coords.end());
   }

   /// move polygon by delta in orient
   inline PolygonImpl& move(Orientation2D orient, Unit delta) {
      if(orient == HORIZONTAL) {
         return move(delta, 0);
      }
      return move(0, delta);
   }

  inline PolygonImpl& scaleUp(UnsignedUnit factor) {
    std::vector<Unit> coords;
    coords.reserve(size());
    for(iterator iter = begin(); iter != end(); ++iter) {
      coords.push_back((*iter) * (Unit)factor);
    }
    return set(coords.begin(), coords.end());
  }

   /// move polygon by delta in orient
  inline PolygonImpl& scaleDown(UnsignedUnit factor) {
    std::vector<Unit> coords;
    coords.reserve(size());
    for(iterator iter = begin(); iter != end(); ++iter) {
      coords.push_back((Unit)lround((double)(*iter) / (double)factor));
    }
    set(coords.begin(), coords.end());
    return *this;
  }

//   /// check if `this` Polygon is inside specified Polygon b
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch true, return true even if `t` touches the boundary
//   //  [ret]    .         true if `t` is inside b
//   template <class T2>
//   inline bool inside(const PolygonImpl<T2>& b, 
//                      bool considerTouch = true) const;

//   /// check if Polygon b intersects `this` Polygon
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if b touches the boundary
//   //  [ret]    .         true if `t` intersects b
//   template <class T2>
//   inline bool intersects(const PolygonImpl<T2>& b, 
//                          bool considerTouch = true) const;

//   /// Check if boundaries of Polygon b and `this` Polygon intersect
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if p is on the foundary
//   //  [ret]    .         true if `t` contains p
//   template <class T2>
//   inline bool boundariesIntersect(const PolygonImpl<T2>& b, 
//                                   bool considerTouch = true) const;
    
//   /// check if b is touching 'this' on the end specified by dir
//   template <class T2>
//   inline bool abuts(const PolygonImpl<T2>& b, Direction2D dir) const;

//   /// check if they are touching in the given orientation
//   template <class T2>
//   inline bool abuts(const PolygonImpl<T2>& b, 
//                     Orientation2D orient)const ;

//   /// check if they are touching but not overlapping
//   template <class T2>
//   inline bool abuts(const PolygonImpl<T2>& b) const;

//   /// bloat the Polygon on orient by bloating
//   inline PolygonImpl& bloat(Orientation2D orient, UnsignedUnit bloating);

//   /// bloat the Polygon by bloating
//   inline PolygonImpl& bloat(UnsignedUnit bloating);

//   /// bloat the Polygon cooresponding to orient by bloating in dir direction
//   inline PolygonImpl& bloat(Direction2D dir, UnsignedUnit bloating);

//   /// returns the center of the polygon
//   inline PointImpl<PointData> getCenter(void) const;
//   inline const PolygonImpl& getCenter(Unit& x, Unit& y) const;


private:
  //private functions
  inline iterator begin_() const {
    return PolygonInterface<T>::PolygonBegin(yieldConst());
  }

  inline iterator end_() const {
    return PolygonInterface<T>::PolygonEnd(yieldConst());
  }

  template <class iT>
  inline void set_(iT inputBegin, iT inputEnd) {
    PolygonInterface<T>::PolygonSet(yield(), inputBegin, inputEnd);
  }

  inline std::size_t size_() const {
    return PolygonInterface<T>::PolygonSize(yieldConst());
  }

  inline WindingDirection winding_() const {
     return PolygonInterface<T>::PolygonWinding(yieldConst());
  }

};

// default polygon type
typedef PolygonImpl<PolygonData> Polygon;

template <class T>
std::ostream& operator<< (std::ostream& o, const PolygonImpl<T>& p) {
   o << "Polygon ";
   for(typename PolygonImpl<T>::iterator itr = p.begin(); itr != p.end(); ++itr) {
      o << *itr << " ";
   }
   return o;
}

// template <class T>
// std::istream& operator>> (std::istream& i, PolygonImpl<T>& p);

inline void testPolygonImpl() {
   Rectangle rect(0, 10, 20, 30);
   Point pts[4] = {
      rect.ll(),
      rect.lr(),
      rect.ur(),
      rect.ul()
   };
   Polygon poly;
   poly.setPoints(pts, pts+4);
   std::cout << "pt in poly test " <<
      poly.contains(Point(2, 12)) << std::endl;
   std::cout << "test pattern 111111111100000000\n";
   std::cout << "test pattern " <<
      poly.contains(Point(10,20)) <<
      poly.contains(Point(0,10)) <<
      poly.contains(Point(20,10)) <<
      poly.contains(Point(20,30)) <<
      poly.contains(Point(0,30)) <<
      poly.contains(Point(10,10)) <<
      poly.contains(Point(20,20)) <<
      poly.contains(Point(10,30)) <<
      poly.contains(Point(0,20)) <<
      poly.contains(Point(10,20), false) <<
      poly.contains(Point(0,10), false) <<
      poly.contains(Point(20,10), false) <<
      poly.contains(Point(20,30), false) <<
      poly.contains(Point(0,30), false) <<
      poly.contains(Point(10,10), false) <<
      poly.contains(Point(20,20), false) <<
      poly.contains(Point(10,30), false) <<
      poly.contains(Point(0,20), false) << std::endl;
   
}

inline int testPolygonEdgeIterator() {

  std::vector<Point> pts(5);
  pts[0] = Point(0, 0);
  pts[1] = Point(0, 10);
  pts[2] = Point(10, 10);
  pts[3] = Point(10, 0);
  pts[4] = Point(0, 0);

  std::vector<Segment> segs(4);
  segs[0] = Segment(pts[0], pts[1]);
  segs[1] = Segment(pts[1], pts[2]);
  segs[2] = Segment(pts[2], pts[3]);
  segs[3] = Segment(pts[3], pts[0]);

  typedef Polygon::iteratorEdgesT<std::vector<Point>::iterator> vie;
  vie vieBegin(pts.begin(), pts.end());
  vie vieEnd(pts.end(), pts.end());
  for(unsigned int i = 0; i < 4; ++i) {
    if(*vieBegin != segs[i]) {
      std::cout << *vieBegin << " " << segs[i] << std::endl;
      return 1 + i;
    }
    ++vieBegin;
  }
  if(vieBegin != vieEnd) {
    std::cout << "wrap around failure\n";
    return 4;
  }
  vieBegin = vie(pts.begin(), pts.begin() + 4);
  vieEnd = vie(pts.begin() + 4, pts.begin() + 4);
  for(unsigned int i = 0; i < 4; ++i) {
    if(*vieBegin != segs[i]) {
      std::cout << *vieBegin << " " << segs[i] << std::endl;
      return 5 + i;
    }
    ++vieBegin;
  }
  if(vieBegin != vieEnd) {
    std::cout << "wrap around failure\n";
    return 6;
  }

  Polygon ply;
  ply.setPoints(pts.begin(), pts.begin() + 4);
  Polygon::iteratorPoints ppBegin = ply.beginPoints();
  Polygon::iteratorPoints ppEnd = ply.endPoints();
  {
    unsigned int i = 0;
    for(; ppBegin != ppEnd; ++ppBegin) {
      if(*ppBegin != pts[i+1]) {
        std::cout << *ppBegin << " " << pts[i+1] << std::endl;
      return 7 + i;
      }
      ++i;
    }
  }
  Polygon::iteratorEdges pieBegin = ply.beginEdges();
  Polygon::iteratorEdges pieEnd = ply.endEdges();
  {
    unsigned int i = 0;
    for(; pieBegin != pieEnd; ++pieBegin) {
      if(*pieBegin != segs[(i+1)%4]) {
        std::cout << *pieBegin << " " << segs[(i+1)%4] << std::endl;
      return 11 + i;
      }
      ++i;
    }
  }
  return 0;
}

inline int testPolygonProject() {
  std::vector<Point> pts(5);
  pts[0] = Point(0, 0);
  pts[1] = Point(0, 10);
  pts[2] = Point(10, 10);
  pts[3] = Point(10, 0);
  pts[4] = Point(0, 0);
  Polygon ply;
  ply.setPoints(pts.begin(), pts.begin() + 4);

  Point rpt, pt(0,0);
  if(pt != ply.project(pt)) return 1;
  if(!ply.project(rpt, pt, WEST)) return 2;
  if(pt != rpt) return 3;
  if(!ply.project(rpt, pt, EAST)) return 4;
  if(pt != rpt) return 5;
  if(!ply.project(rpt, pt, NORTH)) return 6;
  if(pt != rpt) return 7;
  if(!ply.project(rpt, pt, SOUTH)) return 8;
  if(pt != rpt) return 9;
  pt = Point(0, 5);
  if(pt != ply.project(pt)) return 10;
  if(!ply.project(rpt, pt, WEST)) return 11;
  if(pt != rpt) return 12;
  if(!ply.project(rpt, pt, EAST)) return 13;
  if(pt != rpt) return 14;
  if(!ply.project(rpt, pt, NORTH)) return 15;
  if(pt != rpt) return 16;
  if(!ply.project(rpt, pt, SOUTH)) return 17;
  if(pt != rpt) return 18;
  pt = Point(0, 10);
  if(pt != ply.project(pt)) return 19;
  if(!ply.project(rpt, pt, WEST)) return 20;
  if(pt != rpt) return 21;
  if(!ply.project(rpt, pt, EAST)) return 22;
  if(pt != rpt) return 23;
  if(!ply.project(rpt, pt, NORTH)) return 24;
  if(pt != rpt) return 25;
  if(!ply.project(rpt, pt, SOUTH)) return 26;
  if(pt != rpt) return 27;
  pt = Point(0, 11);
  if(Point(0,10) != ply.project(pt)) return 28;
  if(ply.project(rpt, pt, WEST)) return 29;
  if(ply.project(rpt, pt, EAST)) return 30;
  if(ply.project(rpt, pt, NORTH)) return 31;
  if(!ply.project(rpt, pt, SOUTH)) return 32;
  if(Point(0,10) != rpt) return 33;
  pt = Point(0, -1);
  if(Point(0,0) != ply.project(pt)) return 34;
  if(ply.project(rpt, pt, WEST)) return 35;
  if(ply.project(rpt, pt, EAST)) return 36;
  if(!ply.project(rpt, pt, NORTH)) return 37;
  if(Point(0,0) != rpt) return 38;
  if(ply.project(rpt, pt, SOUTH)) return 39;
  pt = Point(1, -1);
  if(Point(1,0) != ply.project(pt)) return 40;
  if(ply.project(rpt, pt, WEST)) return 41;
  if(ply.project(rpt, pt, EAST)) return 42;
  if(!ply.project(rpt, pt, NORTH)) return 43;
  if(Point(1,0) != rpt) return 431;
  if(ply.project(rpt, pt, SOUTH)) return 44;
  pt = Point(1, 0);
  if(Point(1,0) != ply.project(pt)) return 45;
  if(!ply.project(rpt, pt, WEST)) return 46;
  if(rpt != Point(1,0)) return 47;
  if(!ply.project(rpt, pt, EAST)) return 48;
  if(!ply.project(rpt, pt, NORTH)) return 49;
  if(!ply.project(rpt, pt, SOUTH)) return 50;
  pt = Point(1, 5);
  if(Point(0,5) != ply.project(pt)) return 51;
  if(!ply.project(rpt, pt, WEST)) return 52;
  if(rpt != Point(0,5)) return 53;
  if(!ply.project(rpt, pt, EAST)) return 54;
  if(rpt != Point(10,5)) return 541;
  if(!ply.project(rpt, pt, NORTH)) return 55;
  if(rpt != Point(1,10)) return 551;
  if(!ply.project(rpt, pt, SOUTH)) return 56;
  if(rpt != Point(1,0)) return 561;
  pt = Point(1, 10);
  if(Point(1,10) != ply.project(pt)) return 57;
  if(!ply.project(rpt, pt, WEST)) return 58;
  if(rpt != Point(1,10)) return 59;
  if(!ply.project(rpt, pt, EAST)) return 60;
  if(!ply.project(rpt, pt, NORTH)) return 61;
  if(!ply.project(rpt, pt, SOUTH)) return 62;
  pt = Point(1, 11);
  if(Point(1,10) != ply.project(pt)) return 63;
  if(ply.project(rpt, pt, WEST)) return 64;
  if(ply.project(rpt, pt, EAST)) return 65;
  if(ply.project(rpt, pt, NORTH)) return 66;
  if(!ply.project(rpt, pt, SOUTH)) return 67;
  if(rpt != Point(1,10)) return 671;
  pt = Point(-1, -1);
  if(Point(0,0) != ply.project(pt)) return 68;
  if(ply.project(rpt, pt, WEST)) return 69;
  if(ply.project(rpt, pt, EAST)) return 70;
  if(ply.project(rpt, pt, NORTH)) return 71;
  if(ply.project(rpt, pt, SOUTH)) return 72;
  pt = Point(-1, 0);
  if(Point(0,0) != ply.project(pt)) return 73;
  if(ply.project(rpt, pt, WEST)) return 74;
  if(!ply.project(rpt, pt, EAST)) return 75;
  if(rpt != Point(0,0)) return 76;
  if(ply.project(rpt, pt, NORTH)) return 77;
  if(ply.project(rpt, pt, SOUTH)) return 78;
  pt = Point(-1, 5);
  if(Point(0,5) != ply.project(pt)) return 79;
  if(ply.project(rpt, pt, WEST)) return 80;
  if(!ply.project(rpt, pt, EAST)) return 81;
  if(rpt != Point(0,5)) return 82;
  if(ply.project(rpt, pt, NORTH)) return 83;
  if(ply.project(rpt, pt, SOUTH)) return 84;
  pt = Point(-1, 10);
  if(Point(0,10) != ply.project(pt)) return 85;
  if(ply.project(rpt, pt, WEST)) return 86;
  if(!ply.project(rpt, pt, EAST)) return 87;
  if(rpt != Point(0,10)) return 88;
  if(ply.project(rpt, pt, NORTH)) return 89;
  if(ply.project(rpt, pt, SOUTH)) return 90;
  pt = Point(-1, 11);
  if(Point(0,10) != ply.project(pt)) return 91;
  if(ply.project(rpt, pt, WEST)) return 92;
  if(ply.project(rpt, pt, EAST)) return 93;
  if(ply.project(rpt, pt, NORTH)) return 94;
  if(ply.project(rpt, pt, SOUTH)) return 95;
  return 0;
}
