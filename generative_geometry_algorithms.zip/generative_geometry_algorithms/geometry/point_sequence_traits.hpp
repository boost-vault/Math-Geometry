//
//!  Copyright (c) 2008
//!  Brandon Kohn
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef _BOOST_GEOMETRY_POINT_SEQUENCE_TRAITS_HPP
#define _BOOST_GEOMETRY_POINT_SEQUENCE_TRAITS_HPP
#pragma once

#include "point_traits.hpp"

namespace boost
{
namespace numeric
{
namespace geometry
{

//! Default point traits struct. 
template <typename PointSequence>
struct point_sequence_traits
{
	BOOST_MPL_ASSERT_MSG( 
		  ( false )
		, POINT_SEQUENCE_TRAITS_NOT_DEFINED
		, (PointSequence) );	
};

//! Macro for point type with embedded traits
#define BOOST_DEFINE_POINT_SEQUENCE_TRAITS( Point, Container )      \
template <>                                                         \
struct point_sequence_traits< Container >                           \
{                                                                   \
 	typedef Point                                  point_type;      \
    typedef Container                              container_type;  \
    typedef point_traits< Point >::coordinate_type coordinate_type; \
    typedef point_traits< Point >::dimension_type  dimension_type;  \
    typedef container_type::iterator               iterator;        \
    typedef container_type::const_iterator         const_iterator;  \
};

}}}//namespace boost::numeric::geometry;

#endif //_BOOST_GEOMETRY_POINT_SEQUENCE_TRAITS_HPP
