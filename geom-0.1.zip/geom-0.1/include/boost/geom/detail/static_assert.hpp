#ifndef BOOST_GEOM_DETAIL_STATIC_ASSERT
#define BOOST_GEOM_DETAIL_STATIC_ASSERT

// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

namespace boost { namespace geom {
	namespace detail {

		template<bool> struct BOOST_GEOM_ASSERTION_FAILURE;
		template<> struct BOOST_GEOM_ASSERTION_FAILURE<true> { };
	
		template<int> struct boost_geom_static_assert {};

		#define BOOST_GEOM_JOIN( X, Y ) BOOST_GEOM_DO_JOIN( X, Y )
		#define BOOST_GEOM_DO_JOIN( X, Y ) BOOST_GEOM_DO_JOIN2(X,Y)
		#define BOOST_GEOM_DO_JOIN2( X, Y ) X##Y

		// Compile time assert
		//
		// Rational: Do not depend on some other implementation of it,
		// keep the library self contained.
		//
		// Also do not make it more complicated than it needs to be.
		// Keep the code simple, as simple as possible.
		#define BOOST_GEOM_STATIC_ASSERT(A) \
			 typedef \
		::boost::geom::detail::boost_geom_static_assert<\
			sizeof(::boost::geom::detail::BOOST_GEOM_ASSERTION_FAILURE<A>)> \
			BOOST_GEOM_JOIN(boost_geom_static_assertion_line,__LINE__)

	} // namespace detail

} } // namespace boost::geom

#endif  // BOOST_GEOM_DETAIL_STATIC_ASSERT
