/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Point3DData is the default in memory representation of a 3D point

/// Point3DData has a c-style array of coordinates indexed by the value
/// of an Orientation3D
/// This implementation was chosen for performance reasons because
/// the in memory representation is accessed directly by the value of
/// the orientation argument instead of using an if statement or 
/// branch free primitive such as predicated_value and predicated_assign
class Point3DData {
public:
  /// default constructor does not initialize
  inline Point3DData(){;} //do nothing default constructor

  /// construct a point from x,y and z
  inline Point3DData(Unit x, Unit y, Unit z) {
    coords_[HORIZONTAL] = x;
    coords_[VERTICAL] = y;
    coords_[PROXIMAL] = z;
  }

  inline Point3DData(const Point3DData& that) {
     (*this) = that;
  }

  inline Point3DData& operator=(const Point3DData& that) {
     coords_[0] = that.coords_[0];
     coords_[1] = that.coords_[1];
     coords_[2] = that.coords_[2];
     return *this;
  }

  /// get x y or z depending on the value of orient
  inline Unit get(Orientation3D orient) const {
    return coords_[orient.toInt()];
  }

  /// set x y or z depending on the value of orient
  inline void set(Orientation3D orient, Unit value) {
    coords_[orient.toInt()] = value;
  }

private:
  Unit coords_[3]; //to be indexed by orientation3d value
};
