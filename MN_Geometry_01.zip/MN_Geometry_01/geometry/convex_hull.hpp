// ============================================================================
// convex_hull.hpp                                (C)2005 Michael Andersen Nexo
// ============================================================================

#ifndef CONVEX_HULL_HPP_INCLUDED
#define CONVEX_HULL_HPP_INCLUDED

#include "geometry.hpp"
#include "utility.hpp"
#include <deque>

namespace geom
{
	namespace detail
	{
		// Determines if the point p is left of the line going from a to b
		template <class T, class R1, class R2, class R3>
		bool left_of(const point<T,2,R2>& a, const point<T,2,R3>& b, const point<T,2,R1>& p)
		{
			return geom::cross(b-a, p-a) >= 0;
		}

		template <class T, class R1, class R2, class R3>
		bool right_of(const point<T,2,R2>& a, const point<T,2,R3>& b, const point<T,2,R1>& p)
		{
			return geom::cross(b-a, p-a) <= 0;
		}

		template <class T, class R1, class R2, class R3>
		bool lies_on(const point<T,2,R2>& a, const point<T,2,R3>& b, const point<T,2,R1>& p)
		{
			return geom::cross(b-a, p-a) == 0;
		}
	}

	template <class InIter, class OutIter>
	void melkman_convex_hull(InIter begin, InIter end, OutIter out)
	{
		using namespace detail;

		std::deque<std::iterator_traits<InIter>::value_type> hull;
		InIter i(begin);
		while (i != end && hull.size() < 2)
			hull.push_back(*i++);

		while (i != end && lies_on(hull.front(), hull.back(), *i))
			hull.pop_back(), hull.push_back(*i++);

		if (i != end)
		{
			if (!left_of(*i, hull.front(), hull.back()))
				std::swap(hull.front(), hull.back());
			hull.push_back(*i);
			hull.push_front(*i);

			// POST: hull consists of the points c,a,b,c where c,a,b is a
			// counter clockwise ordered triangle

			while(++i != end)
			{
				bool push(false);
				while (left_of(*(hull.begin()+1), hull.front(), *i))
					hull.pop_front(), push = true;
				while (right_of(*(hull.end()-2), hull.back(), *i))
					hull.pop_back(), push = true;

				if (push)
					hull.push_back(*i), hull.push_front(*i);
			}
		}
		std::copy(hull.begin(), hull.end(), out);
	}
}

#endif // CONVEX_HULL_HPP_INCLUDED
