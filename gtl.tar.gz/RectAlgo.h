/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

inline bool lessRectPair(const RectangleImpl<RectangleData>& rect1,
                         const RectangleImpl<RectangleData>& rect2,
                         Orientation2D orient){
  return ((rect1.get(orient.getPerpendicular()).get(LOW) <
           rect2.get(orient.getPerpendicular()).get(LOW)) ||
          ((rect1.get(orient.getPerpendicular()).get(LOW) ==
            rect2.get(orient.getPerpendicular()).get(LOW)) &&
           (rect1.get(orient).get(LOW) <
            rect2.get(orient).get(LOW))) ||
          ((rect1.get(orient.getPerpendicular()).get(LOW) ==
            rect2.get(orient.getPerpendicular()).get(LOW)) &&
           (rect1.get(orient).get(LOW) ==
            rect2.get(orient).get(LOW)) &&
           (rect1.get(orient.getPerpendicular()).get(HIGH) <
            rect2.get(orient.getPerpendicular()).get(HIGH))) ||
          ((rect1.get(orient.getPerpendicular()).get(LOW) ==
            rect2.get(orient.getPerpendicular()).get(LOW)) &&
           (rect1.get(orient).get(LOW) ==
            rect2.get(orient).get(LOW)) &&
           (rect1.get(orient.getPerpendicular()).get(HIGH) ==
            rect2.get(orient.getPerpendicular()).get(HIGH)) &&
           (rect1.get(orient).get(HIGH) <
            rect2.get(orient).get(HIGH))) 
          );
}
  
//     class lessRectEnds
//       : public binary_function<const RectangleImpl<RectangleData>&, 
//                                const RectangleImpl<RectangleData>&, bool>
//     {
//     private:
//       Direction2D dir_; // we want to compare along this orientation
//     public:
//       lessRectEnds(Direction2D dir) : dir_(dir) {;}
//       bool operator () (const RectangleImpl<RectangleData>& rect1,
//                         const RectangleImpl<RectangleData>& rect2) const {
//         return rect1.get(dir) < rect2.get(dir);
//       }
//     };

typedef lessRectangle<RectangleData, RectangleData> lessRect;

typedef std::set<RectangleImpl<RectangleData>, lessRect> RectSet;
typedef std::vector<RectangleImpl<RectangleData> > RectVec;
typedef std::vector<const RectangleImpl<RectangleData> > ConstRectVec;

inline void sortRects(std::vector<RectangleImpl<RectangleData> >& rects, 
                      Orientation2D orient){
  sort(rects.begin(), rects.end(), lessRect(orient));
}


class CHasPoint {
public:
  int x;
  int y;
};

class cmpHasPointPtrs : public std::binary_function<CHasPoint*, CHasPoint*, bool> {
public:
  cmpHasPointPtrs() {} //default constructor is only constructor
  bool operator () (CHasPoint* ptr1, CHasPoint* ptr2) const {
    return ptr1->y < ptr2->y;
  }
};

template <class T>
class lessVecsT : public std::binary_function<const std::vector<T>&, const std::vector<T>&, bool> {
public:
  lessVecsT() {}
  bool operator () (const std::vector<T>& vec1, const std::vector<T>& vec2) const {
    //empty vectors are equal
    typename std::vector<T>::const_iterator itr1 = vec1.begin(); 
    typename std::vector<T>::const_iterator itr2 = vec2.begin();
    for(; itr1 != vec1.end() && itr2 != vec2.end(); ++itr1, ++itr2){
      if(*itr1 != *itr2) return *itr1 < *itr2;
    }
    //all elements in the vectors are the same through the end of the smaller vector
    return vec1.size() < vec2.size();
  }
};

typedef lessVecsT<RectVec> lessRectVecs;

inline void sortElement(std::vector<RectangleImpl<RectangleData> >& vec, 
                        std::vector<RectangleImpl<RectangleData> >::iterator itr, 
                        Orientation2D orient);

RectangleImpl<RectangleData> findLargestRectangle(const std::vector<PointImpl<PointData> >& poly);

int rectangularize(std::vector<RectangleImpl<RectangleData> >& rects, 
                   const std::vector<PointImpl<PointData> > &poly, 
                   const Orientation2D &o);

int notRectPair(std::vector<RectangleImpl<RectangleData> >& retRects, 
                const RectangleImpl<RectangleData>& rect1,
                const RectangleImpl<RectangleData>& rect2, Orientation2D orient);

int notRectVecs(std::vector<RectangleImpl<RectangleData> >& retRects, 
                const std::vector<RectangleImpl<RectangleData> >& lrects,
                const std::vector<RectangleImpl<RectangleData> >& rrects, 
                Orientation2D orient);

int notFigPair(std::vector<RectangleImpl<RectangleData> >& rects, 
               const std::vector<PointImpl<PointData> > &lpoly, 
               const std::vector<PointImpl<PointData> > &rpoly, 
               Orientation2D orient);

int andRectPair(std::vector<RectangleImpl<RectangleData> >& retRects, 
                const RectangleImpl<RectangleData>& rect1,
                const RectangleImpl<RectangleData>& rect2, Orientation2D orient);

int andRectVecs(std::vector<RectangleImpl<RectangleData> >& retRects, 
                const std::vector<RectangleImpl<RectangleData> >& lrects,
                const std::vector<RectangleImpl<RectangleData> >& rrects, 
                Orientation2D orient);

int andFigPair(std::vector<RectangleImpl<RectangleData> >& rects, 
               const std::vector<PointImpl<PointData> > &lpoly, 
               const std::vector<PointImpl<PointData> > &rpoly, Orientation2D orient);

int orRectPair(std::vector<RectangleImpl<RectangleData> >& retRects, 
               const RectangleImpl<RectangleData>& rect1,
               const RectangleImpl<RectangleData>& rect2, Orientation2D orient);

int orRectVecs(std::vector<RectangleImpl<RectangleData> >& retRects, 
               const std::vector<RectangleImpl<RectangleData> >& lrects,
               const std::vector<RectangleImpl<RectangleData> >& rrects, 
               Orientation2D orient);

int orFigPair(std::vector<RectangleImpl<RectangleData> >& rects, 
              const std::vector<PointImpl<PointData> > &lpoly, 
              const std::vector<PointImpl<PointData> > &rpoly, Orientation2D orient);

template <class pT, class rT>
int pointsInRects(std::vector<PointImpl<pT> >& retPoints,
                  const std::vector<PointImpl<pT> >& inputPoints,
                  const std::vector<RectangleImpl<rT> >& rects,
                  Orientation2D orient, // inputPoints are assumed sorted by orient first
                  bool internal = true,
                  bool considerTouch = true);

std::string benchmark(const std::vector<PointImpl<PointData> > &lpoly, 
                      const std::vector<PointImpl<PointData> > &rpoly, std::string o);

//namespace LR {

//  class PolyNode : public Rectangle
//  {
//      
//  public:
//      
//    //data
//    std::vector<int> children;
//    int color;
//      
//    //constructors
//    PolyNode() {color = 0;}
//    PolyNode(const RectangleImpl<RectangleData>& rect) : RectangleImpl<RectangleData>(rect), color(0) {;}
//    PolyNode(const PolyNode& node) : 
//      RectangleImpl<RectangleData>(node), children(node.children), color(node.color) {;}
//      
//    const PolyNode & operator = (const PolyNode & node)  
//    {
//      if (this != &node) {
//        Rectangle::operator=(node); 
//        children = node.children;
//        color = node.color;
//      }
//      return *this;
//    }
//      
//    //static data (for fast recursion)
//    static double maxArea;
//    static Unit rightMost;
//    static Unit left;
//    static RectangleImpl<RectangleData> maxRect;
//    static std::vector<PolyNode>* nodes;
//      
//    //functions
//      
//    //DFS function
//    void PolyNodeDFS(int top, int bottom);
//      
//  };
//    

//    
//}; //namespace LR

template <class CT, class T> 
class ScanLineToRects {
private:
  typedef std::set<RectangleImpl<T>, lessRectangle<T, T> > ScanData;
  ScanData scanData_;
  bool haveCurrentRect_;
  RectangleImpl<T> currentRect_;
  Orientation2D orient_;
  Unit currentCoordinate_;
public:
  inline ScanLineToRects() {}
    
  inline ScanLineToRects(Orientation2D orient, RectangleImpl<T> model) :
    scanData_(predicated_value(orient.toInt(), AxisTransform(), AxisTransform(AxisTransform::SWAP_XY))),
    haveCurrentRect_(false), currentRect_(model), orient_(orient), currentCoordinate_(UnitMax) 
  {}
    
  inline ScanLineToRects& processEdge(CT& rectangles, const Interval& edge);
    
  inline ScanLineToRects& nextMajorCoordinate(Unit currentCoordinate) {
    if(haveCurrentRect_) {
      scanData_.insert(scanData_.end(), currentRect_);
      haveCurrentRect_ = false;
    }
    currentCoordinate_ = currentCoordinate;
    return *this;
  }
    
};

template <class iT>
void populatePolygonSetDataWithRectangles(PolygonSetData& setData,
                                          iT begin, iT end, Orientation2D orient);
