/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// IntervalData is the default in memory representation of a 1D interval

/// IntervalData has a c-style array of coordinates indexed by the value
/// of a Direction1D object.
/// This implementation was chosen for performance reasons because
/// the in memory representation is accessed directly by the value of
/// the direction argument instead of using an if statement or 
/// branch free primitive such as predicated_value and predicated_assign
class IntervalData {
public:
  /// default constructor does not initialize
  inline IntervalData() {;} //do nothing default constructor

  /// construct an interval with low,high values assumed to be in order
  inline IntervalData(Unit low, Unit high) {
    bounds_[LOW]  = low;
    bounds_[HIGH] = high;
  }

  inline IntervalData(const IntervalData& that) {
     (*this) = that;
  }

  inline IntervalData& operator=(const IntervalData& that) {
     bounds_[0] = that.bounds_[0];
     bounds_[1] = that.bounds_[1];
     return *this;
  }

  /// gets the low or high coordinate depending on the value of dir.
  inline Unit get(Direction1D dir) const {
    return bounds_[dir.toInt()];
  }

  /// sets low or high coordinate to value depending on the value of dir.
  inline void set(Direction1D dir, Unit value) {
    bounds_[dir.toInt()] = value;
    //this is an unlikely condition and branch prediction should be good
    if (bounds_[0] > bounds_[1])
      bounds_[!dir.toInt()] = value;
  }

  Unit bounds_[2]; //to be indexed by direction value
};

