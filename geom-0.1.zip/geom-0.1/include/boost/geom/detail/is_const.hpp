#ifndef BOOST_GEOM_DETAIL_IS_CONST
#define BOOST_GEOM_DETAIL_IS_CONST

// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

namespace boost { namespace geom {
	namespace detail {

		// Meta function that returns true is test is const, false
		// otherwise
		//
		// Rational: Do not depend on some other implementation of it,
		// keep the library self contained.
		//
		// Also do not make it more complicated than it needs to be.
		// Keep the code simple, as simple as possible.
		template<typename T>
		struct is_const { enum {value=false}; };
		
		template<typename T>
		struct is_const<const T> { enum {value=true}; };	

	} // namespace detail

} } // namespace boost::geom

#endif  // BOOST_GEOM_DETAIL_IS_CONST
