/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
#ifndef GTL_H
#define GTL_H

#ifdef WIN32
#pragma warning( disable: 4996 )
#pragma warning( disable: 4800 )
#ifdef max
#undef max
#endif
#ifdef min
#undef min
#endif
#endif

/// \cond

/// gtl (Geometry Template Library)

/// gtl provides rich isotropic interfaces to abstract manhatton geometry types.
/// Interval, Point, Segment, Rectangle, Point3D, Segment3D, LayeredRect, RectPrism
/// gtl provides an abstraction between the rich isotropic interface and the underlying
/// datatype by templated inheritance.  Each abstract type inherits from its template
/// argument.  This provides polymorphism of data types without the run-time penalty of virtual
/// functions.

//gtl dependencies
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <queue>
#include <set>
#include <list>
#include <map>
#include <algorithm>
#include <limits>
#include <math.h>

namespace gtl {
  //////////////////////////////////////////////////////////////////
  // simple position type in one dimensional space, an integer value
  typedef int Unit;
  typedef unsigned int UnsignedUnit;
  typedef long long LongUnit;
  typedef unsigned long long UnsignedLongUnit;

  const Unit UnitMax = std::numeric_limits<int>::max();
  const Unit UnitMin = std::numeric_limits<int>::min();
  //////////////////////////////////////////////////////////////////


#include "Unit.h"
#include "Direction.h"


#define GTL_SEP ' '

#include "IntervalData.h"
#include "PointData.h"
#include "SegmentData.h"
#include "RectangleData.h"
#include "Point3DData.h"
#include "Segment3DData.h"
#include "LayeredRectData.h"
#include "RectPrismData.h"

#include "IntervalInterface.h"
#include "PointInterface.h"
#include "SegmentInterface.h"
#include "RectangleInterface.h"
#include "Point3DInterface.h"
#include "Segment3DInterface.h"
#include "LayeredRectInterface.h"
#include "RectPrismInterface.h"

#include "PointImpl.h"
#include "Point3DImpl.h"
#include "Transform.h"
#include "IntervalImpl.h"
#include "SegmentImpl.h"
#include "RectangleImpl.h"
#include "Segment3DImpl.h"
#include "LayeredRectImpl.h"
#include "RectPrismImpl.h"

#include "TransformDef.h"
#include "DirectionDef.h"

#include "IntervalImplDef.h"
#include "PointImplDef.h"
#include "SegmentImplDef.h"
#include "RectangleImplDef.h"
#include "Point3DImplDef.h"
#include "Segment3DImplDef.h"
#include "LayeredRectImplDef.h"
#include "RectPrismImplDef.h"

#include "BooleanOp.h"
#include "BooleanOpDef.h"

#include "PolygonTouch.h"

#include "PolygonData.h"
#include "PolygonInterface.h"
#include "PolygonImpl.h"
#include "PolygonWithHolesData.h"
#include "PolygonWithHolesInterface.h"
#include "PolygonWithHolesImpl.h"

#include "PolyLine.h"
#include "RectAlgo.h"

#include "RectAlgoDef.h"
#include "MaxCover.h"
#include "PolyLineDef.h"

#include "PolygonSet.h"
#include "PolygonSetDef.h"
   
#include "x45.h"
#include "Polygon45Data.h"
#include "Polygon45Interface.h"
#include "Polygon45Impl.h"
#include "Polygon45WithHolesData.h"
#include "Polygon45WithHolesInterface.h"
#include "Polygon45WithHolesImpl.h"
#include "Polygon45Formation.h"
#include "Polygon45Set.h"
#include "Polygon45SetDef.h"

#include "QT.h"
#include "SpatialQuery.h"

} //end gtl namespace
/// \endcond

#endif

