/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Point3DInterface provides glue to bind PointImpl to T

/// Point3DInterface provides access the the data class T through
/// the constructor, get and set API, which are minimal and sufficient.
template <class T>
class Point3DInterface {
public:
  /// get a coordinate from the 3D point t depending on value of orient
  static inline Unit Point3DGet(const T& t, Orientation3D orient);

  /// set a coordinate of the 3D point t depending on value of orient
  static inline void Point3DSet(T& t, Orientation3D orient, Unit value);

  /// construct a 3d point of type T from x, y and z
  static inline T Point3DConstruct(Unit x, Unit y, Unit z);

private:
  //disallow construction
  Point3DInterface();
};

/// partial specialization of Point3DInterface for T of type Point3DData
template <>
class Point3DInterface<Point3DData> {
public:  
  static inline Unit Point3DGet(const Point3DData& t, Orientation3D orient) {
    return t.get(orient);
  }
  static inline void Point3DSet(Point3DData& t, Orientation3D orient, Unit value) {
    t.set(orient, value);
  }
  static inline Point3DData Point3DConstruct(Unit& x, Unit y, Unit z) {
    return Point3DData(x, y, z);
  }

private:
  //disallow construction
  Point3DInterface(){;}
};
