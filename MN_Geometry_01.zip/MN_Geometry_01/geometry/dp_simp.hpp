// ============================================================================
// dp_simp.hpp                                    (C)2005 Michael Andersen Nexo
// ============================================================================
// Implements the Douglas-Peucker path simplification algorithm for a range of
// points.
#ifndef DP_SIMP_HPP_INCLUDED
#define DP_SIMP_HPP_INCLUDED

#include "utility.hpp"

namespace geom
{

namespace detail
{
	// Calculates the maximum distance from the set of 2D-points in the sequence
	// pointed to by [beg;end[ to the line segment going from a to b.
	// The type T should be able to hold values of at least 2n+1 digits where n
	// is the maximum number of digits in any scalar value in a point.
	template <class RT, class Iter, class T, class R>
	RT maxdist(Iter beg, Iter end, geom::point<T,2,R> const& a, geom::point<T,2,R> const& b, Iter* pmax = 0)
	{
		using namespace geom;
		typedef typename ops::promote_traits<T,T>::promote_type scalar;
		typedef vector<scalar, 2> vector;
		typedef point<scalar, 2> point;

		vector v(b - a);
		RT sqlenv = geom::sqlen<RT>(v);

		Iter res(end); RT maxdist(0);
		for (Iter i = beg; i != end; ++i)
		{
			vector w(*i - a);
			RT dotwv = dot<RT>(w,v);
			RT dist;
			if (dotwv <= 0)		                 // a is closest to *i
				dist = sqlen(w);
			else if(dotwv >= sqlenv)             // b is closest to *i
				dist = sqdist(b, *i);
			else                                 // *i projects onto v
			{
				RT crosswv = cross(w,v);		 // crosswv = dist(ab, *i) * lenv
				dist = crosswv*crosswv/sqlenv;   // <=> dist(ab,p) = crossw/lenv
			}

			if (dist > maxdist)
				res = i, maxdist = dist;
		}

		if (pmax)
			*pmax = res;
		return maxdist;
	}

	template <class InIter, class OutIter, class ToleranceT>
	std::size_t dp_simp_impl(InIter first, InIter last, OutIter& out, ToleranceT sqtolerance)
	{
		std::size_t total;
		InIter second(first); ++second;
		if (first == last)
			total = 0;
		else if (second == last)
			*out++ = *first, total = 1;
		else
		{
			// Split at vertex the farthest away from the line going from first to last
			InIter pmax;
			ToleranceT max = maxdist<ToleranceT>(second, last, *first, *last, &pmax);
			if (max > sqtolerance && pmax != last)
			{
				total = dp_simp_impl(first, pmax, out, sqtolerance);
				total += dp_simp_impl(pmax, last, out, sqtolerance);			
			}
			else
				*out++ = *first;
		}
		return total;
	}
}

// template <class InIter, class OutIter, Tolerance>
// dp_simp(InIter beg, InIter end, OutIter out, Tolerance tolerance);
// 
// Template arguments
//    InIter    InputIterator pointing to values convertible to point<T,2>
//    OutIter   OutputIterator for which point<T,2> can be assigned.
//    Tolerance Scalar type comparable with type T
//
// Function arguments
//    beg, end  iterator pair specifying the path to be simplified
//    out       output iterator to which the simplified path will be written
//    tolerance Discard segments only refining at a resolution below this value
template <class InIter, class OutIter, class ToleranceT>
std::size_t dp_simp(InIter beg, InIter end, OutIter out, ToleranceT tolerance)
{
	if (beg == end)
		return 0;

	// Call implementation function. This outputs all but the last vertex.
	std::size_t total = detail::dp_simp_impl(beg, --end, out, tolerance*tolerance);
	*out = *end; // output last one
    return total+1;
}


} // namespace geom

#endif //DP_SIMP_HPP_INCLUDED
