/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// SegmentData is the default in memory representation of a 2D segment

/// SegmentData has a point of type PointData, a 2D orientation and an
/// unsigned magnitude.
/// SegmentData is connonical, that is, there is only one representation
/// of a particular segment.  This reduces the number of end cased that
/// must be handled by the implementation on top of this representation.
/// A degenerate segment that has zero length still retains an orientation
/// and will grow in that orientation when extended with set or setLength.
class SegmentData {
public:
  /// default constructor of a segment initializes only orientation
  inline SegmentData() : orient_(HORIZONTAL) {;} 

  /// construct a segmetn from low point, orientation and length
  inline SegmentData(const PointData& p, Orientation2D o, UnsignedUnit length) :
    point_(p), orient_(o), magnitude_(length) {;}

  inline SegmentData(const SegmentData& that) {
     (*this) = that;
  }

  inline SegmentData& operator=(const SegmentData& that) {
     point_ = that.point_;
     orient_ = that.orient_;
     magnitude_ = that.magnitude_;
     return *this;
  } 

  /// get the PointData representation of the low or high end of the segment
  inline PointData get(Direction1D dir) const {
    PointData p(point_);
    UnsignedUnit value = predicated_value(dir.toInt(), magnitude_, 
                                          (UnsignedUnit)0);
    Unit value2 = p.get(orient_) + value;
    p.set(orient_, value2);
    return p;
  }

  /// set the low or high end point of the segment to value depending on dir
  inline void set(Direction1D dir, const PointData& value) {
    IntervalData ivl(point_.get(orient_),
                     point_.get(orient_)+magnitude_);
    ivl.set(dir, value.get(orient_));
    point_ = value;
    magnitude_ = (UnsignedUnit)(((LongUnit)(ivl.get(HIGH))) - ivl.get(LOW));
    //it is not expected that people will change the high point
    //near as often as the low point, so branch prediction should be good
    if(dir.toInt()) {
      point_.set(orient_, point_.get(orient_)-magnitude_);
    }
  }

  /// get the 2D orientation of the segment
  inline Orientation2D getOrient() const {
    return orient_;
  }

  /// set the 2D orientation of the segment, the low end point stays the same
  inline void setOrient(Orientation2D orient) {
    orient_ = orient;
  }

  /// get the unsigned length of the segment
  inline UnsignedUnit getLength() const {
    return magnitude_;
  }

  /// set the unsigned length of the segmetn, the low end point stays the same
  inline void setLength(UnsignedUnit value) {
    magnitude_ = value;
  }

private:
  PointData point_;
  Orientation2D orient_;
  UnsignedUnit magnitude_;
};
