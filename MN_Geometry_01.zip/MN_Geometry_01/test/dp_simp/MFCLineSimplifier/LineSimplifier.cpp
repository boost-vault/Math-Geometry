// LineSimplifier.cpp : 
//

#include "stdafx.h"
#include "LineSimplifier.h"
#include "LineSimplifierDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CLineSimplifierApp theApp;

BOOL CLineSimplifierApp::InitInstance()
{
	InitCommonControls();

	CWinApp::InitInstance();

	AfxEnableControlContainer();

	CLineSimplifierDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	return FALSE;
}
