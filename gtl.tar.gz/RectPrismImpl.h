/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// RectPrismImpl implements RectPrism functions on top of rect prism type T

/// RectPrismImpl inherits from rect prism type T and accesses the data owned
/// by T through the RectPrismInterface<T> class
template <class T>
class RectPrismImpl : public T {
public:

  /// get a reference of RectPrismImpl type given a data object
  static RectPrismImpl& mimic(T& t) { return static_cast<RectPrismImpl&>(t); }

  /// get a const reference of RectPrismImpl type given a data object
  static const RectPrismImpl& mimicConst(const T& t) { 
    return static_cast<const RectPrismImpl&>(t); 
  }

  /// construct a RectPrism from horizontal, vertical and proximal intervals
  template <class T2, class T3, class T4>
  RectPrismImpl(const IntervalImpl<T2>& hrange,
                       const IntervalImpl<T3>& vrange,
                       const IntervalImpl<T4>& prange);

  /// construct a RectPrism from a Rectangle and a proximal interval
  template <class T2, class T3>
  RectPrismImpl(const RectangleImpl<T2>& r,
                       const IntervalImpl<T3>& prange);

  /// construct a RectPrism from a Rectangle and two units defining the proximal interval
  template <class T2>
  RectPrismImpl(const RectangleImpl<T2>& r,
                       Unit low, Unit high);

  /// construct a degenerate RectPrism from a LayeredRectangle
  template <class T2>
  explicit RectPrismImpl(const LayeredRectImpl<T2>& lr);

  /// construct a degenerate RectPrism from a Segment3D
  template <class T2>
  explicit RectPrismImpl(const Segment3DImpl<T2>& s);

  /// construct a degenerate RectPrism from a Point3D
  template <class T2>
  explicit RectPrismImpl(const Point3DImpl<T2>& p);

  /// default constructor
  RectPrismImpl();

  /// assignment operator
  template <class T2>
  const RectPrismImpl& operator=(const RectPrismImpl& that) {
    horizontal(that.horizontal()); vertical(that.vertical()); proximal(that.proximal());
  }

  /// assignment operator
  const RectPrismImpl& operator=(const RectPrismImpl& that);

  /// assignment operator
  const RectPrismImpl& operator=(const T& that);

  /// copy constructor
  template <class T2>
  RectPrismImpl(const RectPrismImpl<T2>& that) { *this = that; }
     
  /// copy constructor
  RectPrismImpl(const T& that) : T(that) {;}

  /// equivalence operator
  template <class T2>
  bool operator==(const RectPrismImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const RectPrismImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const RectPrismImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<=(const RectPrismImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const RectPrismImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const RectPrismImpl<T2>& b) const { return !(*this < b); }

  /// conversion to rectangle
  operator RectangleImpl<RectangleData>() const;

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// yield payload
  T& yield() { return *this; }
     
  /// return a reference to 'this' RectangleImpl<T>
  RectangleImpl<T>& mimicRectangle();

  /// return a const reference to 'this' RectangleImpl<T>
  const RectangleImpl<T>& mimicConstRectangle() const;

  /// Is the RectPrism valid
  bool isValid() const;

  /// Is the RectPrism valid
  inline bool isInitialized() const;

  /// get the interval range depending on orient
  IntervalImpl<IntervalData> get(Orientation3D orient) const;

  /// set and interval range to v depending on orient
  template <class T2>
  RectPrismImpl& set(Orientation3D orient, 
                            const IntervalImpl<T2>& v);

  /// get a boundary coordinate depending on dir
  Unit get(Direction3D dir) const;

  /// set a boundary coordinate to value depending on dir
  RectPrismImpl& set(Direction3D dir, Unit value);
    
  /// set all six coordinates based upon two points
  template <class T2, class T3>
  RectPrismImpl& setPoints(const Point3DImpl<T2>& p1,
                                  const Point3DImpl<T3>& p2);

  /// get the horizontal interval range
  IntervalImpl<IntervalData> horizontal() const;

  /// get the vertical interval range
  IntervalImpl<IntervalData> vertical() const;

  /// get the proximal interval range
  IntervalImpl<IntervalData> proximal() const;

  /// set the horizontal interval range
  template <class T2>
  RectPrismImpl& horizontal(const IntervalImpl<T2>& v);

  /// set the vertical interval range
  template <class T2>
  RectPrismImpl& vertical(const IntervalImpl<T2>& v);

  /// set the proximal interval range
  template <class T2>
  RectPrismImpl& proximal(const IntervalImpl<T2>& v);

  /// get the magnitude of the interval
  UnsignedUnit delta(Orientation3D orient) const;

  /// move the prism by delta in orient
  RectPrismImpl& move(Orientation3D orient, Unit delta);

  /// transform rectprism
  RectPrismImpl& transform(const AxisTransform& atr);
    
  /// transform rectprism
  RectPrismImpl& transform(const Transform& tr);

  /// get the volume of the RectPrism
  UnsignedLongUnit volume() const;

  /// Get the area of the RectPrism
  UnsignedLongUnit area() const;

  /// Get the quarter perimeter of the RectPrism
  UnsignedLongUnit sumDeltas() const;
   
  /// Get the half perimeter of the RectPrism
  UnsignedLongUnit halfPerimeter() const;

  /// Get the perimeter of the RectPrism
  UnsignedLongUnit perimeter() const;

  /// Returns the euclidian distance between the edge of the
  /// prism and the point. Returns 0 if point is inside the
  /// rectangle
  template <class T2>
  double
  euclidianDistance(const Point3DImpl<T2> & p) const;

  /// Returns the manhattan distance (deltax + deltay + deltaz) between the
  /// edge of the prism and the point. Returns 0 if point is
  /// inside the prism
  template <class T2>
  double
  manhattanDistance(const Point3DImpl<T2> & p) const;

  /// Returns the distance between this prism and a unit 
  Unit distance(Unit u, Orientation3D o) const;

  /// Returns the distance between this prism and a point
  template <class T2>
  Unit distance(const Point3DImpl<T2> & p, Orientation3D o) const;

  /// Returns the distance between two rectangles along the given orientation
  template <class T2>
  Unit distance(const RectPrismImpl<T2> & r2, Orientation3D o) const;

  /// Returns closest euclidian distance between the edges of the two prisms.
  /// Returns 0 if they overlap or touch
  template <class T2>
  double euclidianDistance(const RectPrismImpl<T2> & r2) const;

  /// Returns manhattan distance (deltax + deltay) between the two prisms
  /// Returns 0 if they overlap or touch
  template <class T2>
  Unit manhattanDistance(const RectPrismImpl<T2> & r2) const;

  /// Returns the distance deltax and deltay between the two prisms
  /// Sets them to 0 if the two prisms' ranges overlap
  /// on that particular axis
  template <class T2>
  RectPrismImpl& getDeltas(const RectPrismImpl<T2> & r2,
                 Unit& deltax, Unit& deltay, Unit& deltaz) const;

  /// check if RectPrism b is inside `this` RectPrism
  //  [in]     b         RectPrism that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` contains b
  template <class T2>
  bool contains(const RectPrismImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if LayeredRect b is inside `this` RectPrism
  template <class T2>
  bool contains(const LayeredRectImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if Segment s is inside `this` RectPrism
  template <class T2>
  bool contains(const Segment3DImpl<T2>& s, 
                       bool considerTouch = true) const;

  /// check if Point p is inside `this` RectPrism
  template <class T2>
  bool contains(const Point3DImpl<T2>& p, 
                       bool considerTouch = true) const;

  /// check if `this` RectPrism is inside specified RectPrism b
  //  [in]     b         RectPrism that will be checked
  //  [in]     considerTouch If true, return true even if `t` touches the boundary
  //  [ret]    .         true if `t` is inside b
  template <class T2>
  bool inside(const RectPrismImpl<T2>& b, 
                     bool considerTouch = true) const;

  /// check if RectPrism b intersects `this` RectPrism
  //  [in]     b         RectPrism that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` intersects b
  template <class T2>
  bool intersects(const RectPrismImpl<T2>& b, 
                         bool considerTouch = true) const;

  /// Check if boundaries of RectPrism b and `this` RectPrism intersect
  //  [in]     b         RectPrism that will be checked
  //  [in]     considerTouch If true, return true even if p is on the foundary
  //  [ret]    .         true if `t` contains p
  template <class T2>
  bool boundariesIntersect(const RectPrismImpl<T2>& b, 
                                  bool considerTouch = true) const;
    
  /// check if 'this' abuts b in dir direction
  template <class T2>
  bool abuts(const RectPrismImpl<T2>& b, Direction3D dir) const;

  /// check if 'this' abuts b in the orientation given
  template <class T2>
  bool abuts(const RectPrismImpl<T2>& b, Orientation3D orient) const;

  /// check if they are touching but not overlapping
  template <class T2>
  bool abuts(const RectPrismImpl<T2>& b) const;

  /// clip 'this' to interval on orientation
  template <class T2>
  bool intersectRange(const IntervalImpl<T2>& b, 
                             Orientation3D orient, 
                             bool considerTouch = true);

  /// clip `this` RectPrism to the specified RectPrism
  //  [in]   b         The intersecting RectPrism
  //  [in]   considerTouch If true, will clip to a single line if appropriate
  template <class T2>
  bool intersect(const RectPrismImpl<T2>& b, bool considerTouch = true);

  /// set `this` RectPrism to the intersection between b1 and b2
  //  [in]     b1        The two intervals to examine
  //  [in]     b2
  //  [in]     considerTouch If true, create intersection even if b1 touches b2
  //  [ret]    .         true if boxes intersect, else `t` is set to b1
  template <class T2, class T3>
  bool intersection(const RectPrismImpl<T2>& b1, const RectPrismImpl<T3>& b2,
                           bool considerTouch = true);

  /// bloat the interval specified by orient by bloating
  RectPrismImpl& bloat(Orientation3D orient, UnsignedUnit bloating); 

  /// bloat the RectPrism by bloating
  //  [in]     bloating  Positive value to bloat each coordinate
  RectPrismImpl& bloat(UnsignedUnit bloating);

  /// bloat the interval cooresponding to orient by bloating in dir direction
  RectPrismImpl& bloat(Direction3D dir, UnsignedUnit bloating); 

  /// shrink the interval specified by orient by bloating
  RectPrismImpl& shrink(Orientation3D orient, UnsignedUnit shrinking);

  /// shring the RectPrism by bloating
  RectPrismImpl& shrink(UnsignedUnit shrinking);

  /// shrink the interval cooresponding to orient by bloating in dir direction
  RectPrismImpl& shrink(Direction3D dir, UnsignedUnit shrinking); 

  /// enlarge this to encompass interval on orientation
  template <class T2>
  bool encompass(const IntervalImpl<T2>& b,
                        Orientation3D orient);

  /// enlarge `this` RectPrism to encompass the RectPrism b
  //  [in]     b         The RectPrism to encompass
  //  [ret]    .         true if enlargement happened at all
  template <class T2>
  bool encompass(const RectPrismImpl<T2>& b);

private:
  //private functions
  IntervalImpl<IntervalData> get_(Orientation3D orient) const;
  void set_(Orientation3D orient, 
                   const IntervalImpl<IntervalData>& value);

  static T construct_(const IntervalImpl<IntervalData>& hrange, 
                             const IntervalImpl<IntervalData>& vrange,
                             const IntervalImpl<IntervalData>& prange);
};

typedef RectPrismImpl<RectPrismData> RectPrism;

template <class T>
std::ostream& operator<< (std::ostream& o, const RectPrismImpl<T>& rp);

template <class T>
std::istream& operator>> (std::istream& i, RectPrismImpl<T>& rp);

