/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
  
template <class T, class T2>
class lessRectangle
  : public std::binary_function<const RectangleImpl<T>&, const RectangleImpl<T2>&, bool>
{
private:
  Direction2D hdir_, vdir_;
  inline void mapToDirs(const AxisTransform& atr) {
    atr.inverse().getDirections(hdir_, vdir_);
  }
public:
  inline lessRectangle() : hdir_(EAST), vdir_(NORTH) {}
  inline lessRectangle(AxisTransform atr) { mapToDirs(atr); }
  inline lessRectangle(Direction2D dir) { mapToDirs(AxisTransform(dir)); }
  inline lessRectangle(Orientation2D orient) { mapToDirs(AxisTransform(orient)); }
  inline bool operator () (const RectangleImpl<T>& a,
                           const RectangleImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessRectangle<T, T2>::operator () (const RectangleImpl<T>& a,
                                   const RectangleImpl<T2>& b) const {
  Unit vl1 = a.get(vdir_.backward());
  Unit vl2 = b.get(vdir_.backward());
  if(vdir_.isNegative()){
    vl1 *= -1;
    vl2 *= -1;
  }
  if(vl1 > vl2) return false;
  if(vl1 == vl2) {
    Unit hl1 = a.get(hdir_.backward());
    Unit hl2 = b.get(hdir_.backward());
    if(hdir_.isNegative()){
      hl1 *= -1;
      hl2 *= -1;
    }
    if(hl1 > hl2) return false;
    if(hl1 == hl2) {
      Unit vh1 = a.get(vdir_);
      Unit vh2 = b.get(vdir_);
      if(vdir_.isNegative()) {
        vh1 *= -1;
        vh2 *= -1;
      }
      if(vh1 > vh2) return false;
      if(vh1 == vh2) {
        Unit hh1 = a.get(hdir_);
        Unit hh2 = b.get(hdir_);
        if(hdir_.isNegative()) {
          hh1 *= -1;
          hh2 *= -1;
        }
        return hh1 < hh2;
      }
    }
  }
  return true;
}
  
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::operator<(const RectangleImpl<T2>& b) const {
  const Interval v1(vertical());
  const Interval v2(b.vertical());
  if(v1.low() > v2.low()) return false;
  if(v1.low() == v2.low()) {
    const Interval h1(horizontal());
    const Interval h2(b.horizontal());
    if(h1.low() > h2.low()) return false;
    if(h1.low() == h2.low()) {
      if(v1.high() > v2.high()) return false;
      if(v1.high() == v2.high()) {
        return h1.high() < h2.high();
      }
    }
  }
  return true;
}

template<class T> template<class T2, class T3>
inline 
RectangleImpl<T>::RectangleImpl(const IntervalImpl<T2>& hrange, 
                                const IntervalImpl<T3>& vrange) {
  *this = construct_(IntervalImpl<IntervalData>(hrange), 
                     IntervalImpl<IntervalData>(vrange));
}

template<class T> template<class T2, class T3>
inline
RectangleImpl<T>::RectangleImpl(const PointImpl<T2>& ll, const PointImpl<T3>& ur)
{
  *this = construct_(Interval(ll.x(), ur.x()), Interval(ll.y(), ur.y()));
}

template<class T> template<class T2>
inline
RectangleImpl<T>::RectangleImpl(const PointImpl<T2>& p) 
{
  *this = construct_(Interval(p.x(), p.x()), Interval(p.y(), p.y()));
}

template<class T>
inline 
RectangleImpl<T>::RectangleImpl(Unit xl, Unit yl, Unit xh, Unit yh)
{
  *this = construct_(Interval(xl, xh), Interval(yl, yh));
}

template<class T> template<class T2>
inline
RectangleImpl<T>::RectangleImpl(const SegmentImpl<T2>& s) 
{
  *this = construct_(Interval(s.low().x(), s.high().x()), Interval(s.low().y(), s.high().y()));
}

template<class T>
inline 
RectangleImpl<T>::RectangleImpl()
{
  *this = construct_(Interval(), Interval());
}

template<class T>
const RectangleImpl<T>& 
RectangleImpl<T>::operator=(const RectangleImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T>
const RectangleImpl<T>& 
RectangleImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::operator==(const RectangleImpl<T2>& b) const {
  return horizontal() == b.horizontal() & 
    vertical() == b.vertical();
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::operator!=(const RectangleImpl<T2>& b) const {
  return horizontal() != b.horizontal() |
    vertical() != b.vertical();
}

template<class T>
inline bool 
RectangleImpl<T>::isValid() const {
  return (horizontal().isValid() &
          vertical().isValid());
}

template<class T>
inline bool 
RectangleImpl<T>::isInitialized() const {
   return (horizontal().isInitialized() |
      vertical().isInitialized());
}

template<class T>
inline IntervalImpl<IntervalData> 
RectangleImpl<T>::get(Orientation2D orient) const {
  return RectangleInterface<T>::RectangleGet(*this, orient);
}    

template<class T> template<class T2>
inline RectangleImpl<T>& 
RectangleImpl<T>::set( Orientation2D orient, 
                       const IntervalImpl<T2>& value) {
  RectangleInterface<T>::RectangleSet(*this, orient, value.yieldConst());
  return *this;
}    

template<class T>
inline Unit 
RectangleImpl<T>::get(Direction2D dir) const {
  return get(Orientation2D(dir)).get(Direction1D(dir));
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::set(Direction2D dir, Unit value) {
  IntervalImpl<IntervalData> ivl(get(Orientation2D(dir)));
  ivl.set(Direction1D(dir), value);
  set(Orientation2D(dir), ivl); return *this;
}

template<class T>
inline Unit 
RectangleImpl<T>::getBoundary(Orientation2D orient, Direction1D dir)  const {
  return get(orient).get(dir);
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::setBoundary(Orientation2D orient, 
                              Direction1D dir, Unit value) {
  return set(orient, get(orient).set(dir,value));
}

template<class T>
inline Unit 
RectangleImpl<T>::getLowerBoundary(Orientation2D orient)  const {
  return getBoundary(orient, LOW);
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::setLowerBoundary(Orientation2D orient, Unit value) {
  return setBoundary(orient, LOW, value);
}

template<class T>
inline Unit 
RectangleImpl<T>::getUpperBoundary(Orientation2D orient)  const {
  return getBoundary(orient, HIGH);
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::setUpperBoundary(Orientation2D orient, Unit value) {
  return setBoundary(orient, HIGH, value);
}
  
template<class T> template<class T2, class T3>
inline RectangleImpl<T>& 
RectangleImpl<T>::setPoints(const PointImpl<T2>& p1,
                            const PointImpl<T3>& p2) {
  Unit x1 = p1.x();
  Unit x2 = p2.x();
  Unit y1 = p1.y();
  Unit y2 = p2.y();
  predicated_swap(x2 < x1, x1, x2);
  predicated_swap(y2 < y1, y1, y2);
  horizontal(IntervalImpl<IntervalData>(x1, x2));
  vertical(IntervalImpl<IntervalData>(y1, y2));
  return *this;
}

template<class T>
inline RectangleImpl<T>&
RectangleImpl<T>::move(Orientation2D orient, Unit delta) {
  return set(orient, get(orient).move(delta));
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::transform(const AxisTransform& atr) {
  Interval hivl = get(HORIZONTAL);
  Interval vivl = get(VERTICAL);
  Direction2D hdir, vdir;
  atr.getDirections(hdir, vdir);
  if(hdir.isNegative()) hivl.flip();
  if(vdir.isNegative()) vivl.flip();
  set(Orientation2D(hdir), hivl);
  return set(Orientation2D(vdir), vivl);
}
    
template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::transform(const Transform& tr) {
  const Point3D translation = tr.getTranslation();
  Direction2D hdir, vdir;
  Interval hivl = get(HORIZONTAL);
  hivl.move(-translation.get(HORIZONTAL));
  Interval vivl = get(VERTICAL);
  vivl.move(-translation.get(VERTICAL));
  tr.getAxisTransform().getDirections(hdir, vdir);
  if(hdir.isNegative()) hivl.flip();
  if(vdir.isNegative()) vivl.flip();
  set(Orientation2D(hdir), hivl);
  return set(Orientation2D(vdir), vivl);
}

template<class T> template<class T2>
inline RectangleImpl<T>& 
RectangleImpl<T>::convolve(const RectangleImpl<T2>& b) {
  horizontal(horizontal().convolve(b.horizontal()));
  vertical(vertical().convolve(b.vertical()));
  return *this;
}

template<class T> template<class T2>
inline RectangleImpl<T>& 
RectangleImpl<T>::deconvolve(const RectangleImpl<T2>& b) {
  horizontal(horizontal().deconvolve(b.horizontal()));
  vertical(vertical().deconvolve(b.vertical()));
  return *this;
}

template<class T> template<class T2>
inline RectangleImpl<T>& 
RectangleImpl<T>::reflectedConvolve(const RectangleImpl<T2>& b) {
  horizontal(horizontal().reflectedConvolve(b.horizontal()));
  vertical(vertical().reflectedConvolve(b.vertical()));
  return *this;
}

template<class T> template<class T2>
inline RectangleImpl<T>& 
RectangleImpl<T>::reflectedDeconvolve(const RectangleImpl<T2>& b) {
  horizontal(horizontal().reflectedDeconvolve(b.horizontal()));
  vertical(vertical().reflectedDeconvolve(b.vertical()));
  return *this;
}

template<class T> template<class T2>
inline RectangleImpl<T>& RectangleImpl<T>::convolve(const PointImpl<T2>& p) {
  return convolve(RectangleImpl<T>(p));
}

template<class T> template<class T2>
inline RectangleImpl<T>& RectangleImpl<T>::deconvolve(const PointImpl<T2>& p) {
  return deconvolve(RectangleImpl<T>(p));
}

template<class T>
inline UnsignedUnit 
RectangleImpl<T>::delta(Orientation2D orient) const {
  return get(orient).delta();
}

template<class T>
inline UnsignedLongUnit 
RectangleImpl<T>::area() const {
  return ((UnsignedLongUnit)delta(HORIZONTAL)) * delta(VERTICAL);
}

template<class T>
inline Orientation2D 
RectangleImpl<T>:: guessOrientation() const {
  return predicated_value((get(HORIZONTAL).delta() > get(VERTICAL).delta()), HORIZONTAL, VERTICAL);
}

template<class T>
inline UnsignedLongUnit 
RectangleImpl<T>::halfPerimeter() const {
  return ((UnsignedLongUnit)delta(HORIZONTAL)) + delta(VERTICAL);
}
   
template<class T>
inline UnsignedLongUnit 
RectangleImpl<T>::perimeter() const {
  //multiply by two
  return halfPerimeter() << 1;
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::contains(const RectangleImpl<T2>& b, 
                           bool considerTouch) const {
  return horizontal().contains(b.horizontal(), considerTouch) &
    vertical().contains(b.vertical(), considerTouch);
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::contains(const PointImpl<T2>& p, 
                           bool considerTouch) const {
  return horizontal().contains(p.x(), considerTouch) &
    vertical().contains(p.y(), considerTouch);
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::inside(const RectangleImpl<T2>& b, 
                         bool considerTouch) const {
  return b.contains(*this, considerTouch);
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::intersects(const RectangleImpl<T2>& b, 
                             bool considerTouch) const {
  if(considerTouch) {
    return horizontal().intersects(b.horizontal(), true) &
      vertical().intersects(b.vertical(), true);        
  }else{
    return horizontal().intersects(b.horizontal(), false) &
      vertical().intersects(b.vertical(), false);        
  }
}

/// Check if boundaries of Rectangle b and `this` Rectangle intersect
/// if considerTouch is true a boundary in common is considered intersection
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::boundariesIntersect(const RectangleImpl<T2>& b, 
                                      bool considerTouch) const {
  return (intersects(b, considerTouch) &
          !(contains(b, !considerTouch)) &
          !(inside(b, !considerTouch)));
}
    
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::abuts(const RectangleImpl<T2>& b, 
                        Direction2D dir) const {
  return get(Orientation2D(dir)).
    abuts(b.get(Orientation2D(dir)), Direction1D(dir)) &
    get(Orientation2D(dir).getPerpendicular()).
    intersects(b.get(Orientation2D(dir).getPerpendicular()));
}

/// check if they are touching on a side at the high or low direction of
/// orientation orient
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::abuts(const RectangleImpl<T2>& b, 
                        Orientation2D orient) const {
  return get(orient).
    abuts(b.get(orient)) &
    get(orient.getPerpendicular()).
    intersects(b.get(orient.getPerpendicular()));
}

template<class T> template<class T2>
inline bool 
RectangleImpl<T>::abuts(const RectangleImpl<T2>& b) const {
  return abuts(b, HORIZONTAL) | abuts(b, VERTICAL);
} 

/// set the range of 'this' specified by orient to between its
/// intersection with Interval b
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::intersectRange(const IntervalImpl<T2>& b, 
                                 Orientation2D orient, 
                                 bool considerTouch) {
  IntervalImpl<IntervalData> ivl(get(orient));
  bool retval = ivl.intersect(b, considerTouch);
  set(orient, ivl);
  return retval;
}

/// clip `this` Rectangle to the specified Rectangle
/// if considerTouch is true will clip to a zero area rectangle if 
/// appropriate
/// if 'this' does not intersect b, leave 'this' unchanged and return false
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::intersect(const RectangleImpl<T2>& b, bool considerTouch) {
  IntervalImpl<IntervalData> hr = horizontal();
  IntervalImpl<IntervalData> vr = vertical();
  bool result = hr.intersect(b.horizontal(), considerTouch);
  result &= vr.intersect(b.vertical(), considerTouch);
  horizontal(predicated_value(result, hr, horizontal()));
  vertical(predicated_value(result, vr, vertical()));
  return result;
}

/// set `t` Rectangle to the intersection between b1 and b2
/// if such and intersection exists, else set 'this' to b1 and return false
template<class T> template<class T2, class T3>
inline bool 
RectangleImpl<T>::intersection(const RectangleImpl<T2>& b1, 
                               const RectangleImpl<T3>& b2,
                               bool considerTouch) {
  *this = b1;
  return intersect(b2, considerTouch);
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::bloat(Orientation2D orient, UnsignedUnit bloating) {
  IntervalImpl<IntervalData> ivl = get(orient);
  ivl.bloat(bloating);
  set(orient, ivl);
  return *this;
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::bloat(UnsignedUnit bloating) {
  bloat(VERTICAL, bloating);
  bloat(HORIZONTAL, bloating);
  return *this;
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::bloat(Direction2D dir, UnsignedUnit bloating) {
  IntervalImpl<IntervalData> ivl = get(Orientation2D(dir));
  ivl.bloat(Direction1D(dir), bloating);
  set(Orientation2D(dir), ivl);
  return *this;
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::shrink(Orientation2D orient, UnsignedUnit shrinking) {
  IntervalImpl<IntervalData> ivl = get(orient);
  ivl.shrink(shrinking);
  set(orient, ivl);
  return *this;
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::shrink(UnsignedUnit shrinking) {
  shrink(VERTICAL, shrinking);
  shrink(HORIZONTAL, shrinking);
  return *this;
}

template<class T>
inline RectangleImpl<T>& 
RectangleImpl<T>::shrink(Direction2D dir, UnsignedUnit shrinking) {
  IntervalImpl<IntervalData> ivl = get(Orientation2D(dir));
  ivl.shrink(Direction1D(dir), shrinking);
  set(Orientation2D(dir), ivl);
  return *this;
}

/// enlarge 'this' Rectangle to encompass the Interval b on the
/// orientation orient
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::encompass(const IntervalImpl<T2>& b,
                            Orientation2D orient) {
  IntervalImpl<IntervalData> ivl = get(orient);
  bool retval = ivl.encompass(b);
  set(orient, predicated_value(retval, ivl, get(orient)));
  return retval;
}

/// enlarge `this` Rectangle to encompass the Rectangle b
/// return true of the enlargement happened at all
template<class T> template<class T2>
inline bool 
RectangleImpl<T>::encompass(const RectangleImpl<T2>& b) {
  bool retval = encompass(b.horizontal(), HORIZONTAL);
  retval |= encompass(b.vertical(), VERTICAL);
  return retval;
}
 
template <class T>
inline Unit 
RectangleImpl<T>::distance(Unit u, Orientation2D o) const {
   return get(o).distance(u);
}

template <class T> template <class T2>
inline UnsignedLongUnit
RectangleImpl<T>::squareEuclidianDistance(const PointImpl<T2> & p) const {
   UnsignedLongUnit h = horizontal().distance(p.x());
   UnsignedLongUnit v = vertical().distance(p.y());
   return h*h + v*v;
}

template <class T> template <class T2>
inline double
RectangleImpl<T>::euclidianDistance(const PointImpl<T2> & p) const {
   return sqrt((double)squareEuclidianDistance(p));
}

template <class T> template <class T2>
inline double
RectangleImpl<T>::manhattanDistance(const PointImpl<T2> & p) const {
   return horizontal().distance(p.x()) + (double)(vertical().distance(p.y()));
}


template <class T> template <class T2>
inline Unit 
RectangleImpl<T>::distance(const PointImpl<T2> & p, Orientation2D o) const {
   return get(o).distance(p.get(o));
}

template <class T> template <class T2>
inline Unit 
RectangleImpl<T>::distance(const RectangleImpl<T2> & r2, Orientation2D o) const {
   return get(o).distance(r2.get(o));
}

template <class T> template <class T2>
inline RectangleImpl<T>& 
RectangleImpl<T>::getDeltas(const RectangleImpl<T2> & r2,
                            Unit& deltax,
                            Unit& deltay) const {
  deltax = distance(r2, HORIZONTAL);
  deltay = distance(r2, VERTICAL);
  return *this;
}

template <class T> template <class T2>
inline UnsignedLongUnit 
RectangleImpl<T>::squareEuclidianDistance(const RectangleImpl<T2> & r2) const {
  UnsignedLongUnit h = distance(r2, HORIZONTAL);
  UnsignedLongUnit v = distance(r2, VERTICAL);
  return h*h + v*v;
}

template <class T> template <class T2> 
inline double 
RectangleImpl<T>::euclidianDistance(const RectangleImpl<T2> & r2) const {
  return sqrt((double)squareEuclidianDistance(r2));
}

template <class T> template <class T2>
inline Unit 
RectangleImpl<T>::manhattanDistance(const RectangleImpl<T2> & r2) const {
  return distance(r2, HORIZONTAL) + distance(r2, VERTICAL);
}
  

template<class T>
inline PointImpl<PointData> RectangleImpl<T>::center() const {
  return PointImpl<PointData>(get(HORIZONTAL).center(),
                              get(VERTICAL).center());
}

template<class T>
inline SegmentImpl<SegmentData> RectangleImpl<T>::getCutline(Orientation2D o) const
{
  return SegmentImpl<SegmentData>(PointImpl<PointData>(predicated_value(o.toInt(), get(HORIZONTAL).center(), get(WEST)),
                                                       predicated_value(o.toInt(), get(SOUTH), get(VERTICAL).center())
                                                       ),
                                  o, get(o).delta());
}

template<class T>
inline RectangleImpl<T> RectangleImpl<T>::getCutlineAsRectangle(Orientation2D o) const
{
  return RectangleImpl(predicated_value(o.toInt(), IntervalImpl<IntervalData>(get(HORIZONTAL).center()), get(HORIZONTAL)), 
                       predicated_value(o.toInt(), get(VERTICAL), IntervalImpl<IntervalData>(get(VERTICAL).center())));
}

template<class T>
inline SegmentImpl<SegmentData> RectangleImpl<T>::getEdge(Direction2D d2d) const
{
  Orientation2D orient = static_cast<Orientation2D>(d2d).getPerpendicular();
  return SegmentImpl<SegmentData>(PointImpl<PointData>(predicated_value((d2d == EAST),  get(EAST),  get(WEST)),
                                                       predicated_value((d2d == NORTH), get(NORTH), get(SOUTH))),
                                  orient,
                                  delta(orient));
}

template<class T>
inline  PointImpl<PointData> RectangleImpl<T>::getCorner(Direction2D d2d, Direction1D turn) const
{
  Unit u1 = get(d2d);
  Unit u2 = get(d2d.turn(turn));
  predicated_swap(((Orientation2D)d2d).isVertical(), u1, u2);
  return PointImpl<PointData>(u1,u2);
}

template<class T>
inline RectangleImpl<T> RectangleImpl<T>::getHalf(Direction2D d2d) const
{
  return RectangleImpl(predicated_value(static_cast<Orientation2D>(d2d).isHorizontal(), 
                                        get(HORIZONTAL).getHalf(d2d), get(HORIZONTAL)),
                       predicated_value(static_cast<Orientation2D>(d2d).isVertical(),
                                        get(VERTICAL).getHalf(d2d), get(VERTICAL)));
}

template<class T> template<class T2, class T3, class T4>
inline Orientation2D
RectangleImpl<T>::getTwoHalvesAndShorterCutline(RectangleImpl<T2>& A, 
                                                RectangleImpl<T3>& C, 
                                                RectangleImpl<T4>& B) const {
  Orientation2D retval = 
    predicated_value((get(HORIZONTAL).delta() >= 
                      get(VERTICAL).delta()), VERTICAL, HORIZONTAL);
  Orientation2D temp = retval.getPerpendicular();

  A = getHalf(temp.getNegativeDirection());
  C = getCutlineAsRectangle(retval);
  B = getHalf(temp.getPositiveDirection());
  return retval;
}

template<class T>
inline RectangleImpl<T> RectangleImpl<T>::flip (void) const {
  return RectangleImpl<T>(get(VERTICAL), get(HORIZONTAL));
}

template<class T>
inline RectangleImpl<T>& RectangleImpl<T>::flipInPlace(Orientation2D o) {
  return set(o, get(o).flip());
}

template<class T>
inline RectangleImpl<T> RectangleImpl<T>::flip(Orientation2D o) const {
  RectangleImpl retval(*this);
  retval.flipInPlace(o);
  return retval;
}

template<class T> RectangleImpl<T> 
RectangleImpl<T>::getSubRectangle(Direction2D direction,
                                  unsigned short numPieces,
                                  unsigned short whichPiece) const {
  whichPiece %= numPieces;
    
  // get two boundaries we'll muck with
  Unit boundaryInDirection = get(direction);
  Unit boundaryInOpDirection = get(direction.backward());
  // yes, keep the sign the way it is
  Unit width = boundaryInDirection - boundaryInOpDirection;
  Unit subStart = boundaryInOpDirection + whichPiece * (width / numPieces);
  Unit subEnd   = boundaryInOpDirection + (whichPiece+1) * (width / numPieces);
  // if at end, slurp in any remainder (happens when (r.delta(direction) % numPieces > 0)
  if (numPieces == whichPiece+1) {
    subEnd = get(direction);
  }
  //std::cout << "BoundaryInDir " << boundaryInDirection << ", boundaryInOpDirection " << boundaryInOpDirection << "which piece " << whichPiece << ", width " << width << ", subStart " << subStart << ", subEnd " << subEnd << std::endl;
  return RectangleImpl(
                       predicated_value((static_cast<Orientation2D>(direction) == HORIZONTAL), Interval(subStart, subEnd), get(HORIZONTAL)),
                       predicated_value((static_cast<Orientation2D>(direction) == HORIZONTAL), get(VERTICAL), Interval(subStart, subEnd)));
    
}

template<class T> template<class T2, class T3>
bool RectangleImpl<T>::joinWith( RectangleImpl<T2>& newRect, const RectangleImpl<T3>& r2) const
{
  Interval hi1 = get(HORIZONTAL);
  Interval vi1 = get(VERTICAL);
  Interval hi2 = r2.get(HORIZONTAL), vi2 = r2.get(VERTICAL);
  Interval temp;
  if (hi1 == hi2 && vi1.joinWith(temp, vi2)) {
    newRect = RectangleImpl(hi1, temp);
    return true;
  }
  if (vi1 == vi2 && hi1.joinWith(temp, hi2)) {
    newRect = RectangleImpl(temp, vi1);
    return true;
  }
  return false;
}
 
template<class T> template<class T2>
RectangleImpl<T>&
RectangleImpl<T>::generalizedIntersect(const RectangleImpl<T2>& r) {
  IntervalImpl<IntervalData> h = horizontal(), v= vertical();
  h.generalizedIntersect(r.horizontal());
  v.generalizedIntersect(r.vertical());
  horizontal(h);
  vertical(v);
  return *this;
}

template<class T> template<class T2, class T3>
RectangleImpl<T>&
RectangleImpl<T>::generalizedIntersection(const RectangleImpl<T2>& r1, 
                                          const RectangleImpl<T3>& r2) {
  *this = r1;
  return generalizedIntersect(r2);
}

//private functions
template<class T>
inline T 
RectangleImpl<T>::construct_(const IntervalImpl<IntervalData>& hrange, 
                             const IntervalImpl<IntervalData>& vrange) {
  return RectangleInterface<T>::RectangleConstruct(hrange.yieldConst(), 
                                                   vrange.yieldConst());
}


class PointAndDepth{
private:
  Unit v_; // unit value
  Unit d_; // depth
  bool end_; // false - start, true - end
  int id_;
public:
  bool operator < (const PointAndDepth& rs) const {
    if(v_ < rs.v_) return true;
    if(v_ > rs.v_) return false;
    // the two v_'s must be same here
    if(end_ != rs.end_){
      if(id_ == rs.id_) return !end_;
      else return end_; // if this is end, then other is begin, so this is smaller
    }
    if(!end_){ // the begin part
      return d_ > rs.d_;
    }
    // must be end part
    return d_ < rs.d_;
  }
  Unit getVal(void) const { return v_; }
  Unit getDepth(void) const { return d_; }
  PointAndDepth(Unit v, Unit d, bool isEnd, int id) : v_(v), d_(d), end_(isEnd), id_(id) {}
  bool isEnd() const { return end_; }
  bool isBegin() const { return !end_; }
};


class Sliver{
private:
  Unit  l_, h_;
  Unit d_; // depth
public:
  Sliver(Unit l, Unit h, Unit d) : l_(l), h_(h), d_(d)
  {
    //assert(l_ <= h_)(l_)(h_);
  }
  Unit lVal(void) const { return l_;}
  Unit hVal(void) const { return h_;}
  Unit depth(void) const { return d_; }
  Sliver& operator += (const Sliver& rs) {
    if(d_ < rs.d_) d_ = rs.d_;
    return *this;
  }
 

  static void tileizeSlivers(std::vector<Sliver>& results, const std::vector<Sliver>& inputData)
  {
    std::vector<PointAndDepth> padv;

    for(unsigned int i = 0; i < inputData.size(); ++i){
      const Sliver& sr = inputData[i];
      Unit lv = sr.lVal();
      Unit hv = sr.hVal();
      //assert(lv < hv)(lv)(hv);
      padv.push_back(PointAndDepth(lv, sr.depth(), false, i));
      padv.push_back(PointAndDepth(hv, sr.depth(), true, i));
    }
    // let's sort the vector
    std::vector<PointAndDepth>::iterator vit1 = padv.begin(), vit2 = padv.end();
    std::sort(vit1, vit2);

    //  for(unsigned int j = 0; j < padv.size(); ++j){
    //        std::cout << j << "= " << padv[j].getVal()
    //                  << ", depth: " << padv[j].getDepth() << ", " << padv[j].isBegin() << "\n";
    //      }
    bool inProgress = false;
    bool mergeAbutting = false;
    std::list<Unit> ulist;
    Unit v0 = 0; // begin and and values for the sliver we create
    for(unsigned int j = 0; j < padv.size(); ++j){ // go thur the vector, one coord at a time

      Unit depth = padv[j].getDepth();
      Unit val = padv[j].getVal();
      bool isBeg = padv[j].isBegin();

      if(!inProgress){
        //assert(isBeg);
        v0 = val;
        inProgress = true;
        ulist.push_back(depth);
        mergeAbutting = false;
        continue;
      }
      // inProgress
      if(isBeg){ // inProgress && isBeg
        if(mergeAbutting){
          mergeAbutting = false;
          ulist.push_back(depth);
          continue;
        }
        if(depth <= ulist.back()){ // keep on going
          if(depth == ulist.back()) ulist.push_back(depth);
          else{
            bool insertedOK = false;
            for(std::list<Unit>::iterator lit = ulist.begin(); lit != ulist.end(); ++lit){
              if(depth <= *lit){
                ulist.insert(lit, depth);
                insertedOK = true;
                break;
              }
            }
            //assert(insertedOK);
          }
          continue;
        }
        // depth is larger than last
        results.push_back(Sliver(v0, val, ulist.back()));
        ulist.push_back(depth);
        v0 = val;
        continue;
      }

      // inProgress && !isBeg
      if(depth < ulist.back()){
        bool removedOK = false;
        for(std::list<Unit>::iterator lit = ulist.begin(); lit != ulist.end(); ++lit){
          if(*lit == depth){
            ulist.erase(lit);
            removedOK = true;
            break;
          }
        }
        //assert(removedOK);
        continue;
      }
      //assert(depth == ulist.back());
      ulist.pop_back();


      // we just about to finish one here
      // let's look ahead, to see if next is same depth as this one
      if(j+1 < padv.size()){ // there are more in the vector
        PointAndDepth& lah = padv[j+1];
        if(lah.getVal() == val && lah.getDepth() == depth && lah.isBegin()){
          // there's another candidate same depth as this one, abutting, ready to begin
          // just skip
          mergeAbutting = true;
          continue;
        }
      }

      if(ulist.empty()){
        results.push_back(Sliver(v0, val, depth));
        inProgress = false;
        continue;
      }


      if(ulist.back() == depth){ // there's another one with same depth
        continue;
      }

      results.push_back(Sliver(v0, val, depth));
      v0 = val;
      // and inProgress stays true
    }
  }
};


template<class T> template<class T2, class T3>
void  RectangleImpl<T>::tileizeRectanglesInDir(std::vector<RectangleImpl<T2> >& results,
                                               const std::vector<RectangleImpl<T3> >& rects,
                                               Direction2D dir) const
{
  results.clear();
  //std::cout << "Direction is: " << dir << "\n";
  SegmentImpl<SegmentData> seg = getEdge(dir);
  std::cout << "segment : " << seg << std::endl;
  RectangleImpl refEdge = RectangleImpl(seg);
  RectangleImpl specialResult(refEdge);
  Orientation2D perpend = dir; perpend.turn90();
  bool specialPoint = (delta(perpend) == 0);

  refEdge.set(dir, predicated_value(dir.isPositive(),  UnitMax, UnitMin));

  std::vector<Sliver> inSVec, outSvec;

  for(unsigned int i = 0; i < rects.size(); ++i){
    RectangleImpl temp = rects[i];
    if(temp.intersect(refEdge, true)) { // clip to play area
      if(specialPoint){
        specialResult.encompass(temp);
      }
      else{
        if(temp.delta(perpend) == 0){
          temp.bloat(perpend, 1);
        }
        IntervalImpl<IntervalData> tempInt = temp.get(static_cast<Orientation2D>(dir).getPerpendicular());
        inSVec.push_back(Sliver(tempInt.get(LOW), tempInt.get(HIGH), temp.delta(static_cast<Orientation2D>(dir))));
      }
    }
  }

  if(specialPoint){
    results.push_back(specialResult);
    return;
  }


  Sliver::tileizeSlivers(outSvec, inSVec);
  for(unsigned int j = 0; j < outSvec.size(); ++j){
    Sliver& sr = outSvec[j];
    Unit l = sr.lVal();
    Unit h = sr.hVal();
    Unit d = sr.depth();
    /*
      if(dir == Direction2D::NORTH){
      results.push_back(RectangleImpl(l, r.getyh(), h, r.getyh()+d));
      }
      else if(dir == Direction2D::SOUTH){
      results.push_back(RectangleImpl(l, r.getyl()-d, h, r.getyl()));
      }
      else if(dir == Direction2D::EAST){
      results.push_back(RectangleImpl(r.getxh(), l, r.getxh()+d, h));
      }
      else if(dir == Direction2D::WEST){
      results.push_back(RectangleImpl(r.getxl()-d, l, r.getxl(), h));
      }
    */

    Orientation2D o2d = dir;
    RectangleImpl temp = RectangleImpl(getEdge(dir));
    temp.bloat(dir, d);
    temp.set(o2d.getPerpendicular(), IntervalImpl<IntervalData>(l, h));
    results.push_back(temp);
    
  }
  return;
}


template <class T>
std::ostream& operator<< (std::ostream& o, const RectangleImpl<T>& r)
{
  o << r.horizontal() << GTL_SEP << r.vertical();
  return o;
}

template <class T>
std::istream& operator>> (std::istream& i, RectangleImpl<T>& r)
{
  Interval h, v;
  i >> h >> v;
  r.horizontal(h);
  r.vertical(v);
  return i;
}

