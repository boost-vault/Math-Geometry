#ifndef VEC2_CLASS_H
#define VEC2_CLASS_H

#include "permutation.h"
#include "boost/static_assert.hpp"
#include "boost/type_traits.hpp"

namespace blas
{

template <typename X, typename Y = X>
struct vec2
{
	typedef vec2 &reference;
	typedef vec2 const &const_reference;
	typedef X x_type;
	typedef Y y_type;

	x_type x;
	y_type y;

	vec2() { }
	vec2(x_type vx, y_type vy) : x(vx), y(vy) { }

	template <typename T>
	vec2(T d) : x(d), y(d) { }

	template <typename VX, typename VY>
	vec2(const vec2<VX, VY> &v) : x(v.x), y(v.y) { }

	template <typename VX, typename VY>
	reference operator=(const vec2<VX, VY> & v)
	{
		x = v.x;
		y = v.y;
		return *this;
	}

	typename boost::remove_reference<X>::type &operator[](size_t idx)
	{
		assert(idx < 2);
		return array()[idx];
	}

	BLAS_DECLARE_SWIZZLE(BLAS_VEC2D_SEQ)

	// array will only be enabled if x_type == y_type
	typename boost::remove_reference<X>::type *array(void)
	{
		BOOST_STATIC_ASSERT((boost::is_reference<X>::value == false));
		BOOST_STATIC_ASSERT((boost::is_reference<Y>::value == false));
		BOOST_STATIC_ASSERT((boost::is_same<X, Y>::value));
		return static_cast<X *>(&x);
	}
	typename boost::remove_reference<X>::type const *array(void) const
	{
		return const_cast<vec2 *>(this)->array();
	}
};

template <typename X, typename Y>
inline std::ostream &operator<<(std::ostream &os, const vec2<X, Y> &v)
{
	os << "[" << v.x << ", " << v.y << "]";
	return os;
}

typedef vec2<float> vec2f;
typedef vec2<double> vec2d;
typedef vec2f float2;
typedef vec2d double2;

BOOST_STATIC_ASSERT(sizeof(float2) == sizeof(float) * 2);
BOOST_STATIC_ASSERT(sizeof(double2) == sizeof(double) * 2);

}

#endif
