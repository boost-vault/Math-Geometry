/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// default constructor
inline Polygon45Set::Polygon45Set(){}

/// constructor from an iterator pair over polygons
template <class T>
inline Polygon45Set::Polygon45Set(T inputBegin, T inputEnd) {
   insert(inputBegin, inputEnd);
}

/// constructor from a Polygon
template <class T>
inline Polygon45Set::Polygon45Set(const Polygon45Impl<T>& polygon) {
   insert(polygon);
   dirty_ = true;
   unsorted_ = true;
}

/// constructor from a PolygonWithHoles
template <class T>
inline Polygon45Set::Polygon45Set(const Polygon45WithHolesImpl<T>& polyWithHoles) {
   insert(polyWithHoles);
   dirty_ = false;
   unsorted_ = true;
}

template <class T>
inline Polygon45Set::Polygon45Set(const RectangleImpl<T>& rect) {
  Point pts[4] = {rect.ur(), rect.ul(), rect.ll(), rect.lr()};
  Polygon45 poly(pts, pts+4);
  insert(poly);
}

/// copy constructor
inline Polygon45Set::Polygon45Set(const Polygon45Set& that) : 
   data_(that.data_), dirty_(that.dirty_), unsorted_(that.unsorted_) {}

/// destructor
inline Polygon45Set::~Polygon45Set() {}

/// assignement operator
inline Polygon45Set& Polygon45Set::operator=(const Polygon45Set& that){
   if(this == &that) return *this;
   data_ = that.data_;
   dirty_ = that.dirty_;
   unsorted_ = that.unsorted_;
   return *this;
}

/// equivilence operator
inline bool Polygon45Set::operator==(const Polygon45Set& p) const {
  clean_();
  p.clean_();
  return data_ == p.data_;
}

/// inequivilence operator
inline bool Polygon45Set::operator!=(const Polygon45Set& p) const {
  return !(p == (*this));
}

/// append to the container cT 
template <class cT>
unsigned int Polygon45Set::get(cT& container, bool fractureHoles) const {
   clean_();
   unsigned int countPolygons = container.size();
   Polygon45Formation pf(fractureHoles);
   //std::cout << "FORMING POLYGONS\n";
   pf.scan(container, data_.begin(), data_.end());
   //std::cout << "DONE FORMING POLYGONS\n";
   return container.size() - countPolygons;
}

/// append to the container cT with polygons (holes will be fractured along orientation)
template <class cT>
inline unsigned int Polygon45Set::getPolygons(cT& container) const{
   return get(container, true);
}

/// append to the container cT with PolygonWithHoles objects
template <class cT>
inline unsigned int Polygon45Set::getPolygonsWithHoles(cT& container) const{
   return get(container, false);
}

template <class cT>
inline unsigned int Polygon45Set::getTrapezoids(cT& container) const{
  clean_();
  unsigned int countPolygons = container.size();
  Polygon45Tiling pf;
  //std::cout << "FORMING POLYGONS\n";
  pf.scan(container, data_.begin(), data_.end());
  //std::cout << "DONE FORMING POLYGONS\n";
  return container.size() - countPolygons;
}

/// insert polygons
template <class T>
inline Polygon45Set& Polygon45Set::insert(T inputBegin, T inputEnd){
   while(inputBegin != inputEnd){
      insert(*inputBegin);
      ++inputBegin;
   }
   return *this;
} 

/// insert holes
template <class T>
inline Polygon45Set& Polygon45Set::insertHoles(T inputBegin, T inputEnd){
   while(inputBegin != inputEnd){
      insertHole(*inputBegin);
      ++inputBegin;
   }
   return *this;
} 

inline std::pair<int, int> characterizeEdge45(const Point& pt1, const Point& pt2) {
   std::pair<int, int> retval(0, 1);
   if(pt1.x() == pt2.x()) {
      retval.first = 3;
      retval.second = -1;
      return retval;
   }
   //retval.second = pt1.x() < pt2.x() ? -1 : 1;
   retval.second = 1;
   if(pt1.y() == pt2.y()) {
      retval.first = 1;
   } else if(pt1.x() < pt2.x()) {
      if(pt1.y() < pt2.y()) {
         retval.first = 2;
      } else {
         retval.first = 0;
      }
   } else {
      if(pt1.y() < pt2.y()) {
         retval.first = 0;
      } else {
         retval.first = 2;
      }
   }
   return retval;
}

inline void check45(const Point& pt1, const Point& pt2) {
   LongUnit deltaX = pt1.x();
   deltaX -= pt2.x();
   if(deltaX < 0) deltaX *= -1;
   LongUnit deltaY = pt1.y();
   deltaY -= pt2.y();
   if(deltaY < 0) deltaY *= -1;
   if(deltaX && deltaY) {
      if(deltaX != deltaY) {
         //this is not a 45 degree edge because deltaX != deltaY
         throw("GTL 45 Booleans input edge is non-manhattan and non-45 degree, not a legal input.");
      }
   }
}

//this function snaps the vertex of the two edges described by the three points (pt)
//to be both even or both odd coordinate values if one of the edges is 45
//and throws an excpetion if an edge is non-manhattan, non-45.
inline void checkAndPerterb45(const Point& pt1, Point& pt, const Point& pt3) {
  bool prevVert = pt1.x() == pt.x();
  bool nextVert = pt3.x() == pt.x();
  bool prevHorz = pt1.y() == pt.y();
  bool nextHorz = pt3.y() == pt.y();
  bool prev45 = !prevVert && !prevHorz;
  bool next45 = !nextVert && !nextHorz;
  if(!prev45 && !next45) return; //manhattan is the common case
  //if both coordinates of pt are odd or both are even no perterbations is needed
  bool oddX = pt.x() & 1;
  bool oddY = pt.y() & 1;
  if(oddX == oddY) {
    check45(pt, pt3);
    return;
  }
  if(prev45 && next45) {
    // End Cases:
    // >  \/  /\  <
    // Action: Add one to the x coordinate
    check45(pt3, pt);
    pt.x(pt.x() + 1);
    return;
  }

  //check before we perterb 
  if(next45) {
    check45(pt3, pt);
  }

  if(prevHorz || nextHorz) {
    // End Cases:
    //  _  _  _\  /_  
    //  \  /
    // Action: Add one to the x coordinate
    pt.x(pt.x() + 1);
  } else {
    if(pt.y() > pt1.y() && pt.y() > pt3.y()) {
      if(pt.x() >= pt1.x() && pt.x() >= pt3.x()) {
        // End Case:
        // /|
        pt.y(pt.y() - 1);
      } else {
        // End Case:
        // |\      -
        pt.y(pt.y() + 1);
      }
    } else if(pt.y() < pt1.y() && pt.y() < pt3.y()) {
      if(pt.x() <= pt1.x() && pt.x() <= pt3.x()) {
        // End Case:
        // |/
        pt.y(pt.y() - 1);
      } else {
        // End Case:
        // \|
        pt.y(pt.y() + 1);
      }
    } else {
      // End Cases:
      //  |    |  \   / 
      //   \  /    | |
      Point abovePt(pt1);
      Point belowPt(pt3);
      if(pt1.y() < pt3.y()) std::swap(abovePt, belowPt);
      if(abovePt.x() < pt.x()) {
        // End Case:
        //   \    -
        //    |
        pt.y(pt.y() + 1);
      } else if(abovePt.x() > pt.x()) {
        // End Case:
        //     /
        //    |
        pt.y(pt.y() - 1);
      } else if(belowPt.x() < pt.x()) {
        // End Case:
        //     |
        //    /
        pt.y(pt.y() - 1);
      } else if(belowPt.x() > pt.x()) {
        // End Case:
        //     |
        //      \    -
        pt.y(pt.y() + 1);
      }
    }
  }
}

inline void insertVertexHalfEdge45Pair(std::vector<Vertex45Compact>& output,
                                       const Point& pt1, Point& pt2, const Point& pt3, 
                                       Direction1D wdir) {
  //checkAndPerterb45(pt1, pt2, pt3);
   int multiplier = wdir == LOW ? -1 : 1;
   Vertex45Compact vertex(pt2, 0, 0);
   //std::cout << pt1 << " " << pt2 << " " << pt3 << std::endl;
   std::pair<int, int> check;
   check = characterizeEdge45(pt1, pt2); 
   //std::cout << "index " << check.first << " " << check.second * -multiplier << std::endl;
   vertex.count[check.first] += check.second * -multiplier;
   check = characterizeEdge45(pt2, pt3); 
   //std::cout << "index " << check.first << " " << check.second * multiplier << std::endl;
   vertex.count[check.first] += check.second * multiplier;
   output.push_back(vertex);
}

/// insert polygon
template <class T>
inline Polygon45Set& Polygon45Set::insert(const Polygon45Impl<T>& poly, bool isHole){
  return insertVertexSequence(poly.begin(), poly.end(), poly.winding(), isHole);
}

template <class iT>
inline Polygon45Set& Polygon45Set::insertVertexSequence(iT beginVertex, iT endVertex,
                                                        Direction1D winding, bool isHole) {
  if(beginVertex == endVertex) return *this;
  if(isHole) winding = winding.backward();
  iT itr = beginVertex;
  Point firstPt = *itr;
  ++itr;
  Point secondPt(firstPt);
  //skip any duplicate points
  do {
    if(itr == endVertex) return *this;
    secondPt = *itr;
    ++itr;
  } while(secondPt == firstPt);
  Point prevPt = secondPt;
  Point prevPrevPt = firstPt;
  while(itr != endVertex) {
    Point pt = *itr;
    //skip any duplicate points
    if(pt == prevPt) {
      ++itr;
      continue;
    }
    //operate on the three points
    insertVertexHalfEdge45Pair(data_, prevPrevPt, prevPt, pt, winding);
    prevPrevPt = prevPt;
    prevPt = pt;
    ++itr;
  }
  if(prevPt != firstPt) {
    insertVertexHalfEdge45Pair(data_, prevPrevPt, prevPt, firstPt, winding);
    insertVertexHalfEdge45Pair(data_, prevPt, firstPt, secondPt, winding);
  } else {
    insertVertexHalfEdge45Pair(data_, prevPrevPt, firstPt, secondPt, winding);
  }
  dirty_ = true;
  unsorted_ = true;
  return *this;
}

/// insert hole
template <class T>
inline Polygon45Set& Polygon45Set::insertHole(const Polygon45Impl<T>& hole){
   insert(hole, true);
   return *this;
} 

/// insert polygon with holes
template <class T>
inline Polygon45Set& Polygon45Set::insert(const Polygon45WithHolesImpl<T>& polyWithHoles){
   insert(Polygon45Impl<T>::mimicConst(polyWithHoles.yieldConst()));
   typename Polygon45WithHolesImpl<T>::iteratorHoles holeItr;
   for(holeItr = polyWithHoles.beginHoles(); holeItr != polyWithHoles.endHoles(); ++holeItr) {
      insertHole(Polygon45Impl<typename Polygon45WithHolesImpl<T>::holeType>::mimicConst(*holeItr));
   }
   return *this;
}

/// insert polygon set
inline Polygon45Set& Polygon45Set::insert(const Polygon45Set& polygonSet) {
   if(empty()) return (*this) = polygonSet;
   data_.insert(data_.end(), polygonSet.data_.begin(), polygonSet.data_.end());
   dirty_ = true;
   unsorted_ = true;
   return *this;
}

/// get the external boundary rectangle
inline Rectangle Polygon45Set::extents() const{
   if(empty()) {
      return Rectangle();
   }
   Unit low = UnitMax;
   Unit high = UnitMin;
   IntervalData xivl(low, high); 
   IntervalData yivl(low, high);
   for(Polygon45VectorData::const_iterator itr = data_.begin();
       itr != data_.end(); ++ itr) {
      if((*itr).pt.x() > xivl.get(HIGH))
         xivl.set(HIGH, (*itr).pt.x());
      if((*itr).pt.x() < xivl.get(LOW))
         xivl.set(LOW, (*itr).pt.x());
      if((*itr).pt.y() > yivl.get(HIGH))
         yivl.set(HIGH, (*itr).pt.y());
      if((*itr).pt.y() < yivl.get(LOW))
         yivl.set(LOW, (*itr).pt.y());
   }
   Rectangle box(Interval::mimic(xivl), Interval::mimic(yivl));
   return box;
}

//this function snaps the vertex and two half edges
//to be both even or both odd coordinate values if one of the edges is 45
//and throws an excpetion if an edge is non-manhattan, non-45.
inline void snapVertex45(Vertex45Compact& vertex) {
  bool plus45 = vertex.count[2] != 0;
  bool minus45 = vertex.count[0] != 0;
  if(plus45 || minus45) {
    if(abs(vertex.pt.x()) % 2 != abs(vertex.pt.y()) % 2) {
      if(vertex.count[1] != 0 ||
         plus45 && minus45) {
        //move right
        vertex.pt.x(vertex.pt.x() + 1);
      } else {
        //assert that vertex.count[3] != 0
        Unit modifier = predicated_value(plus45, -1, 1);
        vertex.pt.y(vertex.pt.y() + modifier);
      }
    }
  }
}

inline const Polygon45Set& Polygon45Set::snap() const {
  for(Polygon45VectorData::iterator itr = data_.begin();
      itr != data_.end(); ++itr) {
    snapVertex45(*itr);
  }
  return *this;
}

/// | & + * - ^ binary operators
inline Polygon45Set Polygon45Set::operator|(const Polygon45Set& b) const{
   Polygon45Set retVal(*this);
   retVal |= b;
   return retVal;
}
inline Polygon45Set Polygon45Set::operator&(const Polygon45Set& b) const{
   Polygon45Set retVal;
   b.sort_();
   sort_();
   applyBoolean_(retVal.data_, 1, b.data_);
   retVal.dirty_ = false;
   retVal.unsorted_ = false;
   return retVal;
}
inline Polygon45Set Polygon45Set::operator+(const Polygon45Set& b) const{
   return (*this) | b;
}
inline Polygon45Set Polygon45Set::operator*(const Polygon45Set& b) const{
   return (*this) & b;
}
inline Polygon45Set Polygon45Set::operator-(const Polygon45Set& b) const{
   Polygon45Set retVal;
   b.sort_();
   sort_();
   applyBoolean_(retVal.data_, 2, b.data_);
   retVal.dirty_ = false;
   retVal.unsorted_ = false;
   return retVal;
}
inline Polygon45Set Polygon45Set::operator^(const Polygon45Set& b) const{
   Polygon45Set retVal;
   b.sort_();
   sort_();
   applyBoolean_(retVal.data_, 3, b.data_);
   retVal.dirty_ = false;
   retVal.unsorted_ = false;
   return retVal;
}

/// |= &= += *= -= ^= binary operators
inline Polygon45Set& Polygon45Set::operator|=(const Polygon45Set& b){
   insert(b);
   return *this;
}
inline Polygon45Set& Polygon45Set::operator&=(const Polygon45Set& b){
   b.sort_();
   sort_();
   applyBoolean_(1, b.data_);
   dirty_ = false;
   unsorted_ = false;
   return *this;
}
inline Polygon45Set& Polygon45Set::operator+=(const Polygon45Set& b){
   return (*this) |= b;
}
inline Polygon45Set& Polygon45Set::operator*=(const Polygon45Set& b){
   return (*this) &= b;
}
inline Polygon45Set& Polygon45Set::operator-=(const Polygon45Set& b){
   b.sort_();
   sort_();
   applyBoolean_(2, b.data_);   
   dirty_ = false;
   unsorted_ = false;
   return *this;
}
inline Polygon45Set& Polygon45Set::operator^=(const Polygon45Set& b){
   b.sort_();
   sort_();
   applyBoolean_(3, b.data_);   
   dirty_ = false;
   unsorted_ = false;
   return *this;
}

/// | & + * - ^ binary operators
template <class T2>
inline Polygon45Set Polygon45Set::operator|(const Polygon45Impl<T2>& b) const{
   Polygon45Set retVal(*this);
   return retVal |= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator&(const Polygon45Impl<T2>& b) const{
   Polygon45Set retVal(*this);
   return retVal &= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator+(const Polygon45Impl<T2>& b) const{
   Polygon45Set retVal(*this);
   return retVal += b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator*(const Polygon45Impl<T2>& b) const{
   Polygon45Set retVal(*this);
   return retVal *= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator-(const Polygon45Impl<T2>& b) const{
   Polygon45Set retVal(*this);
   return retVal -= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator^(const Polygon45Impl<T2>& b) const{
   Polygon45Set retVal(*this);
   return retVal ^= b;
}

/// |= &= += *= -= ^= binary operators
template <class T2>
inline Polygon45Set& Polygon45Set::operator|=(const Polygon45Impl<T2>& b){
   return (*this) |= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator&=(const Polygon45Impl<T2>& b){
   return (*this) &= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator+=(const Polygon45Impl<T2>& b){
   return (*this) += Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator*=(const Polygon45Impl<T2>& b){
   return (*this) *= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator-=(const Polygon45Impl<T2>& b){
   return (*this) -= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator^=(const Polygon45Impl<T2>& b){
   return (*this) ^= Polygon45Set(b);
}

/// | & + * - ^ binary operators
template <class T2>
inline Polygon45Set Polygon45Set::operator|(const Polygon45WithHolesImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal |= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator&(const Polygon45WithHolesImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal &= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator+(const Polygon45WithHolesImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal += b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator*(const Polygon45WithHolesImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal *= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator-(const Polygon45WithHolesImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal -= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator^(const Polygon45WithHolesImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal ^= b;
}

/// |= &= += *= -= ^= binary operators
template <class T2>
inline Polygon45Set& Polygon45Set::operator|=(const Polygon45WithHolesImpl<T2>& b){
  return (*this) |= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator&=(const Polygon45WithHolesImpl<T2>& b){
  return (*this) &= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator+=(const Polygon45WithHolesImpl<T2>& b){
  return (*this) += Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator*=(const Polygon45WithHolesImpl<T2>& b){
  return (*this) *= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator-=(const Polygon45WithHolesImpl<T2>& b){
  return (*this) -= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator^=(const Polygon45WithHolesImpl<T2>& b){
  return (*this) ^= Polygon45Set(b);
}

/// | & + * - ^ binary operators
template <class T2>
inline Polygon45Set Polygon45Set::operator|(const RectangleImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal |= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator&(const RectangleImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal &= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator+(const RectangleImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal += b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator*(const RectangleImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal *= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator-(const RectangleImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal -= b;
}
template <class T2>
inline Polygon45Set Polygon45Set::operator^(const RectangleImpl<T2>& b) const{
  Polygon45Set retVal(*this);
  return retVal ^= b;
}

/// |= &= += *= -= ^= binary operators
template <class T2>
inline Polygon45Set& Polygon45Set::operator|=(const RectangleImpl<T2>& b){
  return (*this) |= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator&=(const RectangleImpl<T2>& b){
  return (*this) &= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator+=(const RectangleImpl<T2>& b){
  return (*this) += Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator*=(const RectangleImpl<T2>& b){
  return (*this) *= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator-=(const RectangleImpl<T2>& b){
  return (*this) -= Polygon45Set(b);
}
template <class T2>
inline Polygon45Set& Polygon45Set::operator^=(const RectangleImpl<T2>& b){
  return (*this) ^= Polygon45Set(b);
}

/// resizing operations
inline Polygon45Set Polygon45Set::operator+(Unit delta) const{
  Polygon45Set retVal(*this);
  return retVal += delta;
}
inline Polygon45Set& Polygon45Set::operator+=(Unit delta){
  if(delta > 0) return bloat(delta);
  return shrink(-delta);
}
inline Polygon45Set& Polygon45Set::operator-=(Unit delta){
  return (*this) += -delta;
}
inline Polygon45Set Polygon45Set::operator-(Unit delta) const{
  Polygon45Set retVal(*this);
  return retVal -= delta;
}

inline Polygon45Set& 
Polygon45Set::resize(Unit resizing, Polygon45Set::RoundingOption rounding,
                     Polygon45Set::CornerOption corner) {
  if(resizing == 0) return *this;
  std::list<Polygon45WithHoles> pl;
  getPolygonsWithHoles(pl);
  clear();
  for(std::list<Polygon45WithHoles>::iterator itr = pl.begin(); itr != pl.end(); ++itr) {
    insertWithResize(*itr, resizing, rounding, corner);
  }
  //perterb 45 edges to prevent non-integer intersection errors upon boolean op
  //snap();
  return *this;
}

/// shrink the Polygon45Set by shrinking
inline Polygon45Set& 
Polygon45Set::shrink(UnsignedUnit shrinking, Polygon45Set::RoundingOption rounding,
                     Polygon45Set::CornerOption corner) {
  return resize(-((Unit)shrinking), rounding, corner);
}

/// bloat the Polygon45Set by bloating
inline Polygon45Set& Polygon45Set::bloat(UnsignedUnit bloating, Polygon45Set::RoundingOption rounding,
                                         Polygon45Set::CornerOption corner) {
  return resize(bloating, rounding, corner);
}

//distance is assumed to be positive
inline Unit roundClosest(double distance) {
  Unit f = (Unit)distance;
  if(distance - (double)f < 0.5) return f;
  return f+1;
}

//distance is assumed to be positive
inline Unit roundWithOptions(double distance, Polygon45Set::RoundingOption rounding) {
    if(rounding == Polygon45Set::CLOSEST) {
      return roundClosest(distance);
    } else if(rounding == Polygon45Set::OVERSIZE) {
      return (Unit)distance + 1;
    } else { //UNDERSIZE
      return (Unit)distance;
    }
}

// 0 is east, 1 is northeast, 2 is north, 3 is northwest, 4 is west, 5 is southwest, 6 is south
// 7 is southwest
inline Point bloatVertexInDirWithOptions(const Point& point, unsigned int dir,
                                         UnsignedUnit bloating, Polygon45Set::RoundingOption rounding) {
  const double sqrt2 = 1.4142135623730950488016887242097;
  if(dir & 1) {
    Unit unitDistance = (Unit)bloating;
    if(rounding != Polygon45Set::SQRT2) {
      //45 degree bloating
      double distance = (double)bloating;
      distance /= sqrt2;  // multiply by 1/sqrt2
      unitDistance = roundWithOptions(distance, rounding);
    }
    int xMultiplier = 1;
    int yMultiplier = 1;
    if(dir == 3 || dir == 5) xMultiplier = -1;
    if(dir == 5 || dir == 7) yMultiplier = -1;
    return Point(point.x()+xMultiplier*unitDistance,
                 point.y()+yMultiplier*unitDistance);
  } else {
    if(dir == 0)
      return Point(point.x()+bloating, point.y());
    if(dir == 2)
      return Point(point.x(), point.y()+bloating);
    if(dir == 4)
      return Point(point.x()-bloating, point.y());
    if(dir == 6)
      return Point(point.x(), point.y()-bloating);
    return Point();
  }
}

inline unsigned int getEdge45Direction(const Point& pt1, const Point& pt2) {
  if(pt1.x() == pt2.x()) {
    if(pt1.y() < pt2.y()) return 2;
    return 6;
  }
  if(pt1.y() == pt2.y()) {
    if(pt1.x() < pt2.x()) return 0;
    return 4;
  }
  if(pt2.y() > pt1.y()) {
    if(pt2.x() > pt1.x()) return 1;
    return 3;
  }
  if(pt2.x() > pt1.x()) return 7;
  return 5;
}

inline unsigned int getEdge45NormalDirection(unsigned int dir, int multiplier) {
  if(multiplier < 0)
    return (dir + 2) % 8;
  return (dir + 4 + 2) % 8;
}

inline Point getIntersectionPoint(const Point& pt1, unsigned int slope1,
                                  const Point& pt2, unsigned int slope2) {
  //the intention here is to use all integer arithmetic without causing overflow
  //turncation error or divide by zero error
  //I don't use floating point arithmetic because its precision may not be high enough
  //at the extremes of the integer range
  const Unit rises[8] = {0, 1, 1, 1, 0, -1, -1, -1};
  const Unit runs[8] = {1, 1, 0, -1, -1, -1, 0, 1};
  LongUnit rise1 = rises[slope1];
  LongUnit rise2 = rises[slope2];
  LongUnit run1 = runs[slope1];
  LongUnit run2 = runs[slope2];
  LongUnit x1 = (LongUnit)pt1.x();
  LongUnit x2 = (LongUnit)pt2.x();
  LongUnit y1 = (LongUnit)pt1.y();
  LongUnit y2 = (LongUnit)pt2.y();
  Unit x = 0;
  Unit y = 0;
  if(run1 == 0) {
    x = pt1.x();
    y = (Unit)(((x1 - x2) * rise2) / run2) + pt2.y(); 
  } else if(run2 == 0) {
    x = pt2.x();
    y = (Unit)(((x2 - x1) * rise1) / run1) + pt1.y();
  } else {
    // y - y1 = (rise1/run1)(x - x1)
    // y - y2 = (rise2/run2)(x - x2)
    // y = (rise1/run1)(x - x1) + y1 = (rise2/run2)(x - x2) + y2
    // (rise1/run1 - rise2/run2)x = y2 - y1 + rise1/run1 x1 - rise2/run2 x2
    // x = (y2 - y1 + rise1/run1 x1 - rise2/run2 x2)/(rise1/run1 - rise2/run2)
    // x = (y2 - y1 + rise1/run1 x1 - rise2/run2 x2)(rise1 run2 - rise2 run1)/(run1 run2)
    x = (Unit)((y2 - y1 + ((rise1 * x1) / run1) - ((rise2 * x2) / run2)) * 
               (run1 * run2) / (rise1 * run2 - rise2 * run1));
    if(rise1 == 0) {
      y = pt1.y();
    } else if(rise2 == 0) {
      y = pt2.y();
    } else {
      // y - y1 = (rise1/run1)(x - x1)
      // (run1/rise1)(y - y1) = x - x1
      // x = (run1/rise1)(y - y1) + x1 = (run2/rise2)(y - y2) + x2
      y = (Unit)((x2 - x1 + ((run1 * y1) / rise1) - ((run2 * y2) / rise2)) * 
                 (rise1 * rise2) / (run1 * rise2 - run2 * rise1));
    }
  }
  return Point(x, y);
}

inline
void handleResizingEdge45(Polygon45Set& sizingSet, Point first, 
                          Point second, Unit resizing, Polygon45Set::RoundingOption rounding) {
  if(first.x() == second.x()) {
    sizingSet += Rectangle(first.x() - resizing, first.y(), first.x() + resizing, second.y());
    return;
  }
  if(first.y() == second.y()) {
    sizingSet += Rectangle(first.x(), first.y() - resizing, second.x(), first.y() + resizing);
    return;
  }
  //edge is 45
  std::vector<Point> pts;
  UnsignedUnit bloating = abs(resizing);
  if(second.x() < first.x()) std::swap(first, second);
  if(first.y() < second.y()) {
    pts.push_back(bloatVertexInDirWithOptions(first, 3, bloating, rounding));
    pts.push_back(bloatVertexInDirWithOptions(first, 7, bloating, rounding));
    pts.push_back(bloatVertexInDirWithOptions(second, 7, bloating, rounding));
    pts.push_back(bloatVertexInDirWithOptions(second, 3, bloating, rounding));
    sizingSet.insertVertexSequence(pts.begin(), pts.end(), HIGH, false);
  } else {
    pts.push_back(bloatVertexInDirWithOptions(first, 1, bloating, rounding));
    pts.push_back(bloatVertexInDirWithOptions(first, 5, bloating, rounding));
    pts.push_back(bloatVertexInDirWithOptions(second, 5, bloating, rounding));
    pts.push_back(bloatVertexInDirWithOptions(second, 1, bloating, rounding));
    sizingSet.insertVertexSequence(pts.begin(), pts.end(), HIGH, false);
  }
}

inline
void handleResizingVertex45(Polygon45Set& sizingSet, const Point& first, 
                            const Point& second, const Point& third, Unit resizing, 
                            Polygon45Set::RoundingOption rounding, Polygon45Set::CornerOption corner, 
                            int multiplier) {
  unsigned int edge1 = getEdge45Direction(first, second);
  unsigned int edge2 = getEdge45Direction(second, third);
  unsigned int diffAngle;
  if(multiplier < 0) 
    diffAngle = (edge2 + 8 - edge1) % 8;
  else
    diffAngle = (edge1 + 8 - edge2) % 8;
  if(diffAngle < 4) {
    if(resizing > 0) return; //accute interior corner
    else multiplier *= -1; //make it appear to be an accute exterior angle
  }
  unsigned int normal1 = getEdge45NormalDirection(edge1, multiplier);
  unsigned int normal2 = getEdge45NormalDirection(edge2, multiplier);
  UnsignedUnit bloating = abs(resizing);
  Point edgePoint1 = bloatVertexInDirWithOptions(second, normal1, bloating, rounding);
  Point edgePoint2 = bloatVertexInDirWithOptions(second, normal2, bloating, rounding);
  //if the change in angle is 135 degrees it is an accute exterior corner
  if((edge1+ multiplier * 3) % 8 == edge2) {
    if(corner == Polygon45Set::ORTHOGINAL) {
      sizingSet += Rectangle(edgePoint1, edgePoint2);
      return;
    }
  } 
  std::vector<Point> pts;
  pts.push_back(edgePoint1);
  pts.push_back(second);
  pts.push_back(edgePoint2);
  if(edgePoint1 != edgePoint2) {
    pts.push_back(getIntersectionPoint(edgePoint1, edge1, edgePoint2, edge2));
    Polygon45 poly(pts.begin(), pts.end());
    sizingSet += poly;
  }
}

/// accumulate the bloated polygon with holes
template <class T2>
inline Polygon45Set& 
Polygon45Set::insertWithResize(const Polygon45Impl<T2>& poly,
                               Unit resizing, Polygon45Set::RoundingOption rounding,
                               Polygon45Set::CornerOption corner,
                               bool hole) {
  Direction1D wdir = poly.winding();
  int multiplier = wdir == LOW ? -1 : 1;
  if(hole) multiplier *= -1;
  //if(resizing < 0) {
    //multiplier *= -1;
    //resizing *= -1;
  //}
  typedef typename Polygon45Impl<T2>::iterator piterator;
  piterator first, second, third, end;
  third = poly.begin();
  first = third;
  ++third;
  second = end = third;
  ++third;
  Polygon45Set sizingSet;
  do {
    handleResizingEdge45(sizingSet, *first, *second, resizing, rounding);
    handleResizingVertex45(sizingSet, *first, *second, *third, resizing, rounding, corner, multiplier);
    first = second;
    second = third;
    ++third;
    if(third == poly.end()) {
      third = poly.begin();
      if(*second == *third) {
        ++third; //skip first point if it is duplicate of last point
      }
    }
  } while(second != end);
  //sizingSet.snap();
  Polygon45Set tmp;
  tmp.insert(poly, hole);
  if(hole) {
    std::vector<Point> pts;
    pts.reserve(4);
    pts.push_back(Point(UnitMin, UnitMin));
    pts.push_back(Point(UnitMin, UnitMax));
    pts.push_back(Point(UnitMax, UnitMax));
    pts.push_back(Point(UnitMax, UnitMin));
    tmp.insertVertexSequence(pts.begin(), pts.end(), LOW, false);
    //tmp.snap();
    if(resizing < 0) tmp -= sizingSet;
    else tmp += sizingSet;
    tmp.clean_();
    tmp.insertVertexSequence(pts.begin(), pts.end(), LOW, true);
    //tmp.snap();
  } else {
    if(resizing < 0) tmp -= sizingSet;
    else tmp += sizingSet;
    tmp.clean_();
  }
  return (*this) += tmp;
}

/// accumulate the bloated polygon with holes
template <class T2>
inline Polygon45Set& 
Polygon45Set::insertWithResize(const Polygon45WithHolesImpl<T2>& poly,
                               Unit resizing, Polygon45Set::RoundingOption rounding,
                               Polygon45Set::CornerOption corner) {
  insertWithResize(poly.mimicConstPolygon(), resizing, rounding, corner);
  for(typename Polygon45WithHolesImpl<T2>::iteratorHoles hiter = poly.beginHoles();
      hiter != poly.endHoles(); ++hiter) {
    typedef Polygon45Impl<typename Polygon45WithHolesImpl<T2>::holeType> PT;
    insertWithResize(PT::mimicConst(*hiter), resizing, rounding, corner, true);
  }
  return *this;
}

/// get the area of the set 
inline double Polygon45Set::area() const {
   clean_();
   std::vector<Polygon45> polys;
   getPolygons(polys);
   double retVal = 0;
   for(std::vector<Polygon45>::iterator itr = polys.begin();
       itr != polys.end(); ++itr) {
      retVal += (*itr).area();
   }
   return retVal;
}

/// transform set
inline Polygon45Set& Polygon45Set::transform(const AxisTransform& atr){
   clean_();
   std::vector<Polygon45WithHoles> polys;
   getPolygonsWithHoles(polys);
   for(std::vector<Polygon45WithHoles>::iterator itr = polys.begin();
       itr != polys.end(); ++itr) {
     (*itr).transform(atr);
   }
   clear();
   insert(polys.begin(), polys.end());
   dirty_ = true; 
   unsorted_ = true;
   return *this;
}
    
/// transform set
inline Polygon45Set& Polygon45Set::transform(const Transform& tr){
   clean_();
   std::vector<Polygon45WithHoles> polys;
   getPolygonsWithHoles(polys);
   for(std::vector<Polygon45WithHoles>::iterator itr = polys.begin();
       itr != polys.end(); ++itr) {
     (*itr).transform(tr);
   }
   clear();
   insert(polys.begin(), polys.end());
   dirty_ = true; 
   unsorted_ = true;
   return *this;
}

inline Polygon45Set& Polygon45Set::scaleUp(UnsignedUnit factor) {
     clean_();
   std::vector<Polygon45WithHoles> polys;
   getPolygonsWithHoles(polys);
   for(std::vector<Polygon45WithHoles>::iterator itr = polys.begin();
       itr != polys.end(); ++itr) {
     (*itr).scaleUp(factor);
   }
   clear();
   insert(polys.begin(), polys.end());
   dirty_ = true; 
   unsorted_ = true;
   return *this;
}

inline Polygon45Set& Polygon45Set::scaleDown(UnsignedUnit factor) {
     clean_();
   std::vector<Polygon45WithHoles> polys;
   getPolygonsWithHoles(polys);
   for(std::vector<Polygon45WithHoles>::iterator itr = polys.begin();
       itr != polys.end(); ++itr) {
     (*itr).scaleDown(factor);
   }
   clear();
   insert(polys.begin(), polys.end());
   dirty_ = true; 
   unsorted_ = true;
   return *this;
}


// inline Polygon45Set& Polygon45Set::growAnd(UnsignedUnit westDelta,
//                                        UnsignedUnit eastDelta,
//                                        UnsignedUnit southDelta,
//                                        UnsignedUnit northDelta) {
//    std::vector<Polygon> polys;
//    getPolygons(polys);
//    clear();
//    for(unsigned int i = 0; i < polys.size(); ++i) {
//       Polygon45Set tmpPs(orient_, polys[i]);
//       tmpPs.bloat(westDelta, eastDelta, southDelta, northDelta);
//       tmpPs.clean_(); //apply implicit OR on tmp polygon set
//       insert(tmpPs);
//    }
//    return selfIntersect();
// }

// inline Polygon45Set& Polygon45Set::growAnd(Direction2D dir, UnsignedUnit bloating) {
//    if(dir == WEST) return growAnd(bloating, 0, 0, 0);
//    if(dir == EAST) return growAnd(0, bloating, 0, 0);
//    if(dir == SOUTH) return growAnd(0, 0, bloating, 0);
//    return growAnd(0, 0, 0, bloating);
// }

// inline Polygon45Set& Polygon45Set::growAnd(UnsignedUnit bloating) {
//    return growAnd(bloating, bloating, bloating, bloating);
// }

// inline Polygon45Set& Polygon45Set::growAnd(Orientation2D orient, UnsignedUnit lowDelta,
//                                        UnsignedUnit highDelta) {
//    if(orient == HORIZONTAL) {
//       return growAnd(lowDelta, highDelta, 0, 0);
//    }
//    return growAnd(0, 0, lowDelta, highDelta);
// }

// inline Polygon45Set& Polygon45Set::growAnd(Orientation2D orient, UnsignedUnit bloating) {
//    if(orient == HORIZONTAL) {
//       return growAnd(bloating, bloating, 0, 0);
//    }
//    return growAnd(0, 0, bloating, bloating);
// }

// inline Polygon45Set& Polygon45Set::interact(const Polygon45Set& that) {
//    if(that.dirty_) that.clean_();
//    TouchSetData tsd;
//    populateTouchSetData(tsd, that.data_, 0);
//    std::vector<Polygon> polys;
//    getPolygons(polys);
//    std::vector<std::set<int> > graph(polys.size()+1, std::set<int>());
//    for(unsigned int i = 0; i < polys.size(); ++i){
//       Polygon45Set psTmp(that.orient_, polys[i]);
//       psTmp.clean_();
//       if(psTmp.extents() == Rectangle(3155,28560,3325,29040)) std::cout << "Error ID, " << i+1 << std::endl;
//       populateTouchSetData(tsd, psTmp.data_, i+1);
//    }
//    performTouch(graph, tsd);
//    clear();
//    for(std::set<int>::iterator itr = graph[0].begin(); itr != graph[0].end(); ++itr){
//       insert(polys[(*itr)-1]);
//    }
//    dirty_ = false;
//    return *this;
// }

// inline Polygon45Set Polygon45Set::interaction(const Polygon45Set& that) {
//    Polygon45Set tmp = (*this);
//    return tmp.interact(that);
// }

// inline Polygon45Set& Polygon45Set::selfIntersect() {
//    insertHole(extents());
//    clean_(); //apply implicit OR on polygon set with effect of performing self intersection
//    return *this;
// }

// inline Polygon45Set Polygon45Set::selfIntersection() {
//    Polygon45Set tmp(*this);
//    return tmp.selfIntersect();
// }

// inline Polygon45Set& Polygon45Set::keep(UnsignedLongUnit minArea, UnsignedLongUnit maxArea, 
//                                         UnsignedUnit minWidth, UnsignedUnit maxWidth, 
//                                         UnsignedUnit minHeight, UnsignedUnit maxHeight) {
//    std::list<Polygon45> polys;
//    getPolygons(polys);
//    clear();
//    for(std::list<Polygon45>::iterator itr = polys.begin(); itr != polys.end(); ++itr){
//       Rectangle bbox = (*itr).boundingBox();
//       UnsignedUnit pwidth = bbox.delta(HORIZONTAL);
//       if(pwidth > minWidth && pwidth <= maxWidth){
//          UnsignedUnit pheight = bbox.delta(VERTICAL);
//          if(pheight > minHeight && pheight <= maxHeight){
//             UnsignedLongUnit parea = (*itr).area();
//             if(parea <= maxArea && parea >= minArea) {
//                insert(*itr);
//             }
//          }
//       }
//    }
//    return *this;
// }

inline void Polygon45Set::sort_() const {
   if(unsorted_) {
      std::sort(data_.begin(), data_.end());
      unsorted_ = false;
   }
}

inline void Polygon45Set::clean_() const {
   if(unsorted_) sort_();
   if(dirty_) {
      Polygon45VectorData empty;
      applyBoolean_(0, empty);
      dirty_ = false;
   }
}

inline void Polygon45Set::applyBoolean_(int op, Polygon45VectorData& rvalue) const {
   Polygon45VectorData tmp;
   applyBoolean_(tmp, op, rvalue);
   data_.swap(tmp); //swapping vectors should be constant time operation
   unsorted_ = false;
   dirty_ = false;
}

inline void Polygon45Set::applyBoolean_(Polygon45VectorData& result, int op, 
                                        Polygon45VectorData& rvalue) const {
  unsigned int originalSize = result.size();
  try {
    applyBooleanException_(result, op, rvalue);
  } catch (std::string str) {
    string msg = "GTL 45 Boolean error, precision insufficient to represent edge intersection coordinate value.";
    if(str == msg) {
      result.resize(originalSize);
      snap();
      std::sort(data_.begin(), data_.end());
      for(Polygon45VectorData::iterator itr = rvalue.begin();
          itr != rvalue.end(); ++itr) {
        snapVertex45(*itr);
      }
      std::sort(rvalue.begin(), rvalue.end());
      applyBooleanException_(result, op, rvalue);
    } else { throw str; }
  }
}

inline void Polygon45Set::applyBooleanException_(Polygon45VectorData& result, int op, 
                                                 Polygon45VectorData& rvalue) const {
   Scan45 scan45(op);
   std::vector<Vertex45> eventOut;
   std::vector<Scan45Vertex> eventIn;
   Polygon45VectorData::const_iterator iter1 = data_.begin();
   Polygon45VectorData::const_iterator iter2 = rvalue.begin();
   Polygon45VectorData::const_iterator end1 = data_.end();
   Polygon45VectorData::const_iterator end2 = rvalue.end();
   Unit x = UnitMax;
   while(iter1 != end1 || iter2 != end2) {
      Unit currentX = UnitMax;
      if(iter1 != end1) currentX = iter1->pt.x();
      if(iter2 != end2) currentX = min(currentX, iter2->pt.x());
      if(currentX != x) {
         //std::cout << "SCAN " << currentX << "\n";
         //scan event
         scan45.scan(eventOut, eventIn.begin(), eventIn.end());
         std::sort(eventOut.begin(), eventOut.end());
         for(unsigned int i = 0; i < eventOut.size(); ++i) {
            if(!result.empty() &&
               result.back().pt == eventOut[i].pt) {
               result.back().count += eventOut[i];
            } else {
               result.push_back(eventOut[i]);
            }
            if(result.back().count == Vertex45Count(0, 0, 0, 0)) {
               result.pop_back();
            }
         }
         eventOut.clear();
         eventIn.clear();
         x = currentX;
      }
      //std::cout << "get next\n";
      if(iter2 != end2 && (iter1 == end1 || iter2->pt.x() < iter1->pt.x() || 
                           (iter2->pt.x() == iter1->pt.x() &&
                            iter2->pt.y() < iter1->pt.y()) )) {
        //std::cout << "case1 next\n";
        eventIn.push_back(Scan45Vertex(iter2->pt, Scan45Count(Count2(0, iter2->count[0]),
                                                              Count2(0, iter2->count[1]),
                                                              Count2(0, iter2->count[2]),
                                                              Count2(0, iter2->count[3]))));
        ++iter2;
      } else if(iter1 != end1 && (iter2 == end2 || iter1->pt.x() < iter2->pt.x() || 
                                  (iter1->pt.x() == iter2->pt.x() &&
                                   iter1->pt.y() < iter2->pt.y()) )) {
        //std::cout << "case2 next\n";
        eventIn.push_back(Scan45Vertex(iter1->pt, Scan45Count(Count2(iter1->count[0], 0),
                                                              Count2(iter1->count[1], 0),
                                                              Count2(iter1->count[2], 0),
                                                              Count2(iter1->count[3], 0))));
        ++iter1;
      } else {
      //std::cout << "case3 next\n";
        eventIn.push_back(Scan45Vertex(iter2->pt, Scan45Count(Count2(iter1->count[0], iter2->count[0]),
                                                              Count2(iter1->count[1], iter2->count[1]),
                                                              Count2(iter1->count[2], iter2->count[2]),
                                                              Count2(iter1->count[3], iter2->count[3]))));
        ++iter1;
        ++iter2;
      }
   }
   scan45.scan(eventOut, eventIn.begin(), eventIn.end());
   std::sort(eventOut.begin(), eventOut.end());
   for(unsigned int i = 0; i < eventOut.size(); ++i) {
      if(!result.empty() &&
         result.back().pt == eventOut[i].pt) {
         result.back().count += eventOut[i];
      } else {
         result.push_back(eventOut[i]);
      }
      if(result.back().count == Vertex45Count(0, 0, 0, 0)) {
         result.pop_back();
      }
   }
   //std::cout << "DONE SCANNING\n";
}


inline std::ostream& operator<< (std::ostream& o, const Polygon45Set& p) {
   o << "Polygon45Set ";
   o << " " << p.unsorted_ << " " << p.dirty_ << " { ";
   for(Polygon45VectorData::const_iterator itr = p.data_.begin();
       itr != p.data_.end(); ++itr) {
      o << (*itr) << "; ";
   }
   o << "} ";
   return o;
}

inline std::istream& operator>> (std::istream& i, Polygon45Set& p) {
  p.clear();
  char name[14];
  char spc;
  i.get(spc);
  while(spc == ' ') {
    i.get(spc);
  }
  i.unget();
  i.get(name, 13);
  i >> p.unsorted_ >> p.dirty_;
  std::stringstream strstr;
  i.get(*(strstr.rdbuf()), '}');
  char openbrace;
  do {
    strstr.get(openbrace);
  } while (openbrace != '{');
  char lastchar;
  strstr.get(lastchar);
  while(strstr.good()) {
    if(lastchar != ' ') {
      strstr.unget();
      Unit x, y;
      int a, b, c, d;
      strstr >> x >> y >> lastchar >> a>> lastchar >> b >> lastchar>> c >> lastchar >> d >> lastchar; 
      Vertex45Compact element;
      element.pt = Point(x, y);
      element.count = Vertex45Count(a, b, c, d);
      p.data_.push_back(element);
    }
    strstr.get(lastchar);
  }
  char closebrace;
  i.get(closebrace);
  return i;
}

inline bool testPolygon45SetRect() {
   std::vector<Point> points;
   points.push_back(Point(0,0));
   points.push_back(Point(0,10));
   points.push_back(Point(10,10));
   points.push_back(Point(10,0));
   Polygon45 poly;
   poly.set(points.begin(), points.end());
   Polygon45Set ps;
   ps.insert(poly);
   std::vector<Polygon45> polys;
   ps.getPolygons(polys);
   std::cout << polys.size() << std::endl;
   for(unsigned int i = 0; i < polys.size(); ++i) {
      std::cout << polys[i] << std::endl;
   }
   return true;
}

inline bool testPolygon45Set() {
   Polygon45Formation pf(true);
   std::vector<Vertex45> data;
   // result == 0 8 -1 1
   data.push_back(Vertex45(Point(0, 8), -1, 1));
   // result == 0 8 1 -1
   data.push_back(Vertex45(Point(0, 8), 1, -1));
   // result == 4 0 1 1
   data.push_back(Vertex45(Point(4, 0), 1, 1));
   // result == 4 0 2 1
   data.push_back(Vertex45(Point(4, 0), 2, 1));
   // result == 4 4 2 -1
   data.push_back(Vertex45(Point(4, 4), 2, -1));
   // result == 4 4 -1 -1
   data.push_back(Vertex45(Point(4, 4), -1, -1));
   // result == 4 12 1 1
   data.push_back(Vertex45(Point(4, 12), 1, 1));
   // result == 4 12 2 1
   data.push_back(Vertex45(Point(4, 12), 2, 1));
   // result == 4 16 2 -1
   data.push_back(Vertex45(Point(4, 16), 2, 1));
   // result == 4 16 -1 -1
   data.push_back(Vertex45(Point(4, 16), -1, -1));
   // result == 6 2 1 -1
   data.push_back(Vertex45(Point(6, 2), 1, -1));
   // result == 6 14 -1 1
   data.push_back(Vertex45(Point(6, 14), -1, 1));
   // result == 6 2 -1 1
   data.push_back(Vertex45(Point(6, 2), -1, 1));
   // result == 6 14 1 -1
   data.push_back(Vertex45(Point(6, 14), 1, -1));
   // result == 8 0 -1 -1
   data.push_back(Vertex45(Point(8, 0), -1, -1));
   // result == 8 0 2 -1
   data.push_back(Vertex45(Point(8, 0), 2, -1));
   // result == 8 4 2 1
   data.push_back(Vertex45(Point(8, 4), 2, 1));
   // result == 8 4 1 1
   data.push_back(Vertex45(Point(8, 4), 1, 1));
   // result == 8 12 -1 -1
   data.push_back(Vertex45(Point(8, 12), -1, -1));
   // result == 8 12 2 -1
   data.push_back(Vertex45(Point(8, 12), 2, -1));
   // result == 8 16 2 1
   data.push_back(Vertex45(Point(8, 16), 2, 1));
   // result == 8 16 1 1
   data.push_back(Vertex45(Point(8, 16), 1, 1));
   // result == 12 8 1 -1
   data.push_back(Vertex45(Point(12, 8), 1, -1));
   // result == 12 8 -1 1
   data.push_back(Vertex45(Point(12, 8), -1, 1));

   data.push_back(Vertex45(Point(6, 4), 1, -1));
   data.push_back(Vertex45(Point(6, 4), 2, -1));
   data.push_back(Vertex45(Point(6, 12), -1, 1));
   data.push_back(Vertex45(Point(6, 12), 2, 1));
   data.push_back(Vertex45(Point(10, 8), -1, -1));
   data.push_back(Vertex45(Point(10, 8), 1, 1));

   std::sort(data.begin(), data.end());
   std::vector<Polygon45> polys;
   pf.scan(polys, data.begin(), data.end());
   Polygon45Set ps;
   std::cout << "inserting1\n";
   //std::vector<Point> points;
   //points.push_back(Point(0,0));
   //points.push_back(Point(0,10));
   //points.push_back(Point(10,10));
   //points.push_back(Point(10,0));
   //Polygon45 poly;
   //poly.set(points.begin(), points.end());
   //ps.insert(poly);
   ps.insert(polys[0]);

   Polygon45Set ps2;
   std::cout << "inserting2\n";
   ps2.insert(polys[0]);
   std::cout << "applying boolean\n";
   ps |= ps2;
   std::vector<Polygon45> polys2;
   std::cout << "getting result\n";
   ps.getPolygons(polys2);
   std::cout << ps2 << std::endl;
   std::cout << ps << std::endl;
   std::cout << polys[0] << std::endl;
   std::cout << polys2[0] << std::endl;
   if(polys != polys2) std::cout << "test Polygon45Set failed\n";
   return polys == polys2;
   return true;
}

inline bool testPolygon45SetPerterbation() {
   Polygon45Formation pf(true);
   std::vector<Vertex45> data;
   // result == 0 8 -1 1
   data.push_back(Vertex45(Point(0, 80), -1, 1));
   // result == 0 8 1 -1
   data.push_back(Vertex45(Point(0, 80), 1, -1));
   // result == 4 0 1 1
   data.push_back(Vertex45(Point(40, 0), 1, 1));
   // result == 4 0 2 1
   data.push_back(Vertex45(Point(40, 0), 2, 1));
   // result == 4 4 2 -1
   data.push_back(Vertex45(Point(40, 40), 2, -1));
   // result == 4 4 -1 -1
   data.push_back(Vertex45(Point(40, 40), -1, -1));
   // result == 4 12 1 1
   data.push_back(Vertex45(Point(40, 120), 1, 1));
   // result == 4 12 2 1
   data.push_back(Vertex45(Point(40, 120), 2, 1));
   // result == 4 16 2 -1
   data.push_back(Vertex45(Point(40, 160), 2, 1));
   // result == 4 16 -1 -1
   data.push_back(Vertex45(Point(40, 160), -1, -1));
   // result == 6 2 1 -1
   data.push_back(Vertex45(Point(60, 20), 1, -1));
   // result == 6 14 -1 1
   data.push_back(Vertex45(Point(60, 140), -1, 1));
   // result == 6 2 -1 1
   data.push_back(Vertex45(Point(60, 20), -1, 1));
   // result == 6 14 1 -1
   data.push_back(Vertex45(Point(60, 140), 1, -1));
   // result == 8 0 -1 -1
   data.push_back(Vertex45(Point(80, 0), -1, -1));
   // result == 8 0 2 -1
   data.push_back(Vertex45(Point(80, 0), 2, -1));
   // result == 8 4 2 1
   data.push_back(Vertex45(Point(80, 40), 2, 1));
   // result == 8 4 1 1
   data.push_back(Vertex45(Point(80, 40), 1, 1));
   // result == 8 12 -1 -1
   data.push_back(Vertex45(Point(80, 120), -1, -1));
   // result == 8 12 2 -1
   data.push_back(Vertex45(Point(80, 120), 2, -1));
   // result == 8 16 2 1
   data.push_back(Vertex45(Point(80, 160), 2, 1));
   // result == 8 16 1 1
   data.push_back(Vertex45(Point(80, 160), 1, 1));
   // result == 12 8 1 -1
   data.push_back(Vertex45(Point(120, 80), 1, -1));
   // result == 12 8 -1 1
   data.push_back(Vertex45(Point(120, 80), -1, 1));

   data.push_back(Vertex45(Point(60, 40), 1, -1));
   data.push_back(Vertex45(Point(60, 40), 2, -1));
   data.push_back(Vertex45(Point(60, 120), -1, 1));
   data.push_back(Vertex45(Point(60, 120), 2, 1));
   data.push_back(Vertex45(Point(100, 80), -1, -1));
   data.push_back(Vertex45(Point(100, 80), 1, 1));

   std::sort(data.begin(), data.end());
   std::vector<Polygon45> polys;
   pf.scan(polys, data.begin(), data.end());
   Polygon45Set ps;
   std::cout << "inserting1\n";
   //std::vector<Point> points;
   //points.push_back(Point(0,0));
   //points.push_back(Point(0,10));
   //points.push_back(Point(10,10));
   //points.push_back(Point(10,0));
   //Polygon45 poly;
   //poly.set(points.begin(), points.end());
   //ps.insert(poly);
   Polygon45Set preps(polys[0]);
   
   polys[0].move(0, 1);
   ps.insert(polys[0]);

   Polygon45Set ps2;
   std::cout << "inserting2\n";
   ps2.insert(polys[0]);
   std::cout << "applying boolean\n";
   ps |= ps2;
   std::vector<Polygon45> polys2;
   std::cout << "getting result\n";
   ps.getPolygons(polys2);
   std::cout << preps << std::endl;
   std::cout << ps2 << std::endl;
   std::cout << ps << std::endl;
   std::cout << polys[0] << std::endl;
   std::cout << polys2[0] << std::endl;
   //if(polys != polys2) std::cout << "test Polygon45Set failed\n";
   //return polys == polys2;
   return true;
}
