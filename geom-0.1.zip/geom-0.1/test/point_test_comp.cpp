// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/geom/point.hpp>
#include <boost/geom/point_xy.hpp>
#include <boost/geom/point_xyz.hpp>
#include <boost/geom/box.hpp>
#include <boost/geom/std_complex.hpp>

#ifdef BOOST_GEOM_TEST_QT
#include <boost/geom/qt/point.hpp>
#endif

#ifdef BOOST_GEOM_TEST_GDI
#include <boost/geom/gdi/point.hpp>
#endif

#ifdef BOOST_GEOM_TEST_X
#include <boost/geom/x/point.hpp>
#endif

template<typename point_impl>
void test_basic()
{
	typedef boost::geom::point<point_impl> point;

	point pt;

	pt.y()=pt.x();
	pt.z()=pt.y();
	pt.x()=pt.z();
	pt.theta()=pt.rho();
	pt.rho()=pt.phi();

	point_impl imp;
	pt=imp;

	point pt2=imp;

	pt=pt2;

	pt2=imp;

	pt+=pt2;
	
	pt=pt2+imp;
	pt=pt+pt2;

	pt=pt2-imp;
	pt=pt2+pt;

	pt*=3;
	pt/=4;

	pt=pt*3-imp+pt2;
	pt=pt2/4+imp-pt*3;

	if(pt==imp && pt2==pt) {};
	if(pt!=imp || pt2!=pt) {};

	// Now constness

	const point pt3;

	pt.x()=pt3.x();
	pt.y()=pt3.y();
	pt.z()=pt3.z();
	pt.rho()=pt3.rho();
	pt.theta()=pt3.theta();
	pt.phi()=pt3.phi();

	pt=pt3;

	pt+=pt3;
	
	pt=pt3+imp;
	pt=pt+pt3;

	pt=pt3-imp;
	pt=pt3+pt;

	pt=pt3*3-imp+pt3;
	pt=pt3/4+imp-pt3*3;

	if((pt3==imp && pt3==pt) && pt==pt3) {};
	if((pt3!=imp || pt3!=pt) && pt != pt3) {};
	
}

template<typename point_impl1, typename point_impl2>
void test_mix()
{
	typedef boost::geom::point<point_impl1> point1;
	typedef boost::geom::point<point_impl2> point2;

	point1 pt1;
	point_impl1 pt1_impl;

	point2 pt2;
	point_impl2 pt2_impl;

	pt1=pt2;
	pt1=-pt2;
	pt1+=pt2;
	pt1-=pt2;
	if(pt1==pt2 || pt1 != pt2){};

	pt1=pt2_impl;
	pt1+=pt2_impl;
	pt1-=pt2_impl;
	if(pt1==pt2_impl || pt1 != pt2_impl){};

	pt2=pt1;
	pt2=-pt1;
	pt2+=pt1;
	pt2-=pt1;
	if(pt2==pt1 || pt2 != pt1){};

	pt2=pt1_impl;
	pt2+=pt1_impl;
	pt2-=pt1_impl;
	if(pt2==pt1_impl || pt2 != pt1_impl){};

}

int main()
{
	using namespace boost::geom;
	
	test_basic< point_xyz<int> >();
	test_basic< point_xyz<double> >();
	test_basic< point_xy<float> >();
	test_basic< point_xy<short> >();
	test_basic< std::complex<double> >();
	test_basic< std::complex<float> >();

	test_mix<std::complex<float>, point_xy<float> >();
	test_mix<std::complex<int>, point_xyz<int> >();
	test_mix<point_xy<short>, point_xyz<short> >();
	
#ifdef BOOST_GEOM_TEST_QT
	test_basic<QPoint>();
	test_mix<QPoint, point_xy<QCOORD> >();
	test_mix<QPoint, point_xyz<QCOORD> >();
	test_mix<QPoint, std::complex<QCOORD> >();
#endif

#ifdef BOOST_GEOM_TEST_GDI
	test_basic<POINT>();
	test_mix<POINT, point_xy<LONG> >();
	test_mix<POINT, point_xyz<LONG> >();
	test_mix<POINT, std::complex<LONG> >();
#endif

#ifdef BOOST_GEOM_TEST_X
	test_basic<XPoint>();
	test_mix<XPoint, point_xy<short> >();
	test_mix<XPoint, point_xyz<short> >();
	test_mix<XPoint, std::complex<short> >();
#endif

}
