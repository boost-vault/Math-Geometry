/*
(***********************************************************************)
(*                                                                     *)
(* Wykobi Computational Geometry Library                               *)
(* Release Version 0.0.2                                               *)
(* http://www.wykobi.com                                               *)
(* Copyright (c) 2005-2006 Arash Partow, All Rights Reserved.          *)
(*                                                                     *)
(* The Wykobi computational geometry library and its components are    *)
(* supplied under the terms of the General Wykobi License agreement.   *)
(* The contents of the Wykobi computational geometry library and its   *)
(* components may not be copied or disclosed except in accordance with *)
(* the terms of that agreement.                                        *)
(*                                                                     *)
(* URL: http://www.wykobi.com/license.html                             *)
(*                                                                     *)
(***********************************************************************)
*/


#ifndef INCLUDE_WYKOBI_GRAPHICS_NET
#define INCLUDE_WYKOBI_GRAPHICS_NET

#include <iostream>
#include <iterator>
#include <vector>
#include <string>

#include <math.h>
#include <vcclr.h>

#include "wykobi.h"


using namespace System;
using namespace System::Drawing;

namespace wykobi
{
   template<typename T>
   class wykobi_graphics_net
   {
      public:

         wykobi_graphics_net(Graphics^ _gc, unsigned int w, unsigned int h):gc(_gc),width(w),height(h)
         {
            pen = gcnew Pen(System::Drawing::Color::Black,2);
         }

        ~wykobi_graphics_net()
         {
            delete gc;
         }

         inline void set_pen(Pen^ _pen)
         {
            pen = pen;
         }

         inline void set_pen_color(unsigned int color)
         {
            switch(color)
            {
               case  0 : pen->Color = System::Drawing::Color::Aqua;
               case  1 : pen->Color = System::Drawing::Color::Black;
               case  2 : pen->Color = System::Drawing::Color::Blue;
               case  3 : pen->Color = System::Drawing::Color::Brown;
               case  4 : pen->Color = System::Drawing::Color::Cyan;
               case  5 : pen->Color = System::Drawing::Color::Gray;
               case  6 : pen->Color = System::Drawing::Color::Green;
               case  7 : pen->Color = System::Drawing::Color::Indigo;
               case  8 : pen->Color = System::Drawing::Color::LimeGreen;
               case  9 : pen->Color = System::Drawing::Color::Magenta;
               case 10 : pen->Color = System::Drawing::Color::Orange;
               case 11 : pen->Color = System::Drawing::Color::Purple;
               case 12 : pen->Color = System::Drawing::Color::Red;
               case 13 : pen->Color = System::Drawing::Color::Violet;
               case 14 : pen->Color = System::Drawing::Color::White;
               case 15 : pen->Color = System::Drawing::Color::Yellow;
            }
         }

         inline void draw_pixel(const T x, const T y)
         {
            gc->DrawLine(pen,float(x - 1.0f),float(y - 1.0f),float(x + 1.0f),float(y + 1.0f));
         }

         inline void draw_segment(const T x1, const T y1, const T x2, const T y2)
         {
            gc->DrawLine(pen,float(x1),float(y1),float(x2),float(y2));
         }

         inline void draw_segment(const point2d<T>& point1, const point2d<T>& point2)
         {
            draw_segment(point1.x,point1.y,point2.x,point2.y);
         }

         inline void draw_triangle(const T x1, const T y1,
                                   const T x2, const T y2,
                                   const T x3, const T y3)
         {
            gc->DrawLine(pen,float(x1),float(y1),float(x2),float(y2));
            gc->DrawLine(pen,float(x2),float(y2),float(x3),float(y3));
            gc->DrawLine(pen,float(x3),float(y3),float(x1),float(y1));
         }

         inline void draw_rectangle(const T x1, const T y1, const T x2, const T y2)
         {
            gc->DrawRectangle(float(x1),float(y1),fabs(float(x2 - x1)),fabs(float(y2 - y1)));
         }

         inline void draw_quadix(const T x1, const T y1,
                                 const T x2, const T y2,
                                 const T x3, const T y3,
                                 const T x4, const T y4)
         {
            gc->DrawLine(pen,float(x1),float(y1),float(x2),float(y2));
            gc->DrawLine(pen,float(x2),float(y2),float(x3),float(y3));
            gc->DrawLine(pen,float(x3),float(y3),float(x4),float(y4));
            gc->DrawLine(pen,float(x4),float(y4),float(x1),float(y1));
         }

         inline void draw_circle(const T x, const T y, const T radius)
         {
            gc->DrawEllipse(pen,float(x - radius),float(y - radius),float(2.0f * radius),float(2.0f * radius));
         }

         inline void draw_circle(const point2d<T> center, const T radius)
         {
            draw_circle(point.x,point.y,radius);
         }

         inline void clear()
         {
            clear_white();
         }

         inline void clear_white()
         {
            gc->Clear(System::Drawing::Color::White);
         }

         inline void clear_black()
         {
            gc->Clear(System::Drawing::Color::White);
         }

         inline void draw(const point2d<T>& point)
         {
            draw_pixel(point.x,point.y);
         }

         inline void draw(const segment<T,2>& segment)
         {
            draw_segment(segment[0].x,segment[0].y,segment[1].x,segment[1].y);
         }

         inline void draw(const triangle<T,2>& triangle)
         {
            draw_triangle(triangle[0].x,triangle[0].y,
                          triangle[1].x,triangle[1].y,
                          triangle[2].x,triangle[2].y);
         }

         inline void draw(const rectangle<T>& rectangle)
         {
            draw_rectangle(rectangle[0].x,rectangle[0].y,rectangle[1].x,rectangle[1].y);
         }

         inline void draw(const quadix<T,2>& quadix)
         {
            draw_quadix(quadix[0].x,quadix[0].y,
                        quadix[1].x,quadix[1].y,
                        quadix[2].x,quadix[2].y,
                        quadix[3].x,quadix[3].y);
         }

         inline void draw(const circle<T>& circle)
         {
            draw_circle(circle.x,circle.y,circle.radius);
         }

         const static unsigned int clAqua      =  0;
         const static unsigned int clBlack     =  1;
         const static unsigned int clBlue      =  2;
         const static unsigned int clBrown     =  3;
         const static unsigned int clCyan      =  4;
         const static unsigned int clGray      =  5;
         const static unsigned int clGreen     =  6;
         const static unsigned int clIndigo    =  7;
         const static unsigned int clLimeGreen =  8;
         const static unsigned int clMagenta   =  9;
         const static unsigned int clOrange    = 10;
         const static unsigned int clPurple    = 11;
         const static unsigned int clRed       = 12;
         const static unsigned int clViolet    = 13;
         const static unsigned int clWhite     = 14;
         const static unsigned int clYellow    = 15;

      private:

         unsigned int      width;
         unsigned int      height;

         gcroot<Graphics^> gc;
         gcroot<Pen^>      pen;
   };

} // namespace wykobi

#endif