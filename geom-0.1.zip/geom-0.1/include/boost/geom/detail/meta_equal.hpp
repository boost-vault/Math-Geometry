#ifndef BOOST_GEOM_DETAIL_META_EQUAL
#define BOOST_GEOM_DETAIL_META_EQUAL

// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

namespace boost { namespace geom {
	namespace detail {

		// Meta function that returns true if type1 is the same as
		// type2, otherwise returns false 
		//
		// Rational: Do not depend on some other implementation of it,
		// keep the library self contained.
		template<typename type1, typename type2>
			struct meta_equal { enum {value=false}; };

		template<typename type>
			struct meta_equal<type, type> { enum {value=true}; };

	} // namespace detail

} } // namespace boost::geom

#endif  // BOOST_GEOM_DETAIL_META_EQUAL
