/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
//polygon45 class
class Polygon45Data {
public:
  typedef std::vector<Point>::const_iterator iterator;

  /// default constructor of point does not initialize x and y
  inline Polygon45Data(){;} //do nothing default constructor

  /// initialize a polygon from x,y values, it is assumed that the first is an x
  /// and that the input is a well behaved polygon
  template<class iT>
  inline Polygon45Data& set(iT inputBegin, iT inputEnd) {
    points_.clear();  //just in case there was some old data there
    while(inputBegin != inputEnd) {
       points_.insert(points_.end(), *inputBegin);
       ++inputBegin;
    }
    return *this;
  }

  /// copy constructor (since we have dynamic memory)
  inline Polygon45Data(const Polygon45Data& that) : points_(that.points_) {}
  
  /// assignment operator (since we have dynamic memory do a deep copy)
  inline Polygon45Data& operator=(const Polygon45Data& that) {
    points_ = that.points_;
    return *this;
  }

  /// get begin iterator, returns a pointer to a const Unit
  inline iterator begin() const { return points_.begin(); }

  /// get end iterator, returns a pointer to a const Unit
  inline iterator end() const { return points_.end(); }

  inline std::size_t size() const { return points_.size(); }

private:
  std::vector<Point> points_; 
};
