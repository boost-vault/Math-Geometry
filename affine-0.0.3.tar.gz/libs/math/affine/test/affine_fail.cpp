//  boost affine_fail.cpp test file

//  (C) Copyright Hugo Duncan 2007.
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

// See http://www.boost.org for updates, documentation, and revision history.

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>

#include <boost/numeric/ublas/vector.hpp>
#include <boost/preprocessor/slot/counter.hpp>
#include <boost/preprocessor/comparison/equal.hpp>

#include <boost/math/affine.hpp>

using namespace boost::math;

struct frame1 {};
struct frame2 {};

#define TEST() \
  BOOST_PP_CAT( TEST_ , BOOST_PP_COUNTER )

#if ( BOOST_PP_EQUAL( TEST_CASE , BOOST_PP_COUNTER ) )
BOOST_AUTO_TEST_CASE(test_point_point_op_1)
{
  point<double,frame1> p1(1.);
  point<double,frame1> p2=1.;
  p1+=p2;
}
#endif

#include BOOST_PP_UPDATE_COUNTER()
#if BOOST_PP_EQUAL( TEST_CASE , BOOST_PP_COUNTER )
BOOST_AUTO_TEST_CASE(test_displacement_point_op_1)
{
  point<double,frame1> p1(1.);
  point<double,frame1> d1=1.;
  d1+=p1;
}
#endif

#include BOOST_PP_UPDATE_COUNTER()
#if BOOST_PP_EQUAL( TEST_CASE , BOOST_PP_COUNTER )
BOOST_AUTO_TEST_CASE(test_mixed_space_operations_1)
{
  point<double,frame1> p1(1.);
  displacement<double,frame2> d1=1.;
  p1+=d1;
}
#endif

#include BOOST_PP_UPDATE_COUNTER()
#if BOOST_PP_EQUAL( TEST_CASE , BOOST_PP_COUNTER )
BOOST_AUTO_TEST_CASE(test_const_lhs_ops_1)
{
  displacement<double,frame1> d1=1.;
  point_ref<frame1>(2)+=d1;
}
#endif


