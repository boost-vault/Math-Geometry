/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// PointInterface provides glue to bind PointImpl to T

/// PointInterface provides access the the data class T through
/// the constructor, get and set API, which are minimal and sufficient.
template <class T>
class PointInterface {
public:
  /// get a coordinate from the point t depending on value of orient
  static inline Unit PointGet(const T& t, Orientation2D orient);

  /// set a coordinate of the point t to value depending on value of orient
  static inline void PointSet(T& t, Orientation2D orient, Unit value);

  /// construct a T type point from low and high
  static inline T PointConstruct(Unit x, Unit y);

private:
  //disallow construction
  PointInterface();
};

/// partial specialization of PointInterface for T of type PointData
template <>
class PointInterface<PointData> {
public:
  static inline Unit PointGet(const PointData& t, Orientation2D orient) {
    return t.get(orient);
  }
  static inline void PointSet(PointData& t, Orientation2D orient, Unit value) {
    t.set(orient, value);
  }
  static inline PointData PointConstruct(Unit x, Unit y) {
    return PointData(x, y);
  }

private:
  //disallow construction
  PointInterface(){;}
};

/// partial specialization of PointInterface for T of type Point3DData
template <>
class PointInterface<Point3DData> {
public:  
  static inline Unit PointGet(const Point3DData& t, 
                              Orientation2D orient){
    return t.get(orient);
  }
  static inline void PointSet(Point3DData& t, Orientation2D orient, Unit value) {
    t.set(orient, value);
  }
  static inline Point3DData PointConstruct(Unit x, Unit y) {
    return Point3DData(x, y, 0);
  }

private:
  //disallow construction
  PointInterface(){;}
};
