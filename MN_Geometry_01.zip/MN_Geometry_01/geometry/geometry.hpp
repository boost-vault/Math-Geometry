// ============================================================================
// geometry.hpp                                   (C)2005 Michael Andersen Nexo
// ============================================================================
// This header file defines template classes for representing vectors, points
// and ranges (=2D-rects/3D-boxes). 
// The template signature of these classes are vector<T,D,R>, point<T,D,R>, 
// and range<T,D,R> where T is the scalar type, D is the dimensionality, and R 
// is an optional class used for internal representation of the data.
//
// Selling points:
//
// * Provides a generic interface for points, vectors and ranges that can be 
//   used for all scalar types and dimensionalities, thereby allowing the user
//   to write generic algorithms that are independent of these parameters.
//
// * The classes provide a Standard C++ container-like interface with begin(),
//   end() etc., much in the same way as boost::array. For D<=3 it also provides
//   the usual x(), y() and z() shorthands.
//
// * The interfaces can function as seamless adapters for platform specific 
//   vector, point and range classes without incurring any extra overhead.
//   All you need to do is specialize sequence_traits and xyz_traits for the
//   classes, and you'll have a point/vector class that is compatible with the
//   generic algorithms as well as the native platform.
//   E.g. point<LONG,2,CPoint> winpoint;
//
// * The classes naturally extend the automatic conversion of the basic numeric 
//   types in C++. 
//   E.g: vector<float,2> f = vector<int,2>(3,2)+vector<short,2>(1,1) is 
//   allowed while vector<int,3> d = vector<float,3>(3.2, 3.0) will cause a
//   compile-time truncation warning (if the compiler warns about float to int
//   conversions at all).
//
// * The classes handle type promotion the way it is naturally handled in C++
//   E.g.: typeof(point<char,2> + vector<long,2>) == typeof(point<long,2>)
//
// * Provide an interface that (optionally) implements expression templates,
//   avoiding creation of temporaries in expressions such as: v = 2*w+u.
//   (Note: this may only be a performance gain for larger D's)

#ifndef GEOMETRY_HPP_INCLUDED
#define GEOMETRY_HPP_INCLUDED

#include <algorithm>
#include <numeric>
#include "traits.hpp"
#include "details.hpp"
#include "ops.hpp"

namespace geom
{
	// ------------------------------------------------------------------------
	// class base<R,D>
	// ------------------------------------------------------------------------
	// Implements standard-like container interface for representation, R,
	// provided that sequence_traits<R,D> has been specialized sufficiently.
	// Alternatively, the user should provide specializations of base<R,D>
	// implementing all the typedefs and member functions manually.
	template <class R, size_t D>
	class base
	{
	private:
		typedef sequence_traits<R,D> st;
		typedef xyz_traits<R,D> xyzt;
	public:
		// Bring in standard typedef's and functions. This also functions
		// as a guard for insufficiently defined representation classes.
		typedef typename st::iterator iterator;
		typedef typename st::const_iterator const_iterator;
		typedef typename st::reverse_iterator reverse_iterator;
		typedef typename st::const_reverse_iterator const_reverse_iterator;
		typedef typename st::size_type size_type;
		typedef typename std::iterator_traits<iterator>::value_type value_type;
		typedef typename std::iterator_traits<iterator>::reference reference;
		typedef typename std::iterator_traits<const_iterator>::reference const_reference;
		typedef typename std::iterator_traits<iterator>::difference_type difference_type;

		// Standard C++ stuff
		size_type size() { return D; }
		iterator begin() { return st::begin(rep_); }
		iterator end() { return st::end(rep_); }
		const_iterator begin() const { return st::begin(rep_); }
		const_iterator end() const { return st::end(rep_); }

		reverse_iterator rbegin() { return st::rbegin(rep_); }
		reverse_iterator rend() { return st::rend(rep_); }
		const_reverse_iterator rbegin() const { return st::rbegin(rep_); }
		const_reverse_iterator rend() const { return st::rend(rep_); }

		// Note array accessors are templated in order to avoid ambiguities when
		// array accessors are defined for R
		template <class N> reference operator [](N n) { return *(begin() + n); }
		template <class N> const_reference operator [](N n) const { return *(begin() + n); }

		// TODO: at, front, back, etc.

		// Access via x,y,z (only applicable for D<=3)
		reference x() { return xyzt::x(rep_); }
		const_reference x() const { return xyzt::x(rep_); }
		reference y() { return xyzt::y(rep_); }
		const_reference y() const { return xyzt::y(rep_); }
		reference z() { return xyzt::z(rep_); }
		const_reference z() const { return xyzt::z(rep_); }

		// Constructors
		base() {}
		base(R const& s) : rep_(s) { }
		base(value_type xx, value_type yy) { x() = xx; y() = yy; }
		base(value_type xx, value_type yy, value_type zz) { x()=xx; y()=yy; z()=zz; }

		// Provide conversion to R, easing calls to functions expecting the
		// "native" type.
		operator R const& () const { return rep_; }
		operator R& () { return rep_; }
		// Because the above doesn't work for function templates, we provide
		// explicit conversions.
		R const& impl() const { return rep_; }
		R& impl() { return rep_; }
	
	private:
		R rep_;
	};

	// ------------------------------------------------------------------------
	// operator==(base, base)
	// ------------------------------------------------------------------------
	// Mixed comparison of vectors and points (e.g. if(vector==point)) is 
	// allowed, so we defined it for the base class.
	template <class R, class S, size_t D>
	inline bool operator==(base<R, D> const& lhs, base<S, D> const& rhs)
	{
		return detail::equal(lhs, rhs);
	}

	template <class R, class S, size_t D>
	inline bool operator!=(base<R, D> const& lhs, base<S, D> const& rhs)
	{
		return !detail::equal(lhs, rhs);
	}

	// ------------------------------------------------------------------------
	// class vector
	// ------------------------------------------------------------------------
	template <class T, size_t D, class R = T[D] >
	class vector : public base<R,D>
	{
	private:
		typedef base<R,D> base;
	public:
	// Operators
		template <class U, class E>	vector<T,D,R>& operator =(vector<U,D,E> const& e) { detail::assign(*this, e); return *this; }
		template <class U, class E>	
		vector<T,D,R>& operator +=(vector<U,D,E> const& e) { detail::assign(*this, e, ops::plus<T,U>()); return *this; }
		template <class U, class E>	
		vector<T,D,R>& operator -=(vector<U,D,E> const& e) { detail::assign(*this, e, ops::minus<T,U>()); return *this; }
		template <class U> vector<T,D,R>& operator *=(U n) { detail::assign(*this, n, ops::multiplies<T,U>()); return *this; }
		template <class U> vector<T,D,R>& operator /=(U n) { detail::assign(*this, n, ops::divides<T,U>()); return *this; }

	// Cast to vector<T,D,R> from point or R
		static vector<T,D,R>& cast(point<T,D,R>& p) { return reinterpret_cast<vector<T,D,R>&>(p); }
		static const vector<T,D,R>& cast(point<T,D,R> const& p) { return reinterpret_cast<const vector<T,D,R>&>(p); }
		static const vector<T,D,R>& cast(R& r) { return reinterpret_cast<vector<T,D,R>&>(r); }
		static const vector<T,D,R>& cast(R const& r) { return reinterpret_cast<const vector<T,D,R>&>(r); }

	// Constructors
		vector() { }
		vector(T n) { std::fill_n(this->begin(), D, n); }
		vector(R const& s) : base(s) { }		// Construction from R
		vector(T x, T y) : base(x,y) { }		// Special constructor for D=2
		vector(T x, T y, T z) : base(x,y,z) { } // Special constructor for D=3

		// Construction from a vector with a different scalar or representation type
		template <class U, class E> vector(vector<U,D,E> const& v) { *this = v; }
		// Explicit construction from a point
		template <class U, class E> explicit vector(point<U,D,E> const& p) { *this = cast(p); }
	};

	// ------------------------------------------------------------------------
	// class point
	// ------------------------------------------------------------------------
	template <class T, size_t D, class R = T[D]>
	class point : public base<R,D>
	{
	private:
		typedef base<R,D> base;
	public:
	// Operators
		template <class U, class E>	
		point<T,D,R>& operator =(point<U,D,E> const& e) { detail::assign(*this, e); return *this; }
		template <class U, class E>	
		point<T,D,R>& operator +=(vector<U,D,E> const& e) { detail::assign(*this, e, ops::plus<T,U>()); return *this; }
		template <class U, class E> 
		point<T,D,R>& operator -=(vector<U,D,E> const& e) { detail::assign(*this, e, ops::minus<T,U>()); return *this; }

	// Cast to point<T,D,R> from vector or R
		static point<T,D,R>& cast(vector<T,D,R>& v) { return reinterpret_cast<point<T,D,R>&>(v); }
		static const point<T,D,R>& cast(vector<T,D,R> const& v) { return reinterpret_cast<const point<T,D,R>&>(v); }
		static const point<T,D,R>& cast(R& r) { return reinterpret_cast<point<T,D,R>&>(r); }
		static const point<T,D,R>& cast(R const& r) { return reinterpret_cast<const point<T,D,R>&>(r); }

	// Constructors
		point() { }
		point(T n) { std::fill_n(this->begin(), D, n); }
		point(R const& s) : base(s) { }			// Construction from R
		point(T x, T y) : base(x,y) { }			// Special constructor for D=2
		point(T x, T y, T z) : base(x,y,z) { }	// Special constructor for D=3

		// Construction from a point with a different value- and representation type
		template <class U, class E> point(point<U,D,E> const& p) { *this = p; }
		// Explicit construction from a vector
		template <class U, class E> explicit point(vector<U,D,E> const& v) { *this = cast(v); }
	};

	template <class T, size_t D, class R>
	inline point<T,D,R>& point_cast(vector<T,D,R>& v)
	{
		return reinterpret_cast<point<T,D,R>&>(v);
	}

	template <class T, size_t D, class R>
	inline point<T,D,R> const& point_cast(vector<T,D,R> const& v)
	{
		return reinterpret_cast<point<T,D,R> const&>(v);
	}

	template <class T, size_t D, class R>
	inline vector<T,D,R>& vector_cast(point<T,D,R>& p)
	{
		return reinterpret_cast<vector<T,D,R>&>(p);
	}

	template <class T, size_t D, class R>
	inline vector<T,D,R> const& vector_cast(point<T,D,R> const& p)
	{
		return reinterpret_cast<vector<T,D,R> const&>(p);
	}

	template <class T, size_t D>
	inline point<T,D,T*>& point_cast(T*& data)
	{
		return reinterpret_cast<point<T,D,T*>&>(data);
	}

/*	// ------------------------------------------------------------------------
	// class range
	// ------------------------------------------------------------------------
	// range<T, D> describes a D-dimensional rectangle/box with coordinates of
	// type T, specified by the two points low() and high().
	template <class T, size_t D, class R = std::pair<point<T,D>, point<T,D> > >
	class range
	{
	public:
		typedef range_traits<R,D> rt;
		typedef typename rt::point_type point_type;

	// Member access:
		point_type const& low() const { rt::low(r_); }
		point_type& low() { return rt::low(r_); }
		point_type const& high() const { return rt::high(r_); }
		point_type& high() { return rt::high(r_); }

	// Special access for D<=3
		T& left() { return low().x(); }
		T& top() { return low().y(); }
		T& front() { return low().z(); }
		T& right() { return high().x(); }
		T& bottom() { return high().y(); }
		T& back() { return high().z(); }
		const T& left() const { return low().x(); }
		const T& top() const { return low().y(); }
		const T& front() const { return low().z(); }
		const T& right() const { return high().x(); }
		const T& bottom() const { return high().y(); }
		const T& back() const { return high().z(); }

	// Operators (union, intersection, offsetting):
		range<T,D>& operator|=(const range<T,D>& r); // Union
		range<T,D>& operator&=(const range<T,D>& r); // Intersection
		range<T,D>& operator+=(const vector<T,D>& v) { low()+=v; high()+=v; ; return *this; }
		range<T,D>& operator-=(const vector<T,D>& v) { low()-=v; high()-=v; ; return *this; }

		bool empty() const;
		template <class U, class E> bool contains(const point<U,D,E>& p) const;
		template <class U, class E> bool contains(const range<U,D,E>& r) const;

		// Constructors
		range() { }
		range(const point<T,D>& l, const point<T,D>& h) { low() = l; high() = h; }
		range(const point<T,D>& p, const vector<T,D>& s) { low() = p; high() = p+s; }
	private:
		R r_;
	};

	// Partial specialization of range<T,2>
	// Defines additional constructors, member accessors, and area(), width() and height()
	template <class T> class range<T,2> : public detail::rbase<T,2>
	{
		using detail::rbase<T,2>::b;
		using detail::rbase<T,2>::e;
	public:
	// Member accessors
		T& left() { return b().x(); }
		T& top() { return b().y(); }
		T& right() { return e().x(); }
		T& bottom() { return e().y(); }
		const T& left() const { return b().x(); }
		const T& top() const { return b().y(); }
		const T& right() const { return e().x(); }
		const T& bottom() const { return e().y(); }
		point<T,2>& topleft() { return b(); }
		point<T,2>& bottomright() { return e(); }
		const point<T,2>& topleft() const { return b(); }
		const point<T,2>& bottomright() const { return e(); }
	// Operators
		range<T,2>& operator|=(const range<T,2>& r) { if(r.b().x()<b().x()) b().x()=r.b().x(); if(r.b().y()<b().y()) b().y()=r.b().y(); if(r.e().x()>e().x()) e().x()=r.e().x(); if(r.e().y()>e().y()) e().y()=r.e().y(); return *this; }
		range<T,2>& operator&=(const range<T,2>& r) { if(r.b().x()>b().x()) b().x()=r.b().x(); if(r.b().y()>b().y()) b().y()=r.b().y(); if(r.e().x()<e().x()) e().x()=r.e().x(); if(r.e().y()<e().y()) e().y()=r.e().y(); return *this; }
		range<T,2>& operator+=(const vector<T,2>& v) { b()+=v; e()+=v; return *this; }
		range<T,2>& operator-=(const vector<T,2>& v) { b()-=v; e()-=v; return *this; }
		range<T,2> operator |(const range<T,2>& r) const { range<T,2> res(*this); return res |= r; } 
		range<T,2> operator &(const range<T,2>& r) const { range<T,2> res(*this); return res &= r; }
		range<T,2> operator +(const vector<T,2>& r) const { range<T,2> res(*this); return res += r; }
		range<T,2> operator -(const vector<T,2>& r) const { range<T,2> res(*this); return res -= r; }
	// Methods
		typename conv::promote<T>::result_type volume() const { return (e().x()-b().x())*(e().y()-b().y()); }
		typename conv::promote<T>::result_type area() const { return volume(); }
		T width() const { return e[0]-b[0]; }
		T height() const { return e[1]-b[1]; }
		bool empty() const { return (b().x()>=e().x() || b().y()>=e().y()); }
		bool contains(const point<T,2>& p) const { return (b().x()<=p.x() && p.x()<e().x() && b().y()<=p.y() && p.y()<e().y()); }
		bool contains(const range<T,2> r) const { return contains(r.b()) && contains(r.e() - vector<T,2>(1)); }
	// Constructors
		range() { }
		template <class U, class V>
		range(const point<U,2>& beg, const point<V,2>& end) : detail::rbase<T,2>(beg, end) { }
		template <class U, class V>
		range(const point<U,2>& beg, const vector<V,2>& size) : detail::rbase<T,2>(beg, size) { }
		range(T left, T top, T right, T bottom) : detail::rbase<T,2>(left,top,right,bottom) { }	
		template <class U>
		explicit range(const range<U,2>& r) : detail::rbase<T,2>(r) { }
	};

	// Partial specialization for D=3
	template <class T> class range<T,3> : public detail::rbase<T,3>
	{
		using detail::rbase<T,2>::b;
		using detail::rbase<T,2>::e;
	public:
	// Member accessors
		T& left() { return b().x(); }
		T& top() { return b().y(); }
		T& front() { return b().z(); }
		T& right() { return e().x(); }
		T& bottom() { return e().y(); }
		T& back() { return e().z(); }
		const T& left() const { return b().x(); }
		const T& top() const { return b().y(); }
		const T& front() const { return b().z(); }
		const T& right() const { return e().x(); }
		const T& bottom() const { return e().y(); }
		const T& back() const { return e().z(); }
	// Operators
		range<T,3>& operator|=(const range<T,3>& r) { if(r.b().x()<b().x()) b().x()=r.b().x(); if(r.b().y()<b().y()) b().y()=r.b().y(); if (r.b().z()<b().z()) b().z()=r.b().z(); if(r.e().x()>e().x()) e().x()=r.e().x(); if(r.e().y()>e().y()) e().y()=r.e().y(); if (r.e().z()>e().z()) e().z()=r.e().z(); return *this; }
		range<T,3>& operator&=(const range<T,3>& r) { if(r.b().x()>b().x()) b().x()=r.b().x(); if(r.b().y()>b().y()) b().y()=r.b().y(); if (r.b().z()>b().z()) b().z()=r.b().z(); if(r.e().x()<e().x()) e().x()=r.e().x(); if(r.e().y()<e().y()) e().y()=r.e().y(); if (r.e().z()<e().z()) e().z()=r.e().z(); return *this; }
		range<T,3>& operator+=(const vector<T,3>& v) { b()+=v; e()+=v; return *this; }
		range<T,3>& operator-=(const vector<T,3>& v) { b()-=v; e()-=v; return *this; }
		range<T,3> operator |(const range<T,3>& r) const { range<T,3> res(*this); return res |= r; } 
		range<T,3> operator &(const range<T,3>& r) const { range<T,3> res(*this); return res &= r; }
		range<T,3> operator +(const vector<T,3>& r) const { range<T,3> res(*this); return res += r; }
		range<T,3> operator -(const vector<T,3>& r) const { range<T,3> res(*this); return res -= r; }
	// Methods
		T volume() const { return (e().x()-b().x()) * (e().y()-b().y()) * (e().z()-b().z()); }
		T width() const { return e[0]-b[0]; }
		T height() const { return e[1]-b[1]; }
		T depth() const { return e[2]-b[2]; }
		bool empty() const { return (b().x()>=e().x() || b().y()>=e().y()); }
		bool contains(const point<T,3>& p) const { return (b().x()<=p.x() && p.x()<e().x() && b().y()<=p.y() && p.y()<e().y()); }
		bool contains(const range<T,3> r) const { return contains(r.b()) && contains(r.e() - vector<T,3>(1,1,1)); }
	// Constructors
		range() { }
		range(T x1, T y1, T z1, T x2, T y2, T z2) : detail::rbase<T,3>(x1,y1,z1, x2,y2,z2) { }
		template <class U, class V>
		range(const point<U,3>& beg, const point<V,3>& end) : detail::rbase<T,3>(beg,end) { }
		template <class U, class V>
		range(const point<U,3>& beg, const vector<V,3>& size) : detail::rbase<T,3>(beg,size) { }
		template <class U>
		explicit range(const range<U,3>& r) : detail::rbase<T,3>(r) { }
	};
*/
}

// Include implementation of larger functions...
//#include "geometry.ipp"

// Include implementation of operators (==+-*/, etc) for points and vectors (using expression templates)
#ifdef GEOM_USE_EXPRESSION_TEMPLATES
	#include "operators_et.ipp"
#else
	#include "operators_simp.ipp"
#endif //GEOM_USE_EXPRESSION_TEMPLATES

#endif // GEOMETRY_HPP_INCLUDED
