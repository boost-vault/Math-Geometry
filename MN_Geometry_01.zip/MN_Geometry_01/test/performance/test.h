#include <geometry/geometry.hpp>

#define DIM 10
typedef geom::vector<double,DIM> vector;
typedef geom::point<double,DIM> point;

void test_plain();
void test_et();
void axpy_plain();
void axpy_et();
