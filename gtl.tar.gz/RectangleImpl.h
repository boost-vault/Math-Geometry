/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// RectangleImpl implements Rectangle functions on top of rectangle type T

/// RectangleImpl inherits from rectangle type T and accesses the data owned
/// by T through the RectangleInterface<T> class
template <class T>
class RectangleImpl : public T {
public:

  /// get a reference of rectangleImpl type given a data object
  static RectangleImpl& mimic(T& t) { return static_cast<RectangleImpl&>(t); }

  /// get a const reference of RectangleImpl type given a data object
  static const RectangleImpl& mimicConst(const T& t) { 
    return static_cast<const RectangleImpl&>(t); 
  }

  /// construct a rectangle from horizontal and vertical intervals
  template <class T2, class T3>
  RectangleImpl(const IntervalImpl<T2>& hrange, 
                       const IntervalImpl<T3>& vrange);

  /// construct a rectangle from two points (ll, ur)
  template <class T2, class T3>
  RectangleImpl(const PointImpl<T2>& ll, const PointImpl<T3>& ur);

  /// construct a rectangle from 4 numbers: xl, yl, xh, yh
  RectangleImpl(Unit xl, Unit yl, Unit xh, Unit yh);

  /// construct a degenerated Rectangle from a Point
  template <class T2>
  explicit RectangleImpl(const PointImpl<T2>& p); 

  /// construct a degenerated Rectangle from a Segment
  template <class T2>
  explicit RectangleImpl(const SegmentImpl<T2>& p); 

  /// default constructor
  RectangleImpl(); 

  /// assignment operator
  template <class T2>
  const RectangleImpl& operator=(const RectangleImpl<T2>& that) {
    horizontal(that.horizontal()); vertical(that.vertical());
    return *this;
  }

  /// assignment operator
  const RectangleImpl& operator=(const RectangleImpl& that);

  /// assignment operator
  const RectangleImpl& operator=(const T& that);

  /// comparison operator
  template <class T2>
  bool operator<(const RectangleImpl<T2>& b) const; 

  /// comparison operator
  template <class T2>
  bool operator<=(const RectangleImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const RectangleImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const RectangleImpl<T2>& b) const { return !(*this < b); }

  /// copy constructor
  template <class T2>
  RectangleImpl(const RectangleImpl<T2>& that) { *this = that; }

  /// copy constructor
  RectangleImpl(const T& that) : T(that) {;}

  /// equivalence operator
  template <class T2>
  bool operator==(const RectangleImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const RectangleImpl<T2>& b) const;

  /// yield payload
  T& yield() { return *this; }
     
  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// Is the T valid
  bool isValid() const;

  /// Is the T initialized
  inline bool isInitialized() const;

  /// get the interval range depending on orient
  IntervalImpl<IntervalData> get(Orientation2D orient) const;

  /// set and interval range to v depending on orient
  template <class T2>
  RectangleImpl& set(Orientation2D orient, const IntervalImpl<T2>& value);
    
  /// get the horizontal interval range
  IntervalImpl<IntervalData> horizontal() const { return get(HORIZONTAL); }

  /// get the vertical interval range
  IntervalImpl<IntervalData> vertical() const { return get(VERTICAL); }

  /// set the horizontal interval range
  template <class T2>
  RectangleImpl& horizontal(const IntervalImpl<T2>& v) { return set(HORIZONTAL, v); }

  /// set the vertical interval range
  template <class T2>
  RectangleImpl& vertical(const IntervalImpl<T2>& v) { return set(VERTICAL, v); }

  /// get a boundary coordinate depending on dir
  Unit get(Direction2D dir) const;

  /// non-isotropic functions, provided for convenience
  Unit xl(void) const { return get(WEST);  }
  Unit yl(void) const { return get(SOUTH); }
  Unit xh(void) const { return get(EAST);  }
  Unit yh(void) const { return get(NORTH); }
  RectangleImpl& xl(Unit xl)  { return set(WEST, xl);  }
  RectangleImpl& yl(Unit yl)  { return set(SOUTH, yl); }
  RectangleImpl& xh(Unit xh)  { return set(EAST, xh);  }
  RectangleImpl& yh(Unit yh)  { return set(NORTH, yh); }

  /// Get all coordinates
  const RectangleImpl& get(Unit& xll, Unit& yll, 
                                  Unit& xhh, Unit& yhh) const{
    xll = xl(); yll = yl(); xhh = xh(); yhh = yh(); return *this;
  }

  /// set a boundary coordinate to value depending on dir
  RectangleImpl& set(Direction2D dir, Unit value);

  /// Set all coordinates
  RectangleImpl& set(Unit xll, Unit yll, Unit xhh, Unit yhh) {
    xl(xll); yl(yll); xh(xhh); yh(yhh); return *this;
  }

  /// Get boundary APIs
  Unit getBoundary(Orientation2D orient, Direction1D dir) const;
  RectangleImpl& setBoundary(Orientation2D orient, Direction1D dir, 
                                    Unit value);
  Unit getLowerBoundary(Orientation2D orient) const;
  RectangleImpl& setLowerBoundary(Orientation2D orient, Unit value);
  Unit getUpperBoundary(Orientation2D orient) const;
  RectangleImpl& setUpperBoundary(Orientation2D orient, Unit value);

  /// set all four coordinates based upon two points
  template <class T2, class T3>
  RectangleImpl& setPoints(const PointImpl<T2>& p1,
                                  const PointImpl<T3>& p2);

  /// move rectangle by delta in orient
  RectangleImpl& move(Orientation2D orient, Unit delta);

  /// transform rectangle
  RectangleImpl& transform(const AxisTransform& atr);
    
  /// transform rectangle
  RectangleImpl& transform(const Transform& tr);

  /// convolve this with b
  template <class T2>
  RectangleImpl& convolve(const RectangleImpl<T2>& b);

  /// deconvolve this with b
  template <class T2>
  RectangleImpl& deconvolve(const RectangleImpl<T2>& b);

  /// reflectedConvolve this with b
  template <class T2>
  RectangleImpl& reflectedConvolve(const RectangleImpl<T2>& b);

  /// reflectedDeconvolve this with b
  template <class T2>
  RectangleImpl& reflectedDeconvolve(const RectangleImpl<T2>& b);

  /// convolve with point
  template <class T2>
  RectangleImpl& convolve(const PointImpl<T2>& p);

  /// deconvolve with point
  template <class T2>
  RectangleImpl& deconvolve(const PointImpl<T2>& p);

  /// get the magnitude of the interval range depending on orient
  UnsignedUnit delta(Orientation2D orient) const;

  /// get the area of the rectangle
  UnsignedLongUnit area() const;

  /// returns the orientation of the longest side
  Orientation2D guessOrientation(void) const;

  /// get the half perimeter of the rectangle
  UnsignedLongUnit halfPerimeter() const;
   
  /// get the perimeter of the rectangle
  UnsignedLongUnit perimeter() const;

  /// check if Rectangle b is inside `this` Rectangle
  //  [in]     b         Rectangle that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` contains b
  template <class T2>
  bool contains(const RectangleImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if Point p is inside `this` Rectangle
  template <class T2>
  bool contains(const PointImpl<T2>& p, 
                       bool considerTouch = true) const;

  /// check if `this` Rectangle is inside specified Rectangle b
  //  [in]     b         Rectangle that will be checked
  //  [in]     considerTouch true, return true even if `t` touches the boundary
  //  [ret]    .         true if `t` is inside b
  template <class T2>
  bool inside(const RectangleImpl<T2>& b, 
                     bool considerTouch = true) const;

  /// check if Rectangle b intersects `this` Rectangle
  //  [in]     b         Rectangle that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` intersects b
  template <class T2>
  bool intersects(const RectangleImpl<T2>& b, 
                         bool considerTouch = true) const;

  /// Check if boundaries of Rectangle b and `this` Rectangle intersect
  //  [in]     b         Rectangle that will be checked
  //  [in]     considerTouch If true, return true even if p is on the foundary
  //  [ret]    .         true if `t` contains p
  template <class T2>
  bool boundariesIntersect(const RectangleImpl<T2>& b, 
                                  bool considerTouch = true) const;
    
  /// check if b is touching 'this' on the end specified by dir
  template <class T2>
  bool abuts(const RectangleImpl<T2>& b, Direction2D dir) const;

  /// check if they are touching in the given orientation
  template <class T2>
  bool abuts(const RectangleImpl<T2>& b, 
                    Orientation2D orient) const;

  /// check if they are touching but not overlapping
  template <class T2>
  bool abuts(const RectangleImpl<T2>& b) const;

  /// intersect rectangle with interval on orient
  template <class T2>
  bool intersectRange(const IntervalImpl<T2>& b, 
                             Orientation2D orient, 
                             bool considerTouch = true);

  /// clip `this` Rectangle to the specified Rectangle
  //  [in]   b         The intersecting Rectangle
  //  [in]   considerTouch If true, will clip to a single line if appropriate
  template <class T2>
  bool intersect(const RectangleImpl<T2>& b, bool considerTouch = true);

  /// set `t` Rectangle to the intersection between b1 and b2
  /// if such and intersection exists, else set 'this' to b1 and return false
  //  [in]     b1        The two intervals to examine
  //  [in]     b2
  //  [in]     considerTouch If true, create intersection even if b1 touches b2
  //  [ret]    .         true if boxes intersect, else `t` is set to b1
  template <class T2, class T3>
  bool intersection(const RectangleImpl<T2>& b1, const RectangleImpl<T3>& b2,
                           bool considerTouch = true);

  /// bloat the interval specified by orient by bloating
  RectangleImpl& bloat(Orientation2D orient, UnsignedUnit bloating);

  /// bloat the Rectangle by bloating
  RectangleImpl& bloat(UnsignedUnit bloating);

  /// bloat the interval cooresponding to orient by bloating in dir direction
  RectangleImpl& bloat(Direction2D dir, UnsignedUnit bloating);

  /// shrink the interval specified by orient by bloating
  RectangleImpl& shrink(Orientation2D orient, UnsignedUnit shrinking);

  /// shring the Rectangle by bloating
  RectangleImpl& shrink(UnsignedUnit shrinking);

  /// shrink the interval cooresponding to orient by bloating in dir direction
  RectangleImpl& shrink(Direction2D dir, UnsignedUnit shrinking);

  /// encompass interval on orient
  template <class T2>
  bool encompass(const IntervalImpl<T2>& b,
                        Orientation2D orient);

  /// enlarge `this` Rectangle to encompass the Rectangle b
  //  [in]     b         The Rectangle to encompass
  //  [ret]    .         true if enlargement happened at all
  template <class T2>
  bool encompass(const RectangleImpl<T2>& b);

  /// returns the center of the rectangle
  PointImpl<PointData> center() const;

  /// cuts the rectangle in half in the given orientation
  /// returns the cutline as a Segment
  SegmentImpl<SegmentData> getCutline(Orientation2D o) const;

  /// cuts the rectangle in half in the given orientation
  /// returns the cutline as a rectangle
  RectangleImpl getCutlineAsRectangle(Orientation2D o) const;

  /// gets the appropriate edge
  // for example:
  // getEdge(NORTH) gets the line from ul to ur
  SegmentImpl<SegmentData> getEdge(Direction2D d2d) const;

  /// returns the corner obtained by rotating 'd2d' 45 degrees in the direction 'turn" 
   PointImpl<PointData> getCorner(Direction2D d2d, Direction1D turn) const;

  /// returns the left corner of the given direction
   PointImpl<PointData> getLeftCorner(Direction2D d2d) const {return getCorner(d2d, HIGH);}

  /// returns the right corner of the given direction
   PointImpl<PointData> getRightCorner(Direction2D d2d) const {return getCorner(d2d, LOW);}
  
  /// get the 4 corners, for convenience
  PointImpl<PointData> sw() const { return getLeftCorner(WEST); }
  PointImpl<PointData> ne() const { return getLeftCorner(EAST); }
  PointImpl<PointData> se() const { return getLeftCorner(SOUTH); }
  PointImpl<PointData> nw() const { return getLeftCorner(NORTH); }

  PointImpl<PointData> ll() const { return sw(); }
  PointImpl<PointData> ur() const { return ne(); }
  PointImpl<PointData> lr() const { return se(); }
  PointImpl<PointData> ul() const { return nw(); }

  /// returns the half of the rectangle as another rectangle
  // for NORTH it returns the upper half
  RectangleImpl getHalf(Direction2D d2d) const;

  /// the following 4 functions are non-isotropic and are provided for speed purpose
  RectangleImpl getNorthHalf(void) const
  {
    return RectangleImpl(get(HORIZONTAL), get(VERTICAL).getHalf(HIGH));
  }

  RectangleImpl getSouthHalf(void) const
  {
    return RectangleImpl(get(HORIZONTAL), get(VERTICAL).getHalf(LOW));
  }

  RectangleImpl getWestHalf(void) const
  {
    return RectangleImpl(get(HORIZONTAL).getHalf(LOW), get(VERTICAL));
  }

  RectangleImpl getEastHalf(void) const
  {
    return RectangleImpl(get(HORIZONTAL).getHalf(HIGH), get(VERTICAL));
  }

  /// Get two halves and a shorter cutline of a rect R
  // you get:
  //            R
  //            ---------------------
  //            |         |         |
  //            |         |         |
  //            |  A      C    B    |
  //            |         |         |
  //            |         |         |
  //            ---------------------
  //
  // or if the rectangle is tall
  // then you get A on bottom half, get the horizontal cutline in C,
  // and B the top half
  //
  // return the orientation of the cut line
  // i.e. if R's width >= R's height, return VERTICAL
  //      else return HORIZONTAL
  template <class T2, class T3, class T4>
  Orientation2D
  getTwoHalvesAndShorterCutline(RectangleImpl<T2>& A, RectangleImpl<T3>& C, 
                                RectangleImpl<T4>& B) const;

  //! Calculate the sub rectangle achieved by dividing the rectangle
  // into N portions and grabbing the Mth portion.
  // Divide the rectangle either horizontally or vertically, and traverse
  // the sub rectangles in the given direction, starting at 0.
  //
  // Given the following rectangle, the direction WEST,
  // and the numbers N=5, M=1
  //
  // ------------------------------------
  // |  4   |  3   |  2   |  1   |  0   |
  // |      |      |      |      |      |
  // |      |      |      |      |      |
  // |      |      |      |      |      |
  // |      |      |      |      |      |
  // |      |      |      |      |      |
  // |      |      |      |      |      |
  // ------------------------------------
  //
  // return this ---------^^^^^^^^
  // rectangle to the user
  //
  // obviously N > M
  //
  RectangleImpl
  getSubRectangle(Direction2D direction,
                  unsigned short numPieces, unsigned short whichPiece) const;

  //! Tries to join self with rect, and set the newRect to the result of
  //  the join. It only succeeds if the two rectangles touch exactly at
  //  the edges. The edges that touch need to be same size.
  //  Note: Does not handle other join-able situations when rectangles are
  //  partly or fully overlapping.
  template <class T2, class T3>
  bool joinWith( RectangleImpl<T2>& newRect, const RectangleImpl<T3>& r2) const;

  // ---
  //+ detailed functions;
  // ---

  //  The distance from a point to a rectangle is defined
  //  in the following way:
  //
  //                               |           |
  //                               |           |
  //    __________________________ |           |    __________________________
  //  \| (x-xl)^2 + (y-yh)^2       | (y - yh)  |  \| (x - xh)^2 + (y - yh)^2
  //                               |           |
  //                               |           |
  //                               |           |
  //                  -------------------------*--------------
  //                               |           |
  //                               |           |
  //                     (xl - x)  |     0     |  (x - xh)
  //                               |           |
  //                               |           |
  //                  -------------*--------------------------
  //                               |           |
  //                               |           |
  //    __________________________ |           |    __________________________
  //  \| (x-xl)^2 + (y-yl)^2       | (yl - y)  |  \| (x - xh)^2 + (y - yl)^2
  //                               |           |
  //                               |           |
  //                               |           |
  //

  /// Returns the euclidian distance between the edge of the
  /// rectangle and the point. Returns 0 if point is inside the
  /// rectangle
  template <class T2>
  double
  euclidianDistance(const PointImpl<T2> & p) const;

  /// Returns the square of the euclidian distance between the edge of the
  /// rectangle and the point. Returns 0 if point is inside the
  /// rectangle
  template <class T2>
  UnsignedLongUnit
  squareEuclidianDistance(const PointImpl<T2> & p) const;

  //  The manhattan distance from a point to a rectangle is defined
  //  in the following way:
  //
  //                               |           |
  //                               |           |
  //                               |           |
  //         (xl - x) + (y-yh)     | (y - yh)  |   (x - xh) + (y - yh)
  //                               |           |
  //                               |           |
  //                               |           |
  //                  -------------------------*--------------
  //                               |           |
  //                               |           |
  //                     (xl - x)  |     0     |  (x - xh)
  //                               |           |
  //                               |           |
  //                  -------------*--------------------------
  //                               |           |
  //                               |           |
  //                               |           |
  //       (xl - x) + (yl - y)     | (yl - y)  |   (x - xh) + (yl - y)
  //                               |           |
  //                               |           |
  //                               |           |
  //

  /// Returns the manhattan distance (deltax + deltay) between the
  /// edge of the rectangle and the point. Returns 0 if point is
  /// inside the rectangle
  template <class T2>
  double
  manhattanDistance(const PointImpl<T2> & p) const;

  /// Returns the distance between this rectangle and a unit or a point
  // o == VERTICAL  returns y distance
  // o == HORIZONTAL returns x distance
  //
  /// returns 0 if point or coordinate lies within
  /// the range of the rectangle
  Unit distance(Unit u, Orientation2D o) const;
  template <class T2>
  Unit distance(const PointImpl<T2> & p, Orientation2D o) const;

  /// Returns the distance between two rectangles along the given orientation
  template <class T2>
  Unit distance(const RectangleImpl<T2> & r2, Orientation2D o) const;

  /// Returns closest euclidian distance between the edges of the two rectangles.
  /// Returns 0 if they overlap or touch
  template <class T2>
  double euclidianDistance(const RectangleImpl<T2> & r2) const;

  /// Returns the square of the closest euclidian distance between the edges of the two rectangles.
  /// Returns 0 if they overlap or touch
  template <class T2>
  UnsignedLongUnit squareEuclidianDistance(const RectangleImpl<T2> & r2) const;

  /// Returns manhattan distance (deltax + deltay) between the two rectangles
  /// Returns 0 if they overlap or touch
  template <class T2>
  Unit manhattanDistance(const RectangleImpl<T2> & r2) const;

  /// Returns the distance deltax and deltay between the two rectangles
  /// Sets them to 0 if the two rectangles' ranges overlap
  /// on that particular axis
  template <class T2>
  RectangleImpl& getDeltas(const RectangleImpl<T2> & r2,
                           Unit& deltax,
                           Unit& deltay) const;

  /// Bloats or shrinks independently on each orientation.
  /// Leaves this unchanged, returns the resulting rectangle
  /// Bloats if corresponding arg is > 0 and shrinks otherwise.
  /// Allows a shrunk rectangle to "flip" over

  RectangleImpl generalBloat(const Unit xbloat, const Unit ybloat) const;

  // Bloats r along o with bloatAlongO
  // bloats r perpendicular to o with bloatPerpendicularToO
  // makes no assumptions about correctness of o, or any overflow on coord values!

  /* this name does not conform !!
     void
     bloat(RectangleImpl & r, Orientation2D o,
     const Unit bloatAlongO, const Unit bloatPerpendicularToO);
  */

  //. returns true if the range in orientation o overlaps
  //  considerTouch will make it consider touch
  //  o == HORIZONTAL  will check for x range overlaps
  //  o == VERTICAL will check for y range overlaps
  template <class T2>
  bool rangeOverlaps(const RectangleImpl<T2> & r2, Orientation2D o, bool considerTouch) const;

  // For HORIZONTAL orientation, returns a,b,c,d below.
  //
  //       a
  // ---------------
  //     |   |
  //  b  | R |   d
  //     |   |
  // ---------------
  //       c
  //
  // For VERTICAL orientation, returns a,b,c,d below.
  //
  //     |   |
  //     |   |
  //     | a |
  //  b  |   |
  //     -----
  //     |   |
  //     | R |   d
  //     |   |
  //     -----
  //     |   |
  //     | c |
  //     |   |
  //

  template <class T2>
  void getNeighbors(RectangleImpl<T2> resultArray[4],  Orientation2D o) const;


  //. Subtract subtrahend from minuend  (minuend - subtrahend)
  // The result is 0,1,2,3 or 4 rectangles put in the resultArray
  //
  // If orientation is set to VERTICAL (default) then
  // the result rectangles are minim number of vertical slices
  //
  //   M (minuend)
  // --------------------
  // |      |   |       |
  // |      |   |       |
  // |      | a |       |
  // |   b  |   |       |
  // |      -----       |
  // |      |   |       |
  // |      | S |   d   |
  // |      |   |       |
  // |      -----       |
  // |      |   |       |
  // |      | c |       |
  // |      |   |       |
  // --------------------
  //
  //
  // If orientation is set to HORIZONTAL, then
  // the result rectangles are minim number of horizontal slices
  //
  //   M (minuend)
  // --------------------
  // |                  |
  // |        a         |
  // |------------------|
  // |      |   |       |
  // |  b   | S |   d   |
  // |      |   |       |
  // |------------------|
  // |        c         |
  // |                  |
  // --------------------
  //
  // If M doesn't intersect with S then a copy of M is put in a's slot ([0])
  // The return value is 'false'.
  //
  // Otherwise, the return value is 'true'.
  //
  // When M is inside of S, then all the results are null.
  //
  // The resultArray and resultValid store the data
  // about the resulting rectangles in the following order:
  // [0] = a
  // [1] = b
  // [2] = c
  // [3] = d
  //
  // The caller has to send in a sane resultArray[] and a sane resultValid[]
  // and not just some bogus pointer. The function will populate the
  // elements of these arrays, but will not allocate the arrays if they are null.
  // !!!!!
  //
  template <class T2, class T3>
  bool
  areaSubtract(RectangleImpl<T2> resultArray[4], 
               bool resultValid[4],
               const RectangleImpl<T3>& subtrahend,
               Orientation2D orientation = VERTICAL,
               bool considerTouch = false) const;

  //. Generalized intersection (GI) between R1 and R2:
  // if the two rectangles overlap, then
  // it's the area of intersection. If they don't, then it's the
  // rectangle _between_ the two
  //
  //
  //             --------------
  //             |            |
  //             |    R1      |
  //             |            |
  //             |------------
  //             |    |
  //             | GI |
  //             |    |
  //    --------------
  //    |   R2        |
  //    |             |
  //    --------------
  //
  //
  //
  //             ----------------
  //             |              |
  //             |     R1       |
  //             |              |
  //    ----------------        |
  //    |        |     |        |
  //    |        | GI  |        |
  //    |        |     |        |
  //    |        ------+--------
  //    |              |
  //    |              |
  //    |    R2        |
  //    ---------------+
  //
  //
  //
  //                    -----------------
  //                    |               |
  //                    |               |
  //                    |      R1       |
  //                    |               |
  //                    |               |
  //              ------+----------------
  //             |      |
  //             | GI   |
  //             |      |
  //    ---------+------
  //   |         |
  //   |     R2  |
  //   |         |
  //   ----------

  /// Sets this to the generalized intersection of this and the given rectangle
  template <class T2>
  RectangleImpl& generalizedIntersect(const RectangleImpl<T2>& r);

  /// Sets this to the generalized intersection of the given rectangles
  template <class T2, class T3>
  RectangleImpl&
  generalizedIntersection(const RectangleImpl<T2>& r1, const RectangleImpl<T3>& r2);

  // What does this do?
  static
  RectangleImpl
  generalizedIntersection(const std::vector<RectangleImpl>& rs);

  // set {x|y}l,h appropriately depending on Orientation
  // args: lo & hi are automatically ordered
  RectangleImpl& setBounds(Orientation2D o, Unit lo, Unit hi);  

  // bloat r to infinity on dir
  // clip rects to r
  // populate results with the tileized rects along dir
  template <class T2, class T3>
  void
  tileizeRectanglesInDir(std::vector<RectangleImpl<T2> >& results,
                         const std::vector<RectangleImpl<T3> >& rects,
                         Direction2D dir) const;

  // Compute the maximal rectangles cover of the area covered by a set rectangles
  // rlist is an in-out argument
  // input: rectangles defining the area to be covered
  // output: max size rectangles covering the same area
  template <class T2>
  static void maxCover (std::vector<RectangleImpl<T2> >& rects);

  template <class T2>
  static void tunnelBloat (std::vector<RectangleImpl<T2> >& rects, Unit xbloat, Unit ybloat, bool considerTouch = true);

  // Find the transformation (translation + expansion/contraction) from rectangle "from" to rectangle "to" and apply it to r
  template <class T2, class T3>
  RectangleImpl transform(const RectangleImpl<T2>& from, const RectangleImpl<T3>& to) const;

  // Returns the symmetric with respect to the first diagonal (flip x<->y)
  RectangleImpl flip (void) const;

  RectangleImpl& flipInPlace(Orientation2D o);

  RectangleImpl flip(Orientation2D o) const;

  // returns true if p is on the boundary of rect
  template <class T2>
  bool isPointOnBoundary(const PointImpl<T2>& p) const;

  // it will align one of the 4 edges of the rectangle with the given point
  // if it needs to it will modify up to 2 coordinates to make that happen
  // for ex:  rect 10, 20, 30, 40   point 5,6
  //   rect.alignEdgeInDirectionToPoint(point, WEST)  -> 5, 20, 30, 40 // modified only xl
  //   rect.alignEdgeInDirectionToPoint(point, EAST)  -> 5, 20, 5, 40  // it had to modify both xl and xh
  template <class T2>
  RectangleImpl& alignEdgeInDirectionToPoint(const PointImpl<T2>& p, 
                                                    Direction2D d2d)
  {
    set(d2d, p.get(static_cast<Orientation2D>(d2d)));
    ////SMART_ASSERT(get(d2d) == p.get((static_cast<Orientation2D>(d2d))));
    return *this;
  }

  // sets the positive and negative edges of toAdjust along ori to be equal to
  // the positive and negative edges of toMatch
  template <class T2, class T3>
  static bool setEdgesInOrientationToMatch(RectangleImpl<T2>& toAdjust, 
                                           const RectangleImpl<T3>& toMatch,
                                           Orientation2D ori);


  // OK, here's the deal
  // this function is written specifically for shield-related edge obscuring detection
  // given victim and the collection of agressors, each agressor bites away from the victim's four edges and four corners
  // if nothing is left, false is returned
  // edge results are all the exposed edges (edges that need to be shielded)
  // cornerResults are all the exposed corners
  // When I say exposed, it means that if the edge or corner is visible to to outside and needs to be shielded (aka.
  // it does make a difference wrt design rule enforcing)
  // For example if two rectangles overlap and their north edge is flush, then the north edge is exposed
  // if say victim's north edge touches the agressors south edge, then the edge is obscured
  // For a corner to be exposed, there must be 2 exposed edges that touch it
  //
  //   bool identifyExposedEdgesAndCorners(std::vector<std::pair<RectangleImpl, Direction2D> >& edgeResults,
  //                                       std::vector<std::pair<PointImpl<PointData>, Diagonal2D> >& cornerResults,
  //                                       const std::vector<RectangleImpl>& aggressors) const;

  // clip incoming collection of rectangles to incoming rectangle.  Return
  // result in output collection
  template <class T2, class Container>
  static void clip (Container& out, const Container& in, const RectangleImpl<T2>& clipper)
  {
    std::insert_iterator<Container> inserter(out, out.end());
    typename Container::const_iterator it;
    for (it = in.begin(); it != in.end(); ++it) {
      typename Container::value_type rect = *it;
      if (clipper.intersects(rect)) {
        rect.clip(clipper);
        *inserter++ = rect;
      }
    }
  }

  // rectangle difference: r = r1 (-) r2 is a non-commutative operation
  // The operation returns in r, the deltas (along the 4 dirs) w.r.t (0,0) the rectangle r2
  // need to be bloated to become the encompassingbbox(r1, r2)
  template <class T2>
  RectangleImpl rectangleDifference(const RectangleImpl<T2>& r2) const;

private:
  static T construct_(const IntervalImpl<IntervalData>& hrange, 
                             const IntervalImpl<IntervalData>& vrange);
};

typedef RectangleImpl<RectangleData> Rectangle;

template <class T>
std::ostream& operator<< (std::ostream& o, const RectangleImpl<T>& r);

template <class T>
std::istream& operator>> (std::istream& i, RectangleImpl<T>& r);

