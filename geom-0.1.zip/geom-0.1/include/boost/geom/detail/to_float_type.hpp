#ifndef BOOST_GEOM_DETAIL_TO_FLOAT_TYPE_HPP
#define BOOST_GEOM_DETAIL_TO_FLOAT_TYPE_HPP

// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/geom/detail/meta_if.hpp>
#include <boost/geom/detail/meta_equal.hpp>

namespace boost { namespace geom { namespace detail {

/// Template meta-function that returns the float type
/// ``corresponding'' to Value 
template <typename Value>
struct to_float_type 
{
 	// This (fairly complicated stuff) returns Value if Value is
	// float, double or long double. Otherwise, this typdefs
	// float_type to double.
	typedef typename meta_if<meta_equal<Value, double>::value ||
		meta_equal<Value, float>::value ||
	meta_equal<Value, long double>::value, Value, double>::type type;
};
 
} } } // namespace boost::geom::detail

#endif // #ifndef BOOST_GEOM_DETAIL_TO_FLOAT_TYPE_HPP
