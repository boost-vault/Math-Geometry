#ifndef PERMUTATION_H
#define PERMUTATION_H

#include "boost/preprocessor/comparison/not_equal.hpp"
#include "boost/preprocessor/comparison/greater.hpp"
#include "boost/preprocessor/comparison/equal.hpp"
#include "boost/preprocessor/facilities/expand.hpp"
#include "boost/preprocessor/facilities/empty.hpp"
#include "boost/preprocessor/control/if.hpp"
#include "boost/preprocessor/tuple/eat.hpp"
#include "boost/preprocessor/seq.hpp"
#include "boost/preprocessor/cat.hpp"
#include "boost/type_traits.hpp"

#define BLAS_VEC2D_SEQ	((x)(y))((x)(y))
#define BLAS_VEC3D_SEQ	((0)(x)(y)(z))((x)(y)(z))((x)(y)(z))
#define BLAS_VEC4D_SEQ	((0)(x)(y)(z)(w))((0)(x)(y)(z)(w))((x)(y)(z)(w))((x)(y)(z)(w))

#define BLAS_VECTOR_ELEMENT_AS_NUMBER(I)	BOOST_PP_CAT(BLAS_VECTOR_ELEMENT_AS_NUMBER, I)
#define BLAS_VECTOR_ELEMENT_AS_NUMBER0	0
#define BLAS_VECTOR_ELEMENT_AS_NUMBERx	1
#define BLAS_VECTOR_ELEMENT_AS_NUMBERy	1
#define BLAS_VECTOR_ELEMENT_AS_NUMBERz	1
#define BLAS_VECTOR_ELEMENT_AS_NUMBERw	1

#define BLAS_VECTOR_ELEMENT(I)	BOOST_PP_CAT(BLAS_VECTOR_ELEMENT, I)
#define BLAS_VECTOR_ELEMENTx	X
#define BLAS_VECTOR_ELEMENTy	Y
#define BLAS_VECTOR_ELEMENTz	Z
#define BLAS_VECTOR_ELEMENTw	W

#define BLAS_REMOVE_REFERENCE(s, data, elem)	\
typename boost::remove_reference<BLAS_VECTOR_ELEMENT(elem)>::type &

#define BLAS_REMOVE_REFERENCE_AS_VALUE(s, data, elem)	\
typename boost::remove_reference<BLAS_VECTOR_ELEMENT(elem)>::type

#define BLAS_FILTER_BLANK(s, data, elem)	\
BOOST_PP_NOT_EQUAL(BLAS_VECTOR_ELEMENT_AS_NUMBER(elem), data)

#define BLAS_NUM_BLANKS(seq)	\
BOOST_PP_SUB(BOOST_PP_SEQ_SIZE(seq), BOOST_PP_SEQ_SIZE(BOOST_PP_SEQ_FILTER(BLAS_FILTER_BLANK, 0, seq)))

#define BLAS_FILTER_SEQUENCE_FIRST(seq)																	\
BOOST_PP_IF(BOOST_PP_EQUAL(0, BLAS_VECTOR_ELEMENT_AS_NUMBER(BOOST_PP_SEQ_ELEM(0, seq))),	\
BOOST_PP_SEQ_PUSH_BACK(BOOST_PP_SEQ_NIL, 0), seq)

#define BLAS_FILTER_SEQUENCE_ONLY_VEC4(seq)	\
BOOST_PP_IF(BOOST_PP_EQUAL(4, BOOST_PP_SEQ_SIZE(seq)), BLAS_FILTER_SEQUENCE_FIRST(seq), seq)

#define BLAS_FILTER_SEQUENCE(seq)	\
BOOST_PP_IF(BOOST_PP_EQUAL(BLAS_NUM_BLANKS(seq), 1), BLAS_FILTER_SEQUENCE_ONLY_VEC4(seq), seq)

#define BLAS_SWIZZLE_BODY(seq)																			\
BOOST_PP_CAT(vec, BOOST_PP_SEQ_SIZE(seq))																\
<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_TRANSFORM(BLAS_REMOVE_REFERENCE, ~, seq))>					\
BOOST_PP_SEQ_CAT(seq)(void) { return BOOST_PP_CAT(vec, BOOST_PP_SEQ_SIZE(seq))			\
<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_TRANSFORM(BLAS_REMOVE_REFERENCE, ~, seq))>					\
(BOOST_PP_SEQ_ENUM(seq)); }																				\
BOOST_PP_CAT(vec, BOOST_PP_SEQ_SIZE(seq))																\
<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_TRANSFORM(BLAS_REMOVE_REFERENCE_AS_VALUE, ~, seq))>		\
BOOST_PP_SEQ_CAT(seq)(void) const { return BOOST_PP_CAT(vec, BOOST_PP_SEQ_SIZE(seq))	\
<BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_TRANSFORM(BLAS_REMOVE_REFERENCE_AS_VALUE, ~, seq))>		\
(BOOST_PP_SEQ_ENUM(seq)); }

#define BLAS_LAZY_SWIZZLE_BODY(seq)	BLAS_SWIZZLE_BODY(BOOST_PP_SEQ_FILTER(BLAS_FILTER_BLANK, 0, seq))

#define BLAS_NEXT_PERMUTATION_IF_NOT_EMPTY(seq)												\
BOOST_PP_IF(BOOST_PP_GREATER(BOOST_PP_SEQ_SIZE(seq), 1),	BLAS_LAZY_SWIZZLE_BODY,	\
BOOST_PP_TUPLE_EAT(1))(seq)

#define BLAS_NEXT_PERMUTATION(r, product)	\
BLAS_NEXT_PERMUTATION_IF_NOT_EMPTY(BLAS_FILTER_SEQUENCE(product))

#define BLAS_DECLARE_SWIZZLE(n)	BOOST_PP_SEQ_FOR_EACH_PRODUCT(BLAS_NEXT_PERMUTATION, n)

#endif
