/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T, class T2>
class lessSegment
  : public std::binary_function<const SegmentImpl<T>&, const SegmentImpl<T2>&, bool>
{
private:
  AxisTransform atr_; // we want to compare along this orientation
public:
  inline lessSegment() {;} // allow data member to take default value
  inline lessSegment(AxisTransform atr) : atr_(atr) {;}
  inline lessSegment(Direction2D dir) : atr_(dir) {;}
  inline lessSegment(Orientation2D orient) : atr_(orient) {;}
  inline bool operator () (const SegmentImpl<T>& a,
                           const SegmentImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessSegment<T, T2>::operator () (const SegmentImpl<T>& a,
                                 const SegmentImpl<T2>& b) const {
  SegmentImpl<T> a_(a);
  SegmentImpl<T2> b_(b);
  a_.transform(atr_);
  b_.transform(atr_);
  return a_ < b_;
}
  
template<class T> template<class T2>
inline bool 
SegmentImpl<T>::operator<(const SegmentImpl<T2>& b) const {
  return low() < b.low() || ((low() == b.low()) & (high() < high()));
}

template<class T> template<class T2>
inline 
SegmentImpl<T>::SegmentImpl(const PointImpl<T2>& p, 
                            Orientation2D orient,
                            UnsignedUnit length) {
  *this = construct_(PointImpl<PointData>(p), orient, length);
}

template<class T> template<class T2, class T3>
inline 
SegmentImpl<T>::SegmentImpl(const PointImpl<T2>& p1, const PointImpl<T3>& p2) {
  Orientation2D orient = predicated_value(p1.x() != p2.x(), HORIZONTAL,
                                          VERTICAL);
  *this = construct_(min(p1, p2), orient, abs(p1.get(orient) - p2.get(orient))); 
}

template<class T>
inline SegmentImpl<T>::SegmentImpl() {
  *this = construct_(PointImpl<PointData>(), Orientation2D(), UnsignedUnit());
}

template<class T>
const SegmentImpl<T>& 
SegmentImpl<T>::operator=(const SegmentImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T>
const SegmentImpl<T>& 
SegmentImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::operator==(const SegmentImpl<T2>& b) const {
  return (low() == b.low()) & (getOrient() == b.getOrient()) &
    (getLength() == b.getLength());
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::operator!=(const SegmentImpl<T2>& b) const {
  return !((*this) == b);
}

template<class T>
inline
SegmentImpl<T>::operator IntervalImpl<IntervalData>() const {
  const IntervalImpl<T>& i = mimicConstInterval();
  return IntervalImpl<IntervalData>(i.low(), i.high());
}

template<class T>
inline PointImpl<PointData> 
SegmentImpl<T>::get(Direction1D dir) const {
  return get_(dir);
}

template<class T> template<class T2>
inline SegmentImpl<T>& 
SegmentImpl<T>::set(Direction1D dir, const PointImpl<T2>& value) {
  set_(dir, PointImpl<PointData>(value)); return *this;
} 
    
template<class T> template<class T2>
inline SegmentImpl<T>& 
SegmentImpl<T>::low(const PointImpl<T2>& value) {
  return set(LOW, value);
}

template<class T> template<class T2>
inline SegmentImpl<T>& 
SegmentImpl<T>::high(const PointImpl<T2>& value) {
  return set(HIGH, value);
}

template<class T>
inline Orientation2D 
SegmentImpl<T>::getOrient() const {
  return getOrient_();
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::setOrient(Orientation2D orient) {
  setOrient_(orient); return *this;
}

template<class T>
inline UnsignedUnit 
SegmentImpl<T>::getLength() const {
  return getLength_();
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::setLength(UnsignedUnit value) {
  setLength_(value); return *this;
}

template<class T>
inline Unit 
SegmentImpl<T>::getMajor() const {
  return low().get(getOrient().getPerpendicular());
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::setMajor(Unit value) {
  PointImpl<PointData> newLow = low();
  newLow.set(getOrient().getPerpendicular(), value);
  low(newLow); return *this;
}
    
template<class T>
inline IntervalImpl<T>& 
SegmentImpl<T>::mimicInterval() {
  return reinterpret_cast<IntervalImpl<T>&>(yield());
}

template<class T>
inline const IntervalImpl<T>& 
SegmentImpl<T>::mimicConstInterval() const {
  return reinterpret_cast<const IntervalImpl<T>&>(yieldConst());
}

/// isValid will detect integer overflow and improper data stored in T
/// because the length is stored length plus low end point coordinate
/// may exceed the range of the coordinate data type.
template<class T>
inline bool 
SegmentImpl<T>::isValid() const {
  return mimicConstInterval().isValid();
}

template<class T>
inline UnsignedUnit 
SegmentImpl<T>::delta() const {
  return mimicConstInterval().delta();
}

template<class T>
inline UnsignedUnit 
SegmentImpl<T>::delta(Orientation2D orient) const {
  return predicated_value(orient == getOrient(), delta(), (UnsignedUnit)0);
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::transform(const AxisTransform& atr) {
  Direction2D trDirs[2];
  atr.getDirections(trDirs[0], trDirs[1]);
  Direction2D newDir = trDirs[getOrient().toInt()];
  UnsignedUnit len = getLength();
  setOrient(getOrient().transform(atr));
  low(low().transform(atr));
  setLength(0);
  bloat(newDir, len);
  return *this;
}
    
template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::transform(const Transform& tr) {
  Direction3D trDirs[3];
  tr.getAxisTransform().getDirections(trDirs[0], trDirs[1], trDirs[2]);
  Direction3D newDir = trDirs[getOrient().toInt()];
  UnsignedUnit len = getLength();
  setOrient(getOrient().transform(tr.getAxisTransform()));
  setLength(0);
  set(LOW, get(LOW).transform(tr));
  return bloat(newDir, len);
}

/// check if Segment b is inside `this` Segment
/// if considerTouch is true b is allowed to touch the boundary of 'this'
/// and an orthoginal segment will only be contained if considerTouch 
/// is true and the orthoginal segment has zero length
template<class T> template<class T2>
inline bool 
SegmentImpl<T>::contains(const SegmentImpl<T2>& b, 
                         bool considerTouch) const {
  bool ivlcontains = mimicConstInterval().contains(b.mimicConstInterval(), considerTouch);
  bool zerolen = b.getLength() == 0;
  return (getOrient() == b.getOrient() & ivlcontains) | 
    (zerolen & contains(b.low()) & considerTouch);
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::contains(const PointImpl<T2>& p, 
                         bool considerTouch) const {
  bool ivlcontains = mimicConstInterval().contains(p.get(getOrient()), 
                                                   considerTouch);
  return ivlcontains & colinear(p);
}

template <class T> template <class T2>
inline PointImpl<PointData>  
SegmentImpl<T>::project(const PointImpl<T2>& point) const {
  PointImpl<PointData> retval(getMajor(), getMajor());
  if(mimicConstInterval().contains(point.get(getOrient()), true)) {
    retval.set(getOrient(), point.get(getOrient()));
  }
  else {
    retval.set(getOrient(), 
               predicated_value(abs(point.get(getOrient()) - low().get(getOrient())) <
                                abs(point.get(getOrient()) - high().get(getOrient())),
                                low().get(getOrient()), high().get(getOrient())));
  }
  return retval;
}

template <class T> template <class T2, class T3>
inline bool 
SegmentImpl<T>::project(PointImpl<T2>& result, const PointImpl<T3>& point,
                         Direction2D dir) const {
  PointImpl<PointData> retval(getMajor(), getMajor());
  if(Orientation2D(dir) == getOrient()) {
    if(point.get(getOrient().getPerpendicular()) != getMajor()) {
      return false;
    }
    if(mimicConstInterval().contains(point.get(getOrient()), true)) {
      retval.set(getOrient(), point.get(getOrient()));
    } else {
      if(Direction1D(dir) == HIGH && mimicConstInterval().low() >
         point.get(getOrient())) {
        retval.set(getOrient(), mimicConstInterval().low());
      } else if(Direction1D(dir) == LOW && mimicConstInterval().high() <
                point.get(getOrient())) {
        retval.set(getOrient(), mimicConstInterval().high());
      } else {
        return false;
      }
    }
  } else {
    if(mimicConstInterval().contains(point.get(getOrient()), true)) {
      if(Direction1D(dir) == HIGH && getMajor() >=
         point.get(getOrient().getPerpendicular()) ||
         Direction1D(dir) == LOW && getMajor() <=
         point.get(getOrient().getPerpendicular())) {
        retval.set(getOrient(), point.get(getOrient()));
      } else {
        return false;
      }
    } else {
      return false;
    }
  }
  result = retval;
  return true;
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::colinear(const PointImpl<T2>& p) const {
  return getMajor() == p.get(getOrient());
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::colinear(const SegmentImpl<T2>& b) const {
  return getOrient() == b.getOrient() & getMajor() == b.getMajor();
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::perpendicular(const SegmentImpl<T2>& b) const {
  return getOrient() != b.getOrient();
}

/// check if a segment b crosses to 'this'
/// if consider touch is true the segments are considered to cross if they
/// are abutting
template<class T> template<class T2>
inline bool 
SegmentImpl<T>::crosses(const SegmentImpl<T2>& b, bool considerTouch) const {
  return getOrient() != b.getOrient() &
    b.mimicConstInterval().contains(getMajor(), considerTouch);
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::inside(const SegmentImpl<T2>& b, bool considerTouch) const {
  return b.contains(*this, considerTouch);
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::intersects(const SegmentImpl<T2>& b, 
                           bool considerTouch) const {
  bool cl = colinear(b);
  bool ivlintersects = mimicConstInterval().intersects(b.mimicConstInterval(), considerTouch);
  return (cl & ivlintersects) | crosses(b, considerTouch);
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::boundariesIntersect(const SegmentImpl<T2>& b, 
                                    bool considerTouch) const {
  return (intersects(b, considerTouch) &
          !(contains(b, !considerTouch)) &
          !(inside(b, !considerTouch)));
}
    
template<class T> template<class T2>
inline bool 
SegmentImpl<T>::abuts(const SegmentImpl<T2>& b, Direction1D dir) const {
  return (colinear(b) & mimicConstInterval().abuts(b.mimicConstInterval(), dir)) |
    (perpendicular(b) & mimicConstInterval().get(dir) == b.getMajor());
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::abuts(const SegmentImpl<T2>& b) const {
  return (colinear(b) & mimicConstInterval().abuts(b.mimicConstInterval())) |
    (perpendicular(b) & (mimicConstInterval().low() == b.getMajor() |
                         mimicConstInterval().high() == b.getMajor()));
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::intersectRange(const IntervalImpl<T2>& b, 
                               bool considerTouch) {
  return mimicInterval().intersect(b, considerTouch);
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::intersect(const SegmentImpl<T2>& b, bool considerTouch) {
  if(colinear(b)) {
    return mimicInterval().intersect(b.mimicConstInterval(), considerTouch);
  }
  if(perpendicular(b) && 
     mimicInterval().contains(b.getMajor())) {
    mimicInterval().low(b.getMajor());
    mimicInterval().high(b.getMajor());
    return true;
  }
  return false;
}

/// set `this` Segment to the intersection between b1 and b2
/// if considerTouch is true, create intersection even if b1 touches b2
/// and return true if boxes intersect, else set `this` to b1, return false
template<class T> template<class T2, class T3>
inline bool 
SegmentImpl<T>::intersection(const SegmentImpl<T2>& b1, 
                             const SegmentImpl<T3>& b2,
                             bool considerTouch) {
  this = b1;
  return intersect(b2, considerTouch);
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::bloat(UnsignedUnit bloating) {
  mimicInterval().bloat(bloating);
  return *this;
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::bloat(Direction1D dir, UnsignedUnit bloating) {
  mimicInterval().bloat(dir, bloating);
  return *this;
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::shrink(UnsignedUnit shrinking) {
  mimicInterval().shrink(shrinking);
  return *this;
}

template<class T>
inline SegmentImpl<T>& 
SegmentImpl<T>::shrink(Direction1D dir, UnsignedUnit shrinking) {
  mimicInterval().shrink(dir, shrinking);
  return *this;
}

template<class T> template<class T2>
inline bool 
SegmentImpl<T>::encompass(const IntervalImpl<T2>& b) {
  return mimicInterval().encompass(b);
}

/// enlarge `this` Segment to encompass the Segment b 
/// return true if enlargement happened at all
template<class T> template<class T2>
inline bool 
SegmentImpl<T>::encompass(const SegmentImpl<T2>& b) {
  if(!colinear(b))return false;
  return mimicInterval().encompass(b.mimicConstInterval());
}    
    
//private functions
template<class T>
inline PointImpl<PointData> 
SegmentImpl<T>::get_(Direction1D dir) const {
  return SegmentInterface<T>::SegmentGet(*this, dir);
}
template<class T>
inline void 
SegmentImpl<T>::set_(Direction1D dir, const PointImpl<PointData>& value) {
  SegmentInterface<T>::SegmentSet(*this, dir, value.yieldConst());
}
template<class T>
inline Orientation2D 
SegmentImpl<T>::getOrient_() const {
  return SegmentInterface<T>::SegmentGetOrient(*this);
}
template<class T>
inline void 
SegmentImpl<T>::setOrient_(Orientation2D orient) {
  SegmentInterface<T>::SegmentSetOrient(*this, orient);
}
template<class T>
inline UnsignedUnit 
SegmentImpl<T>::getLength_() const {
  return SegmentInterface<T>::SegmentGetLength(*this);
}
template<class T>
inline void 
SegmentImpl<T>::setLength_(UnsignedUnit value) {
  SegmentInterface<T>::SegmentSetLength(*this, value);
}
template<class T>
inline T 
SegmentImpl<T>::construct_(const PointImpl<PointData>& p, 
                           Orientation2D o,
                           UnsignedUnit length) {
  return SegmentInterface<T>::SegmentConstruct(p.yieldConst(), o, length);
}


template <class T>
std::ostream& operator<< (std::ostream& o, const SegmentImpl<T>& s)
{
  o << s.low() << GTL_SEP << s.getOrient() << GTL_SEP << s.getLength();
  return o;
}

template <class T>
std::istream& operator>> (std::istream& i, SegmentImpl<T>& s)
{
  Point low;
  Orientation2D o;
  UnsignedUnit length;
  i >> low >> o >> length;
  s.low(low);
  s.setOrient(o);
  s.setLength(length);
  return i;
}

