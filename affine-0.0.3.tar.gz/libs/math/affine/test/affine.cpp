//  boost affine.cpp test file

//  (C) Copyright Hugo Duncan 2007.
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

// See http://www.boost.org for updates, documentation, and revision history.

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>

#include <boost/numeric/ublas/vector.hpp>
#include <boost/math/affine.hpp>

namespace math=boost::math;

struct frame1 {};
struct frame2 {};

BOOST_AUTO_TEST_CASE(test_scalar)
{
  math::point<double,frame1> p1(1.);
  math::point<double,frame1> p2=1.;
  math::displacement<double,frame1> d1(3);
  p1+=d1;
  BOOST_CHECK_EQUAL(p1.value(),4);
  d1+=d1;
  BOOST_CHECK_EQUAL(d1.value(),6);
  BOOST_CHECK_EQUAL((p2+d1).value(),7);
  d1+=math::displacement_ref<frame1>(3);
  BOOST_CHECK_EQUAL(d1.value(),9);
  p1+=math::displacement_ref<frame1>(3);
  BOOST_CHECK_EQUAL(p1.value(),7);
  double p3=3;
  math::point_ref<frame1>(p3)+=d1;
  BOOST_CHECK_EQUAL(p3,12);
}

BOOST_AUTO_TEST_CASE(test_vector)
{
  //[vectors
  namespace ublas=boost::numeric::ublas;
  typedef ublas::bounded_vector<double,3> vector;
  typedef math::point<vector, frame1> point;
  typedef math::displacement<vector, frame1> displacement;
  point p1(ublas::scalar_vector<double>(3,1.));
  displacement d1(ublas::scalar_vector<double>(3,1.));

  p1+=d1;
//<--
  BOOST_CHECK_EQUAL(norm_1(p1.value()),6);
//-->

  vector p2(ublas::scalar_vector<double>(3,1.));
  math::point_ref<frame1>(p2)+=d1;
//<--
  BOOST_CHECK_EQUAL(norm_1(p2),6);
//-->

  p1=math::point_ref<frame1>(p2)+d1;
//<--
  BOOST_CHECK_EQUAL(norm_1(p1.value()),9);
//-->
  point p3(math::point_ref<frame1>(p2)+d1);
//<--
  BOOST_CHECK_EQUAL(norm_1(p3.value()),9);
//-->

  p3=math::point_ref<frame1>(p2)+d1 ;
//<--
  BOOST_CHECK_EQUAL(norm_1(p3.value()),9);
//-->

  p3-=d1;
//<--
  BOOST_CHECK_EQUAL(norm_1(p3.value()),6);
//-->

  p3=math::point_ref<frame1>(p2)-d1;
//<--
  BOOST_CHECK_EQUAL(norm_1(p3.value()),3);
//-->

  const vector d2(ublas::scalar_vector<double>(3,2.));
  d1+=math::displacement_ref<frame1>(d2);
//<--
  BOOST_CHECK_EQUAL(norm_1(d1.value()),9);
//-->

  vector d3(ublas::scalar_vector<double>(3,2.));
  math::displacement_ref<frame1>(d3)-=d1;
//<--
  BOOST_CHECK_EQUAL(norm_1(d3),3);
//-->

  math::displacement_ref<frame1>(d3)=d1+math::displacement_ref<frame1>(d2);
//<--
  BOOST_CHECK_EQUAL(norm_1(d3),15);
//-->

  math::displacement_ref<frame1>(d3)=d1-math::displacement_ref<frame1>(d2);
//<--
  BOOST_CHECK_EQUAL(norm_1(d3),3);
//-->


  //]
}
