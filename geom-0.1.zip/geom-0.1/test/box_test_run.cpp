// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <cassert>

// Boost.Geom
#include <boost/geom/point.hpp>
#include <boost/geom/point_xy.hpp>
#include <boost/geom/box.hpp>
#include <boost/geom/box_xywh.hpp>

// Output points
template<class Char, class Traits, class PointImpl>
std::basic_ostream<Char, Traits>&
operator<<(std::basic_ostream<Char, Traits>& os, const boost::geom::point<PointImpl>& pt)
{ return os<<'('<<pt.x()<<','<<pt.y()<<','<<pt.z()<<')'; }

// Outputs boxes
template<class Char, class Traits, class BoxImpl>
std::basic_ostream<Char, Traits>&
operator<<(std::basic_ostream<Char, Traits>& os, const boost::geom::box<BoxImpl>& bx)
{
	return os<<"(X1: "<<bx.x1()<<", Y1: "<<bx.y1()<<", Width: "<<bx.width()<<", Height: "<<
	    bx.height()<<")";
}

int main()
{
	typedef short value_type;
	
	typedef boost::geom::point_xy<value_type> point_xy;
	typedef boost::geom::point<point_xy> point;
	
	// This is an implementation type for the box abstraction that
	// holds its X1, Y1, Width, and Height attibutes as value_types
	typedef boost::geom::box_xywh<short> box_xywh;

	typedef boost::geom::box<box_xywh> box;

	box bx=box_xywh(3, 5, 10, 20); // box_xywh() gets X, Y, Width,
				     // Height (inorder);
	
        // bx displaced by a factor of 4 for X and 10 for the Y,
	// this doesn't affect the size of the box, it just "moves" it.
	assert ( (box(bx+point_xy(4,10)).width()==bx.width()) );
	assert ( (box(bx+point_xy(4,10)).height()==bx.height()) );

	box bx2=bx;

	// Enlarge bx2's width by 10 units in both directions
	bx2.xmin()-=10;
	bx2.xmax()+=10;
//	std::cout<<bx<<" after enlarging by 10 units "<< bx2<<std::endl;

	// Now bx is contained within bx2, so union operation should
	// do no harm to bx2
	assert(bx2==(bx2|bx));

	// And bx is the intersection of bx and bx2
	assert(bx==(bx&bx2));

	// Here bx is "centered" inside bx2
	assert(bx.center()==bx2.center());

	using boost::geom::x1;
	using boost::geom::y1;
	
	// Bringing the center of bx at one corner of bx2	
	bx.center()=bx2.corner<x1, y1>();
	assert( (bx.center()==bx2.corner<x1,y1>()) );

	// Now bx is no longer contained within bx2
	std::cout<<"*********"<<bx<<bx2<<(bx|bx2)<<std::endl;
 
	assert(bx2!=(bx|bx2));

	// Clip bx by bx2, cuts the parts of bx that are not also
	// inside bx2
	bx &= bx2;

	// Bring bx back to the center of bx2
	bx.center()=bx2.center();

	// Bring the center of bx2 to the origin (bx is not affected,
	// of course)
	bx2.center()=point_xy(0, 0);

	bx2 |= bx; // Make bx2 large enough to contain bx
}
