/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

//
// =================================================================
// CLASS: Direction2D
// =================================================================
// (class summary here)
// =================================================================
//

/////////////////////
// Casting operators
/////////////////////

// The DAG (directed acyclic graph) of the casting operators is
//
//
// D2D -> O3D
// D2D -> O2D
// D2D -> D3D
// D2D -> D1D
//
// O2D -> O3D
//
// D3D -> O3D
// D3D -> D1D
//
//
// Notice we never cast from 3D to 2D
// We always cast from specific to more general
// Keep it this way, or you'll ask for trouble
// Mt St Helens is erupting Oct 2004


inline Direction2D::operator Orientation2D() const
{
  return Orientation2D(Orientation2D::All2DOrientations(val_ >> 1));
}

inline Direction2D::operator Direction1D() const
{
  return Direction1D(Direction1D::All1DDirections(val_ & 1)); // mask only LSB
}


inline bool Direction2D::operator == (Orientation2D rs) const { return rs == static_cast<Orientation2D>(*this); }
//inline bool Direction2D::operator == (Direction3D rs)   const { return rs ==  static_cast<Direction3D>(*this); }
inline bool Direction2D::operator == (Orientation3D rs) const { return rs ==  static_cast<Orientation3D>(*this); }

inline bool Direction2D::operator != (Orientation2D rs) const { return rs != static_cast<Orientation2D>(*this); }
//inline bool Direction2D::operator != (Direction3D rs)   const { return rs !=  static_cast<Direction3D>(*this); }
inline bool Direction2D::operator != (Orientation3D rs) const { return rs !=  static_cast<Orientation3D>(*this); }

inline Direction3D::operator Orientation3D() const {
  return Orientation3D(Orientation3D::All3DOrientations(val_ >> 1));
}

inline Direction3D::operator Direction1D() const {
  return Direction1D(Direction1D::All1DDirections(val_ & 1)); // mask only LSB
}

inline bool Direction3D::operator == (Orientation3D rs) const { return rs == static_cast<Orientation3D>(*this); }
//inline bool Direction3D::operator == (Direction2D rs) const { return *this == static_cast<Direction3D>(rs); }

inline bool Direction3D::operator != (Orientation3D rs) const { return rs != static_cast<Orientation3D>(*this); }
//inline bool Direction3D::operator != (Direction2D rs) const { return *this != static_cast<Direction3D>(rs); }

inline Orientation2D::operator Orientation3D() const {
  return Orientation3D(Orientation3D::All3DOrientations(val_));
}

//inline bool Orientation2D::operator == (Orientation3D rs) const { return rs == static_cast<Orientation3D>(*this); }

//inline bool Orientation2D::operator != (Orientation3D rs) const { return rs != static_cast<Orientation3D>(*this); }


inline Direction2D::Direction2D(int d)
{
  val_ = All2DDirections(d);
}
  
inline Direction2D& Direction2D::operator++()
{
  if (val_ < (int)END_DIRECTION_2D) {
    unsigned int v = val_;
    ++v;
    val_ = Direction2D::All2DDirections(v);
  }
  return *this;
}

inline Direction2D Direction2D::operator++(int)
{
  Direction2D temp(*this);
  ++(*this);
  return temp;
}

inline Direction2D& Direction2D::operator--()
{
  if(val_ > (int)BEGIN_DIRECTION_2D){
    unsigned int v = val_;
    --v;
    val_ = Direction2D::All2DDirections(v);
  }
  return * this;
}
  
inline Direction2D Direction2D::operator--(int)
{
  Direction2D temp(*this);
  --(*this);
  return temp;
}
  
inline Direction2D& Direction2D::transform(const AxisTransform& atr) {
  Direction2D axis_array[2];
  atr.getDirections(axis_array[0], axis_array[1]);
  int index = static_cast<Orientation2D>(*this).toInt();
  *this = predicated_value(isPositive(), axis_array[index], axis_array[index].backward());
  return *this;
}
  
inline Direction2D& Direction2D::transform(const Transform& tr) {
  return transform(tr.getAxisTransform());
}
  
inline Direction2D Direction2D::backward() const
{
  // flip the LSB, toggles 0 - 1   and 2 - 3
  return Direction2D(val_ ^ 1);
}

inline Direction2D Direction2D::turn(Direction1D t) const
{
  return Direction2D(val_ ^ 3 ^ (val_ >> 1) ^ t.val_);
}
  

inline Direction2D Direction2D::left()  const {return turn(HIGH);}
inline Direction2D Direction2D::right() const {return turn(LOW);}

//
// =================================================================
// CLASS: Direction3D
// =================================================================
// (class summary here)
// =================================================================
//

//. Private constructor
//  Never use it, only for the very initial setup of the consts
inline Direction3D::Direction3D(int d)
{
  val_ = All3DDirections(d);
}

inline Direction3D& Direction3D::operator++()
{
  if (val_ < (int)END_DIRECTION_3D) {
    unsigned int v = val_;
    ++v;
    val_ = Direction3D::All3DDirections(v);
  }
  return *this;
}

inline Direction3D Direction3D::operator++(int)
{
  Direction3D temp(*this);
  ++(*this);
  return temp;
}

inline Direction3D& Direction3D::operator--()
{
  if (val_ > (int)BEGIN_DIRECTION_3D){
    unsigned int v = val_;
    --v;
    val_ = Direction3D::All3DDirections(v);
  }
  return * this;
}
  
inline Direction3D Direction3D::operator--(int)
{
  Direction3D temp(*this);
  --(*this);
  return temp;
}
  
inline Direction3D& Direction3D::transform(const AxisTransform& atr) {
  Direction3D axis_array[3];
  atr.getDirections(axis_array[0], axis_array[1], axis_array[2]);
  int index = static_cast<Orientation3D>(*this).toInt();
  *this = predicated_value(isPositive(), axis_array[index], axis_array[index].backward());
  return *this;
}
  
inline Direction3D& Direction3D::transform(const Transform& tr) {
  return transform(tr.getAxisTransform());
}
  
inline Direction3D Direction3D::backward() const
{
  // flip the LSB, toggles 0 - 1   and 2 - 3
  return Direction3D(val_ ^ 1);
}
  
//
// =================================================================
// CLASS: Direction1D
// =================================================================
// (class summary here)
// =================================================================
//
  

inline Direction1D::Direction1D(int d)
{
  val_ = All1DDirections(d);
}

inline Direction1D& Direction1D::operator++()
{
  if (val_ < (int)END_DIRECTION_1D) {
    unsigned int v = val_;
    ++v;
    val_ = Direction1D::All1DDirections(v);
  }
  return *this;
}

inline Direction1D Direction1D::operator++(int)
{
  Direction1D temp(*this);
  ++(*this);
  return temp;
}

inline Direction1D& Direction1D::operator--()
{
  if (val_ > (int)BEGIN_DIRECTION_1D){
    unsigned int v = val_;
    --v;
    val_ = Direction1D::All1DDirections(v);
  }
  return * this;
}
  
inline Direction1D Direction1D::operator--(int)
{
  Direction1D temp(*this);
  --(*this);
  return temp;
}
  
inline Direction1D Direction1D::backward() const
{
  return Direction1D(val_ ^ 1);
}
  
//
// =================================================================
// CLASS: Orientation
// =================================================================
// (class summary here)
// =================================================================
//

//. Private constructor
//  Never use it, only for the very initial setup of the consts
inline Orientation2D::Orientation2D(int o)
{
  val_ = All2DOrientations(o);
}
  
inline Orientation2D& Orientation2D::operator++()
{
  if (val_ < (int)END_ORIENTATION_2D) {
    unsigned int v = val_;
    ++v;
    val_ = All2DOrientations(v);
  }
  return *this;
}

inline Orientation2D Orientation2D::operator++(int)
{
  Orientation2D temp(*this);
  ++(*this);
  return temp;
}
  
inline Orientation2D& Orientation2D::operator--()
{
  if(val_ > (int)BEGIN_ORIENTATION_2D ){
    unsigned int v = val_;
    --v;
    val_ = All2DOrientations(v);
  }
  return *this;
}
  
inline Orientation2D Orientation2D::operator--(int)
{
  Orientation2D temp(*this);
  --(*this);
  return temp;
}
  
inline void Orientation2D::turn90()
{
  val_ = All2DOrientations(val_^ 1); // toggle lest significant bit
}
  
inline Orientation2D Orientation2D::getPerpendicular(void) const
{
  return Orientation2D(All2DOrientations(val_ ^ 1));
}
  
inline Direction2D Orientation2D::getNegativeDirection(void) const {
  return getDirection(Direction1D::low());
}
  
inline Direction2D Orientation2D::getPositiveDirection(void) const {
  return getDirection(Direction1D::high());
}
  
inline Direction2D Orientation2D::getDirection(Direction1D dir) const {
  return
    Direction2D(Direction2D::All2DDirections((val_ << 1) + dir.toInt()));
}
  
inline Orientation2D& Orientation2D::transform(const AxisTransform& atr) {
  Direction2D axis_array[2];
  atr.getDirections(axis_array[0], axis_array[1]);
  val_ = All2DOrientations(axis_array[val_].toInt() >> 1); //shift off the lsb
  return *this;
}
  
inline Orientation2D& Orientation2D::transform(const Transform& tr) {
  return transform(tr.getAxisTransform());
}
  
inline Orientation3D::Orientation3D(int o)
{
  val_ = All3DOrientations(o);
}

inline Orientation3D& Orientation3D::operator++()
{
  if (val_ < (int)END_ORIENTATION_3D) {
    unsigned int v = val_;
    ++v;
    val_ = All3DOrientations(v);
  }
  return *this;
}

inline Orientation3D Orientation3D::operator++(int)
{
  Orientation3D temp(*this);
  ++(*this);
  return temp;
}
  
inline Orientation3D& Orientation3D::operator--()
{
  if (val_ > (int)BEGIN_ORIENTATION_3D ){
    unsigned int v = val_;
    --v;
    val_ = All3DOrientations(v);
  }
  return *this;
}
  
inline Orientation3D Orientation3D::operator--(int)
{
  Orientation3D temp(*this);
  --(*this);
  return temp;
}
  
inline Direction3D Orientation3D::getDirection(Direction1D dir) const {
  return Direction3D(Direction3D::All3DDirections((val_ << 1) + 
                                                  dir.toInt()));
}

inline Orientation3D Orientation3D::getNormal(Orientation3D orient) const {
  if(*this == orient) return orient;
  int index = toInt() + orient.toInt();
  //H + V = 1
  //H + P = 2
  //V + P = 3
  --index; //0 through 2
  Orientation3D retArray[3] = {PROXIMAL,VERTICAL,
                               HORIZONTAL};
  return retArray[index];
}
  
inline void Orientation3D::getNormalPlane(Orientation3D& o1, Orientation3D& o2) const {
  bool oeh = *this == HORIZONTAL;
  bool oep = *this == PROXIMAL;
  Orientation3D a1[2] = {HORIZONTAL,
                         VERTICAL};
  Orientation3D a2[2] = {PROXIMAL,VERTICAL};
  o1 = a1[oeh];
  o2 = a2[oep];
}
  
inline Orientation3D& Orientation3D::transform(const AxisTransform& atr) {
  Direction3D axis_array[3];
  atr.getDirections(axis_array[0], axis_array[1], axis_array[2]);
  val_ = All3DOrientations(axis_array[val_].toInt() >> 1); //shift off the lsb
  return *this;
}
  
inline Orientation3D& Orientation3D::transform(const Transform& tr) {
  return transform(tr.getAxisTransform());
}

///////////////
// Direction1D
///////////////
inline std::ostream & operator << (std::ostream& o, Direction1D d)
{
  if(d.val_)
    return o << "HIGH";
  return o << "LOW"; 
}

inline std::istream & operator >> (std::istream& i, Direction1D & d)
{
  char c;
  i >> c;
  if(c == 'H' || c == 'h'){
    char igh[4];
    i.get(igh,4);
    d.val_ = Direction1D::HIGH_1D;
  } else if (c == 'L' || c == 'l'){
    char ow[3];
    i.get(ow,3);
    d.val_ = Direction1D::LOW_1D;
  } 
  return i;
}

///////////////
// Direction2D
///////////////
inline std::ostream & operator << (std::ostream& o, Direction2D d)
{
  switch(d.val_){
  case Direction2D::WEST_2D:  o << "WEST" ; break;
  case Direction2D::EAST_2D:  o << "EAST" ; break;
  case Direction2D::SOUTH_2D: o << "SOUTH"; break;
  case Direction2D::NORTH_2D: o << "NORTH"; break;
  }
  return o;
}

inline std::istream & operator >> (std::istream& i, Direction2D& d)
{
  char c;
  i >> c;
  switch (c) {
  case 'N':
  case 'n':
    {
      char orth[5];
      i.get(orth,5);
      d.val_ = Direction2D::NORTH_2D;
      break;
    }
  case 'S':
  case 's':
    {
      char outh[5];
      i.get(outh,5);
      d.val_ = Direction2D::SOUTH_2D;
      break;
    }
  case 'E':
  case 'e':
    {
      char ast[4];
      i.get(ast,4);
      d.val_ = Direction2D::EAST_2D;
      break;
    }
  case 'W':
  case 'w':
    {
      char est[4];
      i.get(est,4);
      d.val_ = Direction2D::WEST_2D;
      break;
    }


  default:
    ;
  }

  return i;
}


///////////////
// Direction3D
///////////////
inline std::ostream & operator << (std::ostream& o, Direction3D d)
{
  switch(d.val_) {
  case Direction3D::WEST_3D:  o << "WEST" ; break;
  case Direction3D::EAST_3D:  o << "EAST" ; break;
  case Direction3D::SOUTH_3D: o << "SOUTH"; break;
  case Direction3D::NORTH_3D: o << "NORTH"; break;
  case Direction3D::DOWN_3D:  o << "DOWN" ; break;
  case Direction3D::UP_3D  :  o << "UP"   ; break;
  }
  return o;
}

inline std::istream & operator >> (std::istream& i, Direction3D& d)
{
  char c;
  i >> c;
  switch (c) {
  case 'N':
  case 'n':
    {
      char orth[5];
      i.get(orth,5);
      d.val_ = Direction3D::NORTH_3D;
      break;
    }
  case 'S':
  case 's':
    {
      char outh[5];
      i.get(outh,5);
      d.val_ = Direction3D::SOUTH_3D;
      break;
    }
  case 'E':
  case 'e':
    {
      char ast[4];
      i.get(ast,4);
      d.val_ = Direction3D::EAST_3D;
      break;
    }
  case 'W':
  case 'w':
    {
      char est[4];
      i.get(est,4);
      d.val_ = Direction3D::WEST_3D;
      break;
    }
  case 'U':
  case 'u':
    {
      char p[2];
      i.get(p,2);
      d.val_ = Direction3D::UP_3D;
      break;
    }
  case 'D':
  case 'd':
    {
      char own[4];
      i.get(own,4);
      d.val_ = Direction3D::DOWN_3D;
      break;
    }

  default:
    ;
  }

  return i;
}


////////////////////
// Orientation2D
////////////////////
inline std::ostream & operator << (std::ostream& o, Orientation2D orient)
{
  switch(orient.val_){
  case Orientation2D::VERTICAL_O:   o << "VERTICAL"; break;
  case Orientation2D::HORIZONTAL_O: o << "HORIZONTAL"; break;
  }
  return o;
}

inline std::istream & operator >> (std::istream & i, Orientation2D & orient)
{
  char c;
  i >> c;
  switch (c) {
  case 'V':
  case 'v':
    {
      char ertical[8];
      i.get(ertical,8);
      orient.val_ = Orientation2D::VERTICAL_O;
      break;
    }
  case 'H':
  case 'h':
    {
      char orizontal[10];
      i.get(orizontal,10);
      orient.val_ = Orientation2D::HORIZONTAL_O;
      break;
    }

  default:
    ;
  }

  return i;
}



////////////////////
// Orientation3D
////////////////////
inline std::ostream & operator << (std::ostream& o, Orientation3D orient)
{
  switch(orient.val_){
  case Orientation3D::VERTICAL_O:   o << "VERTICAL"; break;
  case Orientation3D::HORIZONTAL_O: o << "HORIZONTAL"; break;
  case Orientation3D::PROXIMAL_O:   o << "PROXIMAL" ; break;
  }
  return o;
}

inline std::istream & operator >> (std::istream & i, Orientation3D & orient)
{
  char c;
  i >> c;
  switch (c) {
  case 'V':
  case 'v':
    {
      char ertical[8];
      i.get(ertical,8);
      orient.val_ = (int)Orientation3D::VERTICAL_O;
      break;
    }
  case 'H':
  case 'h':
    {
      char orizontal[10];
      i.get(orizontal,10);
      orient.val_ = (int)Orientation3D::HORIZONTAL_O;
      break;
    }
  case 'P':
  case 'p':
    {
      char roximal[8];
      i.get(roximal,8);
      orient.val_ = (int)Orientation3D::PROXIMAL_O;
      break;
    }
  default:
    ;
  }

  return i;
}

