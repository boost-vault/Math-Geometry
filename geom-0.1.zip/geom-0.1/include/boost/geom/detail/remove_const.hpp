#ifndef BOOST_GEOM_DETAIL_REMOVE_CONST
#define BOOST_GEOM_DETAIL_REMOVE_CONST

// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

namespace boost { namespace geom {
	namespace detail {

		// Removes the const specifier on the given type
		//
		// Rational: Do not depend on some other implementation of it,
		// keep the library self contained.
		//
		// Also do not make it more complicated than it needs to be.
		// Keep the code simple, as simple as possible.
		template<typename T>
		struct remove_const { typedef T type; };
		
		template<typename T>
		struct remove_const<T const> { typedef T type; };	

	} // namespace detail

} } // namespace boost::geom

#endif  // BOOST_GEOM_DETAIL_REMOVE_CONST
