/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// PolygonInterface provides glue to bind PolygonImpl to T

/// PolygonInterface provides access the the data class T through
/// the get and set API, which are minimal and sufficient.
template <class T>
class PolygonWithHolesInterface {
public:

  typedef typename T::iteratorHoles iterator;
  typedef typename T::holeType holeType;

  /// Get the begin iterator
  static inline iterator PolygonWithHolesBegin(const T& t) {
    return t.beginHoles();
  }

  /// Get the end iterator
  static inline iterator PolygonWithHolesEnd(const T& t) {
    return t.endHoles();
  }

  /// Set the data of a polygon with the unique coordinates in an iterator, starting with an x
  template <class iT>
  static inline T& PolygonWithHolesSet(T& t, iT inputBegin, iT inputEnd) {
    t.setHoles(inputBegin, inputEnd);
    return t;
  }

  /// Get the number of holes 
  static inline unsigned int PolygonWithHolesSize(const T& t) {
    return t.sizeHoles();
  }

private:
  //disallow construction
  PolygonWithHolesInterface();
};
