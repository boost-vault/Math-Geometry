/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// LayeredRectImpl implements Rect functions on top of layered rect type T

/// LayeredRectImpl inherits from layered rect type T and accesses data owned
/// by T through the LayeredRectInterface<T> class
template <class T>
class LayeredRectImpl : private T {
public:

  /// get a reference of LayeredRectImpl type given a data object
  static LayeredRectImpl& mimic(T& t) { return static_cast<LayeredRectImpl&>(t); }

  /// get a const reference of LayeredRectImpl type given a data object
  static const LayeredRectImpl& mimicConst(const T& t) { 
    return static_cast<const LayeredRectImpl&>(t); 
  }

  /// construct a layered rect from a rectangle and a layer
  template <class T2>
  LayeredRectImpl(const RectangleImpl<T2>& rect, Unit layer);

  /// default constructor
  LayeredRectImpl();

  /// construct a degenerate point layered rectangle
  template <class T2>
  explicit LayeredRectImpl(const Point3DImpl<T2>& p);

  /// assignment operator
  template <class T2>
  inline const LayeredRectImpl& operator=(const LayeredRectImpl<T2>& that) {
    setLayer(that.layer()); horizontal(that.horizontal()); 
    vertical(that.vertical()); }

  /// assignment operator
  const LayeredRectImpl& operator=(const LayeredRectImpl& that);

  /// assignment operator
  const LayeredRectImpl& operator=(const T& that);

  /// copy constructor
  template <class T2>
  LayeredRectImpl(const LayeredRectImpl<T2>& that) { *this = that; }

  /// copy constructor
  LayeredRectImpl(const T& that) : T(that) {;}

  /// equivalence operator
  template <class T2>
  bool operator==(const LayeredRectImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const LayeredRectImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const LayeredRectImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<=(const LayeredRectImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const LayeredRectImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const LayeredRectImpl<T2>& b) const { return !(*this < b); }

  /// conversion to rectangle
  operator RectangleImpl<RectangleData>() const;

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// yield payload
  T& yield() { return *this; }
     
  /// return a reference to 'this' RectangleImpl<T>
  RectangleImpl<T>& mimicRectangle();

  /// return a const reference to 'this' RectangleImpl<T>
  const RectangleImpl<T>& mimicConstRectangle() const;

  /// Is the T valid
  bool isValid() const;

  /// Is the T valid
  inline bool isInitialized() const;

  /// get the interval range depending on orient
  IntervalImpl<IntervalData> get(Orientation2D orient) const;

  /// set and interval range to v depending on orient
  template <class T2>
  LayeredRectImpl& set(Orientation2D orient, 
                              const IntervalImpl<T2>& v);

  /// get a boundary coordinate depending on dir
  Unit get(Direction2D dir) const;

  /// set a boundary coordinate to value depending on dir
  Unit set(Direction2D dir, Unit value);
    
  /// get the horizontal interval range
  IntervalImpl<IntervalData> horizontal() const;

  /// get the vertical interval range
  IntervalImpl<IntervalData> vertical() const;

  /// set the horizontal interval range
  template <class T2>
  LayeredRectImpl& horizontal(const IntervalImpl<T2>& v);

  /// set the vertical interval range
  template <class T2>
  LayeredRectImpl& vertical(const IntervalImpl<T2>& v);

  /// get the layer
  Unit layer() const;

  /// set the layer
  LayeredRectImpl& layer(Unit layer);

  /// transform layered rectangle
  LayeredRectImpl& transform(const AxisTransform& atr);
    
  /// transform layered rectangle
  LayeredRectImpl& transform(const Transform& tr);

  /// get the magnitude of the interval corresponding to orient
  UnsignedUnit delta(Orientation2D orient) const;

  /// get the area of the rectangle
  UnsignedLongUnit area() const;

  /// get the half perimeter of the rectangle
  UnsignedLongUnit halfPerimeter() const;
   
  /// get the perimeter of the rectangle
  UnsignedLongUnit perimeter() const;

  /// return true if the layer of 'this' matches that of Segment b
  template <class T2>
  bool layersMatch(const LayeredRectImpl<T2>& b) const;

  /// return true if the layer of 'this' matches that of Point3D p
  template <class T2>
  bool layersMatch(const Point3DImpl<T2>& p) const;

  /// check if LayeredRect b is inside `this` LayeredRect
  template <class T2>
  bool contains(const LayeredRectImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if Point p is inside `this` Rectangle
  //  [in]     b         LayeredRect that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` contains b
  template <class T2>
  bool contains(const PointImpl<T2>& p, 
                       bool considerTouch = true) const;

  /// check if Segment s is inside `this` Rectangle
  template <class T2>
  bool contains(const SegmentImpl<T2>& s, 
                       bool considerTouch = true) const;

  /// check if Point3D p is inside `this` Rectangle
  template <class T2>
  bool contains(const Point3DImpl<T2>& p, 
                       bool considerTouch = true) const;

  /// check if Segment3D s is inside `this` Rectangle
  template <class T2>
  bool contains(const Segment3DImpl<T2>& s, 
                       bool considerTouch = true) const;

  /// check if `this` Rectangle is inside specified Rectangle b
  //  [in]     b         LayeredRect that will be checked
  //  [in]     considerTouch true, return true even if `t` touches the boundary
  //  [ret]    .         true if `t` is inside b
  template <class T2>
  bool inside(const LayeredRectImpl<T2>& b, 
                     bool considerTouch = true) const;

  /// check if LayeredRect b intersects `this` LayeredRect
  //  [in]     b         LayeredRect that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` intersects b
  template <class T2>
  bool intersects(const LayeredRectImpl<T2>& b, 
                         bool considerTouch = true) const;

  /// Check if boundaries of b and `this` intersect
  //  [in]     b         LayeredRect that will be checked
  //  [in]     considerTouch If true, return true even if p is on the foundary
  //  [ret]    .         true if `t` contains p
  template <class T2>
  bool boundariesIntersect(const LayeredRectImpl<T2>& b, 
                                  bool considerTouch = true) const;
    
  /// check if they are end to end in the given direction
  template <class T2>
  bool abuts(const LayeredRectImpl<T2>& b, Direction2D dir) const;

  /// check if they are end to end on the given orientation
  template <class T2>
  bool abuts(const LayeredRectImpl<T2>& b, Orientation2D orient) const;

  /// check if they are end to end
  template <class T2>
  bool abuts(const LayeredRectImpl<T2>& b) const;

  /// clip 'this' to the interval on the orientation
  template <class T2>
  bool intersectRange(const IntervalImpl<T2>& b,
                             Orientation2D orient, 
                             bool considerTouch = true);

  /// clip `this` LayeredRect to the specified LayeredRect
  //  [in]   b         The intersecting LayeredRect
  //  [in]   considerTouch If true, will clip to a single line if appropriate
  template <class T2>
  bool intersect(const LayeredRectImpl<T2>& b, bool considerTouch = true);

  /// set `t` Rectangle to the intersection between b1 and b2
  //  [in]     b1        The two LayeredRect to examine
  //  [in]     b2
  //  [in]     considerTouch If true, create intersection even if b1 touches b2
  //  [ret]    .         true if boxes intersect, else `t` is set to b1
  template <class T2, class T3>
  bool intersection(const LayeredRectImpl<T2>& b1, 
                           const LayeredRectImpl<T3>& b2,
                           bool considerTouch = true);

  /// bloat the LayeredRect along the given orientation
  LayeredRectImpl& bloat(Orientation2D orient, 
                                UnsignedUnit bloating); 

  /// bloat the LayeredRect
  LayeredRectImpl& bloat(UnsignedUnit bloating);

  /// bloat the specified side of `this` LayeredRect
  //  [in]     dir       The direction to be bloated
  //  [in]     bloating  Positive value to bloat the LayeredRect
  LayeredRectImpl& bloat(Direction2D dir, UnsignedUnit bloating); 

  /// shrink the LayeredRect along the given orientation
  LayeredRectImpl& shrink(Orientation2D orient, UnsignedUnit shrinking);

  /// shrink the LayeredRect
  LayeredRectImpl& shrink(UnsignedUnit shrinking);

  /// shrink the specified side of `t` LayeredRect
  //  [in]     dir       The direction to be shrunk
  //  [in]     shrinking Positive value to shrink the LayeredRect
  LayeredRectImpl& shrink(Direction2D dir, UnsignedUnit shrinking); 

  /// enlarge 'this' to encompase interval on orient
  template <class T2>
  bool encompass(const IntervalImpl<T2>& b, Orientation2D orient);

  /// enlarge `this` LayeredRect to encompass the LayeredRect b
  //  [in]     b         The LayeredRect to encompass
  //  [ret]    .         true if encompass happened at all
  template <class T2>
  bool encompass(const LayeredRectImpl<T2>& b);

private:
  //private functions
  IntervalData get_(Orientation2D orient) const;
  void set_(Orientation2D orient, const IntervalImpl<IntervalData>& value);
  Unit getLayer_() const;
  void setLayer_(Unit value);
  static T construct_(const RectangleImpl<RectangleData>& rect, Unit layer);
};

typedef LayeredRectImpl<LayeredRectData> LayeredRect;

template <class T>
std::ostream& operator<< (std::ostream& o, const LayeredRectImpl<T>& r);

template <class T>
std::istream& operator>> (std::istream& i, LayeredRectImpl<T>& r);

