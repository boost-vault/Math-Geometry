/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T, class T2>
class lessSegment3D
  : public std::binary_function<const Segment3DImpl<T>&, const Segment3DImpl<T2>&, bool>
{
private:
  AxisTransform atr_; // we want to compare along this orientation
public:
  inline lessSegment3D() {;} // allow data member to take default value
  inline lessSegment3D(AxisTransform atr) : atr_(atr) {;}
  inline lessSegment3D(Direction3D dir) : atr_(dir) {;}
  inline lessSegment3D(Orientation3D orient) : atr_(orient) {;}
  inline bool operator () (const Segment3DImpl<T>& a,
                           const Segment3DImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessSegment3D<T, T2>::operator () (const Segment3DImpl<T>& a,
                                   const Segment3DImpl<T2>& b) const {
  Segment3DImpl<T> a_(a);
  Segment3DImpl<T2> b_(b);
  a_.transform(atr_);
  b_.transform(atr_);
  return a_ < b_;
}
  
template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::operator<(const Segment3DImpl<T2>& b) const {
  return low() < b.low() || ((low() == b.low()) & (high() < high()));
}

template<class T> template<class T2>
inline 
Segment3DImpl<T>::Segment3DImpl(const Point3DImpl<T2>& p, 
                                Orientation3D orient,
                                UnsignedUnit length) {
  *this = construct_(Point3DImpl<Point3DData>(p), orient, length);
}

template<class T>
inline 
Segment3DImpl<T>::Segment3DImpl() {
  *this = construct_(Point3DImpl<Point3DData>(), Orientation3D(), UnsignedUnit());
}

template<class T>
const Segment3DImpl<T>& 
Segment3DImpl<T>::operator=(const Segment3DImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T>
const Segment3DImpl<T>& 
Segment3DImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::operator==(const Segment3DImpl<T2>& b) const {
  return low() == b.low() & getOrient() == b.getOrient() & 
    getLength() == b.getLength();
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::operator!=(const Segment3DImpl<T2>& b) const {
  //apply demorgans theorem to achieve two level logic
  return low() != b.low() | getOrient() != b.getOrient() | 
    getLength() != b.getLength();
}

template<class T>
inline
Segment3DImpl<T>::operator IntervalImpl<IntervalData>() const {
  const IntervalImpl<T>& i = mimicConstInterval();
  return IntervalImpl<IntervalData>(i.low(), i.high());
}

template<class T>
inline IntervalImpl<T>& 
Segment3DImpl<T>::mimicInterval() {
  return reinterpret_cast<IntervalImpl<T>&>(yield());
}

template<class T>
inline const IntervalImpl<T>& 
Segment3DImpl<T>::mimicConstInterval() const {
  return reinterpret_cast<const IntervalImpl<T>&>(yieldConst());
}

template<class T>
inline Point3DImpl<Point3DData> 
Segment3DImpl<T>::get(Direction1D dir) const {
  return (Point3DImpl<Point3DData>)get_(dir);
}

template<class T>
inline Point3DImpl<Point3DData> 
Segment3DImpl<T>::low() const {
  return get(LOW);
}

template<class T>
inline Point3DImpl<Point3DData> 
Segment3DImpl<T>::high() const {
  return get(HIGH);
}

template<class T> template<class T2>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::set( Direction1D dir, const Point3DImpl<T2>& value) {
  set_(dir, Point3DImpl<Point3DData>(value)); return *this;
} 
    
template<class T> template<class T2>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::low(const Point3DImpl<T2>& value) {
  return set(LOW, value);
}

template<class T> template<class T2>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::high(const Point3DImpl<T2>& value) {
  return set(HIGH, value);
}

template<class T>
inline Orientation3D 
Segment3DImpl<T>::getOrient() const {
  return getOrient_();
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::setOrient(Orientation3D orient) {
  setOrient_(orient); return *this;
}

template<class T>
inline UnsignedUnit 
Segment3DImpl<T>::getLength() const {
  return getLength_();
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::setLength(UnsignedUnit value) {
  setLength_(value); return *this;
}

/// get the projection of the segment3D into the plane perpendicular
/// to its orientation
template<class T>
inline PointImpl<PointData> 
Segment3DImpl<T>::getMajor() const {
  Orientation3D o1, o2;
  getOrient().getNormalPlane(o1, o2);
  return PointImpl<PointData>(low().get(o1), low().get(o2));
}

template<class T> template<class T2>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::setMajor(const PointImpl<T2>& value) {
  Point3DImpl<Point3DData> newLow = low();
  Orientation3D o1, o2;
  getOrient().getNormalPlane(o1, o2);
  newLow.set(o1, value.x());
  newLow.set(o2, value.y());
  low(newLow); return *this;
}
    
template<class T>
inline bool 
Segment3DImpl<T>::isValid() const {
  return mimicConstInterval().isValid();
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::transform(const AxisTransform& atr) {
  Direction3D trDirs[3];
  atr.getDirections(trDirs[0], trDirs[1], trDirs[2]);
  Direction3D newDir = trDirs[getOrient().toInt()];
  UnsignedUnit len = getLength();
  setOrient(getOrient().transform(atr));
  low(low().transform(atr));
  setLength(0);
  bloat(newDir, len);
  return *this;
}
    
template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::transform(const Transform& tr) {
  Direction3D trDirs[3];
  tr.getAxisTransform().getDirections(trDirs[0], trDirs[1], trDirs[2]);
  Direction3D newDir = trDirs[getOrient().toInt()];
  UnsignedUnit len = getLength();
  setOrient(getOrient().transform(tr.getAxisTransform()));
  setLength(0);
  set(LOW, get(LOW).transform(tr));
  return bloat(newDir, len);
}

template<class T>
inline UnsignedUnit 
Segment3DImpl<T>::delta() const {
  return mimicConstInterval().delta();
}

template<class T>
inline UnsignedUnit 
Segment3DImpl<T>::delta(const Orientation3D orient) const {
  return orient == getOrient() & delta();
}

/// check if Segment b is inside `this` Segment
/// if considerTouch is true b is allowed to touch the boundary of 'this'
/// and an orthogonal segment will only be contained if considerTouch 
/// is true and the orthogonal segment has zero length
template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::contains(const Segment3DImpl<T2>& b, 
                           bool considerTouch) const {
  bool ivlcontains = mimicConstInterval().contains(b.mimicConstInterval(), considerTouch);
  bool zerolen = b.getLength() == 0;
  return (getOrient() == b.getOrient() & ivlcontains) | 
    (zerolen & contains(b.low()) & considerTouch);
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::contains(const Point3DImpl<T2>& p, 
                           bool considerTouch) const {
  bool ivlcontains = mimicConstInterval().
    contains(p.get(getOrient()), considerTouch);
  return ivlcontains & colinear(p);
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::colinear(const Point3DImpl<T2>& p) const {
  Orientation3D o1, o2;
  getOrient().getNormalPlane(o1, o2);
  return getMajor() == PointImpl<PointData>(p.get(o1), p.get(o2));
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::colinear(const Segment3DImpl<T2>& b) const {
  return getOrient() == b.getOrient() & getMajor() == b.getMajor();
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::perpendicular(const Segment3DImpl<T2>& b) const {
  return getOrient() != b.getOrient();
}

template<class T>
inline SegmentImpl<SegmentData> 
Segment3DImpl<T>::projectInPlane(Orientation3D o1, Orientation3D o2) const {
  return SegmentImpl<SegmentData>(PointImpl<PointData>(low().get(o1), 
                                                       low().get(o2)),
                                  predicated_value(getOrient() == o1,
                                                   HORIZONTAL, VERTICAL),
                                  getLength());
}

/// check if a segment b crosses to 'this'
/// if consider touch is true the segments are considered to cross if they
/// are abutting
template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::crosses(const Segment3DImpl<T2>& b, 
                          bool considerTouch) const {
  bool oe = getOrient() == b.getOrient();
  Orientation3D normal = getOrient().getNormal(b.getOrient());
  bool normaleq = low().get(normal) == b.low().get(normal);
  bool cross2d = projectInPlane(getOrient(), b.getOrient()).
    crosses(b.projectInPlane(getOrient(), b.getOrient()), considerTouch);
  return !oe & normaleq & cross2d;
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::inside(const Segment3DImpl<T2>& b, 
                         bool considerTouch) const {
  return b.contains(*this, considerTouch);
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::intersects(const Segment3DImpl<T2>& b, 
                             bool considerTouch) const {
  bool cl = colinear(b);
  bool ivlintersects = mimicConstInterval().intersects(b.mimicConstInterval(), considerTouch);
  //we may prefer || if one of the two is more frequently true
  return (cl & ivlintersects) | crosses(b, considerTouch);
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::boundariesIntersect(const Segment3DImpl<T2>& b, 
                                      bool considerTouch) const {
  return (intersects(b, considerTouch) &
          !(contains(b, !considerTouch)) &
          !(inside(b, !considerTouch)));
}
    
template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::abuts(const Segment3DImpl<T2>& b, Direction1D dir) const {
  return (colinear(b) & mimicConstInterval().abuts(b.mimicConstInterval(), dir)) |
    (perpendicular(b) & mimicConstInterval().get(dir) == 
     b.low().get(getOrient()));
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::abuts(const Segment3DImpl<T2>& b) const {
  return (colinear(b) & mimicConstInterval().abuts(b.mimicConstInterval())) |
    (perpendicular(b) & (mimicConstInterval().low() == 
                         b.low().get(getOrient()) |
                         mimicConstInterval().high() == 
                         b.low().get(getOrient())));
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::intersect(const Segment3DImpl<T2>& b, bool considerTouch) {
  if (colinear(b)) {
    return mimicInterval().intersect(b.mimicConstInterval(), considerTouch);
  }
  if (perpendicular(b) && crosses(b, considerTouch)) {
    Point3DImpl<Point3DData> newLow = low();
    Orientation3D o1, o2;
    b.getOrient().getNormalPlane(o1, o2);
    newLow.set(o1, b.low().get(o1));
    newLow.set(o2, b.low().get(o2));
    low(newLow);
    UnsignedUnit zero = 0;
    setLength(zero);
    return true;
  }
  return false;
}

/// set `this` Segment to the intersection between b1 and b2
/// if considerTouch is true, create intersection even if b1 touches b2
/// and return true if boxes intersect, else set `this` to b1, return false
template<class T> template<class T2, class T3>
inline bool
Segment3DImpl<T>::intersection(const Segment3DImpl<T2>& b1, 
                               const Segment3DImpl<T3>& b2,
                               bool considerTouch) {
  this = b1;
  return intersect(b2, considerTouch);
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::bloat(UnsignedUnit bloating) {
  mimicInterval().bloat(bloating);
  return *this;
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::bloat(Direction1D dir, UnsignedUnit bloating) {
  mimicInterval().bloat(dir, bloating);
  return *this;
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::shrink(UnsignedUnit shrinking) {
  mimicInterval().shrink(shrinking);
  return *this;
}

template<class T>
inline Segment3DImpl<T>& 
Segment3DImpl<T>::shrink(Direction1D dir, UnsignedUnit shrinking) {
  mimicInterval().shrink(dir, shrinking);
  return *this;
}

template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::encompass(const IntervalImpl<T2>& b) {
  return mimicInterval().encompass(b);
}

/// enlarge `this` Segment to encompass the Segment b 
/// return true if enlargement happened at all
template<class T> template<class T2>
inline bool 
Segment3DImpl<T>::encompass(const Segment3DImpl<T2>& b) {
  if (colinear(b)) {
    return mimicInterval().encompass(b.mimicConstInterval());
  }
  return false;
}    
    
//private functions
template<class T>
inline Point3DImpl<Point3DData> 
Segment3DImpl<T>::get_(Direction1D dir) const {
  return Segment3DInterface<T>::Segment3DGet(*this, dir);
}

template<class T>
inline void 
Segment3DImpl<T>::set_(Direction1D dir, const Point3DImpl<Point3DData>& value) {
  Segment3DInterface<T>::Segment3DSet(*this, dir, value.yieldConst());
}

template<class T>
inline Orientation3D 
Segment3DImpl<T>::getOrient_() const {
  return Segment3DInterface<T>::Segment3DGetOrient(*this);
}

template<class T>
inline void 
Segment3DImpl<T>::setOrient_(Orientation3D orient) {
  Segment3DInterface<T>::Segment3DSetOrient(*this, orient);
}

template<class T>
inline UnsignedUnit 
Segment3DImpl<T>::getLength_() const {
  return Segment3DInterface<T>::Segment3DGetLength(*this);
}

template<class T>
inline void 
Segment3DImpl<T>::setLength_(UnsignedUnit value) {
  Segment3DInterface<T>::Segment3DSetLength(*this, value);
}

template<class T>
inline T 
Segment3DImpl<T>::construct_(const Point3DImpl<Point3DData>& p, 
                             Orientation3D o,
                             UnsignedUnit length) {
  return Segment3DInterface<T>::Segment3DConstruct(p.yieldConst(), o, length);
}


template<class T>
std::ostream& operator<< (std::ostream& o, const Segment3DImpl<T>& s)
{
  o << s.low() << GTL_SEP << s.getOrient() << GTL_SEP << s.getLength();
  return o;
}

template<class T>
std::istream& operator>> (std::istream& i, Segment3DImpl<T>& s)
{
  Point3D low;
  Orientation3D o;
  UnsignedUnit length;
  i >> low >> o >> length;
  s.low(low);
  s.setOrient(o);
  s.setLength(length);
  return i;
}

