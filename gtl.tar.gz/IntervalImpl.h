/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
//forward declarations
class AxisTransform;
class Transform;

/// IntervalImpl implements all Interval functions on top of Interval type T

/// IntervalImpl inherits from interval type T and accesses the data owned
/// by T through the IntervalInterface<T> class
template <class T>
class IntervalImpl : public T {
public:

  /// get a reference of IntervalImpl type given a data object
  static IntervalImpl& mimic(T& t) { return static_cast<IntervalImpl&>(t); }

  /// get a const reference of IntervalImpl type given a data object
  static const IntervalImpl& mimicConst(const T& t) { 
    return static_cast<const IntervalImpl&>(t); 
  }

  /// construct an IntervalImpl<T> from low and high
  IntervalImpl(Unit low, Unit high);

  /// construct a degenerate IntervalImpl<T> from one Unit
  explicit IntervalImpl(Unit x);

  /// default constructor
  IntervalImpl();

  /// assignment operator
  template <class T2>
  const IntervalImpl& operator=(const IntervalImpl<T2>& that) { 
    low(that.low()); high(that.high()); }

  /// assignment operator
  const IntervalImpl& operator=(const IntervalImpl& that);

  /// assignment operator
  const IntervalImpl& operator=(const T& that);

  /// copy constructor
  template <class T2>
  IntervalImpl(const IntervalImpl<T2>& that) {*this = that;}
    
  /// copy constructor
  IntervalImpl(const T& that) : T(that) {;}

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// yield payload
  T& yield() { return *((T*)(this)); }
     
  /// equivalence operator
  template <class T2>
  bool operator==(const IntervalImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const IntervalImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const IntervalImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<=(const IntervalImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const IntervalImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const IntervalImpl<T2>& b) const { return !(*this < b); }

  /// Is the IntervalImpl valid
  bool isValid() const { return (low() <= high()); }

  /// get the low or high coordinate depending on the value of dir
  Unit get(Direction1D dir) const { 
    return IntervalInterface<T>::IntervalGet(*this, dir); }    

  /// set the low or high coordinate depending on the value of dir
  IntervalImpl& set(Direction1D dir, Unit value) { 
    IntervalInterface<T>::IntervalSet(*this, dir, value); return *this; }

  /// get the low coordinate
  Unit low() const { return get(LOW); }

  /// get the high coordinate
  Unit high() const { return get(HIGH); }

  /// get the center coordinate
  Unit center() const { return (high() + low())/2; }

  /// set the low coordinate to v
  IntervalImpl& low(Unit v) { set(LOW, v); return *this; }

  /// set the high coordinate to v
  IntervalImpl& high(Unit v) { set(HIGH, v); return *this; }

  /// get the magnitude of the interval
  UnsignedUnit delta() const;
    
  /// flip this about coordinate
  IntervalImpl& flip(Unit axis = 0);

  /// scale interval by factor
  IntervalImpl& scale(double factor);

  /// move interval by delta
  IntervalImpl& move(Unit delta);

  /// convolve this with b
  IntervalImpl& convolve(Unit b);

  /// deconvolve this with b
  IntervalImpl& deconvolve(Unit b);

  /// convolve this with b
  template <class T2>
  IntervalImpl& convolve(const IntervalImpl<T2>& b);

  /// deconvolve this with b
  template <class T2>
  IntervalImpl& deconvolve(const IntervalImpl<T2>& b);

  /// reflected convolve this with b
  template <class T2>
  IntervalImpl& reflectedConvolve(const IntervalImpl<T2>& b);

  /// reflected deconvolve this with b
  template <class T2>
  IntervalImpl& reflectedDeconvolve(const IntervalImpl<T2>& b);

  /// distance from a coordinate to an interval
  Unit distance(Unit position) const;

  /// distance between two intervals
  template <class T2>
  Unit distance(const IntervalImpl<T2>& b) const;

  /// check if Interval b is inside `this` Interval
  //  [in]     b         Interval that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `this` contains b
  template <class T2>
  bool contains(const IntervalImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if value is inside 'this' Interval
  //  [in]     b         Interval that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `this` contains b
  bool contains(Unit value, bool considerTouch = true) const;

  /// check if 'this' is inside Interval b
  //  [in]     b         Interval that will be checked
  //  [in]     considerTouch true, return true even if `this` touches the boundary
  //  [ret]    .         true if `t` is inside b
  template <class T2>
  bool inside(const IntervalImpl<T2>& b, bool considerTouch = true) const;

  /// check if Interval b intersects `this` Interval
  //  [in]     b         Interval that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `this` intersects b
  template <class T2>
  bool intersects(const IntervalImpl<T2>& b, 
                         bool considerTouch = true) const;

  /// check if Interval b partially overlaps `this` Interval
  //  [in]     b         Interval that will be checked
  //  [in]     considerTouch If true, return true even if p is on the foundary
  //  [ret]    .         true if `this` contains p
  template <class T2>
  bool boundariesIntersect(const IntervalImpl<T2>& b, 
                                  bool considerTouch = true) const;
    
  /// check if they are end to end
  template <class T2>
  bool abuts(const IntervalImpl<T2>& b, Direction1D dir) const;

  /// check if they are end to end
  template <class T2>
  bool abuts(const IntervalImpl<T2>& b) const;

  /// set 'this' interval to the intersection of 'this' and b
  //  [in]     b         The intersecting Interval
  //  [in]     considerTouch If true, will clip to a single line if appropriate
  template <class T2>
  bool intersect(const IntervalImpl<T2>& b, bool considerTouch = true);

  /// set `this` Interval to the intersection between b1 and b2
  //  [in]     b1        The two intervals to examine
  //  [in]     b2
  //  [in]     considerTouch If true, create intersection even if b1 touches b2
  //  [ret]    .         true if boxes intersect, else `this` is set to b1
  template <class T2, class T3>
  bool intersection(const IntervalImpl<T2>& b1, const IntervalImpl<T3>& b2,
                           bool considerTouch = true);

  /// set 'this' interval to the generalized intersection of 'this' and b
  template <class T2>
  IntervalImpl& generalizedIntersect(const IntervalImpl<T2>& b);

  /// set `this` Interval to the generalized intersection between b1 and b2
  template <class T2, class T3>
  IntervalImpl& generalizedIntersection(const IntervalImpl<T2>& b1, const IntervalImpl<T3>& b2);

  /// bloat the Interval
  //  [in]     bloating  Positive value to bloat each coordinate
  IntervalImpl& bloat(UnsignedUnit bloating);

  /// bloat the specified side of `this` Interval
  //  [in]     bloating  Positive value to bloat the Interval
  //  [in]     o         The orientation to be bloated
  IntervalImpl& bloat(Direction1D dir, UnsignedUnit bloating);

  /// shrink the Interval
  //  [in]     shrinking Positive value to shrink each coordinate
  IntervalImpl& shrink(UnsignedUnit shrinking);

  /// shrink the specified side of `this` Interval
  //  [in]     shrinking Positive value to shrink the Interval
  //  [in]     o         The orientation to be shrunk
  IntervalImpl& shrink(Direction1D dir, UnsignedUnit shrinking);

  /// Enlarge `this` Interval to encompass the specified Interval
  //  [in]     b         The Interval to encompass
  //  [ret]    .         true if enlargement happened at all
  template <class T2>
  bool encompass(const IntervalImpl<T2>& b);

  /// gets the half of the interval as an interval
  IntervalImpl getHalf(Direction1D d1d) const;

  /// returns true if the 2 intervals exactly touch at one value, like in  l1 <= h1 == l2 <= h2
  /// sets the argument to the joined interval
  template <class T2, class T3>
  bool joinWith(IntervalImpl<T2>& newInterval, const IntervalImpl<T3>& i2) const;

private:
  //private functions
  static T construct_(Unit low, Unit high);
};

//declare the default interval type
typedef IntervalImpl<IntervalData> Interval;

