// =================================================================================
//	ops.hpp				                               (C)2005 Michael Andersen Nexo
// =================================================================================
//
// This file defines a number of functional style operators for arithmetic operations
// similar to the ones defined in the Standard C++ header file <functional>.
// But, unlike the Standard C++ ones, these operators does implicit type conversion
// between types, thus:
// int i = 3 + 4.6; results in i = 8
// int i = std::plus<int>(3,4.6); results in i = 7!
// int i = ops::plus<int, double>()(3, 4.6); results in i = 8
// Note, this is basically just a shorthand for writing:
// int i = std::plus<typename promote_traits<int,double>::promote_type>(3, 4.6);

#ifndef OPS_HPP_INCLUDED
#define OPS_HPP_INCLUDED

#include <functional>
#include <boost/numeric/ublas/traits.hpp>

namespace ops
{
	using boost::numeric::ublas::promote_traits;

	#define DEFINE_OP(NAME,OP) \
		template <class L, class R> \
		struct NAME : public std::binary_function<L, R, typename promote_traits<L,R>::promote_type> \
		{ \
			inline typename promote_traits<L,R>::promote_type operator()(L lhs, R rhs) const  { return lhs OP rhs; } \
		};


	DEFINE_OP(plus,+)
	DEFINE_OP(minus,-)
	DEFINE_OP(multiplies,*)
	DEFINE_OP(divides,/)
	DEFINE_OP(modulus,%)
	DEFINE_OP(bit_and,&)
	DEFINE_OP(bit_or,|)
	DEFINE_OP(bit_xor,^)

	
	#undef DEFINE_OP

	template <class T> 
	struct abs : public std::unary_function<T,T>
	{
		inline T operator ()(T t) const { return t>=0 ? t : -t; }
	};
}

#endif //OPS_HPP_INCLUDED
