// Canvas.cpp : implementation file
//

#include "stdafx.h"
#include "LineSimplifier.h"
#include "LineSimplifierDlg.h"
#include "Canvas.h"

// CCanvas

IMPLEMENT_DYNAMIC(CCanvas, CStatic)

CLineSimplifierDlg* CCanvas::GetDlg()
{
	return static_cast<CLineSimplifierDlg*>(GetParent());
}

PointVector& CCanvas::Points()
{
	return GetDlg()->m_Points;
}

PointVector& CCanvas::Simp()
{
	return GetDlg()->m_Simp;
}

BEGIN_MESSAGE_MAP(CCanvas, CStatic)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()

// CCanvas message handlers

void CCanvas::OnPaint()
{
	using namespace boost;

	CPaintDC dc(this); // device context for painting
	if (Points().size() > 0)
	{
		dc.MoveTo(Points()[0]);
		std::for_each(Points().begin()+1, Points().end(), bind(&CDC::LineTo, &dc, _1));
	}

	dc.SelectStockObject(WHITE_PEN);
	if (Simp().size() > 0)
	{
		dc.MoveTo(Simp().front());
		std::for_each(Simp().begin()+1, Simp().end(), bind(&CDC::LineTo, &dc, _1));
	}
}

BOOL CCanvas::OnEraseBkgnd(CDC* pDC)
{
	CRect r; GetClientRect(r);
	pDC->FillSolidRect(r, RGB(192,192,192));
	return TRUE;
}

void CCanvas::OnLButtonDown(UINT nFlags, CPoint point)
{
	SetCapture();
	Points().clear();
	Points().push_back(point);
}

void CCanvas::OnLButtonUp(UINT nFlags, CPoint point)
{
	ReleaseCapture();
	Points().push_back(point);
	GetDlg()->SimplifyPath();
}

void CCanvas::OnMouseMove(UINT nFlags, CPoint point)
{
	if (GetCapture() == this && point != Points().back())
	{
		CClientDC dc(this);
		dc.MoveTo(Points().back());
		dc.LineTo(point);
		Points().push_back(point);
	}
}
