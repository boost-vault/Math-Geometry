//
//!  Copyright (c) 2008
//!  Brandon Kohn
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef _BOOST_GEOMETRY_BSPTREE2D_HPP
#define _BOOST_GEOMETRY_BSPTREE2D_HPP
#pragma once

#include "geometric_concepts.hpp"
#include "point_traits.hpp"
#include "segment_traits.hpp"
#include "utilities.hpp"
#include <boost/foreach.hpp>
#include <vector>

namespace boost
{
namespace numeric
{
namespace geometry
{
    enum point_location_classification
    {
        e_inside = -1,
        e_boundary = 0,
        e_outside = 1
    };

    template <typename Segment, typename NumberComparisonPolicy>
    class bsp_tree_2d
    {
    public:

        template <typename InputSegmentIterator>
        bsp_tree_2d( InputSegmentIterator first, InputSegmentIterator last );

        template <typename InputSegmentIterator>
        bsp_tree_2d( InputSegmentIterator first, InputSegmentIterator last, const NumberComparisonPolicy& compare );

        //! Destructor
        virtual ~bsp_tree_2d(){}

        //! Method to detect if a point is inside, on the boundary our outside the shape represented by the partition.
        template <typename Point>
        point_location_classification locate_point( const Point& point ) const;

        //! Method to to a 'painters algorithm' traversal of the BSP for a specified point.
        template <typename Point, typename Visitor>
        void                          painters_traversal( const Point& point, Visitor& visitor ) const;

    private:

        enum classification
        {
            e_crosses,
            e_positive,
            e_negative,
            e_coincident
        };

        ///Method to classify the characterization of the splitting line and an edge (left,right or split).
        classification  classify( const Segment& splittingLine, const Segment& edge, Segment& subPos, Segment& subNeg ) const;

        boost::shared_ptr< bsp_tree_2d<Segment> >   m_positiveChild;
        boost::shared_ptr< bsp_tree_2d<Segment> >   m_negativeChild;
        Segment                                     m_splittingSegment;
        std::vector<Segment>                        m_coincidentEdges;
        NumberComparisonPolicy               m_compare;

    };

    template <typename Segment, typename NumberComparisonPolicy>
    template <typename InputSegmentIterator>
    bsp_tree_2d<Segment>::bsp_tree_2d<Segment>( InputSegmentIterator first, InputSegmentIterator last )
    {
        m_splittingSegment = *first;

        std::vector< Segment > posList, negList;
        while( first != last )
        {
            const Segment segment = *first++;

            Segment subNeg, subPos;
            classification type = classify( m_splittingSegment, segment, subPos, subNeg );

            if( type == e_crosses )
            {
                posList.push_back( subPos );
                negList.push_back( subNeg );
            }
            else if( type == e_positive )
            {
                posList.push_back( segment );
            }
            else if( type == e_negative )
            {
                negList.push_back( segment );
            }
            else
            {
                m_coincidentEdges.push_back( segment );
            }
        }

        if( !posList.empty() )
        {
            m_positiveChild.reset( new bsp_tree_2d( posList.begin(), posList.end() ) );
        }

        if( !negList.empty() )
        {
            m_negativeChild.reset( new bsp_tree_2d( negList.begin(), negList.end() ) );
        }
    }

    template <typename Segment, typename NumberComparisonPolicy>
    template <typename InputSegmentIterator>
    bsp_tree_2d<Segment>::bsp_tree_2d<Segment>( InputSegmentIterator first, InputSegmentIterator last, const NumberComparisonPolicy& compare )
        : m_compare( compare )
    {
        m_splittingSegment = *first;

        std::vector< Segment > posList, negList;
        while( first != last )
        {
            const Segment segment = *first++;

            Segment subNeg, subPos;
            classification type = classify( m_splittingSegment, segment, subPos, subNeg );

            if( type == e_crosses )
            {
                posList.push_back( subPos );
                negList.push_back( subNeg );
            }
            else if( type == e_positive )
            {
                posList.push_back( segment );
            }
            else if( type == e_negative )
            {
                negList.push_back( segment );
            }
            else
            {
                m_coincidentEdges.push_back( segment );
            }
        }

        if( !posList.empty() )
        {
            m_positiveChild.reset( new bsp_tree_2d( posList.begin(), posList.end() ) );
        }

        if( !negList.empty() )
        {
            m_negativeChild.reset( new bsp_tree_2d( negList.begin(), negList.end() ) );
        }
    }


    template <typename Segment, typename NumberComparisonPolicy>
    typename bsp_tree_2d<Segment>::classification  bsp_tree_2d<Segment>::classify( const Segment& splittingLine, const Segment& edge, Segment& subPos, Segment& subNeg ) const
    {
        typedef Segment                                              segment_type;
        typedef typename segment_traits< segment_type >::point_type  point_type;
        typedef typename point_traits< point_type >::coordinate_type coordinate_type;
        typedef segment_access_traits< segment_type >                segment_access;
        typedef cartesian_access_traits< point_type >                point_access;

        orientation_type orientation_start = get_orientation( segment_access::get_start( splittingLine ), segment_access::get_end( splittingLine ), segment_access::get_start( edge ), m_compare );
        orientation_type orientation_end = get_orientation( segment_access::get_start( splittingLine ), segment_access::get_end( splittingLine ), segment_access::get_end( edge ), m_compare );

        if( orientation_start * orientation_end < 0 )
        {
            Point xPoints[2];
            intersection_type iType = intersect( splittingLine, edge, xPoints, m_compare );
            if( iType == e_crossing )
            {
                if( detO > 0 )
                {
                    subPos = segment_access::construct( segment_access::get_start( edge ), xPoints[0] );
                    subNeg = segment_access::construct( xPoints[0], segment_access::get_end( edge ) );
                }
                else
                {
                    subNeg = segment_access::construct( segment_access::get_start( edge ), xPoints[0] );
                    subPos = segment_access::construct( xPoints[0], segment_access::get_end( edge ) );
                }

                return e_crosses;
            }
            else if( iType == e_overlapping )
            {
                return e_coincident;
            }
            else// if( iType == e_endpoint || iType == e_non_crossing )
            {
                if( orientation_end == oriented_collinear && orientation_start == oriented_right )
                {
                    return e_negative;
                }
                else if( orientation_end == oriented_collinear && orientation_start == oriented_left ) 
                {
                    return e_positive;
                }
                if( orientation_start == oriented_collinear && orientation_end == oriented_right )
                {
                    return e_negative;
                }
                else if( orientation_start == oriented_collinear && orienation_end == oriented_left ) 
                {
                    return e_positive;
                }
                else
                {
                    return e_coincident;
                }
            }
        }
        else if( orientation_start == oriented_left && orientation_end == oriented_left )
        {
            return e_positive;
        }
        else if( orientation_start == oriented_right && orientation_end == oriented_right )
        {
            return e_negative;
        }
        else
        {
            return e_coincident;
        }
    }

    template <typename Segment, typename NumberComparisonPolicy>
    template <typename Point>
    point_location_classification bsp_tree_2d<Segment>::locate_point( const Point& point ) const
    {
        typedef Segment                                              segment_type;
        typedef typename segment_traits< segment_type >::point_type  point_type;
        typedef typename point_traits< point_type >::coordinate_type coordinate_type;
        typedef segment_access_traits< segment_type >                segment_access;
        typedef cartesian_access_traits< point_type >                point_access;

        orientation_type orientation_point = get_orientation( segment_access::get_start( splittingLine ), segment_access::get_end( splittingLine ), point, m_compare );
   
        if( orientation_point == oriented_left )
        {
            if( m_positiveChild != 0 )
            {
                return m_positiveChild->locate_point( point );
            }
            else
            {
                return e_outside;
            }
        }
        else if( orientation_point == oriented_right )
        {
            if( m_negativeChild != 0 )
            {
                return m_negativeChild->locate_point( point );
            }
            else
            {
                return e_inside;
            }
        }
        else
        {
            BOOST_FOREACH( const Segment& segment, m_coincidentEdges )
            {
                if( is_between( segment_access::get_start( segment ), segment_access::get_end( segment ), point, true, m_compare ) ) 
                {
                    return e_boundary;
                }
            }

            if( m_positiveChild != 0 )
            {
                return m_positiveChild->locate_point( point );
            }
            else if( m_negativeChild != 0 )
            {
                return m_negativeChild->locate_point( point );
            }
            else
            {
                ///This case should not happen.. but may due to numerical errors. The algorithms suggest noting this in debug mode but returning boundary in 
                ///release (most likely due to round-off on a nearly collinear point.
                assert( false );
                return e_boundary;
            }
        }
    }

    ///This concept is used to check if the edge properties conform to a numeric weight
    ///type which can be used in graph calculations.
    template <typename Visitor, typename VisitedType>
    struct IsVisitorTypeConcept
    {
        void constraints()
        {                
            Visitor* visitor = 0;
            VisitedType* visitee = 0;
            (*visitor)( *visitee ); ///needs to be able to call this.
        }
    };

    template <typename Segment, typename NumberComparisonPolicy>
    template <typename Point, typename Visitor>
    void bsp_tree_2d<Segment>::painters_traversal( const Point& point, Visitor& visitor ) const
    {
        boost::function_requires< IsVisitorTypeConcept<Visitor,Segment> >();      ///must conform to the visitor concept.
        typedef Segment                                              segment_type;
        typedef typename segment_traits< segment_type >::point_type  point_type;
        typedef typename point_traits< point_type >::coordinate_type coordinate_type;
        typedef segment_access_traits< segment_type >                segment_access;
        typedef cartesian_access_traits< point_type >                point_access;
        
        if( m_negativeChild == 0 && m_positiveChild == 0 )
        {
            BOOST_FOREACH( const segment_type& segment, m_coincidentEdges )
            {
                visitor( segment );
            }
        }
        else 
        {
            orientation_type orientation_point = get_orientation( segment_access::get_start( splittingLine ), segment_access::get_end( splittingLine ), point, m_compare );
   
            if( orientation_point == oriented_left )
            {             
                if( m_negativeChild != 0 )
                {
                    m_negativeChild->painters_traversal( point, visitor );
                }

                BOOST_FOREACH( const segment_type& segment, m_coincidentEdges )
                {
                    visitor( segment );
                }
                
                if( m_positiveChild != 0 )
                {
                    m_positiveChild->painters_traversal( point, visitor );
                }   
            }
            else if( orientation_point == oriented_right )
            {
                if( m_positiveChild != 0 )
                {
                    m_positiveChild->painters_traversal( point, visitor );
                }

                BOOST_FOREACH( const segment_type& segment, m_coincidentEdges )
                {
                    visitor( segment );
                }

                if( m_negativeChild != 0 )
                {
                    m_negativeChild->painters_traversal( point, visitor );
                }    
            }
            else
            {
                if( m_positiveChild != 0 )
                {
                    m_positiveChild->painters_traversal( point, visitor );
                }
                if( m_negativeChild != 0 )
                {
                    m_negativeChild->painters_traversal( point, visitor );
                }
            }
        }
    }

}}}//namespace boost::numeric::geometry;

#endif //_BOOST_GEOMETRY_BSPTREE2D_HPP
