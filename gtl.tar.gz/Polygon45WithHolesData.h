/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
class Polygon45WithHolesData {
public:
  typedef std::vector<Point>::const_iterator iterator;
  typedef std::list<Polygon45Data>::const_iterator iteratorHoles;
  typedef Polygon45Data holeType; 

  /// default constructor of point does not initialize x and y
  inline Polygon45WithHolesData(){;} //do nothing default constructor

  /// initialize a polygon from x,y values, it is assumed that the first is an x
  /// and that the input is a well behaved polygon
  template<class iT>
  inline Polygon45WithHolesData& set(iT inputBegin, iT inputEnd) {
    self_.set(inputBegin, inputEnd);
    return *this;
  }

  /// initialize a polygon from x,y values, it is assumed that the first is an x
  /// and that the input is a well behaved polygon
  template<class iT>
  inline Polygon45WithHolesData& setHoles(iT inputBegin, iT inputEnd) {
    holes_.clear();  //just in case there was some old data there
    for( ; inputBegin != inputEnd; ++ inputBegin) {
       holes_.push_back(Polygon45Data());
       holes_.back().set((*inputBegin).begin(), (*inputBegin).end());
    }
    return *this;
  }

  /// copy constructor (since we have dynamic memory)
  inline Polygon45WithHolesData(const Polygon45WithHolesData& that) : self_(that.self_), 
                                                                      holes_(that.holes_) {}
  
  /// assignment operator (since we have dynamic memory do a deep copy)
  inline Polygon45WithHolesData& operator=(const Polygon45WithHolesData& that) {
    self_ = that.self_;
    holes_ = that.holes_;
    return *this;
  }

  /// get begin iterator, returns a pointer to a const Unit
  inline const iterator begin() const {
    return self_.begin();
  }

  /// get end iterator, returns a pointer to a const Unit
  inline const iterator end() const {
    return self_.end();
  }

  inline unsigned int size() const {
    return self_.size();
  } 

  /// get begin iterator, returns a pointer to a const Unit
  inline const iteratorHoles beginHoles() const {
    return holes_.begin();
  }

  /// get end iterator, returns a pointer to a const Unit
  inline const iteratorHoles endHoles() const {
    return holes_.end();
  }

  inline unsigned int sizeHoles() const {
    return holes_.size();
  }

private:
  Polygon45Data self_;
  std::list<Polygon45Data> holes_; 
};
