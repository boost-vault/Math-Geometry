/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T>
class PolygonWithHolesImpl : public T{
public:

  typedef typename PolygonInterface<T>::iterator iterator;
  typedef typename PolygonWithHolesInterface<T>::iterator iteratorHoles;
  typedef typename PolygonWithHolesInterface<T>::holeType holeType;
  typedef typename PolygonImpl<T>::iteratorPoints iteratorPoints;
  typedef typename PolygonImpl<T>::iteratorEdges iteratorEdges;

  /// get a reference of PolygonWithHolesImpl type given a data object
  static inline PolygonWithHolesImpl& mimic(T& t) { return static_cast<PolygonWithHolesImpl&>(t); }

  /// get a reference of PolygonWithHolesImpl type given a data object
  static inline const PolygonWithHolesImpl& mimicConst(const T& t) { 
     return static_cast<const PolygonWithHolesImpl&>(t); }

  /// construct a polygon from an iterator over unique x and y values
  template<class iT>
  inline PolygonWithHolesImpl(iT inputBegin, iT inputEnd) { set(inputBegin, inputEnd); }

  template<class T2>
  inline PolygonWithHolesImpl(const RectangleImpl<T2>& rect) {
     set(rect);
  }

  /// default constructor
  inline PolygonWithHolesImpl() {}

  /// assignment operator
  template <class T2>
  inline PolygonWithHolesImpl& operator=(const PolygonWithHolesImpl<T2>& that) { 
     set(that.begin(), that.end()); 
     setHoles(that.beginHoles(), that.endHoles());
     return *this;
  }

  /// assignment operator
   inline PolygonWithHolesImpl& operator=(const PolygonWithHolesImpl<T>& that) { 
      yield() = that; return *this; }

//   /// assignment operator
//    inline PolygonWithHolesImpl& operator=(const T& that) { yield() = that; return *this; }

   /// copy constructor
   template <class T2>
   inline PolygonWithHolesImpl(const PolygonWithHolesImpl<T2>& that) { 
      set(that.begin(), that.end()); 
      setHoles(that.beginHoles(), that.endHoles());
   }

   /// copy constructor
   inline PolygonWithHolesImpl(const T& that) : T(that) {}

   /// conversion to Polygon
   operator PolygonImpl<T>() const {
      return PolygonImpl<T>::mimicConst(yieldConst());
   }
   /// conversion to Polygon
   operator PolygonImpl<T>() {
      return PolygonImpl<T>::mimic(yield());
   }

//   /// equivalence operator
//   template <class T2>
//   inline bool operator==(const PolygonWithHolesImpl<T2>& b) const;

//   /// inequivalence operator
//   template <class T2>
//   inline bool operator!=(const PolygonWithHolesImpl<T2>& b) const { return !(*this == b); }

  /// yield payload
  inline T& yield() { return *this; }

  /// yield const payload
  inline const T& yieldConst() const { return *this; }

   inline PolygonImpl<T>& mimicPolygon() {
      return PolygonImpl<T>::mimic(yield());
   }

   inline const PolygonImpl<T>& mimicConstPolygon() const {
      return PolygonImpl<T>::mimicConst(yieldConst());
   }

//   /// check for validity
//   inline bool isValid(void) const;

  /// set with coordinates
  template<class iT>
  inline PolygonWithHolesImpl& set(iT inputBegin, iT inputEnd) {
     set_(inputBegin, inputEnd);
     return *this;
  }

  template<class T2>
  inline PolygonWithHolesImpl& set(const RectangleImpl<T2>& rect) {
     mimicPolygon().set(rect);
     Polygon tmp;
     setHoles_(&tmp, &tmp);
     return *this;
  }

  template<class iT>
  inline PolygonWithHolesImpl& setPoints(iT beginPoint, iT endPoint) {
    mimicPolygon().setPoints(beginPoint, endPoint);
    return *this;
  }

  /// set with coordinates
  template<class iT>
  inline PolygonWithHolesImpl& setHoles(iT inputBegin, iT inputEnd) {
     setHoles_(inputBegin, inputEnd);
     return *this;
  }

   inline iterator begin() const {
      return begin_();
   }

   inline iterator end() const {
      return end_();
   }

   inline iteratorPoints beginPoints() const {
      return mimicConstPolygon().beginPoints();
   }

   inline iteratorPoints endPoints() const {
      return mimicConstPolygon().endPoints();
   }

   inline iteratorEdges beginEdges() const {
      return mimicConstPolygon().beginEdges();
   }

   inline iteratorEdges endEdges() const {
      return mimicConstPolygon().endEdges();
   }

   inline std::size_t size() const {
      return size_();
   }

   inline iteratorHoles beginHoles() const {
      return beginHoles_();
   }

   inline iteratorHoles endHoles() const {
      return endHoles_();
   }

   inline std::size_t sizeHoles() const {
      return sizeHoles_();
   }

   inline Rectangle boundingBox() const {
      return mimicConstPolygon().boundingBox();
   }

   inline Direction1D winding() const {
      return mimicConstPolygon().winding();
   }

   template <class T2>
   inline bool contains(const PointImpl<T2>& p, 
                        bool considerTouch = true) const {
      for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
         if(PolygonImpl<holeType>::mimicConst(*iter).contains(p, !considerTouch)) {
            return false;
         }
      }
      return mimicConstPolygon().contains(p, considerTouch);
   }

  template <class pT>
  inline PointImpl<PointData> project(const PointImpl<pT>& point) const {
    PointImpl<PointData> returnVal = mimicConstPolygon().project(point);
    double dist = point.euclidianDistance(returnVal);
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      PointImpl<PointData> holePoint = 
        PolygonImpl<holeType>::mimicConst(*iter).project(point);
      double holeDist = point.euclidianDistance(holePoint);
      if(holeDist < dist) {
        returnVal = holePoint;
        dist = holeDist;
      }
    }
    return returnVal;
  }

  template <class pT1, class pT2>
  inline bool project(PointImpl<pT1>& result, const PointImpl<pT2>& point,
                      Direction2D dir) const {
    PointImpl<PointData> returnVal;
    bool found = mimicConstPolygon().project(returnVal, point, dir);
    if(found) {
      double dist = point.euclidianDistance(returnVal);
      for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
        PointImpl<PointData> holePoint;
        if(PolygonImpl<holeType>::mimicConst(*iter).project(holePoint,
                                                            point, dir)) {
          double holeDist = point.euclidianDistance(holePoint);
          if(holeDist < dist) {
            returnVal = holePoint;
            dist = holeDist;
          }
        }
      }
      result = returnVal;
    }
    return found;
  }

   /// transform polygon
   inline PolygonWithHolesImpl& transform(const AxisTransform& atr) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      PolygonImpl<holeType>::mimic(holes.back()).transform(atr);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().transform(atr);
    return *this;
  }
    
   /// transform polygon
   inline PolygonWithHolesImpl& transform(const Transform& tr) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      PolygonImpl<holeType>::mimic(holes.back()).transform(tr);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().transform(tr);
    return *this;
  }

   inline PolygonWithHolesImpl& move(Unit xDisplacement, Unit yDisplacement) {
      std::vector<holeType> holes;
      holes.reserve(sizeHoles());
      for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
        holes.push_back(*iter);
        PolygonImpl<holeType>::mimic(holes.back()).move(xDisplacement, yDisplacement);
      }
      setHoles(holes.begin(), holes.end());
      mimicPolygon().move(xDisplacement, yDisplacement);
      return *this;
   }

   /// move polygon by delta in orient
   inline PolygonWithHolesImpl& move(Orientation2D orient, Unit delta) {
      if(orient == HORIZONTAL) {
         return move(delta, 0);
      }
      return move(0, delta);
   }

  inline PolygonWithHolesImpl& removeDegenerateHoles() {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      if(PolygonImpl<holeType>::mimicConst(*iter).area() > 0)
        holes.push_back(*iter);
    }
    setHoles(holes.begin(), holes.end());
    return *this;
  }

  inline PolygonWithHolesImpl& scaleUp(UnsignedUnit factor) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      PolygonImpl<holeType>::mimic(holes.back()).scaleUp(factor);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().scaleUp(factor);
    return *this;
  }

   /// move polygon by delta in orient
  inline PolygonWithHolesImpl& scaleDown(UnsignedUnit factor) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      PolygonImpl<holeType>::mimic(holes.back()).scaleDown(factor);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().scaleDown(factor);
    removeDegenerateHoles();
    return *this;
  }
//   /// get the distance between 'this' and p along orientation orient
//   template <class T2>
//   inline UnsignedUnit distance(const PolygonWithHolesImpl<T2>& p, 
//                                Orientation2D orient) const;

//   /// get the manhatton distance between 'this' and p 
//   template <class T2>
//   inline UnsignedUnit manhattanDistance(const PolygonWithHolesImpl<T2>& p) const;

//   /// get the square equclidian distance between 'this' and p 
//   template <class T2>
//   inline UnsignedLongUnit squareEuclidianDistance(const PolygonWithHolesImpl<T2>& p) const;

//   /// get the euclidian distance between 'this' and p
//   template <class T2>
//   inline double euclidianDistance(const PolygonWithHolesImpl<T2>& p) const;

//   /// get the bounding box of the polygon
//   inline RectangleImpl<RectangleData> boundingBox() const;

//   /// get the magnitude of the interval range depending on orient
//   inline UnsignedUnit delta(Orientation2D orient) const;

   /// get the area 
  inline UnsignedLongUnit area() const {
    UnsignedLongUnit retval = mimicConstPolygon().area();
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      retval -= PolygonImpl<holeType>::mimicConst(*iter).area();
    }
    return retval;
  }

//   /// returns the orientation of the longer delta
//   inline Orientation2D guessOrientation(void) const;

//   /// get the perimeter of the rectangle
//   inline UnsignedLongUnit perimeter() const;

//   /// check if Polygon b is inside `this` Polygon
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if b touches the boundary
//   //  [ret]    .         true if `t` contains b
//   template <class T2>
//   inline bool contains(const PolygonWithHolesImpl<T2>& b, 
//                        bool considerTouch = true) const;

//   /// check if Point p is inside `this` Polygon
//   template <class T2>
//   inline bool contains(const PointImpl<T2>& p, 
//                        bool considerTouch = true) const;

//   /// check if `this` Polygon is inside specified Polygon b
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch true, return true even if `t` touches the boundary
//   //  [ret]    .         true if `t` is inside b
//   template <class T2>
//   inline bool inside(const PolygonWithHolesImpl<T2>& b, 
//                      bool considerTouch = true) const;

//   /// check if Polygon b intersects `this` Polygon
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if b touches the boundary
//   //  [ret]    .         true if `t` intersects b
//   template <class T2>
//   inline bool intersects(const PolygonWithHolesImpl<T2>& b, 
//                          bool considerTouch = true) const;

//   /// Check if boundaries of Polygon b and `this` Polygon intersect
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if p is on the foundary
//   //  [ret]    .         true if `t` contains p
//   template <class T2>
//   inline bool boundariesIntersect(const PolygonWithHolesImpl<T2>& b, 
//                                   bool considerTouch = true) const;
    
//   /// check if b is touching 'this' on the end specified by dir
//   template <class T2>
//   inline bool abuts(const PolygonWithHolesImpl<T2>& b, Direction2D dir) const;

//   /// check if they are touching in the given orientation
//   template <class T2>
//   inline bool abuts(const PolygonWithHolesImpl<T2>& b, 
//                     Orientation2D orient)const ;

//   /// check if they are touching but not overlapping
//   template <class T2>
//   inline bool abuts(const PolygonWithHolesImpl<T2>& b) const;

//   /// bloat the Polygon on orient by bloating
//   inline PolygonWithHolesImpl& bloat(Orientation2D orient, UnsignedUnit bloating);

//   /// bloat the Polygon by bloating
//   inline PolygonWithHolesImpl& bloat(UnsignedUnit bloating);

//   /// bloat the Polygon cooresponding to orient by bloating in dir direction
//   inline PolygonWithHolesImpl& bloat(Direction2D dir, UnsignedUnit bloating);

//   /// returns the center of the polygon
//   inline PointImpl<PointData> getCenter(void) const;
//   inline const PolygonWithHolesImpl& getCenter(Unit& x, Unit& y) const;


private:
  //private functions
  inline iterator begin_() const {
    return PolygonInterface<T>::PolygonBegin(yieldConst());
  }

  inline iterator end_() const {
    return PolygonInterface<T>::PolygonEnd(yieldConst());
  }

  template <class iT>
  inline void set_(iT inputBegin, iT inputEnd) {
    PolygonInterface<T>::PolygonSet(yield(), inputBegin, inputEnd);
  }

  inline std::size_t size_() const {
    return PolygonInterface<T>::PolygonSize(yieldConst());
  }

  inline WindingDirection winding_() const {
     return PolygonInterface<T>::PolygonWinding(yieldConst());
  }

  //private functions
  inline iteratorHoles beginHoles_() const {
    return PolygonWithHolesInterface<T>::PolygonWithHolesBegin(yieldConst());
  }

  inline iteratorHoles endHoles_() const {
    return PolygonWithHolesInterface<T>::PolygonWithHolesEnd(yieldConst());
  }

  template <class iT>
  inline void setHoles_(iT inputBegin, iT inputEnd) {
    PolygonWithHolesInterface<T>::PolygonWithHolesSet(yield(), inputBegin, inputEnd);
  }

  inline std::size_t sizeHoles_() const {
    return PolygonWithHolesInterface<T>::PolygonWithHolesSize(yieldConst());
  }

};

// default polygon type
typedef PolygonWithHolesImpl<PolygonWithHolesData> PolygonWithHoles;

template <class T>
std::ostream& operator<< (std::ostream& o, const PolygonWithHolesImpl<T>& p) {
   o << "Shell " << p.mimicConstPolygon();
   for(typename PolygonWithHolesImpl<T>::iteratorHoles itr = p.beginHoles(); itr != p.endHoles(); ++itr) {
      o << "Hole " << PolygonImpl<typename PolygonWithHolesImpl<T>::holeType>::mimicConst(*itr) << " ";
   }
   return o;
}

// template <class T>
// std::istream& operator>> (std::istream& i, PolygonWithHolesImpl<T>& p);

/// assignment operator
template <class T>
template <class T2>
inline PolygonImpl<T>& PolygonImpl<T>::operator=(const PolygonWithHolesImpl<T2>& that) {
   (*this) = PolygonImpl<T2>::mimicConst(that);
   return *this;
} 

/// copy constructor
template <class T>
template <class T2>
inline PolygonImpl<T>::PolygonImpl(const PolygonWithHolesImpl<T2>& that) {
   (*this) = that;
} 

inline void testPolygonWithHolesImpl() {
   Rectangle rect(0, 0, 100, 100);
   Polygon polyHole(Rectangle(10, 10, 90, 90));
   PolygonWithHoles pwh(rect);
   pwh.setHoles(&polyHole, (&polyHole)+1);
   for(PolygonWithHoles::iteratorPoints iter = pwh.beginPoints(); iter != pwh.endPoints(); ++iter) {
      std::cout << (*iter) << " ";
   }
   for(PolygonWithHoles::iteratorHoles iterH = pwh.beginHoles(); iterH != pwh.endHoles(); ++iterH) {
      for(Polygon::iteratorPoints iter = Polygon::mimicConst(*iterH).beginPoints(); 
          iter != Polygon::mimicConst(*iterH).endPoints(); ++iter) {
         std::cout << (*iter) << " ";
      }  
   }
   std::cout << pwh << std::endl;
   std::cout << "PolygonWithHoles test pattern 1 1 1 1 1 1 0 0 0 0 0 0\n";
   std::cout << "PolygonWithHoles test pattern "; 
   std::cout << pwh.contains(Point(1, 11))
             << " " ;
   std::cout <<  pwh.contains(Point(10, 10))
             << " " ;
   std::cout <<  pwh.contains(Point(10, 90))
             << " " ;
   std::cout <<  pwh.contains(Point(90, 90))
             << " " ;
   std::cout <<  pwh.contains(Point(90, 10))
             << " " ;
   std::cout <<  pwh.contains(Point(90, 80))
             << " " ;
   std::cout <<  pwh.contains(Point(12, 12))
             << " " ;
   std::cout <<  pwh.contains(Point(10, 10), false)
             << " " ;
   std::cout <<  pwh.contains(Point(10, 90), false)
             << " " ;
   std::cout <<  pwh.contains(Point(90, 90), false)
             << " " ;
   std::cout <<  pwh.contains(Point(90, 10), false)
             << " " ;
   std::cout <<  pwh.contains(Point(90, 80), false)
             << "\n";

   pwh.move(5, 5);
   std::cout << pwh << std::endl;
}

inline int testPolygonWithHolesProject() {
  std::vector<Point> pts(5);
  pts[0] = Point(0, 0);
  pts[1] = Point(0, 10);
  pts[2] = Point(10, 10);
  pts[3] = Point(10, 0);
  pts[4] = Point(0, 0);
  PolygonWithHoles ply;
  ply.setPoints(pts.begin(), pts.begin() + 4);
  Polygon hole(Rectangle(2,2,8,8));
  ply.setHoles(&hole, (&hole)+1);
  Point rpt, pt(0,0);
  if(pt != ply.project(pt)) return 1;
  if(!ply.project(rpt, pt, WEST)) return 2;
  if(pt != rpt) return 3;
  if(!ply.project(rpt, pt, EAST)) return 4;
  if(pt != rpt) return 5;
  if(!ply.project(rpt, pt, NORTH)) return 6;
  if(pt != rpt) return 7;
  if(!ply.project(rpt, pt, SOUTH)) return 8;
  if(pt != rpt) return 9;
  pt = Point(0, 5);
  if(pt != ply.project(pt)) return 10;
  if(!ply.project(rpt, pt, WEST)) return 11;
  if(pt != rpt) return 12;
  if(!ply.project(rpt, pt, EAST)) return 13;
  if(pt != rpt) return 14;
  if(!ply.project(rpt, pt, NORTH)) return 15;
  if(pt != rpt) return 16;
  if(!ply.project(rpt, pt, SOUTH)) return 17;
  if(pt != rpt) return 18;
  pt = Point(0, 10);
  if(pt != ply.project(pt)) return 19;
  if(!ply.project(rpt, pt, WEST)) return 20;
  if(pt != rpt) return 21;
  if(!ply.project(rpt, pt, EAST)) return 22;
  if(pt != rpt) return 23;
  if(!ply.project(rpt, pt, NORTH)) return 24;
  if(pt != rpt) return 25;
  if(!ply.project(rpt, pt, SOUTH)) return 26;
  if(pt != rpt) return 27;
  pt = Point(0, 11);
  if(Point(0,10) != ply.project(pt)) return 28;
  if(ply.project(rpt, pt, WEST)) return 29;
  if(ply.project(rpt, pt, EAST)) return 30;
  if(ply.project(rpt, pt, NORTH)) return 31;
  if(!ply.project(rpt, pt, SOUTH)) return 32;
  if(Point(0,10) != rpt) return 33;
  pt = Point(0, -1);
  if(Point(0,0) != ply.project(pt)) return 34;
  if(ply.project(rpt, pt, WEST)) return 35;
  if(ply.project(rpt, pt, EAST)) return 36;
  if(!ply.project(rpt, pt, NORTH)) return 37;
  if(Point(0,0) != rpt) return 38;
  if(ply.project(rpt, pt, SOUTH)) return 39;
  pt = Point(1, -1);
  if(Point(1,0) != ply.project(pt)) return 40;
  if(ply.project(rpt, pt, WEST)) return 41;
  if(ply.project(rpt, pt, EAST)) return 42;
  if(!ply.project(rpt, pt, NORTH)) return 43;
  if(Point(1,0) != rpt) return 431;
  if(ply.project(rpt, pt, SOUTH)) return 44;
  pt = Point(1, 0);
  if(Point(1,0) != ply.project(pt)) return 45;
  if(!ply.project(rpt, pt, WEST)) return 46;
  if(rpt != Point(1,0)) return 47;
  if(!ply.project(rpt, pt, EAST)) return 48;
  if(!ply.project(rpt, pt, NORTH)) return 49;
  if(!ply.project(rpt, pt, SOUTH)) return 50;
  pt = Point(1, 5);
  if(Point(0,5) != ply.project(pt)) return 51;
  if(!ply.project(rpt, pt, WEST)) return 52;
  if(rpt != Point(0,5)) return 53;
  if(!ply.project(rpt, pt, EAST)) return 54;
  if(rpt != Point(2,5)) return 541;
  if(!ply.project(rpt, pt, NORTH)) return 55;
  if(rpt != Point(1,10)) return 551;
  if(!ply.project(rpt, pt, SOUTH)) return 56;
  if(rpt != Point(1,0)) return 561;
  pt = Point(1, 10);
  if(Point(1,10) != ply.project(pt)) return 57;
  if(!ply.project(rpt, pt, WEST)) return 58;
  if(rpt != Point(1,10)) return 59;
  if(!ply.project(rpt, pt, EAST)) return 60;
  if(!ply.project(rpt, pt, NORTH)) return 61;
  if(!ply.project(rpt, pt, SOUTH)) return 62;
  pt = Point(1, 11);
  if(Point(1,10) != ply.project(pt)) return 63;
  if(ply.project(rpt, pt, WEST)) return 64;
  if(ply.project(rpt, pt, EAST)) return 65;
  if(ply.project(rpt, pt, NORTH)) return 66;
  if(!ply.project(rpt, pt, SOUTH)) return 67;
  if(rpt != Point(1,10)) return 671;
  pt = Point(-1, -1);
  if(Point(0,0) != ply.project(pt)) return 68;
  if(ply.project(rpt, pt, WEST)) return 69;
  if(ply.project(rpt, pt, EAST)) return 70;
  if(ply.project(rpt, pt, NORTH)) return 71;
  if(ply.project(rpt, pt, SOUTH)) return 72;
  pt = Point(-1, 0);
  if(Point(0,0) != ply.project(pt)) return 73;
  if(ply.project(rpt, pt, WEST)) return 74;
  if(!ply.project(rpt, pt, EAST)) return 75;
  if(rpt != Point(0,0)) return 76;
  if(ply.project(rpt, pt, NORTH)) return 77;
  if(ply.project(rpt, pt, SOUTH)) return 78;
  pt = Point(-1, 5);
  if(Point(0,5) != ply.project(pt)) return 79;
  if(ply.project(rpt, pt, WEST)) return 80;
  if(!ply.project(rpt, pt, EAST)) return 81;
  if(rpt != Point(0,5)) return 82;
  if(ply.project(rpt, pt, NORTH)) return 83;
  if(ply.project(rpt, pt, SOUTH)) return 84;
  pt = Point(-1, 10);
  if(Point(0,10) != ply.project(pt)) return 85;
  if(ply.project(rpt, pt, WEST)) return 86;
  if(!ply.project(rpt, pt, EAST)) return 87;
  if(rpt != Point(0,10)) return 88;
  if(ply.project(rpt, pt, NORTH)) return 89;
  if(ply.project(rpt, pt, SOUTH)) return 90;
  pt = Point(-1, 11);
  if(Point(0,10) != ply.project(pt)) return 91;
  if(ply.project(rpt, pt, WEST)) return 92;
  if(ply.project(rpt, pt, EAST)) return 93;
  if(ply.project(rpt, pt, NORTH)) return 94;
  if(ply.project(rpt, pt, SOUTH)) return 95;
  return 0;
}
