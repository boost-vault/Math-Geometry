/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
using std::cout;
using std::endl;
using std::string;

// ScanEvent holds the 1D polygon data at a single x coordinate stop of an input
// to a scanline algorithm.  It consists of a map of coordinate to dydx of
// intersection at that count.  That is, it is the change in y of the change x
// of the number of intersecting polygons at that point.  A vertical left edge
// of a polygon has a change of +1 across its length and a change in change of
// +1 at its bottom end and -1 at its top end.  The map will store +1 at the
// coordinate of its bottom end and -1 at the coordinate of its top end.
// The ScanEvent can be used in any orientation and is a purely 1D entity.
class ScanEvent{
private:
   typedef std::map<Unit, int> EventData;
   EventData eventData_;
public:

   // The ScanEvent::iterator is a lazy algorithm that accumulates
   // polygon intersection count as it is incremented through the
   // scan event data structure.
   // The iterator provides a forward iterator semantic only.
   class iterator {
   private:
      EventData::const_iterator itr_;
      Unit prevPos_;
      int count_;
   public:
      inline iterator() {}
      inline iterator(EventData::const_iterator itr, 
                      Unit prevPos, int count) : itr_(itr), 
                                                 prevPos_(prevPos), 
                                                 count_(count) {}
      inline iterator(const iterator& that) : itr_(that.itr_), 
                                              prevPos_(that.prevPos_), 
                                              count_(that.count_) {}
      inline iterator& operator=(const iterator& that) ;
      inline bool operator==(const iterator& that) { return itr_ == that.itr_; }
      inline bool operator!=(const iterator& that) { return itr_ != that.itr_; }
      inline iterator& operator++();
      inline iterator operator++(int);
      inline std::pair<Interval, int> operator*();
   };

   inline ScanEvent() {}
   template<class iT>
   inline ScanEvent(iT begin, iT end); 
   inline ScanEvent(const ScanEvent& that) : eventData_(that.eventData_) {}
   inline ScanEvent& operator=(const ScanEvent& that);

   //Insert and interval intersection count change into the EventData
   inline void insert(const std::pair<Interval, int>& intervalCount);

   //Insert and position and change int change in intersection count into EventData
   inline void insert(Unit pos, int count);

   //merge this scan event with that by inserting its data
   inline void insert(const ScanEvent& that);

   //Get the begin iterator over event data
   inline iterator begin() const;

   //Get the end iterator over event data
   inline iterator end() const;

   inline void clear() { eventData_.clear(); }

   inline Interval extents() const { 
      if(eventData_.empty()) return Interval();
      return Interval((*(eventData_.begin())).first, (*(eventData_.rbegin())).first);
   }
};

class ScanEventNew{
private:
   typedef std::vector<std::pair<Unit, int> > EventData;
   mutable EventData eventData_;
   mutable bool dirty_;
   class lessEventDataElement : public std::binary_function<const std::pair<Unit, int>&, const std::pair<Unit, int>&, bool> {
   public:
      inline lessEventDataElement() {}
      inline bool operator () (const std::pair<Unit, int>& elem1, const std::pair<Unit, int>& elem2) const {
         return elem1.first < elem2.first;
      }
   };
public:

   // The ScanEvent::iterator is a lazy algorithm that accumulates
   // polygon intersection count as it is incremented through the
   // scan event data structure.
   // The iterator provides a forward iterator semantic only.
   class iterator {
   private:
      EventData::const_iterator i_;
      Unit prevPos_;
      int count_;
   public:
      inline iterator() {}
      inline iterator(EventData::const_iterator i, 
                      Unit prevPos, int count) : i_(i), 
                                                 prevPos_(prevPos), 
                                                 count_(count) {}
      inline iterator(const iterator& that) : i_(that.i_), 
                                              prevPos_(that.prevPos_), 
                                              count_(that.count_) {}
      inline iterator& operator=(const iterator& that) {
         //std::cout << "iterator assign\n";
         i_ = that.i_;
         prevPos_ = that.prevPos_;
         count_ = that.count_;
         return *this;
      }
      inline bool operator==(const iterator& that) { return i_ == that.i_; }
      inline bool operator!=(const iterator& that) { return i_ != that.i_; }
      inline iterator& operator++() {
         //std::cout << "iterator increment\n";
         prevPos_ = (*i_).first;
         count_ += (*i_).second;
         ++i_;
         return *this;
      }
      inline iterator operator++(int) {
         iterator tmp = *this;
         ++(*this);
         return tmp;
      }
      inline std::pair<Interval, int> operator*() {
         //std::cout << "iterator dereference\n";
         if(count_ == 0) ++(*this);
         std::pair<Interval, int> retVal;
         retVal.first = Interval(prevPos_, (*i_).first);
         retVal.second = count_;
         return retVal;
      }
   };

   inline ScanEventNew() {}
   template<class iT>
   inline ScanEventNew(iT begin, iT end){
      for( ; begin != end; ++begin){
         insert(*begin);
      }
   }
   inline ScanEventNew(const ScanEventNew& that) : eventData_(that.eventData_), dirty_(that.dirty_) {}
   inline ScanEventNew& operator=(const ScanEventNew& that) {
      if(that.dirty_) that.clean();
      eventData_ = that.eventData_;
      dirty_ = that.dirty_;
      return *this;
   } 

   //Insert and interval intersection count change into the EventData
   inline void insert(const std::pair<Interval, int>& intervalCount) {
      insert(intervalCount.first.low(), intervalCount.second);
      insert(intervalCount.first.high(), -intervalCount.second);
   }

   //Insert and position and change int change in intersection count into EventData
   inline void insert(Unit pos, int count) {
      eventData_.push_back(std::pair<Unit, int>());
      eventData_.back().first = pos;
      eventData_.back().second = count;
      //std::cout << "Insert: " << eventData_.size() << std::endl;
      dirty_ = true;
   }

   //merge this scan event with that by inserting its data
   inline void insert(const ScanEventNew& that) {
      EventData::const_iterator itr;
      for(itr = that.eventData_.begin(); itr != that.eventData_.end(); ++itr) {
         insert((*itr).first, (*itr).second);
      }
   }

   inline void clean() const {
      //std::cout << "Clean\n";
      if(eventData_.empty()) return;
      std::sort(eventData_.begin(), eventData_.end(), lessEventDataElement());
      std::vector<std::pair<Unit, int> > collapse;
      collapse.reserve(eventData_.size());
      Unit pos = eventData_[0].first;
      int count = eventData_[0].second;
      unsigned int i = 1;
      for( ; i < eventData_.size(); ++i) {
         if(pos == eventData_[i].first) {
            count += eventData_[i].second;
         } else {
            if(count != 0) {
               //std::cout << "collapse insert\n";
               collapse.push_back(std::pair<Unit, int>());
               collapse.back().first = pos;
               collapse.back().second = count;
            }
            pos = eventData_[i].first;
            count = eventData_[i].second;
         }
      }
      //std::cout << "collapse insert\n";
      if(count != 0) {
         collapse.push_back(std::pair<Unit, int>());
         collapse.back().first = pos;
         collapse.back().second = count;
      }
      //std::cout << "data size: " << eventData_.size() << std::endl;
      //std::cout << "collapse size: " << collapse.size() << std::endl;
      eventData_ = std::vector<std::pair<Unit, int> >();
      eventData_.insert(eventData_.end(), collapse.begin(), collapse.end());
      dirty_ = false;
   }

   //Get the begin iterator over event data
   inline iterator begin() const {
      if(dirty_) clean();
      if(eventData_.empty()) return end();
      Unit pos = eventData_[0].first;
      int count = eventData_[0].second;
      EventData::const_iterator itr = eventData_.begin();
      ++itr;
      return iterator(itr, pos, count);
   }

   //Get the end iterator over event data
   inline iterator end() const {
      if(dirty_) clean();
      return iterator(eventData_.end(), 0, 0);
   }

   inline void clear() { eventData_.clear(); }

   inline Interval extents() const { 
      if(eventData_.empty()) return Interval();
      return Interval((*(eventData_.begin())).first, (*(eventData_.rbegin())).first);
   }
};

//declaration of a map of scan events by coordinate value used to store all the
//polygon data for a single layer input into the scanline algorithm
typedef std::map<Unit, ScanEvent> PolygonSetData;

//BooleanOp is the generic boolean operation scanline algorithm that provides
//all the simple boolean set operations on manhattan data.  By templatizing
//the intersection count of the input and algorithm internals it is extensible
//to multi-layer scans, properties and other advanced scanline operations above
//and beyond simple booleans.
//T must cast to int
template <class T>
class BooleanOp {
public:
   typedef std::map<Unit, T> ScanData;
   typedef std::pair<Unit, T> ElementType;
protected:
   ScanData scanData_;
   typename ScanData::iterator nextItr_;
   T nullT_;
public:
   inline BooleanOp () { nextItr_ = scanData_.end(); }
   inline BooleanOp (T nullT) : nullT_(nullT) { nextItr_ = scanData_.end(); }
   inline BooleanOp (const BooleanOp& that) : scanData_(that.scanData_),
                                              nullT_(that.nullT_) { nextItr_ = scanData_.begin(); }
   inline BooleanOp& operator=(const BooleanOp& that); 
   
   //moves scanline forward
   inline void advanceScan() { nextItr_ = scanData_.begin(); }

   //proceses the given interval and T data
   //appends output edges to cT
   template <class cT>
   inline void processInterval(cT& outputContainer, Interval ivl, T deltaCount);
   
private:
   inline typename ScanData::iterator lookup_(Unit pos){
      if(nextItr_ != scanData_.end() && nextItr_->first >= pos) {
         return nextItr_;
      }
      return nextItr_ = scanData_.lower_bound(pos);
   }
   inline typename ScanData::iterator insert_(Unit pos, T count){ 
      return nextItr_ = scanData_.insert(nextItr_, ElementType(pos, count)); 
   } 
   template <class cT>
   inline void evaluateInterval_(cT& outputContainer, Interval ivl, T beforeCount, T afterCount);
};

//Single layer BooleanOr algorithm, operates on a ScanEvent directly because
//the template argument is int (remember BooleanOp::T must cast to int)
class BooleanOr : public BooleanOp<int> {
public:
   inline BooleanOr () {
      nullT_ = 0;
   }
};


class BinaryAnd {
public:
   inline BinaryAnd() {}
   inline bool operator()(int a, int b) { return (a > 0) & (b > 0); }
};
class BinaryOr {
public:
   inline BinaryOr() {}
   inline bool operator()(int a, int b) { return (a > 0) | (b > 0); }
};
class BinaryNot {
public:
   inline BinaryNot() {}
   inline bool operator()(int a, int b) { return (a > 0) & !(b > 0); }
};
class BinaryXor {
public:
   inline BinaryXor() {}
   inline bool operator()(int a, int b) { return (a > 0) ^ (b > 0); }
};

//BinaryCount is an array of two deltaCounts coming from two different layers
//of scan event data.  It is the merged count of the two suitable for consumption
//as the template argument of the BooleanOp algorithm because BinaryCount casts to int.
//T is a binary functor object that evaluates the array of counts and returns a logical 
//result of some operation on those values.
//BinaryCount supports many of the operators that work with int, particularly the
//binary operators, but cannot support less than or increment.
template <class T>
class BinaryCount {
public:
   inline BinaryCount() { counts_[0] = counts_[1] = 0; }
   // constructs from two integers
   inline BinaryCount(int countL, int countR) { counts_[0] = countL, counts_[1] = countR; }
   inline BinaryCount& operator=(const BinaryCount& that); 
   inline BinaryCount(const BinaryCount& that) { *this = that; }
   inline bool operator==(const BinaryCount& that) const;
   inline bool operator!=(const BinaryCount& that) const { return !((*this) == that);}
   inline BinaryCount& operator+=(const BinaryCount& that);
   inline BinaryCount& operator-=(const BinaryCount& that);
   inline BinaryCount operator+(const BinaryCount& that) const;
   inline BinaryCount operator-(const BinaryCount& that) const;
   inline BinaryCount operator-() const;
   inline int& operator[](bool index) { return counts_[index]; }

   //cast to int operator evaluates data using T binary functor
   inline operator int() const { return T()(counts_[0], counts_[1]); }
private:
   int counts_[2];
};

class BooleanBinaryAnd : public BooleanOp<BinaryCount<BinaryAnd> > {
public:
   inline BooleanBinaryAnd () {
      nullT_ = BinaryCount<BinaryAnd>();
   }
};

//T is a binary count object
template <class T>
class ScanEventMergeIterator {
private:
   typename std::pair<Interval, T> element_;
   ScanEvent::iterator itrs_[2];
   ScanEvent::iterator itrEnds_[2];
public:
   
   inline ScanEventMergeIterator() {}
   inline ScanEventMergeIterator(ScanEvent::iterator* itrs, ScanEvent::iterator* itrEnds);
   inline ScanEventMergeIterator(const ScanEventMergeIterator& that) { (*this) = that; }
   inline ScanEventMergeIterator& operator=(const ScanEventMergeIterator& that);
   inline bool operator==(const ScanEventMergeIterator& that);
   inline bool operator!=(const ScanEventMergeIterator& that) { return !((*this) == that); }
   
   inline ScanEventMergeIterator& operator++();
   inline ScanEventMergeIterator operator++(int);
   inline std::pair<Interval, T>& operator*() { return element_; }
   
private:
   inline Unit getFirstPos_();

   //this is the function that does all the actual work
   inline void increment_();
};

template <class T>
void applyBooleanBinaryOp(PolygonSetData& output, const PolygonSetData& input1,
                          const PolygonSetData& input2, T defaultCount) ;

template <class T>
inline void applyBooleanBinaryOp(PolygonSetData& inputOutput,
                                 const PolygonSetData& input2, T defaultCount) ;

void applyBooleanOr(PolygonSetData& input);

