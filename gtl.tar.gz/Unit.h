/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
//////////////////////////////////////////////////////////////////
// Unit utility functions
//////////////////////////////////////////////////////////////////

/// round floating point to integer
template <class T>
inline Unit round(const T& input){
  Unit retval = (Unit)input;
  return retval + ((input - (T)retval) > 0.5);
}

/// predicated_value returns a if pred is true, else b

/// predicated_value replaces the ()?():(); syntax which
/// compiles to a branch instruction and provides a branch free primitive
/// that can be used to optimize away branch instructions in C++
template <class T>
inline const T& predicated_value(const bool& pred,
                                 const T& a,
                                 const T& b) {
  const T* input[2] = {&b, &a};
  return *(input[pred]);
}

/// predicated_assign assigns value to a if pred is true, else to b

/// predicated_assign replaces the C++ syntax
/// if(pred)
///   a = value;
/// else
///   b = value;
/// which compiles to a branch instruction.  predicated_assign does not
/// generate branch instructions and can be used to optimize away branch
/// instructions in C++
template <class T>
inline const T& predicated_assign(const bool& pred,
                                  T& a,
                                  T& b,
                                  const T& value) {
  T* input[2] = {&b, &a};
  return *(input[pred]) = value;
}
  
/// predicated_swap swaps a and b if pred is true

/// predicated_swap is garenteed to behave the same as
/// if(pred){
///   T tmp = a;
///   a = b;
///   b = tmp;
/// }
/// but will not generate a branch instruction.
/// predicated_swap always creates a temp copy of a, but does not
/// create more than one temp copy of an input.
/// predicated_swap can be used to optimize away branch instructions in C++
template <class T>
inline bool predicated_swap(const bool& pred,
                            T& a,
                            T& b) {
  const T tmp = a;
  const T* input[2] = {&b, &tmp};
  a = *input[!pred];
  b = *input[pred];
  return pred;
}

#undef max
/// max: returns b if a < b, else returns a
 
/// gtl::max is 35% faster than std::max
/// when compiled by gcc 3.2.2 targeting a P4 3.2 GHz server
template <class T>
inline const T& max(const T& a, const T& b) {
  return predicated_value(a>b, a, b);
}


#undef min
/// min: returns a if a < b, else returns b
 
/// gtl::min is 35% faster than std::min
/// when compiled by gcc 3.2.2 targeting a P4 3.2 GHz server
template <class T>
inline const T& min(const T& a, const T& b) {
  return predicated_value(a<b, a, b);
}


/// abs: returns the absolute value of the argument

/// abs functions computes the absolute value and must
/// return by value because it may modify the value of the arguement.
/// abs is implemented in terms of gtl::max for performance 
template <class T>
inline T abs(const T& value) {
  return max<T>(value, -value);
}

/// median returns the median value of a, b, and c

/// gtl::median is 46% faster than stl __median used by stl::sort
/// median is implemented using any branch instructions by
/// constructing an array of pointers to the three arguments and 
/// returning the defreferenced value by index computed by
/// comparisons and bitwise and and or operations
template <class T>
inline const T& median(const T& a, const T& b, const T& c) {
  const bool alb = a < b;
  const bool blc = b < c;
  const bool alc = a < c;
  const T* input[3] = {&a, &b, &c};
  unsigned int index = 0; //default is to return a
  index += (alb & blc) | (!alb & !blc); //return b
  index += (unsigned int)((alc & !blc) | (!alc & blc)) << 1; 
  return *(input[index]);
}

/// equivalent returns true if a == b and b == c
template <class T>
inline bool equivalent(const T& a, const T& b, const T& c) {
  const bool aeb = a == b;
  const bool bec = b == c;
  return aeb & bec;
};

/// inOrder returns true if a < b and b < c
template <class T>
inline bool inOrder(const T& a, const T& b, const T& c) {
  const bool alb = a < b;
  const bool blc = b < c;
  return alb & blc;
};

/// inOrderOrEqual returns true if a <= b and b <= c
template <class T>
inline bool inOrderOrEqual(const T& a, const T& b, const T& c) {
  const bool alb = a <= b;
  const bool blc = b <= c;
  return alb & blc;
};

/// sort2 swaps a and b if b is less than a
template <class T>
inline void sort2(T& a, T& b) {
  predicated_swap(b < a, a, b);
}

/// sort3 puts a, b and c in order by calls to sort2
template <class T>
inline void sort3(T& a, T& b, T& c) {
  sort2(a, c);
  sort2(b, c);
  sort2(a, b);
}

/// sort4 puts l1, h1, l2, h2 in order by calls to sort2. Assumes l1 <= h1 and l2 <= h2
template <class T>
inline void sort4(T& l1, T& h1, T& l2, T& h2) {
  sort2(l1, l2);
  sort2(h1, h2);
  sort2(h1, l2);
}

