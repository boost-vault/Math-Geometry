/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// RectPrismData is the default representation of a rectangular prism

/// RectPrismData has a c-style array of intervals indexed by the value
/// of an Orientation3D object.
/// This implementation was chosen for performance reasons because
/// the in memory representation is accessed directly by the value of
/// the orientation argument instead of using an if statement or 
/// branch free primitive such as predicated_value and predicated_assign.
/// Because the represenation chosen for the intervals is IntervalData
/// a rectangle is stored as a 3x2 array in memory, indexed first by
/// orientation to get an interval and then by direction through the interval
/// API to get a coordiante.
class RectPrismData {
public:
  /// default constructor does not initialize
  inline RectPrismData(){;} //do nothing default constructor

  /// construct from horizontal range, vertical range and proximal range
  inline RectPrismData(const IntervalData& hrange,
                       const IntervalData& vrange,
                       const IntervalData& prange){
    ranges_[HORIZONTAL] = hrange;
    ranges_[VERTICAL] = vrange;
    ranges_[PROXIMAL] = prange;
  }

  inline RectPrismData(const RectPrismData& that) {
     (*this) = that;
  }

  inline RectPrismData& operator=(const RectPrismData& that) {
     ranges_[0] = that.ranges_[0];
     ranges_[1] = that.ranges_[1];
     ranges_[2] = that.ranges_[2];
     return *this;
  } 

  /// get an interval range depending on the value of orient
  inline IntervalData get(Orientation3D orient) const {
    return ranges_[orient.toInt()];
  }
  /// set an interval range depending on the value of orient
  inline void set(Orientation3D orient, const IntervalData& value){
    ranges_[orient.toInt()] = value;
  }

private:
  IntervalData ranges_[3]; //to be indexed by orientation3d value
};
