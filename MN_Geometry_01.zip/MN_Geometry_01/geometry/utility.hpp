// ============================================================================
// utility.hpp                                    (C)2005 Michael Andersen Nexo
// ============================================================================
// This header defines a number of utility functions for vector<T,D> and
// point<T,D>:
//
// dot(v,w)               Dot product of vectors v and w
// cross(v,w)             Cross product (2D returns scalar, 3D returns vector)
// sum(v)                 The sum of all elements in v
// abs(v)				  Returns the vector u, where u[i] = abs(v[i])
// norm_1(v)              The "Manhattan" length of v, sum(abs(v))
// len(v)/norm_2(v)       The Euclidian length of v, |v|
// sqlen(v)               The squared length of v
// sqdist(p, q)			  The squared Euclidian distance between points p, q
// dist(p, q)			  The Euclidian distance between p and q
// normalize(v)           Returns v/len(v)

// For the functions dot, cross, sum, abs, norm_1, sqlen and 
// sqdist, there are two different ways to use these:
//
// 1) Automatic return type inference based on standard type promotion,
//    short * short => int:
//         geom::vector<short,2> v(200, 200) w(200, 200);
//         int d = dot(v,w);             // d == 80000, i.e. no overflow
// 2) Explicit return type:
//         geom::vector<int,2> v(65536, 65536), w(65536, 65536);
//         double d = dot<double>(v, w); // d == 2*(2^32), i.e. no overflow

#ifndef UTILITY_HPP_INCLUDED
#define UTILITY_HPP_INCLUDED

#include "geometry.hpp"

namespace geom
{
	namespace detail
	{
		// Implementation class for functions dot, cross and sum.
		// R is the scalar type of the return value, D is the dimensionality.
		// Used for specializing implementations for D=2 and D=3
		template <class R, size_t D>
		struct specialized
		{
			template <class T, class U, class LE, class RE>
			static R dot(vector<T,D,LE> const& l, vector<U,D,RE> const& r)
			{
				return std::inner_product(l.begin(), l.end(), r.begin(), R());
			}

			template <class T, class E>
			static R sum(vector<T,D,E> const& v)
			{
				return std::accumulate(v.begin(), v.end(), R());
			}

			template <class T, class E>
			static vector<T,D> abs(vector<T,D,E> const& v)
			{
				vector<T,D> res;
				std::transform(v.begin(), v.end(), res.begin(), ops::abs<T>());
				return res;
			}
		};

		template <class R>
		struct specialized<R, 2>
		{
			template <class T, class U, class LE, class RE>
			static R dot(vector<T,2,LE> const& l, vector<U,2,RE> const& r)
			{
				return R(l.x())*r.x() + R(l.y())*r.y();
			}

			template <class T, class LE>
			static R sum(vector<T,2,LE> const& v)
			{
				return R(v.x()) + v.y();
			}

			template <class T, class E>
			static vector<T,2> abs(vector<T,2,E> const& v)
			{
				return vector<T,2>(std::abs(v.x()), std::abs(v.y()));
			}

			typedef R cross_type; // 2D cross returns a scalar value
			template <class T, class LE, class U, class RE>
			static R cross(vector<T,2,LE> const& l, vector<U,2,RE> const& r)
			{
				return R(l.x())*r.y() - R(l.y())*r.x();
			}
		};

		template <class R>
		struct specialized<R, 3>
		{
			template <class T, class U, class LE, class RE>
			static R dot(vector<T,3,LE> const& l, vector<U,3,RE> const& r)
			{
				return R(l.x())*r.x() + R(l.y())*r.y() + R(l.z())*r.z();
			}

			template <class T, class LE>
			static R sum(vector<T,3,LE> const& v)
			{
				return R(v.x()) + v.y() + v.z();
			}

			template <class T, class E>
			static vector<T,3> abs(vector<T,3,E> const& v)
			{
				using std::abs;
				return vector<T,3>(abs(v.x()), abs(v.y()), abs(v.z()));
			}

			typedef vector<R,3> cross_type; // 3D cross returns a vector
			template <class T, class U, class LE, class RE>
			static cross_type cross(vector<T,3,LE> const& l, vector<U,3,RE> const& r)
			{
				// NOTE: If LE and/or RE are expressions, this can perhaps be optimized
				// by creating temporaries...
				return vector<R, 3>( R(l.y())*r.z() - R(r.y())*l.z(),
									 R(r.x())*l.z() - R(l.x())*r.z(),
									 R(l.x())*r.y() - R(r.x())*l.y() );
			}
		};
	}

	// ------------------------------------------------------------------------
	// dot(vector, vector)
	// ------------------------------------------------------------------------
	// With explicit return type
	template <class R, class T, class U, size_t D, class LE, class RE>
	inline R dot(vector<T,D,LE> const& l, vector<U,D,RE> const& r)
	{
		return detail::specialized<R,D>::dot(l, r);
	}

	// With inferred return type
	template <size_t D, class T, class U, class LE, class RE>
	typename ops::promote_traits<T,U>::promote_type 
	dot(vector<T,D,LE> const& l, vector<U,D,RE> const& r)
	{
		typedef typename ops::multiplies<T,U>::result_type mult_type;
		typedef typename ops::plus<mult_type, mult_type>::result_type result_type;
		return dot<result_type>(l, r);
	}

	// ------------------------------------------------------------------------
	// cross<R>(vector, vector): Cross product (only valid for 2D and 3D)
	// ------------------------------------------------------------------------
	// Explicit return type
	template <class R, class T, size_t D, class U, class LE, class RE>
	inline typename detail::specialized<R,D>::cross_type 
	cross(vector<T,D,LE> const& l, vector<U,D,RE> const& r)
	{
		return detail::specialized<R,D>::cross(l, r);
	}

	// Inferred return type
	template <size_t D, class T, class U, class LE, class RE>
	inline typename detail::specialized<typename ops::promote_traits<T,U>::promote_type,D>::cross_type 
	cross(vector<T,D,LE> const& l, vector<U,D,RE> const& r)
	{
		typedef typename ops::promote_traits<T,U>::promote_type result_type;
		return cross<result_type>(l,r);
	}

	// ------------------------------------------------------------------------
	// sum(vector): The sum of all elements in the vector
	// ------------------------------------------------------------------------
	// Explicit return type
	template <class R, class T, size_t D, class E>
	inline R sum(vector<T,D,E> const& v)
	{
		return detail::specialized<R,D>::sum(v);;
	}

	// With inferred return type
	template <size_t D, class T, class E>
	inline typename ops::plus<T,T>::result_type
	sum(vector<T,D,E> const& v)
	{
		typedef typename ops::plus<T,T>::result_type result_type;
		return sum<result_type>(v);
	}

	// ------------------------------------------------------------------------
	// abs(vector): Returns the vector with ith element = abs(v[i])
	// ------------------------------------------------------------------------
	#ifdef GEOM_USE_EXPRESSION_TEMPLATES
		template <class T, size_t D, class E>
		inline vector<T, D, unary_expr<E, D, ops::abs<T> > > const
		abs(vector<T,D,E> const& v)
		{
			typedef ops::abs<T> op;
			typedef unary_expr<E, D, op> expr;
			return vector<T, D, expr>(expr(v));
		}
	#else
		template <class T, size_t D, class E>
		inline vector<T, D> const
		abs(vector<T,D,E> const& v)
		{
			return detail::specialized<T,D>::abs(v);
		}
	#endif

	// ------------------------------------------------------------------------
	// norm_1(vector): The "manhattan" length of a vector
	// ------------------------------------------------------------------------
	template <class R, class T, size_t D, class E>
	inline R norm_1(vector<T,D,E> const& v)
	{
		return sum<R>(abs(v));
	}

	template <class T, size_t D, class E>
	inline typename ops::plus<T,T>::result_type 
	norm_1(vector<T,D,E> const& v)
	{
		return norm_1<typename ops::plus<T,T>::result_type>(v);
	}

	// ------------------------------------------------------------------------
	// len(vector)/norm_2(vector): The length of the vector, |v|
	// ------------------------------------------------------------------------
	// TODO: Figure out whether the return type should be deduced or it should 
	// always be double. Also, if v is a vector expression, this might be 
	// optimized by introducing a temporary...
	template <class T, size_t D, class E>
	inline double len(vector<T,D,E> const& v)
	{
		using std::sqrt;
		return sqrt(dot<double>(v,v)); // Allow ADL
	}

	template <class T, size_t D, class E>
	inline double norm_2(vector<T,D,E> const& v)
	{
		return len(v);
	}

	// ------------------------------------------------------------------------
	// sqlen(vector): The squared norm_2 of of the vector, |v|
	// ------------------------------------------------------------------------
	template <class R, class T, size_t D, class E>
	inline R sqlen(vector<T,D,E> const& v)
	{
		return dot<R>(v,v);
	}

	template <size_t D, class T, class E>
	inline typename ops::promote_traits<T,T>::promote_type
	sqlen(vector<T,D,E> const& v)
	{
		return dot<typename ops::promote_traits<T,T>::promote_type>(v,v);
	}

	// ------------------------------------------------------------------------
	// sqdist(point, point): Euclidian squared distance between two points
	// ------------------------------------------------------------------------
	template <class R, class T, class U, size_t D, class LE, class RE>
	inline R sqdist(point<T,D,LE> const& l, point<U,D,RE> const& r)
	{
		vector<R,D> v(r-l);
		return sqlen<R>(v);
	}

	template <size_t D, class T, class U, class LE, class RE>
	inline typename ops::promote_traits<T,U>::promote_type
	sqdist(point<T,D,LE> const& l, point<U,D,RE> const& r)
	{
		vector<typename ops::minus<T,U>::result_type, D> v(r-l);
		return sqlen(v);
	}

	// ------------------------------------------------------------------------
	// dist(point, point): Euclidian distance between two points
	// ------------------------------------------------------------------------
	template <class T, class U, size_t D, class LE, class RE>
	inline double dist(point<T,D,LE> const& l, point<U,D,RE> const& r)
	{
		using std::sqrt;
		return sqrt(double(sqdist(l,r)));
	}

	// ------------------------------------------------------------------------
	// normalize(vector): Returns vector with length 1 and same direction as v
	// ------------------------------------------------------------------------
	#ifdef GEOM_USE_EXPRESSION_TEMPLATES
		template <class T, size_t D, class E>
		inline vector<double, D, scalar_expr<E,D,double,ops::divides<T,double> > >
		normalize(vector<T,D,E> const& v)
		{
			return v/norm_2(v);
		}
	#else
		template <class T, size_t D, class E>
		inline vector<double, D>
		normalize(vector<T,D,E> const& v)
		{
			return v/norm_2(v);
		}
	#endif // GEOM_USE_EXPRESSION_TEMPLATES
}

#endif // UTILITY_HPP_INCLUDED
