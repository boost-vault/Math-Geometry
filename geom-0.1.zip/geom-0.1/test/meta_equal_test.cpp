// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/geom/detail/meta_equal.hpp>

#include <cassert>

struct type1 { int x; };
struct type2 { int y; };

int main()
{
	using boost::geom::detail::meta_equal;
	assert((meta_equal<int,int>::value));
	assert((meta_equal<int,double>::value==false));
	assert((meta_equal<type1, int>::value==false));
	assert((meta_equal<type1, type2>::value==false));
	assert((meta_equal<type2, type2>::value));
	assert((meta_equal<type1, type1>::value));

}


