// geometry_test.cpp : Defines the entry point for the console application.
//

// Boost.Test
#include <boost/test/unit_test.hpp>
#include <boost/test/unit_test_monitor.hpp>
#include <boost/test/unit_test_log.hpp>

#include "point_tests.hpp"
#include "utility_tests.hpp"
#include "product_tests.hpp"
#include "point_sequence_tests.hpp"
#include "tolerance_comparison_tests.hpp"
#include "intersection_tests.hpp"
#include "convex_hull_test.hpp"
#include "segment_intersection_tests.hpp"
#include "trapezoidal_decomposition_test.hpp"
void StandardExceptionTranslator( const std::exception& e )
{
    BOOST_TEST_MESSAGE( e.what() );
}

boost::unit_test::test_suite* init_unit_test_suite( int , char* [] )
{
    boost::unit_test::unit_test_log.set_threshold_level( boost::unit_test::log_messages );
    boost::unit_test::unit_test_monitor.register_exception_translator<std::exception>( &StandardExceptionTranslator );
    boost::unit_test::framework::master_test_suite().p_name.value = "Boost Geometry Testing Framework";

    // with explicit registration we could specify a test case timeout
    //boost::unit_test::framework::master_test_suite().add( BOOST_TEST_CASE( &infinite_loop ), 0, /* timeout */ 2 );

    return 0; 
}
