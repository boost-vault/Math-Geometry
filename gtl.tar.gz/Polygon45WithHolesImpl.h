/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T>
class Polygon45WithHolesImpl : public T{
public:

  typedef typename Polygon45Interface<T>::iterator iterator;
  typedef typename Polygon45WithHolesInterface<T>::iterator iteratorHoles;
  typedef typename Polygon45WithHolesInterface<T>::holeType holeType;

  /// get a reference of Polygon45WithHolesImpl type given a data object
  static inline Polygon45WithHolesImpl& mimic(T& t) { return static_cast<Polygon45WithHolesImpl&>(t); }

  /// get a reference of Polygon45WithHolesImpl type given a data object
  static inline const Polygon45WithHolesImpl& mimicConst(const T& t) { 
     return static_cast<const Polygon45WithHolesImpl&>(t); }

  /// construct a polygon from an iterator over unique x and y values
  template<class iT>
  inline Polygon45WithHolesImpl(iT inputBegin, iT inputEnd) { set(inputBegin, inputEnd); }

  /// default constructor
  inline Polygon45WithHolesImpl() {}

  /// assignment operator
  template <class T2>
  inline Polygon45WithHolesImpl& operator=(const Polygon45WithHolesImpl<T2>& that) { 
     set(that.begin(), that.end()); 
     setHoles(that.beginHoles(), that.endHoles());
     return *this;
  }

  /// assignment operator
   inline Polygon45WithHolesImpl& operator=(const Polygon45WithHolesImpl<T>& that) { 
      yield() = that; return *this; }

   /// copy constructor
   template <class T2>
   inline Polygon45WithHolesImpl(const Polygon45WithHolesImpl<T2>& that) { 
      set(that.begin(), that.end()); 
      setHoles(that.beginHoles(), that.endHoles());
   }

   /// copy constructor
   inline Polygon45WithHolesImpl(const T& that) : T(that) {}

   /// conversion to Polygon
   inline operator Polygon45Impl<T>() const {
      return Polygon45Impl<T>::mimicConst(yieldConst());
   }
   /// conversion to Polygon
   inline operator Polygon45Impl<T>() {
      return Polygon45Impl<T>::mimic(yield());
   }

  /// yield payload
  inline T& yield() { return *this; }

  /// yield const payload
  inline const T& yieldConst() const { return *this; }

  inline Polygon45Impl<T>& mimicPolygon() {
    return Polygon45Impl<T>::mimic(yield());
  }
  
  inline const Polygon45Impl<T>& mimicConstPolygon() const {
    return Polygon45Impl<T>::mimicConst(yieldConst());
  }  

  template<class iT>
  inline Polygon45WithHolesImpl& set(iT inputBegin, iT inputEnd) {
     set_(inputBegin, inputEnd);
     return *this;
  }

  template<class iT>
  inline Polygon45WithHolesImpl& setHoles(iT inputBegin, iT inputEnd) {
     setHoles_(inputBegin, inputEnd);
     return *this;
  }

   inline iterator begin() const {
      return begin_();
   }

   inline iterator end() const {
      return end_();
   }

   inline std::size_t size() const {
      return size_();
   }

   inline iteratorHoles beginHoles() const {
      return beginHoles_();
   }

   inline iteratorHoles endHoles() const {
      return endHoles_();
   }

   std::size_t sizeHoles() const {
      return sizeHoles_();
   }

  inline double area() const {
    double retval = mimicConstPolygon().area();
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      retval -= Polygon45Impl<holeType>::mimicConst(*iter).area();
    }
    return retval;
  }

  inline bool is45() const {
    if(!mimicConstPolygon().is45()) return false;
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      if(! (Polygon45Impl<holeType>::mimicConst(*iter).is45())) return false;
    }
    return true;
  }

   inline Rectangle boundingBox() const {
      return mimicConstPolygon().boundingBox();
   }

   inline Direction1D winding() const {
     return mimicConstPolygon().winding();
   }

   /// transform polygon
   inline Polygon45WithHolesImpl& transform(const AxisTransform& atr) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      Polygon45Impl<holeType>::mimic(holes.back()).transform(atr);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().transform(atr);
    return *this;
  }
    
   /// transform polygon
   inline Polygon45WithHolesImpl& transform(const Transform& tr) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      Polygon45Impl<holeType>::mimic(holes.back()).transform(tr);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().transform(tr);
    return *this;
  }

   inline Polygon45WithHolesImpl& move(Unit xDisplacement, Unit yDisplacement) {
      std::vector<holeType> holes;
      holes.reserve(sizeHoles());
      for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
         holes.push_back(Polygon45Impl<holeType>::mimicConst(*iter));
         holes.back().move(xDisplacement, yDisplacement);
      }
      setHoles(holes.begin(), holes.end());
      mimicPolygon().move(xDisplacement, yDisplacement);
      return *this;
   }

   /// move polygon by delta in orient
   inline Polygon45WithHolesImpl& move(Orientation2D orient, Unit delta) {
      if(orient == HORIZONTAL) {
         return move(delta, 0);
      }
      return move(0, delta);
   }

  inline Polygon45WithHolesImpl& removeDegenerateHoles() {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      if(Polygon45Impl<holeType>::mimicConst(*iter).area() > 0)
        holes.push_back(*iter);
    }
    setHoles(holes.begin(), holes.end());
    return *this;
  }

  inline Polygon45WithHolesImpl& removeZeroLengthEdges() {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      Polygon45Impl<holeType>::mimic(holes.back()).removeZeroLengthEdges();
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().removeZeroLengthEdges();
    return *this;
  }

  inline Polygon45WithHolesImpl& scaleUp(UnsignedUnit factor) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      Polygon45Impl<holeType>::mimic(holes.back()).scaleUp(factor);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().scaleUp(factor);
    return *this;
  }

   /// move polygon by delta in orient
  inline Polygon45WithHolesImpl& scaleDown(UnsignedUnit factor) {
    std::vector<holeType> holes;
    holes.reserve(sizeHoles());
    for(iteratorHoles iter = beginHoles(); iter != endHoles(); ++iter) {
      holes.push_back(*iter);
      Polygon45Impl<holeType>::mimic(holes.back()).scaleDown(factor);
    }
    setHoles(holes.begin(), holes.end());
    mimicPolygon().scaleDown(factor);
    removeDegenerateHoles();
    return *this;
  }

private:
  //private functions
  inline iterator begin_() const {
    return Polygon45Interface<T>::Polygon45Begin(yieldConst());
  }

  inline iterator end_() const {
    return Polygon45Interface<T>::Polygon45End(yieldConst());
  }

  template <class iT>
  inline void set_(iT inputBegin, iT inputEnd) {
    Polygon45Interface<T>::Polygon45Set(yield(), inputBegin, inputEnd);
  }

  inline std::size_t size_() const {
    return Polygon45Interface<T>::Polygon45Size(yieldConst());
  }

  inline WindingDirection winding_() const {
     return Polygon45Interface<T>::Polygon45Winding(yieldConst());
  }

  //private functions
  inline iteratorHoles beginHoles_() const {
    return Polygon45WithHolesInterface<T>::Polygon45WithHolesBegin(yieldConst());
  }

  inline iteratorHoles endHoles_() const {
    return Polygon45WithHolesInterface<T>::Polygon45WithHolesEnd(yieldConst());
  }

  template <class iT>
  inline void setHoles_(iT inputBegin, iT inputEnd) {
    Polygon45WithHolesInterface<T>::Polygon45WithHolesSet(yield(), inputBegin, inputEnd);
  }

  inline std::size_t sizeHoles_() const {
    return Polygon45WithHolesInterface<T>::Polygon45WithHolesSize(yieldConst());
  }

};

// default polygon type
typedef Polygon45WithHolesImpl<Polygon45WithHolesData> Polygon45WithHoles;

template <class T>
inline std::ostream& operator<< (std::ostream& o, const Polygon45WithHolesImpl<T>& p) {
   o << "Polygon45WithHoles ";
   for(typename Polygon45WithHolesImpl<T>::iterator itr = p.begin(); itr != p.end(); ++itr) {
      o << *itr << " ";
   }
   for(typename Polygon45WithHolesImpl<T>::iteratorHoles itr = p.beginHoles(); itr != p.endHoles(); ++itr) {
      o << Polygon45Impl<typename Polygon45WithHolesImpl<T>::holeType>::mimicConst(*itr) << " ";
   }
   return o;
}

/// assignment operator
template <class T>
template <class T2>
inline Polygon45Impl<T>& Polygon45Impl<T>::operator=(const Polygon45WithHolesImpl<T2>& that) {
   (*this) = Polygon45Impl<T2>::mimicConst(that);
   return *this;
} 

/// copy constructor
template <class T>
template <class T2>
inline Polygon45Impl<T>::Polygon45Impl(const Polygon45WithHolesImpl<T2>& that) {
   (*this) = that;
} 
