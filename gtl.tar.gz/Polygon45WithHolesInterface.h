/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T>
class Polygon45WithHolesInterface {
public:

  typedef typename T::iteratorHoles iterator;
  typedef typename T::holeType holeType;

  /// Get the begin iterator
  static inline iterator Polygon45WithHolesBegin(const T& t) {
    return t.beginHoles();
  }

  /// Get the end iterator
  static inline iterator Polygon45WithHolesEnd(const T& t) {
    return t.endHoles();
  }

  /// Set the data of a polygon with the unique coordinates in an iterator, starting with an x
  template <class iT>
  static inline T& Polygon45WithHolesSet(T& t, iT inputBegin, iT inputEnd) {
    t.setHoles(inputBegin, inputEnd);
    return t;
  }

  /// Get the number of holes 
  static inline unsigned int Polygon45WithHolesSize(const T& t) {
    return t.sizeHoles();
  }

private:
  //disallow construction
  Polygon45WithHolesInterface();
};
