/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

// forward declarations

class Direction2D;
class Orientation2D;
class Direction3D;
class Orientation3D;
class Direction1D;

class AxisTransform;
class Transform;


//////////////////////////////////////////////////////////////////
// isotropic naming convenience 
//////////////////////////////////////////////////////////////////
  
enum Orientation2DEnum {
   /// HORZONTAL is the data value that represents HORIZONTAL orientation
   HORIZONTAL = 0,
   /// VERTICAL is the data value that represents VERTICAL orientation
   VERTICAL = 1
};
enum Direction2DEnum {
   /// WEST is the data value that represents WEST direction
   WEST = 0,
   /// EAST is the data value that represents EAST direction
   EAST = 1,
   /// SOUTH is the data value that represents SOUTH direction
   SOUTH = 2,
   /// NORTH is the data value that represents NORTH direction
   NORTH = 3
};
enum Direction1DEnum {
   /// LOW is the data value that represents LOW direction
   LOW = 0,
   /// HIGH is the data value that represents HIGH direction
   HIGH = 1,
   /// COUNTERCLOCKWISE is the data value that represents COUNTERCLOCKWISE direction
   COUNTERCLOCKWISE = 0,
   /// CLOCKWISE is the data value that represents CLOCKWISE direction
   CLOCKWISE = 1,
   /// REVERSE is the data value that represents REVERSE direction (typically of iteration)
   REVERSE = 0,
   /// FORWARD is the data value that represents FORWARD direction (typically of iteration)
   FORWARD = 1
};
enum Orientation3DEnum {
   /// PROXIMAL is the data value that represents PROXIMAL orientation
   PROXIMAL = 2
};
enum Direction3DEnum {
   /// DOWN is the data value that represents DOWN direction
   DOWN = 4,
   /// UP is the data value that represents UP direction
   UP = 5
};

//
// =================================================================
// CLASS: Direction2D
// =================================================================
// (class summary here)
// =================================================================
//
class Direction2D {
private:
  enum All2DDirections {
    WEST_2D = 0, BEGIN_DIRECTION_2D = 0,
    EAST_2D = 1,
    SOUTH_2D = 2,
    NORTH_2D = 3, END_DIRECTION_2D = 3
  };

  int val_;

  /// Private constructor
  /// Never use it, only for the very initial setup of the consts
  explicit Direction2D(int d);

public:

  Direction2D() { val_ = WEST_2D; }

  Direction2D(const Direction2D& that) : val_(that.val_) {}
  
  Direction2D(const Direction2DEnum val) : val_(val) {}

  const Direction2D& operator=(const Direction2D& d)
  {
    val_ = d.val_;
    return * this;
  }

  ~Direction2D() { }

  bool operator==(Direction2D d) const { return (val_ == d.val_); }
  bool operator!=(Direction2D d) const { return !((*this) == d); }
  bool operator< (Direction2D d) const { return (val_ < d.val_); }
  bool operator<=(Direction2D d) const { return (val_ <= d.val_); }
  bool operator> (Direction2D d) const { return (val_ > d.val_); }
  bool operator>=(Direction2D d) const { return (val_ >= d.val_); }

  /// Casting to int
  unsigned int toInt(void) const { return val_; }

  static unsigned int getMaxValue(void) { return (int)END_DIRECTION_2D; }

  /// Pre-increment operator ++d
  Direction2D& operator++();

  /// Post increment operator d++
  Direction2D operator++(int);

  /// Pre-decrement operator --d
  Direction2D& operator--();

  /// Post decrement operator  d--
  Direction2D operator--(int);

  Direction2D& transform(const AxisTransform& atr);

  Direction2D& transform(const Transform& tr);

  Direction2D backward() const;

  /// Returns a direction 90 degree left (LOW) or right(HIGH) to this one
  Direction2D turn(Direction1D t) const;

  /// Returns a direction 90 degree left to this one
  Direction2D left() const;

  /// Returns a direction 90 degree right to this one
  Direction2D right() const;

  /// N, E are positive, S, W are negative
  bool isPositive() const {return (val_ & 1);}
  bool isNegative() const {return !isPositive();}
  int getSign() const {return ((isPositive()) << 1) -1;}

  // casting operators
  operator Orientation2D() const;
  operator Direction1D() const;

  bool operator == (Orientation2D rs) const;
  //bool operator == (Direction3D rs) const;
  bool operator == (Orientation3D rs) const;

  bool operator != (Orientation2D rs) const;
  bool operator != (Direction3D rs) const;
  bool operator != (Orientation3D rs) const;


  // needed for static initializers
  static Direction2D north() {return Direction2D(NORTH_2D);}
  static Direction2D south() {return Direction2D(SOUTH_2D);}
  static Direction2D east()  {return Direction2D(EAST_2D);}
  static Direction2D west()  {return Direction2D(WEST_2D);}
  static Direction2D begin_direction() {return Direction2D(BEGIN_DIRECTION_2D);}
  static Direction2D end_direction2d() {return Direction2D(END_DIRECTION_2D);}
  static Direction2D begin() {return Direction2D(BEGIN_DIRECTION_2D);}
  static Direction2D end() {return Direction2D(END_DIRECTION_2D);}

  friend class Orientation2D;
  friend class AxisTransform;
  friend std::ostream& operator<<(std::ostream& o, Direction2D d);
  friend std::istream& operator>>(std::istream& i, Direction2D& d);
}; // end of class Direction2D


//
// =================================================================
// CLASS: Direction3D
// =================================================================
// (class summary here)
// =================================================================
//

class Direction3D {
private:
  enum All3DDirections {
    WEST_3D = 0, BEGIN_DIRECTION_3D = 0,
    EAST_3D = 1,
    SOUTH_3D = 2,
    NORTH_3D = 3,
    DOWN_3D = 4, BEGIN_PROXIMAL_3D = 4,
    UP_3D = 5, END_DIRECTION_3D = 5
  };

  int val_;

  /// Private constructor
  ///  Never use it, only for the very initial setup of the consts
  explicit Direction3D(int d);

public:

  Direction3D() { val_ = WEST_3D; }

  Direction3D(const Direction2D& that) { val_ = that.toInt(); }

  Direction3D(const Direction3D& that) : val_(that.val_) {}

  Direction3D(const Direction2DEnum val) : val_(val) {}

  Direction3D(const Direction3DEnum val) : val_(val) {}

  const Direction3D& operator=(const Direction3D& d)
  {
    val_ = d.val_;
    return * this;
  }

  ~Direction3D() { }

  bool operator==(Direction3D d) const { return (val_ == d.val_); }
  bool operator!=(Direction3D d) const { return !((*this) == d); }
  bool operator< (Direction3D d) const { return (val_ < d.val_); }
  bool operator<=(Direction3D d) const { return (val_ <= d.val_); }
  bool operator> (Direction3D d) const { return (val_ > d.val_); }
  bool operator>=(Direction3D d) const { return (val_ >= d.val_); }

  /// Casting to int
  unsigned int toInt(void) const { return val_; }

  static unsigned int getMaxValue(void) { return (int)END_DIRECTION_3D; }

  /// Pre-increment operator ++d
  Direction3D& operator++();

  /// Post increment operator d++
  Direction3D operator++(int);

  /// Pre-decrement operator --d
  Direction3D& operator--();

  /// Post decrement operator  d--
  Direction3D operator--(int);

  Direction3D& transform(const AxisTransform& atr);

  Direction3D& transform(const Transform& tr);

  Direction3D backward() const;

  bool isProximal() const { return (val_ >= (int)BEGIN_PROXIMAL_3D); }

  bool isPlanar() const { return (!isProximal()); }

  bool is2D() const { return isPlanar(); }

  /// N, E, U are positive, S, W, D are negative
  bool isPositive() const {return (val_ & 1);}
  bool isNegative() const {return !isPositive();}
  int getSign() const {return ((isPositive()) << 1) -1;}

  /// casting operators
  operator Orientation3D() const;
  operator Direction1D() const;

  bool operator == (Orientation3D rs) const;

  bool operator != (Orientation3D rs) const;


  // needed for static initializers
  static Direction3D up() {return Direction3D(UP_3D);}
  static Direction3D down() {return Direction3D(DOWN_3D);}
  static Direction3D end_direction3d() {return Direction3D(END_DIRECTION_3D);}
  static Direction3D begin() {return Direction3D(BEGIN_DIRECTION_3D);}
  static Direction3D end() {return Direction3D(END_DIRECTION_3D);}

  friend class AxisTransform;
  friend class Orientation3D;
  friend std::ostream& operator<<(std::ostream& o, Direction3D d);
  friend std::istream& operator>>(std::istream& i, Direction3D& d);
}; // end of class Direction3D

//
// =================================================================
// CLASS: Direction1D
// =================================================================
// (class summary here)
// =================================================================
//
class Direction1D {
private:
  enum All1DDirections {
    LOW_1D = 0, BEGIN_DIRECTION_1D = 0,
    HIGH_1D = 1, END_DIRECTION_1D = 1
  };

  int val_;

  // Private constructor
  ///  Never use it, only for the very initial setup of the consts
  explicit Direction1D(int d);
public:

  Direction1D() { val_ = LOW_1D; }

  Direction1D(const Direction1D& that) : val_(that.val_) {}

  Direction1D(const Direction1DEnum val) : val_(val) {}

  const Direction1D& operator = (const Direction1D& d)
  {
    val_ = d.val_;
    return * this;
  }

  ~Direction1D() { }

  bool operator==(Direction1D d) const { return (val_ == d.val_); }
  bool operator!=(Direction1D d) const { return !((*this) == d); }
  bool operator< (Direction1D d) const { return (val_ < d.val_); }
  bool operator<=(Direction1D d) const { return (val_ <= d.val_); }
  bool operator> (Direction1D d) const { return (val_ > d.val_); }
  bool operator>=(Direction1D d) const { return (val_ >= d.val_); }

  /// Casting to int
  unsigned int toInt(void) const { return val_; }

  static unsigned int getMaxValue(void) { return (int)END_DIRECTION_1D; }

  /// Pre-increment operator ++d
  Direction1D& operator++();

  /// Post increment operator d++
  Direction1D operator++(int);

  /// Pre-decrement operator --d
  Direction1D& operator--();

  /// Post decrement operator  d--
  Direction1D operator--(int);

  Direction1D backward() const;

  bool isPositive() const {return (val_);}
  bool isNegative() const {return !isPositive();}
  int getSign() const {return ((isPositive()) << 1) -1;}

  // needed for static initializers
  static Direction1D low()  {return Direction1D(LOW_1D);}
  static Direction1D high() {return Direction1D(HIGH_1D);}
  static Direction1D begin_direction() {return Direction1D(BEGIN_DIRECTION_1D);}
  static Direction1D end_direction()   {return Direction1D(END_DIRECTION_1D);}
  static Direction1D begin() {return begin_direction();}
  static Direction1D end()   {return end_direction();}

  friend class Direction2D;
#ifndef SWIG
  friend Direction2D::operator Direction1D() const;
  friend Direction3D::operator Direction1D() const;
#endif
  friend std::ostream& operator<<(std::ostream& o, Direction1D d);
  friend std::istream& operator>>(std::istream& i, Direction1D& d);
}; // end of class Direction1D

//
// =================================================================
// CLASS: Orientation
// =================================================================
// (class summary here)
// =================================================================
//

class Orientation2D {
private:
  enum All2DOrientations {
    HORIZONTAL_O = 0, BEGIN_ORIENTATION_2D = 0,
    VERTICAL_O   = 1, END_ORIENTATION_2D = 1
  };

  int val_;

  /// Private constructor
  ///  Never use it, only for the very initial setup of the consts
  explicit Orientation2D(int o);

public:

  Orientation2D() : val_(HORIZONTAL_O) {}

  Orientation2D(const Orientation2D& ori) : val_(ori.val_) {}

  Orientation2D(const Direction2D& dir) { val_ = dir.toInt() >> 1; }

  Orientation2D(const Orientation2DEnum val) : val_(val) {}

  ~Orientation2D() { }

  const Orientation2D& operator=(const Orientation2D& ori)
  {
    val_ = ori.val_;
    return * this;
  }

  bool operator==(Orientation2D that) const { return (val_ == that.val_); }
  bool operator!=(Orientation2D that) const { return (val_ != that.val_); }

  /// casting to int for array indexing
  unsigned int toInt() const { return (unsigned int)(val_); }

  static unsigned int getMaxValue(void) { return (int)END_ORIENTATION_2D; }

  /// Pre-increment operator ++o
  Orientation2D& operator++();

  /// Post increment operator o++
  Orientation2D operator++(int);

  Orientation2D& operator--();

  Orientation2D operator--(int);
    
  /// Changes self to perpendicular orientation
  void turn90();

  /// Returns perpendicular orientation
  Orientation2D getPerpendicular(void) const;

  /// Sets self to horizontal
  void setToHorizontal() { val_ = (int)HORIZONTAL_O; }

  /// Sets self to vertical
  void setToVertical() { val_ = (int)VERTICAL_O; }

  Direction2D getNegativeDirection(void) const ;

  Direction2D getPositiveDirection(void) const ;

  Direction2D getDirection(Direction1D dir) const ;

  bool isHorizontal() const { return (val_ == (int)HORIZONTAL_O); }

  bool isVertical() const { return (val_ == (int)VERTICAL_O); }

  Orientation2D& transform(const AxisTransform& atr); 

  Orientation2D& transform(const Transform& tr);

#ifndef SWIG
  friend Direction2D::operator Orientation2D() const;
#endif

  // casting operators
  operator Orientation3D() const;

   //bool operator == (Orientation3D rs) const;

  bool operator != (Orientation3D rs) const;

  // needed for static initializers
  static Orientation2D horizontal() { return Orientation2D(HORIZONTAL_O); }
  static Orientation2D vertical()   { return Orientation2D(VERTICAL_O); }
  static Orientation2D begin_orientation() { return Orientation2D(BEGIN_ORIENTATION_2D); }
  static Orientation2D end_orientation2D() { return Orientation2D(END_ORIENTATION_2D); }
  static Orientation2D begin() { return Orientation2D(BEGIN_ORIENTATION_2D); }
  static Orientation2D end() { return Orientation2D(END_ORIENTATION_2D); }

  friend std::ostream& operator<<(std::ostream& o, Orientation2D orient);
  friend std::istream& operator>>(std::istream& i, Orientation2D& orient);
}; // end of class Orientation2D


class Orientation3D {
private:
  enum All3DOrientations {
    HORIZONTAL_O = 0, BEGIN_ORIENTATION_3D = 0,
    VERTICAL_O   = 1,
    PROXIMAL_O   = 2, END_ORIENTATION_3D   = 2
  };

  int val_;

  /// Private constructor
  ///  Never use it, only for the very initial setup of the consts
  explicit Orientation3D(int o);

public:

  Orientation3D() : val_((int)HORIZONTAL_O) {}

  Orientation3D(const Orientation3D& ori) : val_(ori.val_) {}

  Orientation3D(const Direction3D& dir) { val_ = dir.toInt() >> 1; }

  Orientation3D(const Orientation2DEnum val) : val_(val) {}

  Orientation3D(const Orientation3DEnum val) : val_(val) {}

  ~Orientation3D() {  }

  const Orientation3D& operator=(const Orientation3D& ori)
  {
    val_ = ori.val_;
    return * this;
  }

  bool operator==(Orientation3D that) const { return (val_ == that.val_); }
  bool operator!=(Orientation3D that) const { return (val_ != that.val_); }

  /// casting to int for array indexing
  unsigned int toInt() const { return (unsigned int)(val_); }

  static unsigned int getMaxValue(void) { return (int)END_ORIENTATION_3D; }

  /// Pre-increment operator ++o
  Orientation3D& operator++();

  /// Post increment operator o++
  Orientation3D operator++(int);

  Orientation3D& operator--();

  Orientation3D operator--(int);

  /// Sets self to horizontal
  void setToHorizontal() { val_ = (int)HORIZONTAL_O; }

  /// Sets self to vertical
  void setToVertical() { val_ = (int)VERTICAL_O; }

  /// Sets self to proximal
  void setToProximal() { val_ = (int)PROXIMAL_O; }

  bool isHorizontal() const { return (val_ == (int)HORIZONTAL_O); }

  bool isVertical() const { return (val_ == (int)VERTICAL_O); }

  bool isProximal() const { return (val_ == (int)PROXIMAL_O); }

  bool isPlanar() const { return (val_ == (int)HORIZONTAL_O || val_ == (int)VERTICAL_O); }

  bool is2D() const { return isPlanar(); }

  Direction3D getNegativeDirection(void) const {
    return getDirection(Direction1D::low());
  }
  
  Direction3D getPositiveDirection(void) const {
     return getDirection(Direction1D::high());
  }
  
  Direction3D getDirection(Direction1D dir) const ;

  Orientation3D getNormal(Orientation3D orient) const ;

  void getNormalPlane(Orientation3D& o1, Orientation3D& o2) const ;

  Orientation3D& transform(const AxisTransform& atr) ;

  Orientation3D& transform(const Transform& tr) ;

  // needed for static initializers
  static Orientation3D proximal() { return Orientation3D(PROXIMAL_O); }
  static Orientation3D end_orientation3D() {  return Orientation3D(END_ORIENTATION_3D); }
  static Orientation3D begin() {  return Orientation3D(BEGIN_ORIENTATION_3D); }
  static Orientation3D end() {  return Orientation3D(END_ORIENTATION_3D); }

#ifndef SWIG
  friend Direction3D::operator   Orientation3D() const;
  friend Orientation2D::operator Orientation3D() const;
#endif
  friend std::ostream& operator<<(std::ostream& o, Orientation3D orient);
  friend std::istream& operator>>(std::istream& i, Orientation3D& orient);
}; // end of class Orientation3D


class DirectionOps {
private:
  // purely static class
  DirectionOps();
  DirectionOps(const DirectionOps & rs);
  DirectionOps & operator = (const DirectionOps & rs);
  ~DirectionOps();

public:
  // convert 3D to 2D, no checks
  static inline Orientation2D convertTo2D (Orientation3D o) {
    return predicated_value(o.isHorizontal(), HORIZONTAL, VERTICAL);
  }

  static inline Direction2D convertTo2D (Direction3D d) {
    return convertTo2D((Orientation3D)d).getDirection(Direction1D(d));
  }

  // convert a bool to a Direction1D
  static inline Direction1D getDirection1D (bool b) {
    return predicated_value(b,HIGH,LOW);
  }
};

#define FOREACH_TYPE(T,d) \
for (T d = T::begin(), __FOREACH_TEMP = T::begin(); __FOREACH_TEMP != T::end(); __FOREACH_TEMP = d++)

#define foreach_Direction1D(d)   FOREACH_TYPE(Direction1D,d)
#define foreach_Direction2D(d)   FOREACH_TYPE(Direction2D,d)
#define foreach_Direction3D(d)   FOREACH_TYPE(Direction3D,d)
#define foreach_Orientation2D(d) FOREACH_TYPE(Orientation2D,d)
#define foreach_Orientation3D(d) FOREACH_TYPE(Orientation3D,d)

