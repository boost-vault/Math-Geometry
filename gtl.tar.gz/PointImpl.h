/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// PointImpl implements all Point functions on top of point type T

/// PointImpl inherits from point type T and accesses the data owned
/// by T through the PointInterface<T> class
template <class T>
class PointImpl : public T{
public:

  /// get a reference of PointImpl type given a data object
  static PointImpl& mimic(T& t) { return static_cast<PointImpl&>(t); }

  /// get a const reference of PointImpl type given a data object
  static const PointImpl& mimicConst(const T& t) { 
    return static_cast<const PointImpl&>(t); 
  }

  /// construct a point from x and y
  PointImpl(Unit x, Unit y) {
    *this = construct_(x, y);
  }

  /// default constructor
  PointImpl() {
    *this = construct_(UnitMin,
                       UnitMin);
  }

  /// assignment operator
  template <class T2>
  const PointImpl& operator=(const PointImpl<T2>& that);

  /// assignment operator
  const PointImpl& operator=(const PointImpl<T>& that);

  /// assignment operator
  const PointImpl& operator=(const T& that);

  /// copy constructor
  template <class T2>
  PointImpl(const PointImpl<T2>& that);

  /// copy constructor
  PointImpl(const T& that) : T(that) {;}

  /// equivalence operator
  template <class T2>
  bool operator==(const PointImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const PointImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const PointImpl<T2>& b) const; 

  /// comparison operator
  template <class T2>
  bool operator<=(const PointImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const PointImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const PointImpl<T2>& b) const { return !(*this < b); }

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// yield payload
  T& yield() { return *this; }

  /// check for validity
  bool isValid(void) const;

  /// addition operator (convolve two points)
  template <class T2>
  PointImpl& operator+=(const PointImpl<T2>& p);
    
  /// binary addtion operator (get the convolution of two points)
  template <class T2>
  PointImpl operator+(const PointImpl<T2>& p) const;
     
  /// subtraction operator (deconvolve two points)
  template <class T2>
  PointImpl& operator-=(const PointImpl<T2>& p);
    
  /// binary subtraction operator (get the deconvolution of two points)
  template <class T2>
  PointImpl operator-(const PointImpl<T2>& p) const;

  /// get x or y depending on orient
  Unit get(Orientation2D orient) const {return get_(orient);}

  /// set x or y depending on orient
  PointImpl& set(Orientation2D orient, Unit value);

  /// get x
  Unit x() const { return get(HORIZONTAL); }

  /// set x
  PointImpl& x(Unit value){ return set(HORIZONTAL, value); }

  /// get y
  Unit y() const { return get(VERTICAL); }

  /// set y
  PointImpl& y(Unit value){ return set(VERTICAL, value); }

  /// convolve this with b
  template <class T2>
  PointImpl& convolve(const PointImpl<T2>& p);

  /// deconvolve this with b
  template <class T2>
  PointImpl& deconvolve(const PointImpl<T2>& p);

  /// transform point
  PointImpl& transform(const AxisTransform& atr);
    
  /// transform point
  PointImpl& transform(const Transform& tr);

  /// scale point
  PointImpl& scaleUp(UnsignedUnit factor);
  PointImpl& scaleDown(UnsignedUnit factor);

  /// get the distance between 'this' and p along orientation orient
  template <class T2>
  UnsignedUnit distance(const PointImpl<T2>& p, 
                               Orientation2D orient) const;

  /// get the manhatton distance between 'this' and p 
  template <class T2>
  UnsignedUnit manhattanDistance(const PointImpl<T2>& p) const;

  /// get the square equclidian distance between 'this' and p 
  template <class T2>
  UnsignedLongUnit squareEuclidianDistance(const PointImpl<T2>& p) const;

  /// get the euclidian distance between 'this' and p
  template <class T2>
  double euclidianDistance(const PointImpl<T2>& p) const;

  /// set dir to the direction that p is from 'this' point
  /// if p has no coordinate in common with this, return false
  /// and leave dir unchanged
  template <class T2>
  bool toward(const PointImpl<T2>& p, Direction2D& dir) const;
    
  /// aligned means they are in a line on that orientation
  template <class T2>
  bool aligned(const PointImpl<T2>& p, 
                      Orientation2D orient) const;

  /// p is in direction dir from 'this' and aligned
  template <class T2>
  bool alignedAndToward(const PointImpl<T2>& p, Direction2D dir, 
                               bool considerTouch = true) const;

  /// get the sign of the cross product of p1, 'this' and p2
  template <class T2, class T3>
  int crossProduct(const PointImpl<T2>& p1, const PointImpl<T3>& p2) const;

  /// return true if 'this' is between p1 and p2 and they are all aligned
  template <class T2, class T3>
  bool between(const PointImpl<T2>& p1, const PointImpl<T3>& p2) const;

private:
  //private functions
  Unit get_(Orientation2D orient) const {
    return PointInterface<T>::PointGet(*this, orient);
  }

  void set_(Orientation2D orient, Unit value) {
    PointInterface<T>::PointSet(*this, orient, value);
  }

  static T construct_(Unit x, Unit y) {
    return PointInterface<T>::PointConstruct(x, y);
  }
};

// default point type
typedef PointImpl<PointData> Point;

template <class T>
std::ostream& operator<< (std::ostream& o, const PointImpl<T>& d);

template <class T>
std::istream& operator>> (std::istream& i, PointImpl<T>& d);

