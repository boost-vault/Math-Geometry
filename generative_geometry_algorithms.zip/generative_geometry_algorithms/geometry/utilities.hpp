//
//!  Copyright (c) 2008
//!  Brandon Kohn
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef _BOOST_GEOMETRY_UTILITIES_HPP
#define _BOOST_GEOMETRY_UTILITIES_HPP
#pragma once

#include "geometric_concepts.hpp"
#include "point_traits.hpp"
#include "number_comparison_policy.hpp"
#include "constants.hpp"
#include "math_functions.hpp"
#include <boost/utility.hpp>
#include <boost/numeric/conversion/cast.hpp>
#include <cmath>

namespace boost
{
namespace numeric
{
namespace geometry
{
	//! Function to get the angle from an origin to a target point in the 2D XY plane.
	template <typename Point>
    inline typename point_traits<Point>::coordinate_type angle_to_point( const Point& A, const Point& B, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0   )
	{
        typedef cartesian_access_traits< Point > access_traits;
        typedef typename point_traits< Point >::coordinate_type coordinate_type;
        return math_functions< coordinate_type >::atan2( access_traits::get_y( B ) - access_traits::get_y( A ), access_traits::get_x( B ) - access_traits::get_x( A ) );
	}

    //! Function to normalize an angle to within the interval [0,2*PI]
    template <typename CoordinateType>
    inline void normalize_angle( CoordinateType& angle )
    {
        //simplifies the angle to lay in the range of the interval 0 - 2*pi
        CoordinateType pi = constants<CoordinateType>::pi();        
        CoordinateType twoPI = CoordinateType( 2 ) * pi;
        if ( angle > twoPI || angle < CoordinateType( 0 ) )
        {
            CoordinateType n = math_functions<CoordinateType>::floor( angle / twoPI );
            if ( n != CoordinateType( 0 ) )
                angle -= twoPI * n;
            if ( angle > twoPI )
		        angle -= twoPI;
	        else if ( angle < CoordinateType( 0 ) )
                angle += twoPI;            
        }
    }

	//! Function to computer the squared distance between two points in the 2D XY plane.
	template <typename Point>
	inline typename point_traits<Point>::coordinate_type distance_to_point_squared( const Point& A, const Point& B, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
	{
        typedef cartesian_access_traits< Point > access_traits;
		typename point_traits<Point>::coordinate_type dx = access_traits::get_x( B ) - access_traits::get_x( A );
		typename point_traits<Point>::coordinate_type dy = access_traits::get_y( B ) - access_traits::get_y( A );
		return ( dx * dx + dy * dy );		
	}

	//! Function to computer the squared distance between two points in the 2D XY plane.
	template <typename Point>
	inline typename point_traits<Point>::coordinate_type distance_to_point( const Point& A, const Point& B, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
	{
        typedef cartesian_access_traits< Point > access_traits;        
        typedef typename point_traits< Point >::coordinate_type coordinate_type;
		coordinate_type dx = access_traits::get_x( B ) - access_traits::get_x( A );
		coordinate_type dy = access_traits::get_y( B ) - access_traits::get_y( A );
        return math_functions< coordinate_type >::sqrt( dx * dx + dy * dy );		
	}

    //! Function to determine if two points are equal to within tolerance.
    template <typename NumberComparisonPolicy, typename Point>
    inline bool equals( const Point& A, const Point& B, const NumberComparisonPolicy& compare, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
    {        
        typedef cartesian_access_traits< Point > access_traits;                
        return compare.equals( access_traits::get_x( A ), access_traits::get_x( B ) ) && compare.equals( access_traits::get_y( A ), access_traits::get_y( B ) );
    }

	//! Function to determine if 3 points are collinear in the 2D XY plane.
	//! From Computational Geometry in C by J. O'Rourke.
	template <typename NumberComparisonPolicy, typename Point>
	inline bool is_collinear( const Point& A, const Point& B, const Point& C, const NumberComparisonPolicy& compare, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
	{
        typedef cartesian_access_traits< Point > access_traits;        
    	typename point_traits<Point>::coordinate_type det = cross_product( A, B, C );
        typename point_traits<Point>::coordinate_type zero = 0;
		return compare.equals( det, zero );//Absolute tolerance checks are fine for Zero checks.
	}

	//! Function to determine if Point C is between points A-B
	//! From Computational Geometry in C by J. O'Rourke.
	template <typename NumberComparisonPolicy, typename Point>
	bool is_between( const Point& A, const Point& B, const Point& C, bool includeBounds, const NumberComparisonPolicy& compare, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
	{
        typedef cartesian_access_traits< Point >        access_traits;        
        typedef typename access_traits::coordinate_type coordinate_type;
        boost::function_requires< NumberComparisonPolicyConcept<NumberComparisonPolicy, coordinate_type > >();

		if( !is_collinear( A, B, C, compare ) )
		{
			return false;
		}

		//If AB not vertical, check between on x; else on y.
        bool ABVertical = compare.equals( access_traits::get_x( A ), access_traits::get_x( B ) );
		if( !ABVertical )
		{
			if(includeBounds)
			{
				return ( compare.less_than_or_equals( access_traits::get_x( A ), access_traits::get_x( C ) ) && compare.less_than_or_equals( access_traits::get_x( C ), access_traits::get_x( B ) ) ||
						 compare.greater_than_or_equals( access_traits::get_x( A ), access_traits::get_x( C ) ) && compare.greater_than_or_equals( access_traits::get_x( C ), access_traits::get_x( B ) ) );
			}
			else
			{
				return ( compare.less_than( access_traits::get_x( A ), access_traits::get_x( C ) ) && compare.less_than( access_traits::get_x( C ), access_traits::get_x( B ) ) ||
						 compare.greater_than( access_traits::get_x( A ), access_traits::get_x( C ) ) && compare.greater_than( access_traits::get_x( C ), access_traits::get_x( B ) ) );
			}
		}
		else
		{
			if(includeBounds)
			{
				return ( compare.less_than_or_equals( access_traits::get_y( A ), access_traits::get_y( C ) ) && compare.less_than_or_equals( access_traits::get_y( C ), access_traits::get_y( B ) ) ||
				 		 compare.greater_than_or_equals( access_traits::get_y( A ), access_traits::get_y( C ) ) && compare.greater_than_or_equals( access_traits::get_y( C ), access_traits::get_y( B ) ) );
			}
			else
			{
				return ( compare.less_than( access_traits::get_y( A ), access_traits::get_y( C ) ) && compare.less_than( access_traits::get_y( C ), access_traits::get_y( B ) ) ||
				         compare.greater_than( access_traits::get_y( A ), access_traits::get_y( C ) ) && compare.greater_than( access_traits::get_y( C ), access_traits::get_y( B ) ) );
			}
		}
	}

    //! Orientation test to check if point C is left, collinear, or right of the line formed by A-B.
    enum orientation_type
    {
        oriented_right     = -1,
        oriented_collinear = 0,
        oriented_left      = 1
    };
    template <typename NumberComparisonPolicy, typename Point>
    orientation_type get_orientation( const Point& A, const Point& B, const Point& C, const NumberComparisonPolicy& compare )
    {
        typename point_traits<Point>::coordinate_type cross = cross_product( A, B, C );
        typename point_traits<Point>::coordinate_type zero = 0;
        if( compare.less_than( cross, zero ) )
        {
            return oriented_right;
        }
        else if( compare.greater_than( cross, zero ) )
        {
            return oriented_left;
        }
        else
        {
            return oriented_collinear;
        }
    }

    template <typename Point, typename NumberComparisonPolicy>
    inline bool is_vertical( const Point& start, const Point& end, const NumberComparisonPolicy& compare )
    {
        return compare.equals( cartesian_access_traits< Point >::get_x( start ), cartesian_access_traits< Point >::get_x( end ) );
    }

    template <typename Segment, typename NumberComparisonPolicy>
    inline bool is_vertical( const Segment& s,const NumberComparisonPolicy& compare )
    {
        return is_vertical( segment_access_traits< Segment >::get_start( s ), segment_access_traits< Segment >::get_end( s ), compare );
    }

    template <typename Point, typename NumberComparisonPolicy>
    inline bool is_horizontal( const Point& start, const Point& end, const NumberComparisonPolicy& compare )
    {
        return compare.equals( cartesian_access_traits< Point >::get_y( start ), cartesian_access_traits< Point >::get_y( end ) );
    }

    template <typename Segment, typename NumberComparisonPolicy>
    inline bool is_horizontal( const Segment& s,const NumberComparisonPolicy& compare )
    {
        return is_horizontal( segment_access_traits< Segment >::get_start( s ), segment_access_traits< Segment >::get_end( s ), compare );
    }

    //! Given two points which define a (non-vertical) line segment and a coordinate X calculate Y and the slope.
    template <typename Point, typename CoordinateType, typename NumberComparisonPolicy>
    inline CoordinateType y_of_x( const Point& s_start, const Point& s_end, CoordinateType x, CoordinateType& slope, const NumberComparisonPolicy& compare )
    {
        typedef Point point_type;        
        CoordinateType y0, y1, x0, x1;

        x0 = cartesian_access_traits< point_type >::get_x( s_start );
        x1 = cartesian_access_traits< point_type >::get_x( s_end );
        y0 = cartesian_access_traits< point_type >::get_y( s_start );
        y1 = cartesian_access_traits< point_type >::get_y( s_end );

        slope = (y1-y0)/(x1-x0);

        CoordinateType y = (x - x0)*slope + y0;
        
        return y;
    }

    //! Given two points which define a (non-vertical) line segment and a coordinate X calculate Y and the slope.
    template <typename Point, typename CoordinateType, typename NumberComparisonPolicy>
    inline CoordinateType y_of_x( const Point& s_start, const Point& s_end, CoordinateType x, const NumberComparisonPolicy& compare )
    {
        CoordinateType slope;
        return y_of_x( s_start, s_end, x, slope, compare );
    }

    //! Given two points which define a (non-vertical) line segment and a coordinate X calculate Y and the slope.
    template <typename Point, typename CoordinateType, typename NumberComparisonPolicy>
    inline CoordinateType x_of_y( const Point& s_start, const Point& s_end, CoordinateType y, CoordinateType& slope, const NumberComparisonPolicy& compare )
    {
        typedef Point point_type;
        CoordinateType y0, y1, x0, x1;

        x0 = cartesian_access_traits< point_type >::get_x( s_start );
        x1 = cartesian_access_traits< point_type >::get_x( s_end );
        y0 = cartesian_access_traits< point_type >::get_y( s_start );
        y1 = cartesian_access_traits< point_type >::get_y( s_end );
        
        slope = (y1-y0)/(x1-x0);

        CoordinateType x = (y - y0)/slope + x0;     
        assert( compare.equals( y, y_of_x( s_start, s_end, x, compare )  ) );

        return x;
    }

    //! Given two points which define a (non-vertical) line segment and a coordinate X calculate Y and the slope.
    template <typename Point, typename CoordinateType, typename NumberComparisonPolicy>
    inline CoordinateType x_of_y( const Point& s_start, const Point& s_end, CoordinateType y, const NumberComparisonPolicy& compare )
    {
        CoordinateType slope;
        return x_of_y( s_start, s_end, y, slope, compare  );
    }

    //! Lexicographical compare functor for Cartesian points. Sorts first in X and then in Y (then Z).
    template <typename AccessTraits, typename NumberComparisonPolicy>
    struct lexicographical_compare
    {
        typedef typename AccessTraits::coordinate_type coordinate_type;
        BOOST_CLASS_REQUIRE2( NumberComparisonPolicy, coordinate_type, boost::numeric::geometry, NumberComparisonPolicyConcept );

        lexicographical_compare(){}
        lexicographical_compare( const NumberComparisonPolicy& compare )
            : m_compare( compare )
        {}

        //! older compilers require disambiguation
        template <int> struct disambiguation_tag { disambiguation_tag(int) {} };

        template <typename Point>
        bool operator()( const Point& p1, const Point& p2, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0, disambiguation_tag<0> = 0 ) const
        {
            typedef AccessTraits access;
            return ( m_compare.less_than( access::get_x( p1 ), access::get_x( p2 ) ) ) ||
                   ( m_compare.equals( access::get_x( p1 ), access::get_x( p2 ) ) && m_compare.less_than( access::get_y( p1 ), access::get_y( p2 ) ) );
        }

        template <typename Point>
        bool operator()( const Point& p1, const Point& p2, typename boost::disable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0, disambiguation_tag<1> = 0 ) const
        {
            typedef AccessTraits access;
            return ( m_compare.less_than( access::get_x( p1 ), access::get_x( p2 ) ) )||
                   ( m_compare.equals( access::get_x( p1 ), access::get_x( p2 ) ) && m_compare.less_than( access::get_y( p1 ), access::get_y( p2 ) ) ) ||
                   ( m_compare.equals( access::get_x( p1 ), access::get_x( p2 ) ) && m_compare.equals( access::get_y( p1 ), access::get_y( p2 ) ) && m_compare.less_than( access::get_z( p1 ), access::get_z( p2 ) ) );
        }

        NumberComparisonPolicy m_compare;

    };

    //! Lexicographical compare functor for Cartesian points - reversed to sort in (Z), then Y then X.
    template <typename AccessTraits, typename NumberComparisonPolicy>
    struct reverse_lexicographical_compare
    {
        typedef typename AccessTraits::coordinate_type coordinate_type;
        BOOST_CLASS_REQUIRE2( NumberComparisonPolicy, coordinate_type, boost::numeric::geometry, NumberComparisonPolicyConcept );

        reverse_lexicographical_compare(){}
        reverse_lexicographical_compare( const NumberComparisonPolicy& compare )
            : m_compare( compare )
        {}

        //! older compilers require disambiguation
        template <int> struct disambiguation_tag { disambiguation_tag(int) {} };

        template <typename Point>
        bool operator()( const Point& p1, const Point& p2, typename boost::enable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0, disambiguation_tag<0> = 0 ) const
        {
            typedef AccessTraits access;
            return ( m_compare.less_than( access::get_y( p1 ), access::get_y( p2 ) ) ) ||
                   ( m_compare.equals( access::get_y( p1 ), access::get_y( p2 ) ) && m_compare.less_than( access::get_x( p1 ), access::get_x( p2 ) ) );
        }

        template <typename Point>
        bool operator()( const Point& p1, const Point& p2, typename boost::disable_if< boost::is_same< typename point_traits<Point>::dimension_type, dimension_tag<2> > >::type* dummy = 0, disambiguation_tag<1> = 0 ) const
        {
            typedef AccessTraits access;
            return ( m_compare.less_than( access::get_z( p1 ), access::get_z( p2 ) ) )||
                   ( m_compare.equals( access::get_z( p1 ), access::get_z( p2 ) ) && m_compare.less_than( access::get_y( p1 ), access::get_y( p2 ) ) ) ||
                   ( m_compare.equals( access::get_z( p1 ), access::get_z( p2 ) ) && m_compare.equals( access::get_y( p1 ), access::get_y( p2 ) ) && m_compare.less_than( access::get_x( p1 ), access::get_x( p2 ) ) );
        }

        NumberComparisonPolicy m_compare;

    };

}}}//namespace boost::numeric::geometry;

#endif //_BOOST_GEOMETRY_UTILITIES_HPP
