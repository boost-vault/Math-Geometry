#pragma once

class CLineSimplifierDlg;

// CCanvas
class CCanvas : public CStatic
{
	DECLARE_DYNAMIC(CCanvas)

	CLineSimplifierDlg* GetDlg();

	PointVector& Points();
	PointVector& Simp();

protected:
	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
};
