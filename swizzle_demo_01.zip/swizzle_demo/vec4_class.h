#ifndef VEC4_CLASS_H
#define VEC4_CLASS_H

#include "permutation.h"
#include "boost/static_assert.hpp"
#include "boost/type_traits.hpp"

namespace blas
{

template <typename X, typename Y = X, typename Z = Y, typename W = Z>
struct vec4
{
	typedef vec4 &reference;
	typedef vec4 const &const_reference;
	typedef X x_type;
	typedef Y y_type;
	typedef Z z_type;
	typedef W w_type;

	x_type x;
	y_type y;
	z_type z;
	w_type w;

	vec4() { }
	vec4(x_type vx, y_type vy, x_type vz, x_type vw) : x(vx), y(vy), z(vz), w(vw) { }

	template <typename T>
	explicit vec4(T d) : x(d), y(d), z(d), w(d) { }

	template <typename VX, typename VY, typename VZ>
	vec4(const vec3<VX, VY, VZ> &v, w_type vw) : x(v.x), y(v.y), z(v.z), w(vw) { }

	template <typename VX, typename VY, typename VZ, typename VW>
	vec4(const vec4<VX, VY, VZ, VW> &v) : x(v.x), y(v.y), z(v.z), w(v.w) { }

	template <typename VX, typename VY, typename VZ, typename VW>
	reference operator=(const vec4<VX, VY, VZ, VW> &v)
	{
		x = v.x;
		y = v.y;
		z = v.z;
		w = v.w;
		return *this;
	}

	typename boost::remove_reference<X>::type &operator[](size_t idx)
	{
		assert(idx < 4);
		return array()[idx];
	}

	BLAS_DECLARE_SWIZZLE(BLAS_VEC4D_SEQ)

	// array will only be enabled if x_type == y_type == z_type == w_type
	typename boost::remove_reference<X>::type *array(void)
	{
		BOOST_STATIC_ASSERT((boost::is_reference<X>::value == false));
		BOOST_STATIC_ASSERT((boost::is_reference<Y>::value == false));
		BOOST_STATIC_ASSERT((boost::is_reference<Z>::value == false));
		BOOST_STATIC_ASSERT((boost::is_reference<W>::value == false));
		BOOST_STATIC_ASSERT((boost::is_same<X, Y>::value));
		BOOST_STATIC_ASSERT((boost::is_same<Y, Z>::value));
		BOOST_STATIC_ASSERT((boost::is_same<Z, W>::value));
		return static_cast<X *>(&x);
	}
	typename boost::remove_reference<X>::type const *array(void) const
	{
		return const_cast<vec4 *>(this)->array();
	}
};

template <typename X, typename Y, typename Z, typename W>
inline std::ostream &operator<<(std::ostream &os, const vec4<X, Y, Z, W> &v)
{
	os << "[" << v.x << ", " << v.y << ", " << v.z << ", " << v.w << "]";
	return os;
}

typedef vec4<float> vec4f;
typedef vec4<double> vec4d;
typedef vec4f float4;
typedef vec4d double4;

BOOST_STATIC_ASSERT(sizeof(float4) == sizeof(float) * 4);
BOOST_STATIC_ASSERT(sizeof(double4) == sizeof(double) * 4);

}

#endif
