/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Segment3DImpl implements Segment3D functions on top of 3D segment type T

/// Segment3DImpl inherits from 3D segment type T and accesses the data owned
/// by T through the Segment3DInterface<T> class
template <class T>
class Segment3DImpl : public T {
public:

  /// get a reference of Segment3DImpl type given a data object
  static Segment3DImpl& mimic(T& t) { return static_cast<Segment3DImpl&>(t); }

  /// get a const reference of SegmentImpl type given a data object
  static const Segment3DImpl& mimicConst(const T& t) { 
    return static_cast<const Segment3DImpl&>(t); 
  }

  /// construct a 3D segment from low end point p, orientation and length
  template <class T2>
  Segment3DImpl(const Point3DImpl<T2>& p, 
                       Orientation3D orient,
                       UnsignedUnit length);

  /// default constructor
  Segment3DImpl();

  /// assignment operator
  template <class T2>
  const Segment3DImpl& operator=(const Segment3DImpl<T2>& that){
    setOrient(that.getOrient()); low(that.low()); high(that.high());
  }

  /// assignment operator
  const Segment3DImpl& operator=(const Segment3DImpl& that);

  /// assignment operator
  const Segment3DImpl& operator=(const T& that);

  /// copy constructor
  template <class T2>
  Segment3DImpl(const Segment3DImpl<T2>& that) {*this = that;}
     
  /// copy constructor
  Segment3DImpl(const T& that) : T(that) {;}

  /// equivalence operator
  template <class T2>
  bool operator==(const Segment3DImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const Segment3DImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const Segment3DImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<=(const Segment3DImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const Segment3DImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const Segment3DImpl<T2>& b) const { return !(*this < b); }

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }

  /// conversion to interval
  operator IntervalImpl<IntervalData>() const;
     
  /// yield payload
  T& yield() { return *this; }
     
  /// return a reference to 'this' IntervalImpl<T>
  IntervalImpl<T>& mimicInterval();

  /// return a const reference to 'this' IntervalImpl<T>
  const IntervalImpl<T>& mimicConstInterval() const;

  /// get the end point correspoinding to direction dir
  Point3DImpl<Point3DData> get(Direction1D dir) const;

  /// get the low end point
  Point3DImpl<Point3DData> low() const;

  /// get the high end point
  Point3DImpl<Point3DData> high() const;

  /// set the end point correspoinding to direction dir to value
  template <class T2>
  Segment3DImpl& set(Direction1D dir,
                            const Point3DImpl<T2>& value);
    
  /// set the low end point to value
  template <class T2>
  Segment3DImpl& low(const Point3DImpl<T2>& value);

  /// set the high end point to value
  template <class T2>
  Segment3DImpl& high(const Point3DImpl<T2>& value);
    
  /// get the orientation
  Orientation3D getOrient() const;

  /// set the orientation, low end point is unchanged
  Segment3DImpl& setOrient(Orientation3D orient);

  /// get the length
  UnsignedUnit getLength() const;

  /// set the length, low end point is unchanged
  Segment3DImpl& setLength(UnsignedUnit value);

  /// get the point in the place perpendicular to the segment
  PointImpl<PointData> getMajor() const;

  /// translate the segment3D in the plane perpendicular to its orientation
  template <class T2>
  Segment3DImpl& setMajor(const PointImpl<T2>& value);
    
  /// Is the T valid
  bool isValid() const;

  /// transform segment
  Segment3DImpl& transform(const AxisTransform& atr);
    
  /// transform segment
  Segment3DImpl& transform(const Transform& tr);

  /// get the length of the segment
  UnsignedUnit delta() const;

  /// get the length of the segment in the orientation orient
  UnsignedUnit delta(const Orientation3D orient) const;

  /// check if Segment b is inside `this` Segment
  template <class T2>
  bool contains(const Segment3DImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if a point is contained inside 'this'
  template <class T2>
  bool contains(const Point3DImpl<T2>& p, 
                       bool considerTouch = true) const;

  /// check if a point p is colinear to 'this'
  template <class T2>
  bool colinear(const Point3DImpl<T2>& p) const;

  /// check if a segment b is colinear to 'this'
  template <class T2>
  bool colinear(const Segment3DImpl<T2>& b) const;

  /// check if a segment b is perpendicular to 'this'
  template <class T2>
  bool perpendicular(const Segment3DImpl<T2>& b) const;

  SegmentImpl<SegmentData> 
  projectInPlane(Orientation3D o1, Orientation3D o2) const;

  /// check if a segment b crosses to 'this'
  template <class T2>
  bool crosses(const Segment3DImpl<T2>& b, 
                      bool considerTouch = true) const;

  /// check if `this` Segment is inside specified Segment b
  //  [in]     b         T that will be checked
  //  [in]     considerTouch true, return true even if `t` touches the boundary
  //  [ret]    .         true if `t` is inside b
  template <class T2>
  bool inside(const Segment3DImpl<T2>& b, 
                     bool considerTouch = true) const;

  /// check if Segment b intersects `this` Segment
  //  [in]     b         Segment3D that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` intersects b
  template <class T2>
  bool intersects(const Segment3DImpl<T2>& b, 
                         bool considerTouch = true) const;

  /// check if b partially overlaps 'this' Segment
  //  [in]     b         Segment3D that will be checked
  //  [in]     considerTouch If true, return true even if p is on the foundary
  //  [ret]    .         true if `t` contains p
  template <class T2>
  bool boundariesIntersect(const Segment3DImpl<T2>& b, 
                                  bool considerTouch = true) const;
    
  /// check if b abutts 'this' Segment's end specified by dir
  template <class T2>
  bool abuts(const Segment3DImpl<T2>& b, Direction1D dir) const;

  /// check if b abutts 'this' Segment
  template <class T2>
  bool abuts(const Segment3DImpl<T2>& b) const;

  /// set 'this' segment to its intersection with Segment b 
  //  [in]   b         The intersecting Segment3D
  //  [in]   considerTouch If true, will clip to a single line if appropriate
  template <class T2>
  bool intersect(const Segment3DImpl<T2>& b, bool considerTouch = true);

  /// set `this` Segment to the intersection between b1 and b2
  //  [in]     b1        The two Segment3D to examine
  //  [in]     b2
  //  [in]     considerTouch If true, create intersection even if b1 touches b2
  //  [ret]    .         true if boxes intersect, else `t` is set to b1
  template <class T2, class T3>
  bool intersection(const Segment3DImpl<T2>& b1, const Segment3DImpl<T3>& b2,
                           bool considerTouch = true);

  /// bloat the Segment
  //  [in]     bloating  Positive value to bloat each coordinate
  Segment3DImpl& bloat(UnsignedUnit bloating);

  /// bloat the specified side of `this` Segment
  //  [in]     bloating  Positive value to bloat the Segment3D
  //  [in]     o         The orientation to be bloated
  Segment3DImpl& bloat(Direction1D dir, UnsignedUnit bloating);

  /// shrink the Segment
  //  [in]     shrinking Positive value to shrink each coordinate
  Segment3DImpl& shrink(UnsignedUnit shrinking);

  /// shrink the specified side of `this` Segment
  //  [in]     shrinking Positive value to shrink the Segment3D
  //  [in]     o         The orientation to be shrunk
  Segment3DImpl& shrink(Direction1D dir, UnsignedUnit shrinking);

  /// elarge 'this' Segment to encompass the range b
  template <class T2>
  bool encompass(const IntervalImpl<T2>& b);

  /// enlarge `this` Segment to encompass the Segment b 
  //  [in]     b         The T to encompass
  //  [ret]    .         true if enlargement happened at all
  template <class T2>
  bool encompass(const Segment3DImpl<T2>& b);
    
private:
  //private functions
  Point3DImpl<Point3DData> get_(Direction1D dir) const;
  void set_(Direction1D dir,
                   const Point3DImpl<Point3DData>& value);
  Orientation3D getOrient_() const;
  void setOrient_(Orientation3D orient);
  UnsignedUnit getLength_() const;
  void setLength_(UnsignedUnit value);
  static T construct_(const Point3DImpl<Point3DData>& p, 
                             Orientation3D o,
                             UnsignedUnit length);
};

typedef Segment3DImpl<Segment3DData> Segment3D;

template <class T>
std::ostream& operator<< (std::ostream& o, const Segment3DImpl<T>& s);

template <class T>
std::istream& operator>> (std::istream& i, Segment3DImpl<T>& s);
