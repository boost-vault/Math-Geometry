//
//!  Copyright (c) 2008
//!  Brandon Kohn
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
#ifndef _BOOST_GEOMETRY_POINT_SEQUENCE_UTILITIES_HPP
#define _BOOST_GEOMETRY_POINT_SEQUENCE_UTILITIES_HPP
#pragma once

#include "geometric_concepts.hpp"
#include "point_sequence_traits.hpp"
#include <boost/foreach.hpp>
#include <boost/tuple/tuple.hpp>

namespace boost
{
namespace numeric
{
namespace geometry
{
	namespace detail
	{
	}

	//! Function to calculate the centroid of a point sequence.
	template <typename PointSequence, typename NumberComparisonPolicy>
    inline typename point_sequence_traits<PointSequence>::point_type get_centroid( const PointSequence& polygon, const NumberComparisonPolicy& compare, typename boost::enable_if< boost::is_same< typename point_traits< typename point_sequence_traits<PointSequence>::point_type >::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
	{
        boost::function_requires< PointSequenceConcept< PointSequence > >();
        //assert( equals( polygon.front(), polygon.back(), fraction_tolerance_comparison_policy<double>(1e-10) ) );//needs to be a closed boundary.

        typedef typename point_sequence_traits<PointSequence>::point_type point_type;		
		typedef typename point_traits<point_type>::coordinate_type        coordinate_type;
        typedef cartesian_access_traits< point_type >                     access_traits;
        boost::function_requires< CartesianCoordinateAccessorConcept< access_traits > >();

        coordinate_type mX = 0.;
        coordinate_type mY = 0.;
		coordinate_type area = 0;
		for( typename PointSequence::const_iterator it( polygon.begin() ), nextIt( polygon.begin() + 1), end( polygon.end() ); nextIt != end; ++it, ++nextIt )
		{
			const point_type& currentPoint = *it;
			const point_type& nextPoint = *nextIt;
			double ai = cross_product( currentPoint, nextPoint );
			area += ai;
            mX += ai * ( access_traits::get_x( currentPoint ) + access_traits::get_x( nextPoint ) );
            mY += ai * ( access_traits::get_y( currentPoint ) + access_traits::get_y( nextPoint ) );	
		}

        if( !equals( polygon.front(), polygon.back(), compare ) )
        {
            double ai = cross_product( polygon.back(), polygon.front() );
            area += ai;
            mX += ai * ( access_traits::get_x( polygon.back() ) + access_traits::get_x( polygon.front() ) );
            mY += ai * ( access_traits::get_y( polygon.back() ) + access_traits::get_y( polygon.front() ) );	
        }
		
		area *= 0.5;
		coordinate_type q = 1. /( 6.0 * area);		
		return point_type( mX * q, mY * q );
	}

    //! Function to calculate the centroid of a point sequence.
	template <typename PointSequence>
	inline typename double get_area( const PointSequence& polygon, typename boost::enable_if< boost::is_same< typename point_traits< typename point_sequence_traits<PointSequence>::point_type >::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
	{
        boost::function_requires< PointSequenceConcept< PointSequence > >();        
        assert( equals( polygon.front(), polygon.back(), fraction_tolerance_comparison_policy<double>(1e-10) ) );//needs to be a closed boundary.

        typedef typename PointSequence::value_type                 point_type;		        
		typedef typename point_traits<point_type>::coordinate_type coordinate_type;

		double area = 0;
		for( typename PointSequence::const_iterator it( polygon.begin() ), nextIt( polygon.begin() + 1), end( polygon.end() ); nextIt != end; ++it, ++nextIt )
		{
			const point_type& currentPoint = *it;
			const point_type& nextPoint = *nextIt;
			double ai = cross_product( currentPoint, nextPoint );
			area += ai;
		}
		
		area *= 0.5;	
		return area;
	}

    //! Function to test if a point is inside a polygon. (From Geometric Tools for Computer Graphics.)
    template <typename Point, typename PointSequence>
    inline bool point_in_polygon( const Point& A, const PointSequence& polygon, typename boost::enable_if< boost::is_same< typename point_traits< typename point_sequence_traits<PointSequence>::point_type >::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
    {
        boost::function_requires< PointConcept< Point > >();
        boost::function_requires< PointSequenceConcept< PointSequence > >();
        boost::function_requires< RandomAccessContainerConcept< PointSequence > >();

        if( polygon.size() < 3 ) //! Must at least be a triangle.
            return false;

        typedef point_sequence_traits< PointSequence>::point_type sequence_point_type;
        typedef cartesian_access_traits< Point >                  paccess;
        typedef cartesian_access_traits< sequence_point_type >    saccess;
        boost::function_requires< CartesianCoordinateAccessorConcept< paccess > >();
        boost::function_requires< CartesianCoordinateAccessorConcept< saccess > >();

        bool inside = false;
        for( size_t i = 0, j = polygon.size() - 1; i < polygon.size(); j = i, ++i )
        {
            const sequence_point_type& u0 = polygon[i];
            const sequence_point_type& u1 = polygon[j];

            if( paccess::get_y( A ) < saccess::get_y( u1 ) )
            {
                // u1 above ray
                if( saccess::get_y( u0 ) <= paccess::get_y( A ) )
                {
                    //u0 on or below ray                    
                    if( ( paccess::get_y( A ) - saccess::get_y( u0 ) ) * ( saccess::get_x( u1 ) - saccess::get_x( u0 ) ) > ( paccess::get_x( A ) - saccess::get_x( u0 ) ) * ( saccess::get_y( u1 ) - saccess::get_y( u0 ) ) )
                    {
                        inside = !inside;
                    }
                }
            }
            else if( paccess::get_y( A ) < saccess::get_y( u0 ) )
            {
                // u1 on or below ray, u0 above ray
                if( ( paccess::get_y( A ) - saccess::get_y( u0 ) ) * ( saccess::get_x( u1 ) - saccess::get_x( u0 ) ) < ( paccess::get_x( A ) - saccess::get_x( u0 ) ) * ( saccess::get_y( u1 ) - saccess::get_y( u0 ) ) )
                {
                    inside = !inside;
                }            
            }           
        }

        return inside;
    }

     //! Function to calculate the min/max bounds of a point sequence.
    enum cartesian_bound
    {
        e_xmin = 0,
        e_ymin = 1,
        e_xmax = 2,
        e_ymax = 3
    };
    template <typename PointSequence>
    struct bounds_tuple
    {
        typedef boost::tuple< typename point_sequence_traits< PointSequence >::coordinate_type, 
                              typename point_sequence_traits< PointSequence >::coordinate_type,
                              typename point_sequence_traits< PointSequence >::coordinate_type,
                              typename point_sequence_traits< PointSequence >::coordinate_type > type;
    };
    template <typename PointSequence, typename NumberComparisonPolicy>
    typename bounds_tuple< PointSequence >::type get_bounds( const PointSequence& pointSequence, const NumberComparisonPolicy& compare, typename boost::enable_if< boost::is_same< typename point_traits< typename point_sequence_traits<PointSequence>::point_type >::dimension_type, dimension_tag<2> > >::type* dummy = 0 )
    {
        typedef typename point_sequence_traits< PointSequence >::point_type point_type;
        typedef typename point_traits< point_type >::coordinate_type        coordinate_type;

        typedef boost::tuple< typename point_sequence_traits< PointSequence >::coordinate_type, 
                              typename point_sequence_traits< PointSequence >::coordinate_type,
                              typename point_sequence_traits< PointSequence >::coordinate_type,
                              typename point_sequence_traits< PointSequence >::coordinate_type > bounds_tuple;

        bounds_tuple bounds;
        if( std::numeric_limits< coordinate_type >::has_infinity )
        {
            bounds = boost::make_tuple( std::numeric_limits< coordinate_type >::infinity(), std::numeric_limits< coordinate_type >::infinity(), -std::numeric_limits< coordinate_type >::infinity(), -std::numeric_limits< coordinate_type >::infinity() );
        }
        else
        {
            bounds = boost::make_tuple( (std::numeric_limits< coordinate_type >::max)(), (std::numeric_limits< coordinate_type >::max)(), -(std::numeric_limits< coordinate_type >::max)(), -(std::numeric_limits< coordinate_type >::max)() );
        }

        BOOST_FOREACH( const point_type& p, pointSequence )
        {
            const coordinate_type& x = cartesian_access_traits< point_type >::get_x( p );            
            if( compare.less_than( x, bounds.get<e_xmin>() ) )
                bounds.get<e_xmin>() = x;
            if( compare.greater_than( x, bounds.get<e_xmax>() ) )
                bounds.get<e_xmax>() = x;

            const coordinate_type& y = cartesian_access_traits< point_type >::get_y( p );
            if( compare.less_than( y, bounds.get<e_ymin>() ) )
                bounds.get<e_ymin>() = y;
            if( compare.greater_than( y, bounds.get<e_ymax>() ) )
                bounds.get<e_ymax>() = y;
        }

        return bounds;
    }
	
}}}//namespace boost::numeric::geometry;

#endif //_BOOST_GEOMETRY_POINT_SEQUENCE_UTILITIES_HPP
