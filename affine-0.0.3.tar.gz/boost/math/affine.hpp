//  boost affine.hpp header file

//  (C) Copyright Hugo Duncan 2007.
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

// See http://www.boost.org for updates, documentation, and revision history.

#ifndef FT_MATH_AFFINE_H
#define FT_MATH_AFFINE_H

#if defined(_MSC_VER) && _MSC_VER>1200
#pragma once
#endif

#include "boost/operators.hpp"
#include "boost/typeof/typeof.hpp"
#include "boost/type_traits/is_same.hpp"
#include "boost/type_traits/remove_const.hpp"
#include "boost/type_traits/remove_reference.hpp"
#include "boost/type_traits/is_convertible.hpp"
#include "boost/mpl/assert.hpp"
#include "boost/mpl/not.hpp"

namespace boost
{
namespace math
{
  namespace detail
  {
    template <typename ValueType, typename FrameTag>
    struct frame_value_type
    {
      typedef typename remove_const<
          typename remove_reference<ValueType>::type >::type value_type;
      typedef FrameTag frame;
      typedef frame_value_type<ValueType,FrameTag> self_type;

      frame_value_type() {}

      template <typename T>
      frame_value_type(const T& value) : m_value(value) {}

      template <typename T>
      frame_value_type(
        T value,
        typename disable_if< boost::is_convertible<T, const T&> >::type* dummy=0
                       ) : m_value(value) {}

      template <typename T>
      frame_value_type(
        const frame_value_type<T,typename self_type::frame>& value)
          : m_value(value.m_value) {}

      const value_type& value() const { return m_value; }
      value_type& value() { return m_value; }
    private:
      value_type m_value;
    };

    template <typename ValueType, typename FrameTag>
    struct frame_ref
    {
      typedef FrameTag frame;
      typedef typename boost::remove_const<ValueType>::type value_type;
      frame_ref(value_type& value) : m_ref(value) {}
      const ValueType& value() const { return m_ref; }
      ValueType& value() { return m_ref; }
    private:
      ValueType& m_ref;
    };

    template <typename ValueType, typename FrameTag>
    struct frame_const_ref
    {
      typedef FrameTag frame;
      typedef typename boost::remove_const<ValueType>::type value_type;
      frame_const_ref(const value_type& value) : m_ref(value) {}
      const ValueType& value() const { return m_ref; }
    private:
      const ValueType& m_ref;
    };

    template <typename FrameValueType> struct displacement;

    template <typename FrameValueType>
    struct point : public FrameValueType
    {
      typedef point<FrameValueType> self_type;
      typedef FrameValueType base_type;

      point() {}

      template < typename V, template <typename,typename> class FrameType >
      explicit point(
        const point< FrameType<V,typename self_type::frame> >& value)
          : base_type(value.value()) {}

      template < typename V, typename F,
          template <typename,typename> class FrameType >
      explicit point(FrameType<V,F>& value)
          : base_type(value.value()) {}

      template < typename V, template <typename,typename> class FrameType >
      explicit point(const FrameType<V,typename self_type::frame>& value)
          : base_type(value.value()) {}

      template <typename T>
      explicit point(const T& value) : base_type(value) {}

      template <typename T>
      explicit point(
        T value,
        typename disable_if<boost::is_convertible<T, const T&> >::type* dummy=0
            ) : base_type(value) {}


      template <typename T>
      self_type& operator=(const T& d)
      {
        BOOST_MPL_ASSERT(
          ( is_same<typename FrameValueType::frame, typename T::frame> ));
        this->value()=d.value();
        return *this;
      }

      /*! Addition of a displacement */
      template <typename ArgType>
      self_type& operator+=(const displacement<ArgType>& d)
      {
        BOOST_MPL_ASSERT(
          (is_same<typename ArgType::frame, typename FrameValueType::frame>));
        this->value()+=d.value();
        return *this;
      }

      /*! Subtraction of a displacement */
      template <typename ArgType>
      self_type& operator-=(const displacement<ArgType>& d)
      {
        BOOST_MPL_ASSERT(
          (is_same<typename ArgType::frame, typename FrameValueType::frame>));
        this->value()-=d.value();
        return *this;
      }

      template <typename ArgType>
      self_type& operator*=(ArgType v)
      {
        this->value()*=v;
        return *this;
      }
    };

    template <typename FrameValueType>
    struct displacement : public FrameValueType
    {
      typedef displacement<FrameValueType> self_type;
      typedef FrameValueType base_type;

      displacement() {}

      template < typename V, template <typename,typename> class FrameType >
      explicit displacement(
        const displacement< FrameType<V,typename self_type::frame> >& value)
          : base_type(value.value()) {}

      template < typename V, typename F,
          template <typename,typename> class FrameType >
      explicit displacement(FrameType<V,F>& value)
          : base_type(value.value()) {}

      template < typename V, template <typename,typename> class FrameType >
      explicit displacement(const FrameType<V,typename self_type::frame>& value)
          : base_type(value.value()) {}

      template <typename T>
      explicit displacement(const T& value) : base_type(value) {}

      template <typename T>
      explicit displacement(
        T value,
        typename disable_if<boost::is_convertible<T, const T&> >::type* dummy=0
            ) : base_type(value) {}

      template <typename T>
      self_type& operator=(const T& d)
      {
        BOOST_MPL_ASSERT(
          ( is_same<typename FrameValueType::frame, typename T::frame> ));
        this->value()=d.value();
        return *this;
      }

      template <typename ArgType>
      self_type& operator+=(const displacement<ArgType>& d)
      {
        BOOST_MPL_ASSERT(
          (is_same<typename ArgType::frame, typename FrameValueType::frame>));
        this->value()+=d.value();
        return *this;
      }

      template <typename ArgType>
      self_type& operator-=(const displacement<ArgType>& d)
      {
        BOOST_MPL_ASSERT(
          (is_same<typename ArgType::frame, typename FrameValueType::frame>));
        this->value()-=d.value();
        return *this;
      }

      template <typename ArgType>
      self_type& operator*=(ArgType v)
      {
        this->value()*=v;
        return *this;
      }

    };

    template <typename T1, typename T2>
    struct plus_type_helper
    {
    private:
      static const T1& m_t1;
      static const T2& m_t2;
    public:
      typedef BOOST_TYPEOF_TPL(m_t1+m_t2) type;
    };

    template <typename T1, typename T2>
    struct minus_type_helper
    {
    private:
      static const T1& m_t1;
      static const T2& m_t2;
    public:
      typedef BOOST_TYPEOF_TPL(m_t1-m_t2) type;
    };

  }

  template <typename FrameTag, typename ValueType>
  detail::point< detail::frame_const_ref<ValueType, FrameTag> >
  point_ref(const ValueType& value)
  {
    detail::frame_const_ref<ValueType,FrameTag > frame_value(value);
    return detail::point< detail::frame_const_ref<ValueType,FrameTag > >(
      frame_value);
  }

  template <typename FrameTag, typename ValueType>
  detail::point< detail::frame_ref<ValueType, FrameTag> >
  point_ref(ValueType& value,
            typename disable_if< is_const<ValueType> >::type* dummy=0)
  {
    detail::frame_ref<ValueType,FrameTag> frame_value(value);
    return detail::point<detail::frame_ref<ValueType,FrameTag > >(
      frame_value);
  }

  template <typename FrameTag, typename ValueType>
  detail::displacement<detail::frame_const_ref<ValueType, FrameTag> >
  displacement_ref(const ValueType& value)
  {
    detail::frame_const_ref<ValueType,FrameTag > frame_value(value);
    return detail::displacement< detail::frame_const_ref<ValueType,
      FrameTag> >(frame_value);
  }

  template <typename FrameTag, typename ValueType>
  detail::displacement< detail::frame_ref<ValueType, FrameTag > >
  displacement_ref(ValueType& value,
                   typename disable_if< is_const<ValueType> >::type* dummy=0)
  {
    detail::frame_ref<ValueType, FrameTag > frame_value(value);
    return detail::displacement<detail::frame_ref<ValueType,FrameTag> >(
      frame_value);
  }

  //! Point value type
  /** Can be instantianted to hold a point value */
  template <typename ValueType, typename FrameTag>
  class point : public detail::point<
      detail::frame_value_type<ValueType, FrameTag> >
  {
    typedef point<ValueType, FrameTag> self_type;
  public:
    typedef detail::point<detail::frame_value_type<ValueType, FrameTag> >
      base_type;

    point() {}
    point(const base_type& value) : base_type(value){}
    point(const typename base_type::value_type& value) : base_type(value) {}
    template <typename T> point(const T& value) : base_type(value) {}

    template <typename T> self_type& operator=(const T& value)
    {
      base_type::operator=(value);
      return *this;
    }
  };

  /*! Displace ment value Type

      Used to create values that are recognised as displacements and
      are tagged as being defined within a particular frame.
   */
  template <typename ValueType, typename FrameTag>
  class displacement : public detail::displacement<
      detail::frame_value_type<ValueType, FrameTag> >
  {
    typedef displacement<ValueType, FrameTag> self_type;
  public:
    typedef detail::displacement<detail::frame_value_type<ValueType, FrameTag> >
      base_type;


  /*! Default constructor
      Default constructs the contained ValueType.
   */
    displacement() {}
    displacement(const base_type& value) : base_type(value){}
    displacement(base_type& value) : base_type(value){}
    displacement(const typename self_type::value_type& value)
        : base_type(value) {}
    //! copy constructor from a type compatible with the contained value type
    template <typename T> displacement(const T& value) : base_type(value) {}

    template <typename T> self_type& operator=(const T& value)
    {
      base_type::operator=(value);
      return *this;
    }
  };

  template <typename ArgType1, typename ArgType2>
  detail::point<
      detail::frame_value_type<
          typename detail::plus_type_helper<
              typename ArgType1::value_type,
              typename ArgType2::value_type>::type, typename ArgType1::frame >
      >
  operator+(const detail::point<ArgType1>& p,
            const detail::displacement<ArgType2>& d)
  {
    BOOST_MPL_ASSERT(
      (is_same<typename ArgType1::frame, typename ArgType2::frame>));
    return point< BOOST_TYPEOF(p.value()+d.value()),
      typename ArgType1::frame > (p.value()+d.value());
  }

  template <typename ArgType1, typename ArgType2>
  detail::point<
      detail::frame_value_type<
          typename detail::minus_type_helper<
              typename ArgType1::value_type,
              typename ArgType2::value_type>::type, typename ArgType1::frame >
      >
  operator-(const detail::point<ArgType1>& p,
            const detail::displacement<ArgType2>& d)
  {
    BOOST_MPL_ASSERT(
      (is_same<typename ArgType1::frame, typename ArgType2::frame>));
    return detail::point< detail::frame_value_type<
      BOOST_TYPEOF(p.value()-d.value()),typename ArgType1::frame > >(
      p.value()-d.value());
  }

  template <typename ArgType1, typename ArgType2>
  detail::displacement<
      detail::frame_value_type<
          typename detail::plus_type_helper<
              typename ArgType1::value_type,
              typename ArgType2::value_type>::type, typename ArgType1::frame >
      >
  operator+(const detail::displacement<ArgType1>& p,
            const detail::displacement<ArgType2>& d)
  {
    BOOST_MPL_ASSERT(
      (is_same<typename ArgType1::frame, typename ArgType2::frame>));
    return displacement< BOOST_TYPEOF(p.value()+d.value()),
      typename ArgType1::frame > (p.value()+d.value());
  }

  /*! Subtraction of a displacement from a displacement */
  template <typename ArgType1, typename ArgType2>
  detail::displacement<
      detail::frame_value_type<
          typename detail::minus_type_helper<
              typename ArgType1::value_type,
              typename ArgType2::value_type>::type, typename ArgType1::frame >
      >
  operator-(const detail::displacement<ArgType1>& p,
            const detail::displacement<ArgType2>& d)
  {
    BOOST_MPL_ASSERT(
      (is_same<typename ArgType1::frame, typename ArgType2::frame>));
    return displacement< BOOST_TYPEOF(p.value()-d.value()),
      typename ArgType1::frame > (p.value()-d.value());
  }

}
}

#endif
