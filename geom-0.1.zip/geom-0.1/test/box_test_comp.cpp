// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/geom/box.hpp>
#include <boost/geom/box_xywh.hpp>
#include <boost/geom/box_lrtb.hpp>
#include <boost/geom/point.hpp>
#include <boost/geom/point_xy.hpp>
#include <boost/geom/point_xyz.hpp>

#ifdef BOOST_GEOM_TEST_SDL
#include <boost/geom/sdl/rect.hpp>
#endif

#ifdef BOOST_GEOM_TEST_QT
#include <boost/geom/qt/rect.hpp>
#include <boost/geom/qt/point.hpp>
#endif

#ifdef BOOST_GEOM_TEST_GDI
#include <boost/geom/gdi/rect.hpp>
#endif

#ifdef BOOST_GEOM_TEST_X
#include <boost/geom/x/rectangle.hpp>
#endif

template<class point_impl, class box_impl>
void test_basic()
{
	typedef boost::geom::point<point_impl> point;
	typedef boost::geom::box<box_impl> box;

	box bx;

	bx.xmin()=4;
	bx.xmin()=bx.xmax();
	bx.xmax()=bx.ymin();
	bx.ymin()=bx.ymax();
	bx.ymax()=bx.zmin();
	bx.zmin()=bx.zmax();
	bx.zmax()=bx.x1();
	bx.x1()=bx.x2();
	bx.x2()=bx.y1();
	bx.y1()=bx.y2();
	bx.y2()=bx.z1();
	bx.z1()=bx.z2();
	bx.z2()=bx.width();
	bx.width()=bx.height();
	bx.height()=bx.depth();
	bx.depth()=bx.xmin();
	
	using boost::geom::x1;
	using boost::geom::y1;
	using boost::geom::z1;
	using boost::geom::x2;
	using boost::geom::y2;
	using boost::geom::z2;

	using boost::geom::xmin;
	using boost::geom::ymin;
	using boost::geom::zmin;
	using boost::geom::xmax;
	using boost::geom::ymax;
	using boost::geom::zmax;

	point pt;
	point_impl pt_impl;
	const box bx2;

#define TEST_CORNER(x,y,z)    			\
	bx.template corner<x,y,z>()=pt;			\
	pt=-bx.template corner<x,y,z>();			\
	pt=bx.template corner<x,y,z>()+pt*3;		\
	bx.template corner<x,y,z>()-pt;			\
	bx.template corner<x,y,z>()-=pt;                 \
	bx.template corner<x,y,z>()=bx2.center();       \
	bx.template corner<x,y,z>()=bx2.template corner<x,y,z>()     

	TEST_CORNER(x1, y1, z1);
	TEST_CORNER(x1, y1, z1);
	TEST_CORNER(x2, y1, z1);
	TEST_CORNER(x1, y2, z1);
	TEST_CORNER(x2, y2, z1);
	TEST_CORNER(x1, y1, z2);
	TEST_CORNER(x2, y1, z2);
	TEST_CORNER(x1, y2, z2);
	TEST_CORNER(x2, y2, z2);
	
	TEST_CORNER(xmax, ymax, zmin);
	TEST_CORNER(xmin, ymin, zmax);
	TEST_CORNER(xmax, ymin, zmax);
	TEST_CORNER(xmin, ymax, zmax);
	TEST_CORNER(xmax, ymax, zmax);

	bx=bx + pt;
	bx=bx2+pt_impl;

	bx.center()=pt;			
	pt=-bx.center()*3;			
	pt=bx.center()+pt/3;
	bx.center()-pt;			
	bx.center()-=pt;

	box_impl bx_impl;
	bx2==bx;
	bx==bx_impl;

	bx|=bx2;
	bx|=bx_impl;
	bx&=bx2;
	bx2&bx_impl;
	
	bx=bx2|bx_impl;
	bx=bx2|bx;

	bx=bx2&bx_impl;
	bx=bx2&bx;
	bx&=bx_impl;
	bx&=bx2;

}

template<typename box_impl1, typename box_impl2>
void test_mix()
{
	typedef boost::geom::box<box_impl1> box1;
	typedef boost::geom::box<box_impl2> box2;

	box1 bx1;
	box_impl1 bx1_impl;
	
	box2 bx2;
	box_impl2 bx2_impl;

	bx1=bx2;
	bx1&=bx2;
	bx1|=bx2;
	if(bx1==bx2 || bx1!=bx2){}
	
	bx1=bx2_impl;
	bx1&=bx2_impl;
	bx1|=bx2_impl;
	if(bx1==bx2_impl || bx1!=bx2_impl){}
	
	bx2=bx1;
	bx2&=bx1;
	bx2|=bx1;
	if(bx2==bx1 || bx2!=bx1){}
	
	bx2=bx1_impl;
	bx2&=bx1_impl;
	bx2|=bx1_impl;
	if(bx2==bx1_impl || bx2!=bx1_impl){}
}

int main()
{
	boost::geom::box<boost::geom::box_xywh<short> > bx;
	
	test_basic<boost::geom::point_xyz<short>,
	    boost::geom::box_xywh<short> >();

	test_basic<boost::geom::point_xyz<short>,
	    boost::geom::box_lrtb<short> >();

	test_mix<boost::geom::box_xywh<short>,
	    boost::geom::box_lrtb<short> >();

#ifdef BOOST_GEOM_TEST_SDL
	test_basic<boost::geom::point_xy<Sint16>,
	    SDL_Rect>();
	test_mix<boost::geom::box_xywh<Sint16>,
	    SDL_Rect>();
	test_mix<boost::geom::box_lrtb<Sint16>,
	    SDL_Rect>();
#endif

#ifdef BOOST_GEOM_TEST_GDI
	test_basic<boost::geom::point_xy<LONG>,
	    RECT>();
	test_mix<boost::geom::box_xywh<LONG>,
	    RECT>();
	test_mix<boost::geom::box_lrtb<LONG>,
	    RECT>();
#endif
	
#ifdef BOOST_GEOM_TEST_QT
	test_basic<boost::geom::point_xy<QCOORD>,
	    QRect>();
	test_mix<boost::geom::box_xywh<QCOORD>,
	    QRect>();
	test_mix<boost::geom::box_lrtb<QCOORD>,
	    QRect>();
#endif

#ifdef BOOST_GEOM_TEST_X
	test_basic<boost::geom::point_xy<short>,
	    XRectangle>();
	test_mix<boost::geom::box_xywh<short>,
	    XRectangle>();
	test_mix<boost::geom::box_lrtb<short>,
	    XRectangle>();
#endif
	
}
