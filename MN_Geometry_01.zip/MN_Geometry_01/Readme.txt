// ============================================================================
// Generic Geometry Library                       (C)2005 Michael Andersen Nexo
// ============================================================================

About this library
------------------
The files in this directory contain my initial work on creating a generic 
framework for writing cross-platform algorithms in the domains of imaging and
computational geometry. 

The overall design goals can be summarized as follows:

 * To create nic, generic vector and point classes that are templatized on 
   scalar type and dimensionality, interface well with the Standard C++ 
   library algorithms and utilize expression template techniques for improved
   performance when the dimensionality is large.
   
 * To provide the foundation for creating a loose coupling between geometric
   algorithms and geometric data structures, like the ones seen found in the 
   Standard Template Library and the Boost Graph Library, thus enabling the 
   user to use the generic geometric algorithms in this library while still 
   using data structures that a compatible with the surrounding platform.

Finally, I've tried to pay attention to issues arising from working with scalar
types with limited range and precision, e.g. the built-in numeric types in C++.

I would suggest reading the comments at the top of geometry.hpp, traits.hpp and 
utility.hpp for a more detailed description of the rationale.

This work is still in its early stages, and most of the work has been put into
getting the vector and point classes (and related operators and functions) 
right. However, two algorithms have been implemented to illustrate how to write
generic algorithms whithin this framework: Melkman's Convec Hull algorithm and 
the Douglas Peucker line simplification algorithm.

Comments are more than welcome! -- I can be reached at nexo[at]fuba.dk
Michael Andersen Nex�


How to build the test projects
------------------------------
The geometry files depend on the boost C++ libraries, so you need to download
and install the boost libraries from http://boost.org

Building with Visual Studio
 * Open the Visual Studio solution, go to the C++ section of the project
   settings and modify the boost include path to whatever fits your setup.
 * Build.

Assuming boost is in your systems include path, building test/dp_simp/simplify
with gcc would amount to:
 * cd test/dp_simp/simplify
 * g++ -I../../.. simplify.cpp

