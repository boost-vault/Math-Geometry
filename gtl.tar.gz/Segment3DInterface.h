/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Segment3DInterface provides glue to bind Segment3DImpl to T

/// Segment3DInterface provides access the the data class T through
/// the constructor, get and set API, nearly minimal and sufficient
template <class T>
class Segment3DInterface {
public:
  /// get an end point of the 3D segment t depending on dir
  static inline Point3DData Segment3DGet(const T& t, Direction1D dir);

  /// set an end point of the 3D segment t depending on dir
  static inline void Segment3DSet(T& t, Direction1D dir, const PointData& value);

  /// get the orientation of the 3D segment t
  static inline Orientation3D Segment3DGetOrient(const T& t);

  /// set the orientation of the 3D segment t
  static inline void Segment3DSetOrient(T& t, Orientation3D orient);

  /// get the length of the 3D segment t
  static inline UnsignedUnit Segment3DGetLength(const T& t);

  /// set the length of the 3D segment t
  static inline void Segment3DSetLength(T& t, UnsignedUnit value);

  /// construct a 3D segment of type T from low end point p, orient and length
  static inline T Segment3DConstruct(const Point3DData& p, 
                                     Orientation3D o,
                                     UnsignedUnit length);

private:
  //disallow construction
  Segment3DInterface();
};

/// partial specialization of Segment3DInterface for T of type Segment3DData
template <>
class Segment3DInterface<Segment3DData> {
public:  
  static inline Point3DData Segment3DGet(const Segment3DData& t, Direction1D dir) {
    return t.get(dir);
  }

  static inline void Segment3DSet(Segment3DData& t, Direction1D dir,
                                  const Point3DData& value) {
    t.set(dir, value);
  }

  static inline Orientation3D Segment3DGetOrient(const Segment3DData& t) {
    return t.getOrient();
  }

  static inline void Segment3DSetOrient(Segment3DData& t, Orientation3D orient) {
    t.setOrient(orient);
  }

  static inline UnsignedUnit Segment3DGetLength(const Segment3DData& t) {
    return t.getLength();
  }

  static inline void Segment3DSetLength(Segment3DData& t, UnsignedUnit value) {
    t.setLength(value);
  }

  static inline Segment3DData 
  Segment3DConstruct(const Point3DData& p, Orientation3D o, UnsignedUnit length) {
    return Segment3DData(p, o, length);
  }

private:
  //disallow construction
  Segment3DInterface() {;}
};

