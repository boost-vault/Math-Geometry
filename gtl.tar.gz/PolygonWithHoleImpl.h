/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T>
class PolygonWithHolesImpl : public T{
public:

  typedef typename PolygonInterface<T>::iterator iterator;
  typedef typename PolygonWithHolesInterface<T>::iterator iteratorHoles;

  /// get a reference of PolygonWithHolesImpl type given a data object
  static inline PolygonWithHolesImpl& mimic(T& t) { return static_cast<PolygonWithHolesImpl&>(t); }

  /// get a reference of PolygonWithHolesImpl type given a data object
  static inline const PolygonWithHolesImpl& mimicConst(const T& t) { 
    return static_cast<const PolygonWithHolesImpl&>(t); }

  /// construct a polygon from an iterator over unique x and y values
  template<class iT>
  inline PolygonWithHolesImpl(iT inputBegin, iT inputEnd) { set(inputBegin, inputEnd); }

  /// default constructor
  inline PolygonWithHolesImpl() {}

  /// assignment operator
  template <class T2>
  inline PolygonWithHolesImpl& operator=(const PolygonWithHolesImpl<T2>& that) { 
     set(that.begin(), that.end()); return *this;}

  /// assignment operator
   inline PolygonWithHolesImpl& operator=(const PolygonWithHolesImpl<T>& that) { yield() = that; return *this; }

//   /// assignment operator
//    inline PolygonWithHolesImpl& operator=(const T& that) { yield() = that; return *this; }

   /// copy constructor
   template <class T2>
   inline PolygonWithHolesImpl(const PolygonWithHolesImpl<T2>& that) { set(that.begin(), that.end()); }

  /// copy constructor
  inline PolygonWithHolesImpl(const T& that) : T(that) {;}

//   /// equivalence operator
//   template <class T2>
//   inline bool operator==(const PolygonWithHolesImpl<T2>& b) const;

//   /// inequivalence operator
//   template <class T2>
//   inline bool operator!=(const PolygonWithHolesImpl<T2>& b) const { return !(*this == b); }

  /// yield payload
  inline T& yield() { return *this; }

  /// yield const payload
  inline const T& yieldConst() const { return *this; }

//   /// check for validity
//   inline bool isValid(void) const;

  /// set with coordinates
  template<class iT>
  inline PolygonWithHolesImpl& set(iT inputBegin, iT inputEnd) {
     set_(inputBegin, inputEnd);
     return *this;
  }

   inline iterator begin() const {
      return begin_();
   }

   inline iterator end() const {
      return end_();
   }

   std::size_t size() const {
      return size_();
   }

   Direction1D winding() const {
      WindingDirection wd = winding_();
      if(wd != WindingDirection::unknown()) {
         return predicated_value(wd == WindingDirection::clockwise(),
                                 LOW, HIGH);
      }
      Direction1D dir = HIGH;
      Unit minX = UnitMax;
      iterator itr = begin();
      Unit firstx = *itr;
      ++itr;
      Unit prevy = *itr;
      Unit firsty = *itr;
      ++itr;
      for( ; itr != end(); ++itr) {
         Unit x = *itr;
         ++itr;
         Unit y = *itr;
         if(x <= minX) {
            minX = x;
            //edge directed downward on left side of figure is counterclockwise
            dir = predicated_value(y < prevy, HIGH, LOW);
         }
         prevy = y;
      }
      if(firstx <= minX) {
         dir = predicated_value(firsty < prevy, HIGH, LOW);
      }
      return dir;
   }

//   template<class iT>
//   inline PolygonWithHolesImpl& setVerticies(iT inputBegin, iT inputEnd);

//   /// move polygon by delta in orient
//   inline PolygonWithHolesImpl& move(Orientation2D orient, Unit delta);

   /// transform polygon
   inline PolygonWithHolesImpl& transform(const AxisTransform& atr) ;
    
   /// transform polygon
   inline PolygonWithHolesImpl& transform(const Transform& tr) ;

//   /// get the distance between 'this' and p along orientation orient
//   template <class T2>
//   inline UnsignedUnit distance(const PolygonWithHolesImpl<T2>& p, 
//                                Orientation2D orient) const;

//   /// get the manhatton distance between 'this' and p 
//   template <class T2>
//   inline UnsignedUnit manhattanDistance(const PolygonWithHolesImpl<T2>& p) const;

//   /// get the square equclidian distance between 'this' and p 
//   template <class T2>
//   inline UnsignedLongUnit squareEuclidianDistance(const PolygonWithHolesImpl<T2>& p) const;

//   /// get the euclidian distance between 'this' and p
//   template <class T2>
//   inline double euclidianDistance(const PolygonWithHolesImpl<T2>& p) const;

//   /// get the bounding box of the polygon
//   inline RectangleImpl<RectangleData> boundingBox() const;

//   /// get the magnitude of the interval range depending on orient
//   inline UnsignedUnit delta(Orientation2D orient) const;

//   /// get the area of the rectangle
//   inline UnsignedLongUnit area() const;

//   /// returns the orientation of the longer delta
//   inline Orientation2D guessOrientation(void) const;

//   /// get the perimeter of the rectangle
//   inline UnsignedLongUnit perimeter() const;

//   /// check if Polygon b is inside `this` Polygon
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if b touches the boundary
//   //  [ret]    .         true if `t` contains b
//   template <class T2>
//   inline bool contains(const PolygonWithHolesImpl<T2>& b, 
//                        bool considerTouch = true) const;

//   /// check if Point p is inside `this` Polygon
//   template <class T2>
//   inline bool contains(const PointImpl<T2>& p, 
//                        bool considerTouch = true) const;

//   /// check if `this` Polygon is inside specified Polygon b
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch true, return true even if `t` touches the boundary
//   //  [ret]    .         true if `t` is inside b
//   template <class T2>
//   inline bool inside(const PolygonWithHolesImpl<T2>& b, 
//                      bool considerTouch = true) const;

//   /// check if Polygon b intersects `this` Polygon
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if b touches the boundary
//   //  [ret]    .         true if `t` intersects b
//   template <class T2>
//   inline bool intersects(const PolygonWithHolesImpl<T2>& b, 
//                          bool considerTouch = true) const;

//   /// Check if boundaries of Polygon b and `this` Polygon intersect
//   //  [in]     b         Polygon that will be checked
//   //  [in]     considerTouch If true, return true even if p is on the foundary
//   //  [ret]    .         true if `t` contains p
//   template <class T2>
//   inline bool boundariesIntersect(const PolygonWithHolesImpl<T2>& b, 
//                                   bool considerTouch = true) const;
    
//   /// check if b is touching 'this' on the end specified by dir
//   template <class T2>
//   inline bool abuts(const PolygonWithHolesImpl<T2>& b, Direction2D dir) const;

//   /// check if they are touching in the given orientation
//   template <class T2>
//   inline bool abuts(const PolygonWithHolesImpl<T2>& b, 
//                     Orientation2D orient)const ;

//   /// check if they are touching but not overlapping
//   template <class T2>
//   inline bool abuts(const PolygonWithHolesImpl<T2>& b) const;

//   /// bloat the Polygon on orient by bloating
//   inline PolygonWithHolesImpl& bloat(Orientation2D orient, UnsignedUnit bloating);

//   /// bloat the Polygon by bloating
//   inline PolygonWithHolesImpl& bloat(UnsignedUnit bloating);

//   /// bloat the Polygon cooresponding to orient by bloating in dir direction
//   inline PolygonWithHolesImpl& bloat(Direction2D dir, UnsignedUnit bloating);

//   /// returns the center of the polygon
//   inline PointImpl<PointData> getCenter(void) const;
//   inline const PolygonWithHolesImpl& getCenter(Unit& x, Unit& y) const;


private:
  //private functions
  inline iterator begin_() const {
    return PolygonInterface<T>::PolygonBegin(yieldConst());
  }

  inline iterator end_() const {
    return PolygonInterface<T>::PolygonEnd(yieldConst());
  }

  template <class iT>
  inline void set_(iT inputBegin, iT inputEnd) {
    PolygonInterface<T>::PolygonSet(yield(), inputBegin, inputEnd);
  }

  inline std::size_t size_() const {
    return PolygonInterface<T>::PolygonSize(yieldConst());
  }

  inline WindingDirection winding_() const {
     return PolygonInterface<T>::PolygonWinding(yieldConst());
  }

};

// default polygon type
typedef PolygonWithHolesImpl<PolygonData> Polygon;

template <class T>
std::ostream& operator<< (std::ostream& o, const PolygonWithHolesImpl<T>& p) {
   o << "Polygon ";
   for(typename PolygonWithHolesImpl<T>::iterator itr = p.begin(); itr != p.end(); ++itr) {
      o << *itr << " ";
   }
   return o;
}

// template <class T>
// std::istream& operator>> (std::istream& i, PolygonWithHolesImpl<T>& p);
