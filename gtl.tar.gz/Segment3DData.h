/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Segment3DData is the default in memory representation of a 3D segment

/// Segment3DData has a point of type Point3DData, a 3D orientation and an
/// unsigned magnitude.
/// Segment3DData is connonical, that is, there is only one representation
/// of a particular segment.  This reduces the number of end cased that
/// must be handled by the implementation on top of this representation.
/// A degenerate segment that has zero length still retains an orientation
/// and will grow in that orientation when extended with set or setLength.
class Segment3DData {
public:
  /// default constructor initializes orient only
  inline Segment3DData() {;} //do nothing default constructor

  /// construct a segment from low end point, orientation and length
  inline Segment3DData(const Point3DData& p, Orientation3D o, UnsignedUnit length) : 
    point_(p), orient_(o), magnitude_(length) {;}

  inline Segment3DData(const Segment3DData& that) {
     (*this) = that;
  }

  inline Segment3DData& operator=(const Segment3DData& that) {
     point_ = that.point_;
     orient_ = that.orient_;
     magnitude_ = that.magnitude_;
     return *this;
  } 

  /// get the low or high end point depending on dir
  inline Point3DData get(Direction1D dir) const {
    Point3DData p(point_);
    p.set(orient_, p.get(orient_) + 
          predicated_value(dir.toInt(), magnitude_, (UnsignedUnit)0));
    return p;
  }

  /// set the low or high end point depending on dir
  inline void set(Direction1D dir, const Point3DData& value) {
    IntervalData ivl(point_.get(orient_),
                     point_.get(orient_)+magnitude_);
    ivl.set(dir, value.get(orient_));
    point_ = value;
	LongUnit newMagnitude = (LongUnit)(ivl.get(HIGH)) - ivl.get(LOW);
    magnitude_ = (UnsignedUnit)newMagnitude;
    //it is not expected that people will change the high point
    //near as often as the low point, so branch prediction should be good
    if(dir.toInt()) {
      point_.set(orient_, (Unit)(point_.get(orient_)-newMagnitude));
    }
  }

  /// get the orientation of the segment
  inline Orientation3D getOrient() const {
    return orient_;
  }

  /// set the orientation of the segment, low end point stays the same
  inline void setOrient(Orientation3D orient) {
    orient_ = orient;
  }

  /// get the length of the segment
  inline UnsignedUnit getLength() const {
    return magnitude_;
  }

  /// set the length of the segment, low end point stays the same
  inline void setLength(UnsignedUnit value) {
    magnitude_ = value;
  }

private:
  Point3DData point_;
  Orientation3D orient_;
  UnsignedUnit magnitude_;
};
