/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// PolygonData is the default in memory representation of a 2D point

/// PolygonData has a vector of coordinates starting with an x
/// that is the compact representatin (no redundant coordinates) meaning
/// a rectangle is represented by a vector containing four cooridnates.
/// No guarentee of winding direction or location of the first vertex is made,
/// and such questions whether given edge is a left or right edge of the polygon
/// must be answered after consuming all of its coodinate data and its when
/// its winding direction becomes clear to the user of the data structure.
class PolygonData {
public:
  typedef std::vector<Unit>::const_iterator iterator;

  /// default constructor of point does not initialize x and y
  inline PolygonData(){;} //do nothing default constructor

  /// initialize a polygon from x,y values, it is assumed that the first is an x
  /// and that the input is a well behaved polygon
  template<class iT>
  inline PolygonData& set(iT inputBegin, iT inputEnd) {
    coords_.clear();  //just in case there was some old data there
    while(inputBegin != inputEnd) {
       coords_.insert(coords_.end(), *inputBegin);
       ++inputBegin;
    }
    return *this;
  }

  /// copy constructor (since we have dynamic memory)
  inline PolygonData(const PolygonData& that) : coords_(that.coords_) {}
  
  /// assignment operator (since we have dynamic memory do a deep copy)
  inline PolygonData& operator=(const PolygonData& that) {
    coords_ = that.coords_;
    return *this;
  }

  /// get begin iterator, returns a pointer to a const Unit
  inline iterator begin() const { return coords_.begin(); }

  /// get end iterator, returns a pointer to a const Unit
  inline iterator end() const { return coords_.end(); }

  inline std::size_t size() const { return coords_.size(); }

private:
  std::vector<Unit> coords_; 
};

template <typename iterator_type>
inline double point_sequence_area(iterator_type begin_range, iterator_type end_range) {
  typedef typename std::iterator_traits<iterator_type>::value_type point_type;
  typedef double area_type;
  if(begin_range == end_range) return area_type(0);
  point_type first = *begin_range;
  point_type previous = first;
  ++begin_range;
  // Initialize trapezoid base line
  area_type y_base = (area_type)(first.y());
  // Initialize area accumulator

  area_type area(0);
  while (begin_range != end_range) {
    area_type x1 = (area_type)(previous.x());
    area_type x2 = (area_type)((*begin_range).x());
    if(x1 != x2) {
      // do trapezoid area accumulation
      area += (x2 - x1) * (((area_type)((*begin_range).y()) - y_base) +
                           ((area_type)(previous.y()) - y_base)) / 2;
    }
    previous = *begin_range;
    // go to next point
    ++begin_range;
  }
  //wrap around to evaluate the edge between first and last if not closed
  if(first != previous) {
    area_type x1 = (area_type)(previous.x());
    area_type x2 = (area_type)(first.x());
    area += (x2 - x1) * (((area_type)(first.y()) - y_base) +
                         ((area_type)(previous.y()) - y_base)) / 2;
  }
  return area;
}
