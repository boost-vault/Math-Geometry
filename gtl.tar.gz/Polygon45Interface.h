/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T>
class Polygon45Interface {
public:

   typedef typename T::iterator iterator;

   /// Get the begin iterator
   static inline iterator Polygon45Begin(const T& t) {
      return t.begin();
   }

   /// Get the end iterator
   static inline iterator Polygon45End(const T& t) {
      return t.end();
   }

   /// Set the data of a polygon with the unique coordinates in an iterator, starting with an x
   template <class iT>
   static inline T& Polygon45Set(T& t, iT inputBegin, iT inputEnd) {
      t.set(inputBegin, inputEnd);
      return t;
   }

   /// Get the number of sides of the polygon
   static inline unsigned int Polygon45Size(const T& t) {
      return t.size();
   }

   /// Get the winding direction of the polygon
   static inline WindingDirection Polygon45Winding(const T& t) {
      return WindingDirection::unknown();
   }

private:
   //disallow construction
   Polygon45Interface();
};
