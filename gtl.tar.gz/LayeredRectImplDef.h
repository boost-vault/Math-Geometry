/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T, class T2>
class lessLayeredRectangle
  : public std::binary_function<const LayeredRectImpl<T>&, 
                                const LayeredRectImpl<T2>&, bool> {
private:
  AxisTransform atr_; // we want to compare along this orientation
public:
  inline lessLayeredRectangle() {;} // allow data member to take default value
  inline lessLayeredRectangle(AxisTransform atr) : atr_(atr) {;}
  inline lessLayeredRectangle(Direction3D dir) : atr_(dir) {;}
  inline lessLayeredRectangle(Orientation3D orient) : atr_(orient) {;}
  inline bool operator () (const LayeredRectImpl<T>& a,
                           const LayeredRectImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessLayeredRectangle<T, T2>::operator () (const LayeredRectImpl<T>& a,
                                          const LayeredRectImpl<T2>& b) const{
  LayeredRectImpl<T> a_(a);
  LayeredRectImpl<T2> b_(b);
  a_.transform2D(atr_);
  b_.transform2D(atr_);
  return a_ < b_;
}
  
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::operator<(const LayeredRectImpl<T2>& b) const {
  return layer() < b.layer() || layer() == b.layer() &&
    mimicConstRectangle() < b.mimicConstRectangle();
}

template<class T> template<class T2>
inline 
LayeredRectImpl<T>::LayeredRectImpl(const RectangleImpl<T2>& rect, Unit layer) {
  *this = construct_(rect, layer);
}

template<class T>
inline 
LayeredRectImpl<T>::LayeredRectImpl() {
  *this = construct_(RectangleImpl<RectangleData>(), Unit());
}

template<class T> template<class T2>
inline LayeredRectImpl<T>::LayeredRectImpl(const Point3DImpl<T2>& p) {
  *this = construct_(RectangleImpl<RectangleData>(p.mimicConstPoint()), p.z());
}

template<class T>
const LayeredRectImpl<T>& 
LayeredRectImpl<T>::operator=(const LayeredRectImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T>
const LayeredRectImpl<T>& 
LayeredRectImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::operator==(const LayeredRectImpl<T2>& b) const {
  return layersMatch(b) & (mimicConstRectangle() == 
                           b.mimicConstRectangle());
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::operator!=(const LayeredRectImpl<T2>& b) const {
  //apply demorgans theorem to achieve two level logic
  return !layersMatch(b) | (mimicConstRectangle() != 
                            b.mimicConstRectangle());
}

template<class T>
inline
LayeredRectImpl<T>::operator RectangleImpl<RectangleData>() const {
  const RectangleImpl<T>& r = mimicConstRectangle();
  return RectangleImpl<RectangleData>(r.xl(), r.yl(), r.xh(), r.yh());
}

template<class T>
inline RectangleImpl<T>& 
LayeredRectImpl<T>::mimicRectangle() {
  return reinterpret_cast<RectangleImpl<T>&>(yield());
}

template<class T>
inline const RectangleImpl<T>& 
LayeredRectImpl<T>::mimicConstRectangle() const {
  return reinterpret_cast<const RectangleImpl<T>&>(yieldConst());
}

template<class T>
inline bool 
LayeredRectImpl<T>::isValid() const {
  return mimicConstRectangle().isValid();
}

template<class T>
inline IntervalImpl<IntervalData> 
LayeredRectImpl<T>::get(Orientation2D orient) const {
  return mimicConstRectangle().get(orient);
}    

template<class T> template<class T2>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::set(Orientation2D orient, const IntervalImpl<T2>& v) {
  mimicRectangle().set(orient, v); return *this;
}    

template<class T>
inline Unit 
LayeredRectImpl<T>::get(Direction2D dir) const {
  return mimicConstRectangle().get(dir);
}

template<class T>
inline Unit 
LayeredRectImpl<T>::set(Direction2D dir, Unit value) {
  return mimicRectangle().set(dir, value);
}

template<class T>
inline IntervalImpl<IntervalData> 
LayeredRectImpl<T>::horizontal() const {
  return get(HORIZONTAL);
}

template<class T>
inline IntervalImpl<IntervalData> 
LayeredRectImpl<T>::vertical() const {
  return get(VERTICAL);
}

template<class T> template<class T2>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::horizontal(const IntervalImpl<T2>& v) {
  return set(HORIZONTAL, v);
}

template<class T> template<class T2>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::vertical(const IntervalImpl<T2>& v) {
  return set(VERTICAL, v);
}

template<class T>
inline Unit 
LayeredRectImpl<T>::layer() const {
  return getLayer_();
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::layer(Unit layer) {
  setLayer_(layer); return *this;
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::transform(const AxisTransform& atr) {
  return mimicConstRectangle().transform(atr);
}
    
template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::transform(const Transform& tr) {
  return mimicConstRectangle().transform(tr);
}

template<class T>
inline UnsignedUnit 
LayeredRectImpl<T>::delta(Orientation2D orient) const {
  return mimicConstRectangle().delta(orient);
}

template<class T>
inline UnsignedLongUnit 
LayeredRectImpl<T>::area() const {
  return mimicConstRectangle().area();
}

template<class T>
inline UnsignedLongUnit 
LayeredRectImpl<T>::halfPerimeter() const {
  return mimicConstRectangle().halfPerimeter();
}
   
template<class T>
inline UnsignedLongUnit 
LayeredRectImpl<T>::perimeter() const {
  //multiply by two
  return mimicConstRectangle().perimeter();
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::layersMatch(const LayeredRectImpl<T2>& b) const {
  return layer() == b.layer();
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::layersMatch(const Point3DImpl<T2>& p) const {
  return layer() == p.z();
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::contains(const LayeredRectImpl<T2>& b, 
                             bool considerTouch) const {
  return layersMatch(b) & mimicConstRectangle().contains(b.mimicConstRectangle(), considerTouch);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::contains(const PointImpl<T2>& p, 
                             bool considerTouch) const {
  return mimicConstRectangle().contains(p, considerTouch);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::contains(const SegmentImpl<T2>& s, 
                             bool considerTouch) const {
  return contains(s.low(), considerTouch) & 
    contains(s.high(), considerTouch);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::contains(const Point3DImpl<T2>& p, 
                             bool considerTouch) const {
  return mimicConstRectangle().contains(PointImpl<PointData>(p.x(), p.y()),
                                        considerTouch) & layersMatch(p);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::contains(const Segment3DImpl<T2>& s, 
                             bool considerTouch) const {
  return contains(s.low(), considerTouch) & 
    contains(s.high(), considerTouch);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::inside(const LayeredRectImpl<T2>& b, 
                           bool considerTouch) const {
  return layersMatch(b) & mimicConstRectangle().inside(b.mimicConstRectangle(), considerTouch);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::intersects(const LayeredRectImpl<T2>& b, 
                               bool considerTouch) const {
  return layersMatch(b) & 
    mimicConstRectangle().intersects(b.mimicConstRectangle(), considerTouch);
}

/// Check if boundaries of b and `this` intersect
/// if considerTouch is true a boundary in common is considered intersection
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::boundariesIntersect(const LayeredRectImpl<T2>& b, 
                                        bool considerTouch) const {
  return layersMatch(b) & 
    mimicConstRectangle().boundariesIntersect(b.mimicConstRectangle(), considerTouch);
}
    
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::abuts(const LayeredRectImpl<T2>& b, Direction2D dir) const {
  return layersMatch(b) & mimicConstRectangle().abuts(b.mimicConstRectangle(), dir);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::abuts(const LayeredRectImpl<T2>& b, Orientation2D orient) const {
  return layersMatch(b) & mimicConstRectangle().abuts(b.mimicConstRectangle(), orient);
}

template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::abuts(const LayeredRectImpl<T2>& b) const {
  return layersMatch(b) & mimicConstRectangle().abuts(b.mimicConstRectangle());
} 

/// set the range of 'this' specified by orient to between its
/// intersection with Interval b
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::intersectRange(const IntervalImpl<T2>& b, 
                                   Orientation2D orient, 
                                   bool considerTouch) {
  return mimicRectangle().intersectRange(b, orient, considerTouch);
}

/// clip `this` LayeredRect to the specified LayeredRect
/// if considerTouch is true will clip to a zero area rectangle if 
/// appropriate
/// if 'this' does not intersect b, leave 'this' unchanged and return false
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::intersect(const LayeredRectImpl<T2>& b, 
                              bool considerTouch) {
  //note intentional usage of && instead of &
  return layersMatch(b) && mimicRectangle().intersect(b.mimicConstRectangle(), considerTouch);
}

/// set `t` Rectangle to the intersection between b1 and b2
/// if such and intersection exists, else set 'this' to b1 and return false
template<class T> template<class T2, class T3>
inline bool 
LayeredRectImpl<T>::intersection(const LayeredRectImpl<T2>& b1, 
                                 const LayeredRectImpl<T3>& b2,
                                 bool considerTouch) {
  this = b1;
  return intersect(b2, considerTouch);
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::bloat(Orientation2D orient, UnsignedUnit bloating) { 
  mimicRectangle().bloat(orient, bloating);
  return *this;
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::bloat(UnsignedUnit bloating) {
  mimicRectangle().bloat(bloating);
  return *this;
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::bloat(Direction2D dir, UnsignedUnit bloating) { 
  mimicRectangle().bloat(dir, bloating);
  return *this;
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::shrink(Orientation2D orient, UnsignedUnit shrinking) {
  mimicRectangle().shrink(orient, shrinking);
  return *this;
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::shrink(UnsignedUnit shrinking) {
  mimicRectangle().shrink(shrinking);
  return *this;
}

template<class T>
inline LayeredRectImpl<T>& 
LayeredRectImpl<T>::shrink(Direction2D dir, UnsignedUnit shrinking) { 
  mimicRectangle().shrink(dir, shrinking);
  return *this;
}

/// enlarge 'this' LayeredRect to encompass the Interval b on the
/// orientation orient
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::encompass(const IntervalImpl<T2>& b, Orientation2D orient) {
  return mimicRectangle().encompass(b, orient);
}

/// enlarge `this` LayeredRect to encompass the LayeredRect b
/// return true of the enlargement happened at all
template<class T> template<class T2>
inline bool 
LayeredRectImpl<T>::encompass(const LayeredRectImpl<T2>& b) {
  //note intentional usage of && instead of &
  return layersMatch(b) && mimicRectangle().encompass(b.mimicConstRectangle());
}    

//private functions
template<class T>
inline IntervalData 
LayeredRectImpl<T>::get_(Orientation2D orient) const {
  return RectangleInterface<T>::RectangleGet(*this, orient);
}

template<class T>
inline void 
LayeredRectImpl<T>::set_(Orientation2D orient, const IntervalImpl<IntervalData>& value) {
  RectangleInterface<T>::RectangleSet(*this, orient, value.yieldConst());
}

template<class T>
inline Unit 
LayeredRectImpl<T>::getLayer_() const {
  return LayeredRectInterface<T>::LayeredRectGetL(*this);
}

template<class T>
inline void 
LayeredRectImpl<T>::setLayer_(Unit value) {
  LayeredRectInterface<T>::LayeredRectSetL(*this, value);
}

template<class T>
inline T
LayeredRectImpl<T>::construct_(const RectangleImpl<RectangleData>& rect, Unit layer) {
  return LayeredRectInterface<T>::LayeredRectConstruct(rect.yieldConst(), layer);
}


template<class T>
std::ostream& operator<< (std::ostream& o, const LayeredRectImpl<T>& r)
{
  o << (Rectangle)r << GTL_SEP << r.layer();
  return o;
}

template<class T>
std::istream& operator>> (std::istream& i, LayeredRectImpl<T>& r)
{
  Rectangle rr;
  Unit l;
  i >> rr >> l;
  r = LayeredRect(rr,l);
  return i;
}
