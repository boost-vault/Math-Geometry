/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// SegmentInterface provides glue to bind SegmentImpl to T
/// SegmentInterface provides access the the data class T through
/// the constructor, get and set API, nearly minimal and sufficient
template <class T>
class SegmentInterface {
public:
  /// get an end point of the segment depending on dir
  static inline PointData SegmentGet(const T& t, Direction1D dir);

  /// set an end point of the segment to value depending on dir
  static inline void SegmentSet(T& t, Direction1D dir, const PointData& value);

  /// get the orientation of the segment
  static inline Orientation2D SegmentGetOrient(const T& t);

  /// set the orientation of the segment
  static inline void SegmentSetOrient(const T& t, Orientation2D orient);

  /// get the length of the segment
  static inline UnsignedUnit SegmentGetLength(const T& t);

  /// set the length of the segment
  static inline void SegmentSetLength(T& t, UnsignedUnit value);

  /// construct segment of type T from low end point p, orientation and lenth
  static inline T SegmentConstruct(const PointData& p, Orientation2D o, UnsignedUnit length);

private:
  //disallow construction
  SegmentInterface();
};

/// partial specialization of SegmentInterface for T of type SegmentData
template <>
class SegmentInterface<SegmentData> {
public:
  static inline PointData SegmentGet(const SegmentData& t, Direction1D dir) {
    return t.get(dir);
  }
  static inline void SegmentSet(SegmentData& t, Direction1D dir, const PointData& value) {
    t.set(dir, value);
  }
  static inline Orientation2D SegmentGetOrient(const SegmentData& t) {
    return t.getOrient();
  }
  static inline void SegmentSetOrient(SegmentData& t, Orientation2D orient) {
    t.setOrient(orient);
  }
  static inline UnsignedUnit SegmentGetLength(const SegmentData& t) {
    return t.getLength();
  }
  static inline void SegmentSetLength(SegmentData& t, UnsignedUnit value) {
    t.setLength(value);
  }
  static inline SegmentData SegmentConstruct(const PointData& p, Orientation2D o, UnsignedUnit length) {
    return SegmentData(p, o, length);
  }

private:
  //disallow construction
  SegmentInterface() {;}
};

