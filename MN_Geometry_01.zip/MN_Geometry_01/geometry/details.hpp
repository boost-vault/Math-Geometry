// ============================================================================
// details.hpp                                    (C)2005 Michael Andersen Nexo
// ============================================================================
// Header file included from geometry.hpp
// Defines helper functions for implementing for vector, point and range:
//
// assign(base<R,D>& base<S,D> const&);
// assign(base<R,D>& base<S,D> const&, OP);
// equal(base<R,D> const& base<S,D> const&);
//
// All the function templates are specialized with loop unrolling for D<=3

#ifndef DETAILS_HPP_INCLUDED
#define DETAILS_HPP_INCLUDED

namespace geom
{
	// Forward declarations
	template <class R, std::size_t D> class base;
	template <class T, std::size_t D, class R> class point;
	template <class T, std::size_t D, class R> class vector;
	template <class T, std::size_t D, class R> class range;

	namespace detail
	{
		// --------------------------------------------------------------------
		// Simple assignment: l = r
		// --------------------------------------------------------------------
		template <class R, class S, std::size_t D> 
		inline void assign(base<R,D>& l, base<S,D> const& r)
		{
			std::copy(r.begin(), r.end(), l.begin());
		}

		template <class R, class S>
		inline void assign(base<R,2>& l, base<S,2> const& r)
		{
			l.x()=r.x(); l.y()=r.y();
		}

		template <class R, class S>
		inline void assign(base<R,3>& l, base<S,3> const& r)
		{
			l.x()=r.x(); l.y()=r.y(); l.z()=r.z();
		}

		// --------------------------------------------------------------------
		// Assignment with operation: l = op(l,r)
		// --------------------------------------------------------------------
		template <class R, class S, std::size_t D, class OP>
		inline void assign(base<R,D>& l, const base<S,D>& r, OP op)
		{
			typedef typename base<R,D>::iterator iter;
			typedef typename base<S,D>::const_iterator const_iter;
			iter lend(l.end());
			const_iter ri(r.begin());
			for (iter li(l.begin()); li != lend; ++li, ++ri)
                *li = op(*li, *ri);
		}

		template <class R, class S, class OP>
		inline void assign(base<R,2>& l, const base<S,2>& r, OP op)
		{
			l.x()=op(l.x(),r.x()); l.y()=op(l.y(),r.y()); 
		}

		template <class R, class S, class OP>
		inline void assign(base<R,3>& l, const base<S,3>& r, OP op)
		{
			l.x()=op(l.x(),r.x()); l.y()=op(l.y(),r.y()); l.z()=op(l.x(),r.y());
		}

		// --------------------------------------------------------------------
		// Equality: l == r
		// --------------------------------------------------------------------
		template <class R, class S, std::size_t D>
		inline bool equal(base<R,D> const& l, base<S,D> const& r)
		{
			return std::equal(l.begin(), l.end(), r.begin());
		}

		template <class R, class S>
		inline bool equal(base<R,2> const& l, base<S,2> const& r)
		{
			return l.x()==r.x() && l.y()==r.y();
		}

		template <class R, class S>
		inline bool equal(base<R,3> const& l, base<S,3> const& r)
		{
			return l.x()==r.x() && l.y()==r.y() && l.z()==r.z();
		}
	}
}

#endif //DETAILS_HPP_INCLUDED
