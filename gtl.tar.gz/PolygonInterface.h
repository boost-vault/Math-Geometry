/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Winding Directions
class WindingDirection {
private:
   enum WINDING_DIRECTION {
      COUNTERCLOCKWISE = 0,
      CLOCKWISE = 1,
      UNKNOWN = 2
   };
   int val_;
   inline WindingDirection(WINDING_DIRECTION dir) : val_(dir) {}
public:
   inline WindingDirection() : val_(UNKNOWN) {}
   inline WindingDirection(const WindingDirection& that) : val_(that.val_) {}
   inline WindingDirection(bool clockwise) { val_ = predicated_value(clockwise, CLOCKWISE,
                                                                     COUNTERCLOCKWISE); }
   inline bool operator==(const WindingDirection& that) const { return val_ == that.val_; }
   inline bool operator!=(const WindingDirection& that) const { return val_ != that.val_; }
   static inline WindingDirection unknown() { return WindingDirection(UNKNOWN); }
   static inline WindingDirection clockwise() { return WindingDirection(CLOCKWISE); }
   static inline WindingDirection counterClockwise() { 
      return WindingDirection(COUNTERCLOCKWISE); }
   inline WindingDirection& reverse() { 
      val_ = predicated_value(val_ == (int)UNKNOWN, 2, val_ ^ 1);
      return *this;
   }
};
   
/// PolygonInterface provides glue to bind PolygonImpl to T

/// PolygonInterface provides access the the data class T through
/// the get and set API, which are minimal and sufficient.
template <class T>
class PolygonInterface {
public:

   typedef typename T::iterator iterator;

   /// Get the begin iterator
   static inline iterator PolygonBegin(const T& t) {
      return t.begin();
   }

   /// Get the end iterator
   static inline iterator PolygonEnd(const T& t) {
      return t.end();
   }

   /// Set the data of a polygon with the unique coordinates in an iterator, starting with an x
   template <class iT>
   static inline T& PolygonSet(T& t, iT inputBegin, iT inputEnd) {
      t.set(inputBegin, inputEnd);
      return t;
   }

   /// Get the number of sides of the polygon
   static inline unsigned int PolygonSize(const T& t) {
      return t.size();
   }

   /// Get the winding direction of the polygon
   static inline WindingDirection PolygonWinding(const T& t) {
      return WindingDirection::unknown();
   }

private:
   //disallow construction
   PolygonInterface();
};
