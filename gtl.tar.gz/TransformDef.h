/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
inline std::ostream& operator<< (std::ostream& o, const AxisTransform& r) {
  o << r.atr_;
  return o;
}

inline std::istream& operator>> (std::istream& i, AxisTransform& r) {
  int tmp;
  i >> tmp;
  r = AxisTransform((AxisTransform::ATR)tmp);
  return i;
}

inline std::ostream& operator<< (std::ostream& o, const Scale& sc) {
  o << sc.scale_[0] << GTL_SEP << sc.scale_[1] << GTL_SEP << sc.scale_[2];
  return o;
}

inline std::istream& operator>> (std::istream& i, Scale& sc) {
  i >> sc.scale_[0] >> sc.scale_[1] >> sc.scale_[2];
  return i;
}

inline std::ostream& operator<< (std::ostream& o, const Transform& tr) {
  o << tr.atr_ << GTL_SEP << tr.p_;
  return o;
}

inline std::istream& operator>> (std::istream& i, Transform& tr) {
  i >> tr.atr_ >> tr.p_;
  return i;
}


inline AxisTransform::AxisTransform(const Orientation3D& orient) {
  const ATR tmp[3] = {
    UP_EAST_NORTH, //sort by x, then z, then y
    EAST_UP_NORTH, //sort by y, then z, then x
    EAST_NORTH_UP  //sort by z, then y, then x
  };
  atr_ = tmp[orient.toInt()];
}
  
inline AxisTransform::AxisTransform(const Orientation2D& orient) {
  const ATR tmp[3] = {
    NORTH_EAST_UP, //sort by z, then x, then y
    EAST_NORTH_UP  //sort by z, then y, then x
  };
  atr_ = tmp[orient.toInt()];
}
  
inline AxisTransform::AxisTransform(const Direction3D& dir) {
  const ATR tmp[6] = {
    DOWN_EAST_NORTH, //sort by -x, then z, then y
    UP_EAST_NORTH,   //sort by x, then z, then y
    EAST_DOWN_NORTH, //sort by -y, then z, then x
    EAST_UP_NORTH,   //sort by y, then z, then x
    EAST_NORTH_DOWN, //sort by -z, then y, then x
    EAST_NORTH_UP    //sort by z, then y, then x
  };
  atr_ = tmp[dir.toInt()];
}
  
inline AxisTransform::AxisTransform(const Direction2D& dir) {
  const ATR tmp[4] = {
    SOUTH_EAST_UP, //sort by z, then x, then y
    NORTH_EAST_UP, //sort by z, then x, then y
    EAST_SOUTH_UP, //sort by z, then y, then x
    EAST_NORTH_UP  //sort by z, then y, then x
  };
  atr_ = tmp[dir.toInt()];
}
  
inline const AxisTransform& AxisTransform::operator=(const AxisTransform& a) {
  atr_ = a.atr_;
  return *this;
}

inline const AxisTransform& AxisTransform::operator=(const ATR& atr) {
  atr_ = atr;
  return *this;
}

inline bool AxisTransform::operator==(const AxisTransform& a) const {
  return atr_ == a.atr_;
}

inline bool AxisTransform::operator!=(const AxisTransform& a) const {
  return !(*this == a);
}

inline bool AxisTransform::operator<(const AxisTransform& a) const {
  return atr_ < a.atr_;
}

inline AxisTransform AxisTransform::operator+(const AxisTransform& a) const {
  AxisTransform retval(*this);
  return retval+=a;
}
  
inline AxisTransform& AxisTransform::operator+=(const AxisTransform& a){
  bool abit5 = a.atr_ & 32;
  bool abit4 = a.atr_ & 16;
  bool abit3 = a.atr_ & 8;
  bool abit2 = a.atr_ & 4;
  bool abit1 = a.atr_ & 2;
  bool abit0 = a.atr_ & 1;      
  bool bit5 = atr_ & 32;
  bool bit4 = atr_ & 16;
  bool bit3 = atr_ & 8;
  bool bit2 = atr_ & 4;
  bool bit1 = atr_ & 2;
  bool bit0 = atr_ & 1;      
  int indexes[2][3] = {
    {
      ((int)((bit5 & bit2) | (bit4 & !bit2)) << 1) +
      (int)(bit2 & !bit5),
      ((int)((bit4 & bit2) | (bit5 & !bit2)) << 1) +
      (int)(!bit5 & !bit2),
      ((int)(!bit4 & !bit5) << 1) +
      (int)(bit5) 
    },
    {
      ((int)((abit5 & abit2) | (abit4 & !abit2)) << 1) +
      (int)(abit2 & !abit5),
      ((int)((abit4 & abit2) | (abit5 & !abit2)) << 1) +
      (int)(!abit5 & !abit2),
      ((int)(!abit4 & !abit5) << 1) +
      (int)(abit5) 
    }
  };
  int zero_bits[2][3] = {
    {bit0, bit1, bit3},
    {abit0, abit1, abit3}
  };
  int nbit3 = zero_bits[0][2] ^ zero_bits[1][indexes[0][2]];
  int nbit1 = zero_bits[0][1] ^ zero_bits[1][indexes[0][1]];
  int nbit0 = zero_bits[0][0] ^ zero_bits[1][indexes[0][0]];
  indexes[0][0] = indexes[1][indexes[0][0]];
  indexes[0][1] = indexes[1][indexes[0][1]];
  indexes[0][2] = indexes[1][indexes[0][2]];
  int nbit5 = (indexes[0][2] == 1);
  int nbit4 = (indexes[0][2] == 0);
  int nbit2 = (!(nbit5 | nbit4) & (bool)(indexes[0][0] & 1)) | //swap xy
    (nbit5 & ((indexes[0][0] & 2) >> 1)) | //z->y x->z
    (nbit4 & ((indexes[0][1] & 2) >> 1));  //z->x y->z
  atr_ = (ATR)((nbit5 << 5) + 
               (nbit4 << 4) + 
               (nbit3 << 3) + 
               (nbit2 << 2) + 
               (nbit1 << 1) + nbit0);
  return *this;
}
  
// populate_axis_array writes the three INDIVIDUAL_AXIS values that the
// ATR enum value of 'this' represent into axis_array
inline void AxisTransform::populate_axis_array(INDIVIDUAL_AXIS axis_array[]) const {
  bool bit5 = atr_ & 32;
  bool bit4 = atr_ & 16;
  bool bit3 = atr_ & 8;
  bool bit2 = atr_ & 4;
  bool bit1 = atr_ & 2;
  bool bit0 = atr_ & 1;      
  axis_array[2] = 
    (INDIVIDUAL_AXIS)((((int)(!bit4 & !bit5)) << 2) +
                      ((int)(bit5) << 1) + 
                      bit3);
  axis_array[1] = 
    (INDIVIDUAL_AXIS)((((int)((bit4 & bit2) | (bit5 & !bit2))) << 2)+
                      ((int)(!bit5 & !bit2) << 1) + 
                      bit1);
  axis_array[0] = 
    (INDIVIDUAL_AXIS)((((int)((bit5 & bit2) | (bit4 & !bit2))) << 2) +
                      ((int)(bit2 & !bit5) << 1) + 
                      bit0);
}
  
// it is recommended that the directions stored in an array
// in the caller code for easier isotropic access by orientation value
//   inline void AxisTransform::getDirections(Direction2D& horizontalDir,
//                                            Direction2D& verticalDir) const {
//     bool bit2 = atr_ & 4;
//     bool bit1 = atr_ & 2;
//     bool bit0 = atr_ & 1;      
//     verticalDir = Direction2D(((int)(!bit2) << 1) + !bit1);
//     horizontalDir = Direction2D(((int)(bit2) << 1) + !bit0);
//   }
  
// it is recommended that the directions stored in an array
// in the caller code for easier isotropic access by orientation value
//   inline void AxisTransform::getDirections(Direction3D& horizontalDir,
//                             Direction3D& verticalDir,
//                             Direction3D& proximalDir) const {
//     bool bit5 = atr_ & 32;
//     bool bit4 = atr_ & 16;
//     bool bit3 = atr_ & 8;
//     bool bit2 = atr_ & 4;
//     bool bit1 = atr_ & 2;
//     bool bit0 = atr_ & 1;      
//     proximalDir = Direction3D((((int)(!bit4 & !bit5)) << 2) +
//                               ((int)(bit5) << 1) + 
//                               !bit3);
//     verticalDir = Direction3D((((int)((bit4 & bit2) | (bit5 & !bit2))) << 2)+
//                               ((int)(!bit5 & !bit2) << 1) + 
//                               !bit1);
//     horizontalDir = Direction3D((((int)((bit5 & bit2) | 
//                                         (bit4 & !bit2))) << 2) +
//                                 ((int)(bit2 & !bit5) << 1) + 
//                                 !bit0);
//   }
  
// combine_axis_arrays concatenates this_array and that_array overwriting
// the result into this_array
inline void 
AxisTransform::combine_axis_arrays (INDIVIDUAL_AXIS this_array[],
                                    const INDIVIDUAL_AXIS that_array[]){
  int indexes[3] = {this_array[0] >> 1,
                    this_array[1] >> 1,
                    this_array[2] >> 1};
  int zero_bits[2][3] = {
    {this_array[0] & 1, this_array[1] & 1, this_array[2] & 1},
    {that_array[0] & 1, that_array[1] & 1, that_array[2] & 1}
  };
  this_array[0] = that_array[indexes[0]];
  this_array[0] = (INDIVIDUAL_AXIS)((int)this_array[0] & (int)((int)PZ+(int)PY));
  this_array[0] = (INDIVIDUAL_AXIS)((int)this_array[0] | 
                                    ((int)zero_bits[0][0] ^ 
                                     (int)zero_bits[1][indexes[0]]));
  this_array[1] = that_array[indexes[1]];
  this_array[1] = (INDIVIDUAL_AXIS)((int)this_array[1] & (int)((int)PZ+(int)PY));
  this_array[1] = (INDIVIDUAL_AXIS)((int)this_array[1] | 
                                    ((int)zero_bits[0][1] ^ 
                                     (int)zero_bits[1][indexes[1]]));
  this_array[2] = that_array[indexes[2]];
  this_array[2] = (INDIVIDUAL_AXIS)((int)this_array[2] & (int)((int)PZ+(int)PY));
  this_array[2] = (INDIVIDUAL_AXIS)((int)this_array[2] | 
                                    ((int)zero_bits[0][2] ^ 
                                     (int)zero_bits[1][indexes[2]]));
}
  
// write_back_axis_array converts an array of three INDIVIDUAL_AXIS values
// to the ATR enum value and sets 'this' to that value
inline void AxisTransform::write_back_axis_array(const INDIVIDUAL_AXIS this_array[]) {
  int bit5 = (bool)((int)this_array[2] & 2);
  int bit4 = !((bool)((int)this_array[2] & 4) | (bool)((int)this_array[2] & 2));
  int bit3 = (bool)((int)this_array[2] & 1);
  //bit 2 is the tricky bit
  int bit2 = (!(bit5 | bit4) & (bool)((int)this_array[0] & 2)) | //swap xy
    (bit5 & (((int)this_array[0] & 4) >> 2)) | //z->y x->z
    (bit4 & (((int)this_array[1] & 4) >> 2));  //z->x y->z
  int bit1 = ((int)this_array[1] & 1);
  int bit0 = ((int)this_array[0] & 1);
  atr_ = ATR((bit5 << 5) + 
             (bit4 << 4) + 
             (bit3 << 3) + 
             (bit2 << 2) + 
             (bit1 << 1) + bit0);
}
  
// behavior is deterministic but undefined in the case where illegal
// combinations of directions are passed in. 
inline AxisTransform& 
AxisTransform::setDirections(const Direction2D& horizontalDir,
                             const Direction2D& verticalDir){
  int bit2 = bool(static_cast<Orientation2D>(horizontalDir).toInt());
  int bit1 = !(verticalDir.toInt() & 1);
  int bit0 = !(horizontalDir.toInt() & 1);
  atr_ = ATR((bit2 << 2) + (bit1 << 1) + bit0);
  return *this;
}
  
// behavior is deterministic but undefined in the case where illegal
// combinations of directions are passed in.
inline AxisTransform& AxisTransform::setDirections(const Direction3D& horizontalDir,
                                                   const Direction3D& verticalDir,
                                                   const Direction3D& proximalDir){
  int this_array[3] = {horizontalDir.toInt(),
                       verticalDir.toInt(),
                       proximalDir.toInt()};
  int bit5 = (bool)(this_array[2] & 2);
  int bit4 = !((bool)(this_array[2] & 4) | (bool)(this_array[2] & 2));
  int bit3 = !(bool)(this_array[2] & 1);
  //bit 2 is the tricky bit
  int bit2 = (!(bit5 | bit4) & (bool)(this_array[0] & 2)) | //swap xy
    (bit5 & ((this_array[0] & 4) >> 2)) | //z->y x->z
    (bit4 & ((this_array[1] & 4) >> 2));  //z->x y->z
  int bit1 = !(this_array[1] & 1);
  int bit0 = !(this_array[0] & 1);
  atr_ = ATR((bit5 << 5) + 
             (bit4 << 4) + 
             (bit3 << 3) + 
             (bit2 << 2) + 
             (bit1 << 1) + bit0);
  return *this;
}
  
inline void AxisTransform::transform2D(Unit& x, Unit& y) const {
  int bit2 = (bool)(atr_ & 4);
  int bit1 = (bool)(atr_ & 2);
  int bit0 = (bool)(atr_ & 1);
  x *= -((bit0 << 1) - 1);
  y *= -((bit1 << 1) - 1);    
  predicated_swap(bit2,x,y);
}
  
template <class T>
inline void AxisTransform::transform2D(PointImpl<T>& p) const {
  Unit x = p.x();
  Unit y = p.y();
  transform2D(x,y);
  p.x(x);
  p.y(y);
}

inline void AxisTransform::transform(Unit& x, Unit& y, Unit& z) const {
  int bit5 = (bool)(atr_ & 32);
  int bit4 = (bool)(atr_ & 16);
  int bit3 = (bool)(atr_ & 8);
  int bit2 = (bool)(atr_ & 4);
  int bit1 = (bool)(atr_ & 2);
  int bit0 = (bool)(atr_ & 1);
  x *= -((bit0 << 1) - 1);
  y *= -((bit1 << 1) - 1);    
  z *= -((bit3 << 1) - 1);
  predicated_swap(bit2, x, y);
  predicated_swap(bit5, y, z);
  predicated_swap(bit4, x, z);
}
  
template <class T>
inline void AxisTransform::transform(Point3DImpl<T>& p) const {
  Unit x = p.x();
  Unit y = p.y();
  Unit z = p.z();
  transform(x,y,z);
  p.x(x);
  p.y(y);
  p.z(z);
}

inline AxisTransform& AxisTransform::invert2D() {
  int bit2 = (bool)(atr_ & 4);
  int bit1 = (bool)(atr_ & 2);
  int bit0 = (bool)(atr_ & 1);
  //swap bit 0 and bit 1 if bit2 is 1
  predicated_swap(bit2, bit0, bit1);
  bit1 = bit1 << 1;
  atr_ = (ATR)(atr_ & (32+16+8+4)); //mask away bit0 and bit1
  atr_ = (ATR)(atr_ | bit0 | bit1);
  return *this;
}
  
inline AxisTransform AxisTransform::inverse2D() const {
  AxisTransform retval(*this);
  return retval.invert();
}
  
inline AxisTransform& AxisTransform::invert() {
  int bit5 = (bool)(atr_ & 32);
  int bit4 = (bool)(atr_ & 16);    
  int bit3 = (bool)(atr_ & 8);
  int bit2 = (bool)(atr_ & 4);
  int bit1 = (bool)(atr_ & 2);
  int bit0 = (bool)(atr_ & 1);
  predicated_swap(bit2, bit4, bit5);
  predicated_swap(bit4, bit0, bit3);
  predicated_swap(bit5, bit1, bit3);
  predicated_swap(bit2, bit0, bit1);
  atr_ = (ATR)((bit5 << 5) + 
               (bit4 << 4) + 
               (bit3 << 3) + 
               (bit2 << 2) + 
               (bit1 << 1) + bit0);
  return *this;
}
  
inline AxisTransform AxisTransform::inverse() const {
  AxisTransform retval(*this);
  return retval.invert();
}
  
inline double Scale::get(Orientation3D orient) const {
  return scale_[orient.toInt()];
}
  
inline void Scale::set(Orientation3D orient, double value) {
  scale_[orient.toInt()] = value;
}

inline double Scale::x() const { return scale_[HORIZONTAL]; }
inline double Scale::y() const { return scale_[VERTICAL]; }
inline double Scale::z() const { return scale_[PROXIMAL]; }
inline void Scale::x(double value) { scale_[HORIZONTAL] = value; }
inline void Scale::y(double value) { scale_[VERTICAL] = value; }
inline void Scale::z(double value) { scale_[PROXIMAL] = value; }
  
//concatenation operator (convolve scale factors)
inline Scale Scale::operator+(const Scale& s) const {
  Scale retval(*this);
  return retval+=s;
}
  
//concatenate this with that
inline const Scale& Scale::operator+=(const Scale& s){
  scale_[0] *= s.scale_[0];
  scale_[1] *= s.scale_[1];
  scale_[2] *= s.scale_[2];
  return *this;
}
  
//transform
inline Scale& Scale::transform(AxisTransform atr){
  Direction3D dirs[3];
  atr.getDirections(dirs[0],dirs[1],dirs[2]);
  double tmp[3] = {scale_[0], scale_[1], scale_[2]};
  for(int i = 0; i < 3; ++i){
    scale_[Orientation3D(dirs[i]).toInt()] = tmp[i];
  }
  return *this;
}

inline void Scale::scale2D(Unit& x, Unit& y) const {
  x = round(x * get(HORIZONTAL));
  y = round(y * get(VERTICAL));
}

inline void Scale::scale(Unit& x, Unit& y, Unit& z) const {
  scale2D(x, y);
  z = round(z * get(PROXIMAL));
}

inline Scale& Scale::invert() {
  x(1/x());
  y(1/y());
  z(1/z());
  return *this;
}


inline Transform::Transform() : p_(0, 0, 0) {;}

inline Transform::Transform(AxisTransform atr) : atr_(atr), p_(0, 0, 0){;}

inline Transform::Transform(Point p) : p_(p.x(),p.y(),0){;}

inline Transform::Transform(AxisTransform atr, Point p) :
  atr_(atr),p_(p.x(), p.y(), 0){;}

inline Transform::Transform(Point3D p) : p_(p){;}

inline Transform::Transform(AxisTransform atr, Point3D p) : atr_(atr), p_(p){;}

inline Transform::Transform(AxisTransform atr, Point referencePt, Point destinationPt) {
   (*this) = Transform(atr, Point3D(referencePt.x(), referencePt.y(), 0), 
                       Point3D(destinationPt.x(), destinationPt.y(), 0));
}

inline Transform::Transform(AxisTransform atr, Point3D referencePt, Point3D destinationPt) {
   Transform tmp(referencePt);
   Transform rotRef(atr);
   Transform tmpInverse = tmp.inverse();
   Transform displacement(Point3D(referencePt.x() - destinationPt.x(),
                                  referencePt.y() - destinationPt.y(),
                                  referencePt.z() - destinationPt.z()));
   tmp += rotRef;
   tmp += tmpInverse;
   tmp += displacement;
   (*this) = tmp;
}

inline Transform::Transform(const Transform& tr) : 
  atr_(tr.atr_), p_(tr.p_) {;}
  
inline bool Transform::operator==(const Transform& tr) const {
  return atr_ == tr.atr_ && p_ == tr.p_;
}
  
inline bool Transform::operator!=(const Transform& tr) const {
  return !(*this == tr);
}
  
inline bool Transform::operator<(const Transform& tr) const {
  return atr_ < tr.atr_ || atr_ == tr.atr_ && p_ < tr.p_;
}
  
inline Transform Transform::operator+(const Transform& tr) const {
  Transform retval(*this);
  return retval+=tr;
}
  
inline const Transform& Transform::operator+=(const Transform& tr){
  //apply the inverse transform of this to the translation point of that
  Point3D tmpPt(tr.p_);
  p_ += tmpPt.transform(inverse()); //and convolve it with this translation point
  //concatenate axis transforms
  atr_ += tr.atr_;
  return *this;
}
  
inline void Transform::setAxisTransform(const AxisTransform& atr) {
  atr_ = atr;
}
  
inline Point3D Transform::getTranslation() const {
  return p_;
}
  
inline void Transform::setTranslation(const Point3D& p) {
  p_ = p;
}
  
inline void Transform::transform2D(Unit& x, Unit& y) const {
  //subtract each component of new origin point
  y -= p_.y();
  x -= p_.x();
  atr_.transform2D(x, y);
}

template <class T>
inline void Transform::transform2D(PointImpl<T>& p) const {
  Unit x = p.x();
  Unit y = p.y();
  transform2D(x,y);
  p.x(x);
  p.y(y);
}
  
inline void Transform::transform(Unit& x, Unit& y, Unit& z) const {
  //subtract each component of new origin point
  z -= p_.z();
  y -= p_.y();
  x -= p_.x();
  atr_.transform(x,y,z);
}
  
template <class T>
inline void Transform::transform(Point3DImpl<T>& p) const {
  Unit x = p.x();
  Unit y = p.y();
  Unit z = p.z();
  transform(x,y,z);
  p.x(x);
  p.y(y);
  p.z(z);
}
  
/// sets the AxisTransform portion to its inverse
/// transforms the tranlastion portion by that inverse AxisTransform
/// multiplies the translation portion by -1 to reverse it
inline Transform& Transform::invert() {
  Unit x = p_.x(), y = p_.y(), z = p_.z();
  atr_.transform(x, y, z);
  x *= -1;
  y *= -1;
  z *= -1;
  p_ = Point3D(x, y, z);
  atr_.invert();
  return *this;
}
  
inline Transform Transform::inverse() const {
  Transform retval(*this);
  return retval.invert();
}
