/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template<class T>
class Polygon45WithHolesImpl;

template <class T>
class Polygon45Impl : public T{
public:

  typedef typename Polygon45Interface<T>::iterator iterator;

  /// get a reference of Polygon45Impl type given a data object
  static inline Polygon45Impl& mimic(T& t) { return static_cast<Polygon45Impl&>(t); }

  /// get a reference of Polygon45Impl type given a data object
  static inline const Polygon45Impl& mimicConst(const T& t) { 
    return static_cast<const Polygon45Impl&>(t); }

  /// construct a polygon from an iterator over unique x and y values
  template<class iT>
  inline Polygon45Impl(iT inputBegin, iT inputEnd) { set(inputBegin, inputEnd); }

  /// default constructor
  inline Polygon45Impl() {}

  /// assignment operator
  template <class T2>
  inline Polygon45Impl& operator=(const Polygon45WithHolesImpl<T2>& that);  

  /// assignment operator
  template <class T2>
  inline Polygon45Impl& operator=(const Polygon45Impl<T2>& that) { 
     set(that.begin(), that.end()); return *this;}

  /// assignment operator
   inline Polygon45Impl& operator=(const Polygon45Impl<T>& that) { yield() = that; return *this; }

   /// copy constructor
   template <class T2>
   inline Polygon45Impl(const Polygon45WithHolesImpl<T2>& that); 

   /// copy constructor
   template <class T2>
   inline Polygon45Impl(const Polygon45Impl<T2>& that) { set(that.begin(), that.end()); }

  /// copy constructor
  inline Polygon45Impl(const T& that) : T(that) {;}

  /// equivilence operator
  template <class T2>
  inline bool operator==(const Polygon45Impl<T2>& that) const { 
     iterator itr1 = begin();
     iterator itr2 = that.begin();
     while(itr1 != end() && itr2 != that.end()) {
        if((*itr1) != (*itr2)) return false;
        ++itr1;
        ++itr2;
     }
     return itr1 == end() && itr2 == that.end();
  }

  /// inequivilence operator
  template <class T2>
  inline bool operator!=(const Polygon45Impl<T2>& that) { return !((*this) == that); }

  /// yield payload
  inline T& yield() { return *this; }

  /// yield const payload
  inline const T& yieldConst() const { return *this; }

  /// set with coordinates
  template<class iT>
  inline Polygon45Impl& set(iT inputBegin, iT inputEnd) {
     set_(inputBegin, inputEnd);
     return *this;
  }

   inline iterator begin() const {
      return begin_();
   }

   inline iterator end() const {
      return end_();
   }

   inline std::size_t size() const {
      return size_();
   }

  inline double area() const {
    double a = point_sequence_area(begin(), end());
    if(a < 0) a *= -1;
    return a;
  }

  inline Direction1D winding() const {
    WindingDirection wd = winding_();
    if(wd != WindingDirection::unknown()) {
      return predicated_value(wd == WindingDirection::clockwise(),
                              LOW, HIGH);
    }
    return point_sequence_area(begin(), end()) < 0 ? HIGH : LOW;
  }

   inline Rectangle boundingBox() const {
      Unit xmin = UnitMax;
      Unit ymin = UnitMax;
      Unit xmax = UnitMin;
      Unit ymax = UnitMin;
      for(iterator itr = begin(); itr != end(); ++itr) {
         PointImpl<PointData> pt = *itr;
         xmin = min(xmin, pt.x());
         xmax = max(xmax, pt.x());
         ymin = min(ymin, pt.y());
         ymax = max(ymax, pt.y());
      }
      return Rectangle(xmin, ymin, xmax, ymax);
   }

   inline Polygon45Impl& move(Unit xDisplacement, Unit yDisplacement) {
      std::vector<Point> points;
      points.reserve(size());
      for(iterator iter = begin(); iter != end(); ++iter) {
        points.push_back((*iter) + Point(xDisplacement, yDisplacement));
      }
      return set(points.begin(), points.end());
   }

   /// move polygon by delta in orient
   inline Polygon45Impl& move(Orientation2D orient, Unit delta) {
      if(orient == HORIZONTAL) {
         return move(delta, 0);
      }
      return move(0, delta);
   }

   /// transform polygon
  inline Polygon45Impl& transform(const AxisTransform& atr) {
    std::vector<Point> pts;
    pts.reserve(size());
    for(iterator iter = begin(); iter != end(); ++iter) {
      pts.push_back(*iter);
      pts.back().transform(atr);
    }
    return set(pts.begin(), pts.end());
  }
    
  /// transform polygon
  inline Polygon45Impl& transform(const Transform& tr) {
    std::vector<Point> pts;
    pts.reserve(size());
    for(iterator iter = begin(); iter != end(); ++iter) {
      pts.push_back(*iter);
      pts.back().transform(tr);
    }
    return set(pts.begin(), pts.end());
  }

  inline Polygon45Impl& scaleUp(UnsignedUnit factor) {
    std::vector<Point> pts;
    pts.reserve(size());
    for(iterator iter = begin(); iter != end(); ++iter) {
      pts.push_back(*iter); 
      pts.back().scaleUp(factor);
    }
    set(pts.begin(), pts.end());
    return *this;
  }

   /// move polygon by delta in orient
  inline Polygon45Impl& scaleDown(UnsignedUnit factor) {
    std::vector<Point> pts;
    pts.reserve(size());
    for(iterator iter = begin(); iter != end(); ++iter) {
      pts.push_back(*iter); 
      pts.back().scaleDown(factor);
    }
    set(pts.begin(), pts.end());
    return snapTo45();
  }

  inline Polygon45Impl& removeZeroLengthEdges() {
    std::vector<Point> pts;
    iterator itr = begin();
    if(itr == end()) return *this;
    Point firstPt = *itr;
    Point prevPt = firstPt;
    pts.push_back(firstPt);
    ++itr;
    while(itr != end()) {
      Point pt = *itr;
      if(pt != prevPt)
        pts.push_back(pt);
      prevPt = pt;
      ++itr;
    }
    if(pts.back() == pts[0]) pts.pop_back();
    return set(pts.begin(), pts.end());
  }

  inline Polygon45Impl& snapTo45() {
    //first remove duplicate points
    std::vector<Point> pts;
    iterator itr = begin();
    if(itr == end()) return *this;
    Point firstPt = *itr;
    Point prevPt = firstPt;
    pts.push_back(firstPt);
    ++itr;
    while(itr != end()) {
      Point pt = *itr;
      if(pt != prevPt)
        pts.push_back(pt);
      prevPt = pt;
      ++itr;
    }
    if(pts.back() == pts[0]) pts.pop_back();
    //iterate over point triplets
    int numPts = pts.size();
    bool wrap_around = false;
    for(int i = 0; i < numPts; ++i) {
      Point& pt1 = pts[i];
      Point& pt2 = pts[(i + 1) % numPts];
      Point& pt3 = pts[(i + 2) % numPts];
      //check if non-45 edge
      Unit deltax = pt2.x() - pt1.x();
      Unit deltay = pt2.y() - pt1.y();
      if(deltax && deltay &&
         abs(deltax) != abs(deltay)) {
        //adjust the middle point
        Unit ndx = pt3.x() - pt2.x();
        Unit ndy = pt3.y() - pt2.y();
        if(ndx && ndy) {
          Unit diff = abs(abs(deltax) - abs(deltay));
          Unit halfdiff = diff/2;
          if(deltax > 0 && deltay > 0 ||
             deltax < 0 && deltay < 0) {
            //previous edge is rising slope
            if(abs(deltax + halfdiff + (diff % 2)) ==
               abs(deltay - halfdiff)) {
              pt2.x(pt2.x() + halfdiff + (diff % 2));
              pt2.y(pt2.y() - halfdiff);
            } else if(abs(deltax - halfdiff - (diff % 2)) ==
                      abs(deltay + halfdiff)) {
              pt2.x(pt2.x() - halfdiff - (diff % 2));
              pt2.y(pt2.y() + halfdiff);
            } else{
              std::cout << "fail1\n";
            }
          } else {
            //previous edge is falling slope
            if(abs(deltax + halfdiff + (diff % 2)) ==
               abs(deltay + halfdiff)) {
              pt2.x(pt2.x() + halfdiff + (diff % 2));
              pt2.y(pt2.y() + halfdiff);
            } else if(abs(deltax - halfdiff - (diff % 2)) ==
                      abs(deltay - halfdiff)) {
              pt2.x(pt2.x() - halfdiff - (diff % 2));
              pt2.y(pt2.y() - halfdiff);
            } else {
              std::cout << "fail2\n";
            }
          }
          if(i == numPts - 1 && (diff % 2)) {
            //we have a wrap around effect
            if(!wrap_around) {
              wrap_around = true;
              i = -1;
            }
          }
        } else if(ndx) {
          //next edge is horizontal
          //find the x value for pt1 that would make the abs(deltax) == abs(deltay)
          Unit newDeltaX = abs(deltay);
          if(deltax < 0) newDeltaX *= -1;
          pt2.x(pt1.x() + newDeltaX);
        } else { //ndy
          //next edge is vertical
          //find the y value for pt1 that would make the abs(deltax) == abs(deltay)
          Unit newDeltaY = abs(deltax);
          if(deltay < 0) newDeltaY *= -1;
          pt2.y(pt1.y() + newDeltaY);
        }
      }
    }
    return set(pts.begin(), pts.end());
  }

  inline bool is45() const {
    iterator itr = begin();
    if(itr == end()) return true;
    Point firstPt = *itr;
    Point prevPt = firstPt;
    ++itr;
    while(itr != end()) {
      Point pt = *itr;
      Unit deltax = pt.x() - prevPt.x();
      Unit deltay = pt.y() - prevPt.y();
      if(deltax && deltay &&
         abs(deltax) != abs(deltay))
        return false;
      prevPt = pt;
      ++itr;
    }
    Unit deltax = firstPt.x() - prevPt.x();
    Unit deltay = firstPt.y() - prevPt.y();
    if(deltax && deltay &&
       abs(deltax) != abs(deltay))
      return false;
    return true;
  }

private:
  //private functions
  inline iterator begin_() const {
    return Polygon45Interface<T>::Polygon45Begin(yieldConst());
  }

  inline iterator end_() const {
    return Polygon45Interface<T>::Polygon45End(yieldConst());
  }

  template <class iT>
  inline void set_(iT inputBegin, iT inputEnd) {
    Polygon45Interface<T>::Polygon45Set(yield(), inputBegin, inputEnd);
  }

  inline std::size_t size_() const {
    return Polygon45Interface<T>::Polygon45Size(yieldConst());
  }

  inline WindingDirection winding_() const {
     return Polygon45Interface<T>::Polygon45Winding(yieldConst());
  }

};

// default polygon type
typedef Polygon45Impl<Polygon45Data> Polygon45;

template <class T>
inline std::ostream& operator<< (std::ostream& o, const Polygon45Impl<T>& p) {
   o << "Polygon45 ";
   for(typename Polygon45Impl<T>::iterator itr = p.begin(); itr != p.end(); ++itr) {
      o << *itr << " ";
   }
   return o;
}
