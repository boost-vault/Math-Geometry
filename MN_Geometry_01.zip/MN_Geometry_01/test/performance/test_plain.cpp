#pragma warning(disable:4996)

#include "test.h"

struct inc
{
	inc(double d) : d_(d) { }
	double operator()() { d_ += 0.01; return d_;}
	double d_;
};

void test_plain()
{
	for (int j = 0; j < 100; ++j)
	{
		vector v,w;
		std::generate(v.begin(), v.end(), inc(1.0));
		std::generate(w.begin(), w.end(), inc(1.1));
		point p(v);

		double a = 1.01;
		for (std::size_t i = 0; i < 1000000; ++i, a*=1.0001)
			p += a*(w - v);
	}
}

void axpy_plain()
{
	for (int j = 0; j < 100; ++j)
	{
		vector x, y;
		std::generate(x.begin(), x.end(), inc(1.0));
		std::generate(y.begin(), y.end(), inc(1.1));
		double a = 2.1;
		for (std::size_t i = 0; i < 1000000; ++i, a*=1.0001)
			y += a*x;
	}
}
