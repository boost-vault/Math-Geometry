/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// PointData is the default in memory representation of a 2D point

/// PointData has a c-style array of coordinates indexed by the value
/// of an Orientation2D object.
/// This implementation was chosen for performance reasons because
/// the in memory representation is accessed directly by the value of
/// the orientation argument instead of using an if statement or 
/// branch free primitive such as predicated_value and predicated_assign
class PointData {
public:
  /// default constructor of point does not initialize x and y
  inline PointData(){;} //do nothing default constructor
  /// construct a point from x,y values
  inline PointData(Unit x, Unit y) {
    coords_[HORIZONTAL] = x;
    coords_[VERTICAL] = y;
  }
  inline PointData(const PointData& that) {
     (*this) = that;
  }

  inline PointData& operator=(const PointData& that) {
     coords_[0] = that.coords_[0];
     coords_[1] = that.coords_[1];
     return *this;
  }
  /// gets the x or y coordinate depending on the value of orient
  inline Unit get(Orientation2D orient) const {
    return coords_[orient.toInt()];
  }
  /// sets the x or y coordinate to value depending on the value of orient
  inline void set(Orientation2D orient, Unit value) {
    coords_[orient.toInt()] = value;
  }

private:
  Unit coords_[2]; //to be indexed by orientation2d value
};

