// ============================================================================
// traits.hpp                                     (C)2005 Michael Andersen Nexo
// ============================================================================
// Defines traits classes for adapting platform specific point/vector classes
// to work as internal representation classes for geom::point and geom::vector

#ifndef TRAITS_HPP_INCLUDED
#define TRAITS_HPP_INCLUDED

#include <cstddef> // std::size_t
#include <iterator>

namespace geom
{
	// ------------------------------------------------------------------------
	// class as_iterator<R>
	// ------------------------------------------------------------------------
	// Many point and vector classes can safely be converted to a random access
	// iterator on the underlying scalars.
	// In this case all you need to do is specialize as_iterator. Otherwise
	// you will have to specialize the full sequence_traits class below.
	template <class R>
	struct as_iterator
	{
		typedef typename R::iterator iterator;
		typedef typename R::const_iterator const_iterator;
		static iterator cast(R& r) { return r.begin(); }
		static const_iterator cast(R const& r) { return r.begin(); }
	};

	// Specialization for pointers
	template <class T>
	struct as_iterator<T*>
	{
		typedef T* iterator;
		typedef T const* const_iterator;
		static iterator cast(T* p) { return p; }
		static const_iterator cast(T const* p) { return p; }
	};

	template <class T>
	struct as_iterator<T const*>
	{
		typedef T const* iterator;
		typedef T const* const_iterator;
		static iterator cast(T const* p) { return p; }
	};

	// Specialization for native C arrays.
	template <class T, size_t D>
	struct as_iterator<T[D]>
	{
		typedef T* iterator;
		typedef T const* const_iterator;
		static iterator cast(T r[D]) { return r; }
		static const_iterator cast(T const r[D]) { return r; }
	};

	template <class T, size_t D>
	struct as_iterator<T const[D]>
	{
		typedef T const* const_iterator;
		typedef T const* iterator;
		static const_iterator cast(T const r[D]) { return r; }
	};

	// ------------------------------------------------------------------------
	// class sequence_traits<R,D>
	// ------------------------------------------------------------------------
	// Specifies sequence traits of the underlying point/vector representation
	// class.
	// The user should specialize this class for point/vector clases that cannot
	// just specialize as_iterator (e.g. classes where the y is placed before x
	// in memory).
	template <class R, size_t D>
	struct sequence_traits
	{
		typedef typename as_iterator<R>::iterator iterator;
		typedef typename as_iterator<R>::const_iterator const_iterator;
		typedef std::reverse_iterator<iterator> reverse_iterator;
		typedef std::reverse_iterator<const_iterator> const_reverse_iterator;
		typedef typename std::iterator_traits<iterator>::value_type value_type;
		typedef std::size_t size_type;
		typedef typename std::iterator_traits<iterator>::difference_type difference_type;
		typedef typename std::iterator_traits<iterator>::reference reference;
		typedef typename std::iterator_traits<const_iterator>::reference const_reference;

		static iterator begin(R& r) { return as_iterator<R>::cast(r); }
		static iterator end(R& r) { return begin(r)+D; }
		static const_iterator begin(R const& r) { return as_iterator<R>::cast(r); }
		static const_iterator end(R const& r) { return begin(r)+D; }

		static reverse_iterator rbegin(R& r) { return reverse_iterator(end(r)); }
		static reverse_iterator rend(R& r) { return reverse_iterator(begin(r)); }
		static const_reverse_iterator rbegin(R const& r) { end(r); }
		static const_reverse_iterator rend(R const& r) { begin(r); }
	};

	// ------------------------------------------------------------------------
	// class xyz_traits<R,D>
	// ------------------------------------------------------------------------
	// Specifies traits for accessing x(), y() and z() members of the 
	// underlying point/vector representation class for D=2 and D=3
	// The default implementation specifies access via sequence_traits, 
	// but the user is encouraged to specialize this for specific 2- and 
	// 3-dimensional point/vector classes if they are internally represented
	// in a non-array form. Debbuging will be much more enjoyable.
	template <class R, std::size_t D>
	struct xyz_traits
	{
	};

	template <class R>
	struct xyz_traits<R,2>
	{
		typedef sequence_traits<R,2> st;
		typedef typename std::iterator_traits<typename st::iterator>::reference reference;
		typedef typename std::iterator_traits<typename st::const_iterator>::reference const_reference;

		static reference x(R& r) { return *st::begin(r); }
		static const_reference x(R const& r) { return *st::begin(r); }
		static reference y(R& r) { return *(st::begin(r)+1); }
		static const_reference y(R const& r) { return *(st::begin(r)+1); }
	};

	template <class R>
	struct xyz_traits<R,3>
	{
		typedef sequence_traits<R,3> st;
		typedef typename std::iterator_traits<typename st::iterator>::reference reference;
		typedef typename std::iterator_traits<typename st::const_iterator>::reference const_reference;

		static reference x(R& r) { return *st::begin(r); }
		static const_reference x(R const& r) { return *st::begin(r); }
		static reference y(R& r) { return *(st::begin(r)+1); }
		static const_reference y(R const& r) { return *(st::begin(r)+1); }
		static reference z(R& r) { return *(st::begin(r)+2); }
		static const_reference z(R const& r) { return *(st::begin(r)+2); }
	};

	/*
	// Template for used for specializing the internal point type for ranges
	template <class R, size_t D>
	struct range_traits
	{
		typedef typename R::value_type value_type;
		typedef typename R::point_type point_type;
	};
	*/
}

#endif // TRAITS_HPP_INCLUDED
