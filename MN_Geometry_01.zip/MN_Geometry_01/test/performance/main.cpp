#include <iostream>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/function.hpp>

#include "test.h"
using namespace boost::posix_time;

void time(char const* function_name, boost::function<void ()> f)
{
	ptime start = microsec_clock::universal_time();
	f();
	ptime finish = microsec_clock::universal_time();

	time_duration td(finish - start);
	std::cout << function_name << " " << td.total_milliseconds()/1000.0 << " seconds.\n";
}

int main()
{
	std::cout << "Testing performance with D=" << DIM << '\n';

	time("y += a*x without expression templates:", &axpy_plain);
	time("y += a*x with expression templates:", &axpy_et);

	time("p += a*(w-v) without expression templates:", &test_plain);
	time("p += a*(w-v) with expression templates:", &test_et);
	return 0;
}
