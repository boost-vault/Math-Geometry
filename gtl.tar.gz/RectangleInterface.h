/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// RectangleInterface provides glue to bind RectangleImpl to T

/// RectangleInterface provides access the the data class T through
/// the constructor, get and set API, which are minimal and sufficient in 
/// combination with the interval API.
template <class T>
class RectangleInterface {
public:
  /// get an interval of the rectangle t depending on orient
  static inline IntervalData RectangleGet(const T& t, Orientation2D orient);

  /// set an interval of the rectangle t depending on orient
  static inline void RectangleSet(T& t, Orientation2D orient,
                                  const IntervalData& value);

  /// construct a rectangle of type T from horizontal and vertical ranges
  static inline T RectangleConstruct(const IntervalData& hrange, 
                                     const IntervalData& vrange);

private:
  //disallow construction
  RectangleInterface();
};

/// partial specialization of RectangleInterface for T of type RectangleData
template <>
class RectangleInterface<RectangleData> {
public:
  static inline IntervalData 
  RectangleGet(const RectangleData& t, Orientation2D orient) {
    return t.ranges_[orient.toInt()];
  }

  static inline void RectangleSet(RectangleData& t, 
                                  Orientation2D orient,
                                  const IntervalData& value) {
    t.ranges_[orient.toInt()] = value;
  }

  static inline RectangleData 
  RectangleConstruct(const IntervalData& hrange, 
                     const IntervalData& vrange) {
    return RectangleData(hrange, vrange);
  }

private:
  //disallow construction
  RectangleInterface() {;}
};

/// partial specialization of RectangleInterface for T = LayeredRectData
template <>
class RectangleInterface<LayeredRectData> {
public:
  static inline IntervalData RectangleGet(const LayeredRectData& t, 
                                          Orientation2D orient) {
    return t.get(orient);
  }

  static inline void RectangleSet(LayeredRectData& t, 
                                  Orientation2D orient,
                                  const IntervalData& value) {
    t.set(orient, value);
  }

  static inline LayeredRectData 
  RectangleConstruct(const IntervalData& hrange, 
                     const IntervalData& vrange) {
    //set default value of layer to be zero
    return LayeredRectData(RectangleData(hrange, vrange), 0);
  }

private:
  //disallow construction
  RectangleInterface() {;}
};

/// partial specialization of RectangleInterface for T of type RectPrismData
template <>
class RectangleInterface<RectPrismData> {
public:
  static inline IntervalData RectangleGet(const RectPrismData& t, 
                                          Orientation2D orient) {
    return t.get(orient);
  }

  static inline void RectangleSet(RectPrismData& t, 
                                  Orientation2D orient,
                                  const IntervalData& value) {
    t.set(orient, value);
  }

  static inline RectPrismData RectangleConstruct(const IntervalData& hrange, 
                                                 const IntervalData& vrange) {
    //degenerate rect prism on the default layer
    return RectPrismData(hrange, vrange, IntervalData(0,0));
  }

private:
  //disallow construction
  RectangleInterface(){;}
};

