/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// LayeredRectInterface provides glue to bind LayeredRectImpl to T

/// LayeredRectInterface provides access the the data class T through
/// the constructor, get and set API, which are minimal and sufficient in 
/// combination with the rectangle API.
template <class T>
class LayeredRectInterface {
public:
  /// get the rectangle of layered rectangle t
  static inline Unit LayeredRectGetL(const T& t);

  /// set the rectangle of layered rectangle t
  static inline void LayeredRectSetL(T& t, Unit value);

  /// construct a layered rectangle of type T from a rectangle and layer
  static inline T LayeredRectConstruct(const RectangleData& rect, Unit layer);

private:
  //disallow construction
  LayeredRectInterface();
};

/// partial specialization of LayeredRectInterface for T = LayeredRectData
template <>
class LayeredRectInterface<LayeredRectData> {
public:
  static inline Unit LayeredRectGetL(const LayeredRectData& t){
    return t.getLayer();
  }

  static inline void LayeredRectSetL(LayeredRectData& t, Unit value) {
    t.setLayer(value);
  }

  static inline LayeredRectData 
  LayeredRectConstruct(const RectangleData& rect, Unit layer) {
    return LayeredRectData(rect, layer);
  }

private:
  //disallow construction
  LayeredRectInterface() {;}
};
