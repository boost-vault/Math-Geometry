/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// SegmentImpl implements all Segment functions on top of segment type T

/// SegmentImpl inherits from segment type T and accesses the data owned
/// by T through the SegmentInterface<T> class
template <class T>
class SegmentImpl : public T{
public:
  
  /// get a reference of SegmentImpl type given a data object
  static SegmentImpl& mimic(T& t) { return static_cast<SegmentImpl&>(t); }
  
  /// get a const reference of SegmentImpl type given a data object
  static const SegmentImpl& mimicConst(const T& t) { 
    return static_cast<const SegmentImpl&>(t); 
  }
  
  /// construct a segment from low end point p, orientation and length
  template <class T2>
  SegmentImpl(const PointImpl<T2>& p, Orientation2D orient, UnsignedUnit length);
  
  /// construct a segment from low end point p, orientation and length
  template <class T2, class T3>
  SegmentImpl(const PointImpl<T2>& p1, const PointImpl<T3>& p2);
  
  /// default constructor
  SegmentImpl();

  /// assignment operator
  template <class T2>
  const SegmentImpl& operator=(const SegmentImpl<T2>& that) {
    setOrient(that.getOrient()); low(that.low()); high(that.high());
  }

  /// assignment operator
  const SegmentImpl& operator=(const SegmentImpl& that);

  /// assignment operator
  const SegmentImpl& operator=(const T& that);

  /// copy constructor
  template <class T2>
  SegmentImpl(const SegmentImpl<T2>& that) {*this = that;}
     
  /// copy constructor
  SegmentImpl(const T& that) : T(that) {;}

  /// equivalence operator
  template <class T2>
  bool operator==(const SegmentImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const SegmentImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const SegmentImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<=(const SegmentImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const SegmentImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const SegmentImpl<T2>& b) const { return !(*this < b); }

  /// conversion to interval
  operator IntervalImpl<IntervalData>() const;

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// yield payload
  T& yield() { return *this; }
     
  /// get an end point of 'this' depending on dir
  PointImpl<PointData> get(Direction1D dir) const;

  /// get the low end point
  PointImpl<PointData> low() const { return get(LOW); }

  /// get the high end point
  PointImpl<PointData> high() const { return get(HIGH); }

  /// set an end point of 'this' to value depending on dir
  template <class T2>
  SegmentImpl& set(Direction1D dir, const PointImpl<T2>& value);
    
  /// set the low end point
  template <class T2>
  SegmentImpl& low(const PointImpl<T2>& value);

  /// set the high end point
  template <class T2>
  SegmentImpl& high(const PointImpl<T2>& value);

  /// get the orientation
  Orientation2D getOrient() const;

  /// set the orientation, low end point is unchanged
  SegmentImpl& setOrient(Orientation2D orient);

  /// get the length
  UnsignedUnit getLength() const;

  /// set the length, low end point is unchanged
  SegmentImpl& setLength(UnsignedUnit value);

  /// gives the coordinate that the two end points have in common
  Unit getMajor() const;

  /// sets the coordinate that the two end points have in common
  SegmentImpl& setMajor(Unit value);
    
  /// returns a reference to an Interval of type T
  IntervalImpl<T>& mimicInterval();

  /// returns a const reference to an Interval of type T
  const IntervalImpl<T>& mimicConstInterval() const;

  /// is the Segment valid
  bool isValid() const;

  /// returns the length of the segment
  UnsignedUnit delta() const;

  /// returns the length of the segment along the given orientation
  UnsignedUnit delta(Orientation2D orient) const;

  /// transform segment
  SegmentImpl& transform(const AxisTransform& atr);
    
  /// transform segment
  SegmentImpl& transform(const Transform& tr);

  /// check if Segment b is inside `this` Segment
  //  [in]     b         Segment that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `this` contains b
  //  orthoginal segment will only be contained if considerTouch is true
  //  and the orthoginal segment has zero length
  template <class T2>
  bool contains(const SegmentImpl<T2>& b, 
                       bool considerTouch = true) const;

  /// check if a point is contained inside 'this'
  template <class T2>
  bool contains(const PointImpl<T2>& p, 
                       bool considerTouch = true) const;

  template <class T2>
  PointImpl<PointData> project(const PointImpl<T2>& point) const;

  template <class T2, class T3>
  bool project(PointImpl<T2>& result, const PointImpl<T3>& point,
               Direction2D dir) const;

  /// check if a point p is colinear to 'this'
  template <class T2>
  bool colinear(const PointImpl<T2>& p) const;

  /// check if a segment b is colinear to 'this'
  template <class T2>
  bool colinear(const SegmentImpl<T2>& b) const;

  /// check if a segment b is perpendicular to 'this'
  template <class T2>
  bool perpendicular(const SegmentImpl<T2>& b) const;

  /// check if segment b crosses 'this' segment
  template <class T2>
  bool crosses(const SegmentImpl<T2>& b, 
                      bool considerTouch = true) const;

  /// check if `this` Segment is inside specified Segment b
  //  [in]     b         T that will be checked
  //  [in]     considerTouch true, return true even if `t` touches the boundary
  //  [ret]    .         true if `t` is inside b
  template <class T2>
  bool inside(const SegmentImpl<T2>& b, bool considerTouch = true) const;

  /// check if Segment b intersects `this` Segment
  //  [in]     b         T that will be checked
  //  [in]     considerTouch If true, return true even if b touches the boundary
  //  [ret]    .         true if `t` intersects b
  template <class T2>
  bool intersects(const SegmentImpl<T2>& b, 
                         bool considerTouch = true) const;

  /// check if b partially overlaps 'this' Segment
  //  [in]     b         T that will be checked
  //  [in]     considerTouch If true, return true even if p is on the foundary
  //  [ret]    .         true if `t` contains p
  template <class T2>
  bool boundariesIntersect(const SegmentImpl<T2>& b, 
                                  bool considerTouch = true) const;
    
  /// check if b abutts 'this' Segment's end specified by dir
  template <class T2>
  bool abuts(const SegmentImpl<T2>& b, Direction1D dir) const;

  /// check if b abutts 'this' Segment
  template <class T2>
  bool abuts(const SegmentImpl<T2>& b) const;

  /// set 'this' segment to its intersection with Interval b 
  template <class T2>
  bool intersectRange(const IntervalImpl<T2>& b, 
                             bool considerTouch = true);

  /// set 'this' segment to its intersection with Segment b
  //  [in]   b         The intersecting T
  //  [in]   considerTouch If true, will clip to a single line if appropriate
  template <class T2>
  bool intersect(const SegmentImpl<T2>& b, bool considerTouch = true);

  /// set `this` Segment to the intersection between b1 and b2
  //  [in]     b1        The two intervals to examine
  //  [in]     b2
  //  [in]     considerTouch If true, create intersection even if b1 touches b2
  //  [ret]    .         true if boxes intersect, else `t` is set to b1
  template <class T2, class T3>
  bool intersection(const SegmentImpl<T2>& b1, const SegmentImpl<T3>& b2,
                           bool considerTouch = true);

  /// bloat the Segment
  //  [in]     bloating  Positive value to bloat each coordinate
  SegmentImpl& bloat(UnsignedUnit bloating);

  /// bloat the specified side of `this` Segment
  //  [in]     bloating  Positive value to bloat the Segment
  //  [in]     o         The orientation to be bloated
  SegmentImpl& bloat(Direction1D dir, UnsignedUnit bloating);

  /// shrink the Segment
  //  [in]     shrinking Positive value to shrink each coordinate
  SegmentImpl& shrink(UnsignedUnit shrinking);

  /// shrink the specified side of `this` Segment
  //  [in]     shrinking Positive value to shrink the T
  //  [in]     o         The orientation to be shrunk
  SegmentImpl& shrink(Direction1D dir, UnsignedUnit shrinking);

  /// elarge 'this' Segment to encompass the range b
  template <class T2>
  bool encompass(const IntervalImpl<T2>& b);

  /// enlarge 'this' segment to encompass segment b
  //  [in]     b         The T to encompass
  //  [ret]    .         true if enlargement happened at all
  template <class T2>
  bool encompass(const SegmentImpl<T2>& b);

private:
  //private functions
  PointImpl<PointData> get_(Direction1D dir) const;
  void set_(Direction1D dir, const PointImpl<PointData>& value);
  Orientation2D getOrient_() const;
  void setOrient_(Orientation2D orient);
  UnsignedUnit getLength_() const;
  void setLength_(UnsignedUnit value);
  static T construct_(const PointImpl<PointData>& p, 
                             Orientation2D o,
                             UnsignedUnit length);
};

typedef SegmentImpl<SegmentData> Segment;

template <class T>
std::ostream& operator<< (std::ostream& o, const SegmentImpl<T>& s);

template <class T>
std::istream& operator>> (std::istream& i, SegmentImpl<T>& s);
