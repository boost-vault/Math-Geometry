// LineSimplifierDlg.h
//
#pragma once
#include "Canvas.h"
#include "afxcmn.h"

// CLineSimplifierDlg
class CLineSimplifierDlg : public CDialog
{
public:
	enum { IDD = IDD_LINESIMPLIFIER_DIALOG };

	CLineSimplifierDlg(CWnd* pParent = NULL);

	double GetTolerance();
	void SetTolerance(double tolerance);
	void SimplifyPath();

	PointVector m_Points;
	PointVector m_Simp;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);

private:
	HICON m_hIcon;
	CCanvas m_Canvas;
	CSliderCtrl m_ToleranceSlider;
};
