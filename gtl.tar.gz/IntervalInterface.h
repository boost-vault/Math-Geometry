/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// IntervalInterface provides glue to bind IntervalImpl to T

/// IntervalInterface provides access the the data class T through
/// the constructor, get and set API, which are minimal and sufficient.
template <class T>
class IntervalInterface {
public:
  /// get a coordinate from the interval t depending on value of dir
  static inline Unit IntervalGet(const T& t, 
                                 Direction1D dir);
  /// set a coordinate of the interval t to value depending on value of dir
  static inline void IntervalSet(T& t,
                                 Direction1D dir,
                                 Unit value);
  /// construct a T type interval from low and high
  static inline T IntervalConstruct(Unit low, 
                                    Unit high);
private:
  //disallow construction
  IntervalInterface(){;}
};


/// partial specialization of IntervalInterface for T of type IntervalData
template <>
class IntervalInterface<IntervalData> {
public:
  static inline Unit IntervalGet(const IntervalData& t, 
                                 Direction1D dir){
    return t.bounds_[dir.toInt()];
  }
  static inline void IntervalSet(IntervalData& t,
                                 Direction1D dir,
                                 Unit value){
    t.bounds_[dir.toInt()] = value;
    //this is an unlikely condition and branch prediction should be good
    if (t.bounds_[0] > t.bounds_[1])
      t.bounds_[!dir.toInt()] = value;
  }
  static inline IntervalData IntervalConstruct(Unit low, 
                                               Unit high) {
    return IntervalData(low, high);
  }
private:
  //disallow construction
  IntervalInterface(){;}
};

/// partial specialization of IntervalInterface for T of type SegmentData
template <>
class IntervalInterface<SegmentData> {
public:
  static inline Unit IntervalGet(const SegmentData& t, 
                                 Direction1D dir){
    return (t.get(dir)).get(t.getOrient());
  }
  static inline void IntervalSet(SegmentData& t, 
                                 Direction1D dir,
                                 Unit value){
    PointData p = t.get(dir);
    p.set(t.getOrient(), value);
    t.set(dir, p);
  }
  static inline SegmentData IntervalConstruct(Unit low, 
                                              Unit high) {
    //default to horizontal with zero y intersect
    PointData p(low, 0);
    UnsignedUnit length = high - low;
    return SegmentData(p, HORIZONTAL, length);
  }
private:
  //disallow construction
  IntervalInterface(){;}
};
    

/// partial specialization of IntervalInterface for T of type Segment3DData
template <>
class IntervalInterface<Segment3DData> {
public:  
  static inline Unit IntervalGet(const Segment3DData& t, 
                                 Direction1D dir){
    return (t.get(dir)).get(t.getOrient());
  }
  static inline void IntervalSet(Segment3DData& t,
                                 Direction1D dir,
                                 Unit value){
    Point3DData p = t.get(dir);
    p.set(t.getOrient(), value);
    t.set(dir, p);
  }
  static inline Segment3DData IntervalConstruct(Unit low, 
                                                Unit high) {
    //default to horizontal with zero y intersect
    Point3DData p(low, 0, 0);
    UnsignedUnit length = high - low;
    return Segment3DData(p, HORIZONTAL, length);
  }
private:
  //disallow construction
  IntervalInterface(){;}
};

