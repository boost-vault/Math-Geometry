/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
//The touch event is a map of y(x) values to a map of polygonIds that are either entering or leaving the scanline at that y
//We need to keep one TouchScanEvent for entering polygons and a seperate one for leaving because all entering polygons
//need to be evaluated at a unique x(y) value before the leaving polygons so that they can be properly assocated in 
//corner touching cases
class TouchScanEvent {
private:
   typedef std::map<Unit, std::set<int> > EventData;
   EventData eventData_;
public:

   // The TouchScanEvent::iterator is a lazy algorithm that accumulates
   // polygon ids in a set as it is incremented through the
   // scan event data structure.
   // The iterator provides a forward iterator semantic only.
   class iterator {
   private:
      EventData::const_iterator itr_;
      std::pair<Interval, std::set<int> > ivlIds_;
   public:
      inline iterator() {}
      inline iterator(EventData::const_iterator itr, 
                      Unit prevPos, const std::set<int>& ivlIds) : itr_(itr) {
         ivlIds_.second = ivlIds;
         ivlIds_.first = Interval(prevPos, itr->first);
      }
      inline iterator(const iterator& that) { (*this) = that; }
      inline iterator& operator=(const iterator& that) {
         itr_ = that.itr_;
         ivlIds_.first = that.ivlIds_.first;
         ivlIds_.second = that.ivlIds_.second;
         return *this;
      };
      inline bool operator==(const iterator& that) { return itr_ == that.itr_; }
      inline bool operator!=(const iterator& that) { return itr_ != that.itr_; }
      inline iterator& operator++() {
         //std::cout << "increment\n";
         //std::cout << "state\n";
         //for(std::set<int>::iterator itr = ivlIds_.second.begin(); itr != ivlIds_.second.end(); ++itr) {
         //   std::cout << (*itr) << " ";
         //} std::cout << std::endl;
         //std::cout << "update\n";
         for(std::set<int>::const_iterator itr = (*itr_).second.begin();
             itr != (*itr_).second.end(); ++itr) {
            //std::cout << (*itr) <<  " ";
            std::set<int>::iterator lb = ivlIds_.second.find(*itr);
            if(lb != ivlIds_.second.end()) {
               ivlIds_.second.erase(lb);
            } else {
               ivlIds_.second.insert(*itr);
            }
         } 
         //std::cout << std::endl;
         //std::cout << "new state\n";
         //for(std::set<int>::iterator itr = ivlIds_.second.begin(); itr != ivlIds_.second.end(); ++itr) {
         //   std::cout << (*itr) << " ";
         //} std::cout << std::endl;
         ++itr_;
         ivlIds_.first = Interval(ivlIds_.first.get(HIGH), itr_->first);
         return *this;
      }
      inline iterator operator++(int){
         iterator tmpItr(*this);
         ++(*this);
         return tmpItr;
      }
      inline std::pair<Interval, std::set<int> >& operator*() { if(ivlIds_.second.empty())(++(*this)); return ivlIds_; }
   };

   inline TouchScanEvent() {}
   template<class iT>
   inline TouchScanEvent(iT begin, iT end) {
      for( ; begin != end; ++begin){
         insert(*begin);
      }
   }
   inline TouchScanEvent(const TouchScanEvent& that) : eventData_(that.eventData_) {}
   inline TouchScanEvent& operator=(const TouchScanEvent& that){
      eventData_ = that.eventData_;
      return *this;
   }
   
   //Insert an interval polygon id into the EventData
   inline void insert(const std::pair<Interval, int>& intervalId){
      insert(intervalId.first.low(), intervalId.second);
      insert(intervalId.first.high(), intervalId.second);
   }
   
   //Insert an position and polygon id into EventData
   inline void insert(Unit pos, int id) {
      EventData::iterator lb = eventData_.lower_bound(pos);
      if(lb != eventData_.end() && lb->first == pos) {
         std::set<int>& mr (lb->second);
         std::set<int>::iterator mri = mr.find(id);
         if(mri == mr.end()) {
            mr.insert(id);
         } else {
            mr.erase(id);
         }
      } else {
         lb = eventData_.insert(lb, std::pair<Unit, std::set<int> >(pos, std::set<int>()));
         (*lb).second.insert(id);
      }
   }
   
   //merge this scan event with that by inserting its data
   inline void insert(const TouchScanEvent& that){
      EventData::const_iterator itr;
      for(itr = that.eventData_.begin(); itr != that.eventData_.end(); ++itr) {
         eventData_[(*itr).first].insert(itr->second.begin(), itr->second.end());
      }
   }
   
   //Get the begin iterator over event data
   inline iterator begin() const { 
      //std::cout << "begin\n";
      if(eventData_.empty()) return end();
      EventData::const_iterator itr = eventData_.begin();
      Unit pos = itr->first;
      const std::set<int>& idr = itr->second;
      ++itr;
      return iterator(itr, pos, idr);
   }
   
   //Get the end iterator over event data
   inline iterator end() const { return iterator(eventData_.end(), 0, std::set<int>()); }
   
   inline void clear() { eventData_.clear(); }
   
   inline Interval extents() const { 
      if(eventData_.empty()) return Interval();
      return Interval((*(eventData_.begin())).first, (*(eventData_.rbegin())).first);
   }
};
   
//declaration of a map of scan events by coordinate value used to store all the
//polygon data for a single layer input into the scanline algorithm
typedef std::pair<std::map<Unit, TouchScanEvent>, std::map<Unit, TouchScanEvent> > TouchSetData;

class TouchOp {
public:
   typedef std::map<Unit, std::set<int> > ScanData;
   typedef std::pair<Unit, std::set<int> > ElementType;
protected:
   ScanData scanData_;
   ScanData::iterator nextItr_;
public:
   inline TouchOp () { nextItr_ = scanData_.end(); }
   inline TouchOp (const TouchOp& that) : scanData_(that.scanData_) { nextItr_ = scanData_.begin(); }
   inline TouchOp& operator=(const TouchOp& that); 
   
   //moves scanline forward
   inline void advanceScan() { nextItr_ = scanData_.begin(); }

   //proceses the given interval and std::set<int> data
   //the output data structre is a graph, the indicies in the vector correspond to graph nodes,
   //the integers in the set are vector indicies and are the nodes with which that node shares an edge
   inline void processInterval(std::vector<std::set<int> >& outputContainer, Interval ivl, const std::set<int>& ids, bool leadingEdge);

   inline void print() const {
      for(ScanData::const_iterator itr = scanData_.begin(); itr != scanData_.end(); ++itr) {
         std::cout << itr->first << ": ";
         for(std::set<int>::const_iterator sitr = itr->second.begin();
             sitr != itr->second.end(); ++sitr){
            std::cout << *sitr << " ";
         }
         std::cout << std::endl;
      }
   }
   
private:
   inline ScanData::iterator lookup_(Unit pos){
      if(nextItr_ != scanData_.end() && nextItr_->first >= pos) {
         return nextItr_;
      }
      return nextItr_ = scanData_.lower_bound(pos);
   }

   inline ScanData::iterator insert_(Unit pos, const std::set<int>& ids){
      //std::cout << "inserting " << ids.size() << " ids at: " << pos << std::endl;
      return nextItr_ = scanData_.insert(nextItr_, std::pair<Unit, std::set<int> >(pos, ids));
   }

   inline void evaluateInterval_(std::vector<std::set<int> >& outputContainer, std::set<int>& ids, 
                                 const std::set<int>& changingIds, bool leadingEdge) {
      for(std::set<int>::const_iterator ciditr = changingIds.begin(); ciditr != changingIds.end(); ++ciditr){
         //std::cout << "evaluateInterval " << (*ciditr) << std::endl;
         evaluateId_(outputContainer, ids, *ciditr, leadingEdge);
      }
   }
   inline void evaluateBorder_(std::vector<std::set<int> >& outputContainer, const std::set<int>& ids, const std::set<int>& changingIds) {
      for(std::set<int>::const_iterator ciditr = changingIds.begin(); ciditr != changingIds.end(); ++ciditr){
         //std::cout << "evaluateBorder " << (*ciditr) << std::endl;
         evaluateBorderId_(outputContainer, ids, *ciditr);
      }
   }
   inline void evaluateBorderId_(std::vector<std::set<int> >& outputContainer, const std::set<int>& ids, int changingId) {
      for(std::set<int>::const_iterator scanItr = ids.begin(); scanItr != ids.end(); ++scanItr) {
         //std::cout << "create edge: " << changingId << " " << *scanItr << std::endl;
         if(changingId != *scanItr){
            outputContainer[changingId].insert(*scanItr);
            outputContainer[*scanItr].insert(changingId);
         }
      }
   }
   inline void evaluateId_(std::vector<std::set<int> >& outputContainer, std::set<int>& ids, int changingId, bool leadingEdge) {
      //std::cout << "changingId: " << changingId << std::endl;
      //for( std::set<int>::iterator itr = ids.begin(); itr != ids.end(); ++itr){
      //   std::cout << *itr << " ";
      //}std::cout << std::endl;
      std::set<int>::iterator lb = ids.lower_bound(changingId);
      if(lb == ids.end() || (*lb) != changingId) {
         if(leadingEdge) {
            //std::cout << "insert\n";
            //insert and add to output
            for(std::set<int>::iterator scanItr = ids.begin(); scanItr != ids.end(); ++scanItr) {
               //std::cout << "create edge: " << changingId << " " << *scanItr << std::endl;
               if(changingId != *scanItr){
                  outputContainer[changingId].insert(*scanItr);
                  outputContainer[*scanItr].insert(changingId);
               }
            }
            ids.insert(changingId);
         }
      } else {
         if(!leadingEdge){
            //std::cout << "erase\n";
            ids.erase(lb);
         }
      }
   }
};

inline void TouchOp::processInterval(std::vector<std::set<int> >& outputContainer, Interval ivl, 
                                     const std::set<int>& ids, bool leadingEdge) {
   //print();
   ScanData::iterator lowItr = lookup_(ivl.low());
   ScanData::iterator highItr = lookup_(ivl.high());
   //std::cout << "Interval: " << ivl << std::endl;
   //for(std::set<int>::const_iterator itr = ids.begin(); itr != ids.end(); ++itr)
   //   std::cout << (*itr) << " ";
   //std::cout << std::endl;
   //add interval to scan data if it is past the end
   if(lowItr == scanData_.end()) {
      //std::cout << "case0" << std::endl;
      lowItr = insert_(ivl.low(), ids);
      evaluateBorder_(outputContainer, ids, ids);
      highItr = insert_(ivl.high(), std::set<int>());
      return;
   }
   //ensure that highItr points to the end of the ivl
   if(highItr == scanData_.end() || (*highItr).first > ivl.high()) {
      //std::cout << "case1" << std::endl;
      //std::cout << highItr->first << std::endl;
      std::set<int> value = std::set<int>();
      if(highItr != scanData_.begin()) {
         --highItr;
         //std::cout << highItr->first << std::endl;
         //std::cout << "high set size " << highItr->second.size() << std::endl;
         value = highItr->second;
      }
      nextItr_ = highItr;
      highItr = insert_(ivl.high(), value);
   } else {
      //evaluate border with next higher interval
      //std::cout << "case1a" << std::endl;
      if(leadingEdge)evaluateBorder_(outputContainer, highItr->second, ids);
   }
   //split the low interval if needed
   if(lowItr->first > ivl.low()) {
      //std::cout << "case2" << std::endl;
      if(lowItr != scanData_.begin()) {
         //std::cout << "case3" << std::endl;
         --lowItr;
         nextItr_ = lowItr;
         //std::cout << lowItr->first << " " << lowItr->second.size() << std::endl;
         lowItr = insert_(ivl.low(), lowItr->second);
      } else {
         //std::cout << "case4" << std::endl;
         nextItr_ = lowItr;
         lowItr = insert_(ivl.low(), std::set<int>());
      }
   } else {
      //evaluate border with next higher interval
      //std::cout << "case2a" << std::endl;
      ScanData::iterator nextLowerItr = lowItr;
      if(leadingEdge && nextLowerItr != scanData_.begin()){
         --nextLowerItr;
         evaluateBorder_(outputContainer, nextLowerItr->second, ids);
      }
   }
   //std::cout << "low: " << lowItr->first << " high: " << highItr->first << std::endl;
   //print();
   //process scan data intersecting interval
   for(ScanData::iterator itr = lowItr; itr != highItr; ){
      //std::cout << "case5" << std::endl;
      //std::cout << itr->first << std::endl;
      std::set<int>& beforeIds = itr->second;
      ++itr;
      evaluateInterval_(outputContainer, beforeIds, ids, leadingEdge);
   }
   //print();
   //merge the bottom interval with the one below if they have the same count
   if(lowItr != scanData_.begin()){
      //std::cout << "case6" << std::endl;
      ScanData::iterator belowLowItr = lowItr;
      --belowLowItr;
      if(belowLowItr->second == lowItr->second) {
         //std::cout << "case7" << std::endl;
         scanData_.erase(lowItr);
      }
   } 
   //merge the top interval with the one above if they have the same count
   if(highItr != scanData_.begin()) {
      //std::cout << "case8" << std::endl;
      ScanData::iterator beforeHighItr = highItr;
      --beforeHighItr;
      if(beforeHighItr->second == highItr->second) {
         //std::cout << "case9" << std::endl;
         scanData_.erase(highItr);
         highItr = beforeHighItr;
         ++highItr;
      }
   }
   //print();
   nextItr_ = highItr;
}

inline void processEvent(std::vector<std::set<int> >& outputContainer, TouchOp& op, const TouchScanEvent& data, bool leadingEdge) {
   for(TouchScanEvent::iterator itr = data.begin(); itr != data.end(); ++itr) {
      //std::cout << "processInterval" << std::endl;
      op.processInterval(outputContainer, (*itr).first, (*itr).second, leadingEdge);
   }
}

inline void performTouch(std::vector<std::set<int> >& outputContainer, const TouchSetData& data) {
   std::map<Unit, TouchScanEvent>::const_iterator leftItr = data.first.begin();
   std::map<Unit, TouchScanEvent>::const_iterator rightItr = data.second.begin();
   std::map<Unit, TouchScanEvent>::const_iterator leftEnd = data.first.end();
   std::map<Unit, TouchScanEvent>::const_iterator rightEnd = data.second.end();
   TouchOp op;
   while(leftItr != leftEnd || rightItr != rightEnd) {
      //std::cout << "loop" << std::endl;
      op.advanceScan();
      //rightItr cannont be at end if leftItr is not at end
      if(leftItr != leftEnd && rightItr != rightEnd &&
         leftItr->first <= rightItr->first) {
         //std::cout << "case1" << std::endl;
         //std::cout << leftItr ->first << std::endl;
         processEvent(outputContainer, op, leftItr->second, true);
         ++leftItr;
      } else {
         //std::cout << "case2" << std::endl;
         //std::cout << rightItr ->first << std::endl;
         processEvent(outputContainer, op, rightItr->second, false);
         ++rightItr;
      }
   }
}

template <class iT>
inline void populateTouchSetData(TouchSetData& data, iT beginData, iT endData, int id) {
   Unit prevPos = UnitMax;
   Unit prevY = UnitMax;
   int count = 0;
   for(iT itr = beginData; itr != endData; ++itr) {
      Unit pos = (*itr).first;
      if(pos != prevPos) {
         prevPos = pos;
         prevY = (*itr).second.first;
         count = (*itr).second.second;
         continue;
      }
      Unit y = (*itr).second.first;
      if(count != 0 && y != prevY) {
         std::pair<Interval, int> element(Interval(prevY, y), id);
         if(count > 0) {
            data.first[pos].insert(element);
         } else {
            data.second[pos].insert(element);
         }
      }
      prevY = y;
      count += (*itr).second.second;
   }
}

inline void populateTouchSetData(TouchSetData& data, const PolygonSetData inputData, int id) {
   PolygonSetData::const_iterator setItr = inputData.begin();
   for(; setItr != inputData.end(); ++setItr){
      for(ScanEvent::iterator itr = (*setItr).second.begin();
          itr != (*setItr).second.end(); ++itr) {
         if((*itr).second > 0) {
            data.first[setItr->first].insert(std::pair<Interval, int>((*itr).first, id));
         } else {
            data.second[setItr->first].insert(std::pair<Interval, int>((*itr).first, id));
         }
      }
   }
}

inline void populateTouchSetData(TouchSetData& data, const std::vector<std::pair<Unit, std::pair<Unit, int> > >& inputData, int id) {
  populateTouchSetData(data, inputData.begin(), inputData.end(), id);
}

inline bool testTouch() {
   PolygonSetData sd1;
   sd1[0].insert(std::pair<Interval, int>(Interval(0,10), 1));
   sd1[10].insert(std::pair<Interval, int>(Interval(0,10), -1));
   PolygonSetData sd2;
   sd2[11].insert(std::pair<Interval, int>(Interval(-10,0), 1));
   sd2[12].insert(std::pair<Interval, int>(Interval(-10,0), -1));
   TouchSetData tsd;
   //std::cout << "pop1" << std::endl;
   populateTouchSetData(tsd, sd1, 0);
   //std::cout << "pop2" << std::endl;
   populateTouchSetData(tsd, sd2, 1);
   std::vector<std::set<int> > c;
   c.push_back(std::set<int>());
   c.push_back(std::set<int>());
   //std::cout << "op1" << std::endl;
   performTouch(c, tsd);
   std::cout << "Touch result\n";
   for(unsigned int i = 0; i < c.size(); ++i){
      for(std::set<int>::iterator itr = c[i].begin();
          itr != c[i].end(); ++itr){
         std::cout << *itr << " ";
      }
      std::cout << std::endl;
   }
   return true;
}


/////////////////////////////////////
//Merge
/////////////////////////////////////
template <typename coordinate_type>
class property_merge_point {
private:
  coordinate_type x_, y_;
public:
  inline property_merge_point() {}
  inline property_merge_point(coordinate_type x, coordinate_type y) : x_(x), y_(y) {}
  //use builtin assign and copy
  inline bool operator==(const property_merge_point& that) const { return x_ == that.x_ && y_ == that.y_; }
  inline bool operator!=(const property_merge_point& that) const { return !((*this) == that); }
  inline bool operator<(const property_merge_point& that) const {
    if(x_ < that.x_) return true;
    if(x_ > that.x_) return false;
    return y_ < that.y_;
  }
  inline coordinate_type x() const { return x_; }
  inline coordinate_type y() const { return y_; }
  inline void x(coordinate_type value) { x_ = value; }
  inline void y(coordinate_type value) { y_ = value; }
};

template <typename coordinate_type>
class property_merge_interval {
private:
  coordinate_type low_, high_;
public:
  inline property_merge_interval() {}
  inline property_merge_interval(coordinate_type low, coordinate_type high) : low_(low), high_(high) {}
  //use builtin assign and copy
  inline bool operator==(const property_merge_interval& that) const { return low_ == that.low_ && high_ == that.high_; }
  inline bool operator!=(const property_merge_interval& that) const { return !((*this) == that); }
  inline bool operator<(const property_merge_interval& that) const {
    if(low_ < that.low_) return true;
    if(low_ > that.low_) return false;
    return high_ < that.high_;
  }
  inline coordinate_type low() const { return low_; }
  inline coordinate_type high() const { return high_; }
  inline void low(coordinate_type value) { low_ = value; }
  inline void high(coordinate_type value) { high_ = value; }
};

template <typename coordinate_type, typename property_type, typename polygon_set_type, typename keytype = std::set<property_type> >
class merge_scanline {
public:
  //definitions

  typedef keytype property_set;
  typedef std::vector<std::pair<property_type, int> > property_map;
  typedef std::pair<property_merge_point<coordinate_type>, std::pair<property_type, int> > vertex_property;
  typedef std::pair<property_merge_point<coordinate_type>, property_map> vertex_data;
  typedef std::vector<vertex_property> property_merge_data;
  //typedef std::map<property_set, polygon_set_type> Result;
  typedef std::map<coordinate_type, property_map> scanline_type;
  typedef typename scanline_type::iterator scanline_iterator;
  typedef std::pair<property_merge_interval<coordinate_type>, std::pair<property_set, property_set> > edge_property;
  typedef std::vector<edge_property> edge_property_vector;

  //static public member functions

  template <typename iT, typename orientation_2d_type>
  static inline void 
  populate_property_merge_data(property_merge_data& pmd, iT input_begin, iT input_end, 
                               const property_type& property, orientation_2d_type orient) {
    for( ; input_begin != input_end; ++input_begin) {
      std::pair<property_merge_point<coordinate_type>, std::pair<property_type, int> > element;
      if(orient == HORIZONTAL)
        element.first = property_merge_point<coordinate_type>((*input_begin).second.first, (*input_begin).first);
      else
        element.first = property_merge_point<coordinate_type>((*input_begin).first, (*input_begin).second.first);
      element.second.first = property;
      element.second.second = (*input_begin).second.second;
      pmd.push_back(element);
    }
  }

  //public member functions

  merge_scanline() {}
  merge_scanline(const merge_scanline& that) :
    output(that.output),
    scanline(that.scanline),
    currentVertex(that.currentVertex),
    tmpVector(that.tmpVector),
    previousY(that.previousY),
    countFromBelow(that.countFromBelow),
    scanlinePosition(that.scanlinePosition)
  {}
  merge_scanline& operator=(const merge_scanline& that) {
    output = that.output;
    scanline = that.scanline;
    currentVertex = that.currentVertex;
    tmpVector = that.tmpVector;
    previousY = that.previousY;
    countFromBelow = that.countFromBelow;
    scanlinePosition = that.scanlinePosition;
  }

  template <typename result_type>
  inline void perform_merge(result_type& result, property_merge_data& data) {
    if(data.empty()) return;
    //sort
    std::sort(data.begin(), data.end(), less_vertex_data<vertex_property>());
    
    //scanline
    bool firstIteration = true;
    scanlinePosition = scanline.end();
    for(unsigned int i = 0; i < data.size(); ++i) {
      if(firstIteration) {
        mergeProperty(currentVertex.second, data[i].second);
        currentVertex.first = data[i].first;
        firstIteration = false;
      } else {
        if(data[i].first != currentVertex.first) {
          if(data[i].first.x() != currentVertex.first.x()) {
            processVertex(output);
            //std::cout << scanline.size() << " ";
            countFromBelow.clear(); //should already be clear
            writeOutput(currentVertex.first.x(), result, output);
            currentVertex.second.clear();
            mergeProperty(currentVertex.second, data[i].second);
            currentVertex.first = data[i].first;
            //std::cout << assertRedundant(scanline) << "/" << scanline.size() << " ";
          } else {
            processVertex(output);
            currentVertex.second.clear();
            mergeProperty(currentVertex.second, data[i].second);
            currentVertex.first = data[i].first;
          }
        } else {
          mergeProperty(currentVertex.second, data[i].second);
        }
      }
    }
    processVertex(output);
    writeOutput(currentVertex.first.x(), result, output);
    //std::cout << assertRedundant(scanline) << "/" << scanline.size() << "\n";
    //std::cout << scanline.size() << "\n";
  }

private:
  //private supporting types

  template <class T>
  class less_vertex_data {
  public:
    less_vertex_data() {}
    bool operator()(const T& lvalue, const T& rvalue) {
      if(lvalue.first.x() < rvalue.first.x()) return true;
      if(lvalue.first.x() > rvalue.first.x()) return false;
      if(lvalue.first.y() < rvalue.first.y()) return true;
      return false;
    }
  };

  template <typename T>
  struct lessPropertyCount {
    lessPropertyCount() {}
    bool operator()(const T& a, const T& b) {
      return a.first < b.first;
    }
  };

  //private static member functions

  static inline void mergeProperty(property_map& lvalue, std::pair<property_type, int>& rvalue) {
    typename property_map::iterator itr = std::lower_bound(lvalue.begin(), lvalue.end(), rvalue, 
                                                          lessPropertyCount<std::pair<property_type, int> >());
    if(itr == lvalue.end() ||
       (*itr).first != rvalue.first) {
      lvalue.insert(itr, rvalue);
    } else {
      (*itr).second += rvalue.second;
      if((*itr).second == 0)
        lvalue.erase(itr);
    }
//     if(assertSorted(lvalue)) {
//       std::cout << "in mergeProperty\n";
//       exit(0);
//     }
  }

  static inline bool assertSorted(property_map& pset) {
    bool result = false;
    for(unsigned int i = 1; i < pset.size(); ++i) {
      if(pset[i] < pset[i-1]) {
        std::cout << "Out of Order Error ";
        result = true;
      }
      if(pset[i].first == pset[i-1].first) {
        std::cout << "Duplicate Property Error ";
        result = true;
      }
      if(pset[0].second == 0 || pset[1].second == 0) {
        std::cout << "Empty Property Error ";
        result = true;
      }
    }
    return result;
  }

  static inline void setProperty(property_set& pset, property_map& pmap) {
    for(typename property_map::iterator itr = pmap.begin(); itr != pmap.end(); ++itr) {
      if((*itr).second > 0) {
        pset.insert(pset.end(), (*itr).first);
      }
    }
  }

  //private data members

  edge_property_vector output;
  scanline_type scanline;
  vertex_data currentVertex;
  property_map tmpVector;
  coordinate_type previousY;
  property_map countFromBelow;
  scanline_iterator scanlinePosition;

  //private member functions

  inline void mergeCount(property_map& lvalue, property_map& rvalue) {
    typename property_map::iterator litr = lvalue.begin();
    typename property_map::iterator ritr = rvalue.begin();
    tmpVector.clear();
    while(litr != lvalue.end() && ritr != rvalue.end()) {
      if((*litr).first <= (*ritr).first) {
        if(!tmpVector.empty() &&
           (*litr).first == tmpVector.back().first) {
          tmpVector.back().second += (*litr).second;
        } else {
          tmpVector.push_back(*litr);
        }
        ++litr;
      } else if((*ritr).first <= (*litr).first) {
        if(!tmpVector.empty() &&
           (*ritr).first == tmpVector.back().first) {
          tmpVector.back().second += (*ritr).second;
        } else {
          tmpVector.push_back(*ritr);
        }
        ++ritr;
      }
    }
    while(litr != lvalue.end()) {
      if(!tmpVector.empty() &&
         (*litr).first == tmpVector.back().first) {
        tmpVector.back().second += (*litr).second;
      } else {
        tmpVector.push_back(*litr);
      }
      ++litr;
    }
    while(ritr != rvalue.end()) {
      if(!tmpVector.empty() &&
         (*ritr).first == tmpVector.back().first) {
        tmpVector.back().second += (*ritr).second;
      } else {
        tmpVector.push_back(*ritr);
      }
      ++ritr;
    }
    lvalue.clear();
    for(unsigned int i = 0; i < tmpVector.size(); ++i) {
      if(tmpVector[i].second != 0) {
        lvalue.push_back(tmpVector[i]);
      }
    }
//     if(assertSorted(lvalue)) {
//       std::cout << "in mergeCount\n";
//       exit(0);
//     }
  }

  inline void processVertex(edge_property_vector& output) {
    if(!countFromBelow.empty()) {
      //we are processing an interval of change in scanline state between
      //previous vertex position and current vertex position where 
      //count from below represents the change on the interval
      //foreach scanline element from previous to current we
      //write the interval on the scanline that is changing
      //the old value and the new value to output
      property_merge_interval<coordinate_type> currentInterval(previousY, currentVertex.first.y());
      coordinate_type currentY = currentInterval.low();
      if(scanlinePosition == scanline.end() ||
         (*scanlinePosition).first != previousY) {
        scanlinePosition = scanline.lower_bound(previousY);
      }
      scanline_iterator previousScanlinePosition = scanlinePosition;
      ++scanlinePosition;
      while(scanlinePosition != scanline.end()) {
        coordinate_type elementY = (*scanlinePosition).first;
        if(elementY <= currentInterval.high()) {
          property_map& countOnLeft = (*previousScanlinePosition).second;
          edge_property element;
          output.push_back(element);
          output.back().first = property_merge_interval<coordinate_type>((*previousScanlinePosition).first, elementY);
          setProperty(output.back().second.first, countOnLeft);
          mergeCount(countOnLeft, countFromBelow);
          setProperty(output.back().second.second, countOnLeft);
          if(output.back().second.first == output.back().second.second) {
            output.pop_back(); //it was an internal vertical edge, not to be output
          }
          else if(output.size() > 1) {
            edge_property& secondToLast = output[output.size()-2];
            if(secondToLast.first.high() == output.back().first.low() &&
               secondToLast.second.first == output.back().second.first &&
               secondToLast.second.second == output.back().second.second) {
              //merge output onto previous output because properties are
              //identical on both sides implying an internal horizontal edge
              secondToLast.first.high(output.back().first.high());
              output.pop_back();
            }
          }
          if(previousScanlinePosition == scanline.begin()) {
            if(countOnLeft.empty()) {
              scanline.erase(previousScanlinePosition);
            }
          } else {
            scanline_iterator tmpitr = previousScanlinePosition;
            --tmpitr;
            if((*tmpitr).second == (*previousScanlinePosition).second)
              scanline.erase(previousScanlinePosition);
          }
             
        } else if(currentY < currentInterval.high()){
          //elementY > currentInterval.high()
          //split the interval between previous and current scanline elements
          std::pair<coordinate_type, property_map> elementScan;
          elementScan.first = currentInterval.high();
          elementScan.second = (*previousScanlinePosition).second;
          scanlinePosition = scanline.insert(scanlinePosition, elementScan);
          continue;
        } else {
          break;
        }
        previousScanlinePosition = scanlinePosition;
        currentY = previousY = elementY;
        ++scanlinePosition;
        if(scanlinePosition == scanline.end() &&
           currentY < currentInterval.high()) {
          //insert a new element for top of range
          std::pair<coordinate_type, property_map> elementScan;
          elementScan.first = currentInterval.high();
          scanlinePosition = scanline.insert(scanline.end(), elementScan);
        } 
      }
      if(scanlinePosition == scanline.end() &&
         currentY < currentInterval.high()) {
        //handle case where we iterated to end of the scanline
        //we need to insert an element into the scanline at currentY
        //with property value coming from below
        //and another one at currentInterval.high() with empty property value
        mergeCount(scanline[currentY], countFromBelow);
        std::pair<coordinate_type, property_map> elementScan;
        elementScan.first = currentInterval.high();
        scanline.insert(scanline.end(), elementScan);

        edge_property element;
        output.push_back(element);
        output.back().first = property_merge_interval<coordinate_type>(currentY, currentInterval.high());
        setProperty(output.back().second.second, countFromBelow);
        mergeCount(countFromBelow, currentVertex.second);
      } else {
        mergeCount(countFromBelow, currentVertex.second);
        if(countFromBelow.empty()) {
          if(previousScanlinePosition == scanline.begin()) {
            if((*previousScanlinePosition).second.empty()) {
              scanline.erase(previousScanlinePosition);
              //previousScanlinePosition = scanline.end();
              //std::cout << "ERASE_A ";
            }
          } else {
            scanline_iterator tmpitr = previousScanlinePosition;
            --tmpitr;
            if((*tmpitr).second == (*previousScanlinePosition).second) {
              scanline.erase(previousScanlinePosition);
              //previousScanlinePosition = scanline.end();
              //std::cout << "ERASE_B ";
            }
          }
        }
      }
    } else {
      //count from below is empty, we are starting a new interval of change
      countFromBelow = currentVertex.second;
      scanlinePosition = scanline.lower_bound(currentVertex.first.y());
      if(scanlinePosition != scanline.end()) {
        if((*scanlinePosition).first != currentVertex.first.y()) {
          if(scanlinePosition != scanline.begin()) {
            //decrement to get the lower position of the first interval this vertex intersects
            --scanlinePosition;
            //insert a new element into the scanline for the incoming vertex
            property_map& countOnLeft = (*scanlinePosition).second;
            std::pair<coordinate_type, property_map> element(currentVertex.first.y(), countOnLeft);
            scanlinePosition = scanline.insert(scanlinePosition, element);
          } else {
            property_map countOnLeft;
            std::pair<coordinate_type, property_map> element(currentVertex.first.y(), countOnLeft);
            scanlinePosition = scanline.insert(scanlinePosition, element);
          }
        }
      } else {
        property_map countOnLeft;
        std::pair<coordinate_type, property_map> element(currentVertex.first.y(), countOnLeft);
        scanlinePosition = scanline.insert(scanlinePosition, element);
      }
    }
    previousY = currentVertex.first.y();
  }

  template <typename T>
  inline int assertRedundant(T& t) {
    if(t.empty()) return 0;
    int count = 0; 
    typename T::iterator itr = t.begin();
    if((*itr).second.empty())
      ++count;
    typename T::iterator itr2 = itr;
    ++itr2;
    while(itr2 != t.end()) {
      if((*itr).second == (*itr2).second)
        ++count;
      itr = itr2;
      ++itr2;
    }
    return count;
  }

  template <typename T>
  inline void performExtract(T& result, property_merge_data& data) {
    if(data.empty()) return;
    //sort
    std::sort(data.begin(), data.end(), less_vertex_data<vertex_property>());
    
    //scanline
    bool firstIteration = true;
    scanlinePosition = scanline.end();
    for(unsigned int i = 0; i < data.size(); ++i) {
      if(firstIteration) {
        mergeProperty(currentVertex.second, data[i].second);
        currentVertex.first = data[i].first;
        firstIteration = false;
      } else {
        if(data[i].first != currentVertex.first) {
          if(data[i].first.x() != currentVertex.first.x()) {
            processVertex(output);
            //std::cout << scanline.size() << " ";
            countFromBelow.clear(); //should already be clear
            writeGraph(currentVertex.first.x(), result, output, scanline);
            currentVertex.second.clear();
            mergeProperty(currentVertex.second, data[i].second);
            currentVertex.first = data[i].first;
          } else {
            processVertex(output);
            currentVertex.second.clear();
            mergeProperty(currentVertex.second, data[i].second);
            currentVertex.first = data[i].first;
          }
        } else {
          mergeProperty(currentVertex.second, data[i].second);
        }
      }
    }
    processVertex(output);
    writeGraph(currentVertex.first.x(), result, output, scanline);
    //std::cout << scanline.size() << "\n";
  }

  template <typename T>
  inline void insertEdges(T& graph, property_set& p1, property_set& p2) {
    for(typename property_set::iterator itr = p1.begin(); itr != p1.end(); ++itr) {
      for(typename property_set::iterator itr2 = p2.begin(); itr2 != p2.end(); ++itr2) {
        if(*itr != *itr2) {
          graph[*itr].insert(*itr2);
          graph[*itr2].insert(*itr);
        }
      }
    }
  }

  template <typename T>
  inline void propertySetAbove(coordinate_type y, property_set& ps, T& scanline) {
    ps.clear();
    typename T::iterator itr = scanline.find(y);
    if(itr != scanline.end())
      setProperty(ps, (*itr).second);
  }

  template <typename T>
  inline void propertySetBelow(coordinate_type y, property_set& ps, T& scanline) {
    ps.clear();
    typename T::iterator itr = scanline.find(y);
    if(itr != scanline.begin()) {
      --itr;
      setProperty(ps, (*itr).second);
    }
  }

  template <typename T, typename T2>
  inline void writeGraph(coordinate_type x, T& graph, edge_property_vector& output, T2& scanline) {
    if(output.empty()) return;
    edge_property* previousEdgeP = &(output[0]);
    bool firstIteration = true;
    property_set ps;
    for(unsigned int i = 0; i < output.size(); ++i) {
      edge_property& previousEdge = *previousEdgeP;
      edge_property& edge = output[i];
      if(previousEdge.first.high() == edge.first.low()) {
        //horizontal edge
        insertEdges(graph, edge.second.first, previousEdge.second.first);
        //corner 1
        insertEdges(graph, edge.second.first, previousEdge.second.second);
        //other horizontal edge
        insertEdges(graph, edge.second.second, previousEdge.second.second);
        //corner 2
        insertEdges(graph, edge.second.second, previousEdge.second.first);
      } else {
        if(!firstIteration){
          //look up regions above previous edge 
          propertySetAbove(previousEdge.first.high(), ps, scanline);
          insertEdges(graph, ps, previousEdge.second.first);
          insertEdges(graph, ps, previousEdge.second.second);
        }
        //look up regions below current edge in the scanline
        propertySetBelow(edge.first.high(), ps, scanline);
        insertEdges(graph, ps, edge.second.first);
        insertEdges(graph, ps, edge.second.second);
      }
      firstIteration = false;
      //vertical edge
      insertEdges(graph, edge.second.second, edge.second.first);
      //shared region to left
      insertEdges(graph, edge.second.second, edge.second.second);
      //shared region to right
      insertEdges(graph, edge.second.first, edge.second.first);
      previousEdgeP = &(output[i]);
    }
    edge_property& previousEdge = *previousEdgeP;
    propertySetAbove(previousEdge.first.high(), ps, scanline);
    insertEdges(graph, ps, previousEdge.second.first);
    insertEdges(graph, ps, previousEdge.second.second);
    output.clear();
  }

  template <typename Result>
  inline void writeOutput(coordinate_type x, Result& result, edge_property_vector& output) {
    for(unsigned int i = 0; i < output.size(); ++i) {
      edge_property& edge = output[i];
      //edge.second.first is the property set on the left of the edge
      if(!edge.second.first.empty()) {
        typename Result::iterator itr = result.find(edge.second.first);
        if(itr == result.end()) {
          std::pair<property_set, polygon_set_type> element(edge.second.first, polygon_set_type(VERTICAL));
          itr = result.insert(result.end(), element);
        }
        std::pair<Interval, int> element2(Interval(edge.first.low(), edge.first.high()), -1); //right edge of figure
        (*itr).second.insert(x, element2);
      }
      if(!edge.second.second.empty()) {
        //edge.second.second is the property set on the right of the edge
        typename Result::iterator itr = result.find(edge.second.second);
        if(itr == result.end()) {
          std::pair<property_set, polygon_set_type> element(edge.second.second, polygon_set_type(VERTICAL));
          itr = result.insert(result.end(), element);
        }
        std::pair<Interval, int> element3(Interval(edge.first.low(), edge.first.high()), 1); //left edge of figure
        (*itr).second.insert(x, element3);
      }
    }
    output.clear();
  }
  
};
