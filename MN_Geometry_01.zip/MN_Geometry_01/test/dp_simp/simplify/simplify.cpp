// This example program reads a list of points from a text file (or from cin)
// and simplifies the the path given by the points using the Douglas-Peucker
// line simplification algorithm, using the tolerance given.

// MSVC8 insanity
#pragma warning(disable:4996)

// Enable expression templates
#define GEOM_USE_EXPRESSION_TEMPLATES

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include "geometry/geometry.hpp"
#include "geometry/utility.hpp"
#include "geometry/dp_simp.hpp"

int main(int argc, char const* argv[])
{
	typedef geom::point<double, 2> point2d;

	// Read points
	std::vector<point2d> points;
	point2d::value_type x, y;
	std::string line;
	std::size_t n = 0;
	if (argc > 1)
	{	// Read from input file
		std::ifstream f(argv[1]);
		for (n = 0; (f >> x >> y) && f.get() == '\n'; ++n)
			points.push_back(point2d(x,y));
	}
	else
	{	// Read from cin
		std::cout << "Enter point coordinates:\n";
		while (true)
		{
			getline(std::cin, line);
			std::istringstream linestrm(line);
			if (!(linestrm >> x >> y))
				break;
			points.push_back(point2d(x,y));
			++n;
		}
	}
	std::cout << "Read " << n << " points.\n";

	if (points.size() > 0)
	{
		// Input tolerance to use:
		double tolerance = 0;
		while(true)
		{
			std::cout << "Enter tolerance: ";
			getline(std::cin, line);
			std::istringstream linestrm(line);
			if (linestrm >> tolerance)
				break;
		}

		// Simplify
		std::vector<point2d> simp;
		std::size_t total = dp_simp(points.begin(), points.end(), std::back_inserter(simp), tolerance);
		
		// Output simplified path
		if (argc > 2)
		{
			std::ofstream file(argv[2]);
			for (std::vector<point2d>::const_iterator i = simp.begin(); i != simp.end() && file; ++i)
			file << i->x() << " " << i->y() << "\n";
		}
		else
			for (std::vector<point2d>::const_iterator i = simp.begin(); i != simp.end(); ++i)
				std::cout << i->x() << " " << i->y() << "\n";

		std::cout << total << " points in simplified path.\n";
	}

	return 0;	
}
