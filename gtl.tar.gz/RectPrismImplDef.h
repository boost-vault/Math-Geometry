/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template <class T, class T2>
class lessRectPrism
  : public std::binary_function<const RectPrismImpl<T>&, const RectPrismImpl<T2>&, bool>
{
private:
  AxisTransform atr_; // we want to compare along this orientation
public:
  inline lessRectPrism() {;} // allow data member to take default value
  inline lessRectPrism(AxisTransform atr) : atr_(atr) {;}
  inline lessRectPrism(Direction3D dir) : atr_(dir) {;}
  inline lessRectPrism(Orientation3D orient) : atr_(orient) {;}
  inline bool operator () (const RectPrismImpl<T>& a,
                           const RectPrismImpl<T2>& b) const ;
};

template <class T, class T2>
inline bool 
lessRectPrism<T, T2>::operator () (const RectPrismImpl<T>& a,
                                   const RectPrismImpl<T2>& b) const {
  RectPrismImpl<T> a_(a);
  RectPrismImpl<T2> b_(b);
  a_.transform(atr_);
  b_.transform(atr_);
  return a_ < b_;
}
  
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::operator<(const RectPrismImpl<T2>& b) const {
  PointImpl<PointData> llb(horizontal().low(), 
                           vertical().low(),
                           proximal().low());
  PointImpl<PointData> urt(horizontal().high(), 
                           vertical().high(),
                           proximal().high());
  PointImpl<PointData> bllb(horizontal().low(), 
                            vertical().low(),
                            proximal().low());
  PointImpl<PointData> burt(horizontal().high(), 
                            vertical().high(),
                            proximal().high());
  return (llb < bllb) | ((llb == bllb) & (urt < burt));
}

template<class T> template<class T2, class T3, class T4>
inline 
RectPrismImpl<T>::RectPrismImpl(const IntervalImpl<T2>& hrange, 
                                const IntervalImpl<T3>& vrange, 
                                const IntervalImpl<T4>& prange) {
  *this = construct_(hrange, vrange, prange);
}

template<class T> template<class T2, class T3>
inline 
RectPrismImpl<T>::RectPrismImpl(const RectangleImpl<T2>& r, 
                                const IntervalImpl<T3>& prange) {
  *this = construct_(r.horizontal(), r.vertical(), prange);
}

template<class T> template<class T2>
inline 
RectPrismImpl<T>::RectPrismImpl(const RectangleImpl<T2>& r, 
                                Unit low, Unit high) {
  *this = construct_(r.horizontal(), r.vertical(), IntervalImpl<IntervalData>(low,high));
}

template<class T> template<class T2>
inline 
RectPrismImpl<T>::RectPrismImpl(const LayeredRectImpl<T2>& lr) {
  *this = construct_(lr.horizontal(),
                     lr.vertical(),
                     IntervalImpl<IntervalData>(lr.layer()));
}

template<class T> template<class T2>
inline 
RectPrismImpl<T>::RectPrismImpl(const Segment3DImpl<T2>& s) {
  Point3DImpl<Point3DData> l = s.low();
  Point3DImpl<Point3DData> h = s.high();
  *this = construct_(IntervalImpl<IntervalData>(l.x(),h.x()),
                     IntervalImpl<IntervalData>(l.y(),h.y()),
                     IntervalImpl<IntervalData>(l.z(),h.z()));
}

template<class T> template<class T2>
inline 
RectPrismImpl<T>::RectPrismImpl(const Point3DImpl<T2>& p) {
  *this = construct_(IntervalImpl<IntervalData>(p.x()),
                     IntervalImpl<IntervalData>(p.y()),
                     IntervalImpl<IntervalData>(p.z()));
}

template<class T>
inline 
RectPrismImpl<T>::RectPrismImpl() {
  *this = construct_(IntervalImpl<IntervalData>(),
                     IntervalImpl<IntervalData>(),
                     IntervalImpl<IntervalData>());
}

template<class T>
const RectPrismImpl<T>& 
RectPrismImpl<T>::operator=(const RectPrismImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T>
const RectPrismImpl<T>& 
RectPrismImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::operator==(const RectPrismImpl<T2>& b) const {
  return horizontal() == b.horizontal() & 
    vertical() == b.vertical() & 
    proximal() == b.proximal();
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::operator!=(const RectPrismImpl<T2>& b) const {
  //apply demorgans theorem to achieve two level logic
  return horizontal() != b.horizontal() | 
    vertical() != b.vertical() | 
    proximal() != b.proximal();
}

template<class T>
inline
RectPrismImpl<T>::operator RectangleImpl<RectangleData>() const {
  const RectangleImpl<T>& r = mimicConstRectangle();
  return RectangleImpl<RectangleData>(r.xl(), r.yl(), r.xh(), r.yh());
}
     
template<class T>
inline RectangleImpl<T>& 
RectPrismImpl<T>::mimicRectangle() {
  return reinterpret_cast<RectangleImpl<T>&>(yield());
}

template<class T>
inline const RectangleImpl<T>& 
RectPrismImpl<T>::mimicConstRectangle() const {
  return reinterpret_cast<const RectangleImpl<T>&>(yieldConst());
}

template<class T>
inline bool 
RectPrismImpl<T>::isValid() const {
  return (horizontal().isValid() &
          vertical().isValid() &
          proximal().isValid());
}

template<class T>
inline bool 
RectPrismImpl<T>::isInitialized() const {
  return (horizontal().isInitialized() |
          vertical().isInitialized() |
          proximal().isInitialized());
}

template<class T>
inline IntervalImpl<IntervalData> 
RectPrismImpl<T>::get(Orientation3D orient) const {
  return get_(orient);
}    

template<class T> template<class T2>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::set(Orientation3D orient, 
                      const IntervalImpl<T2>& v) {
  set_(orient, v); return *this;
}    

template<class T>
inline Unit 
RectPrismImpl<T>::get(Direction3D dir) const {
  return get(Orientation3D(dir)).get(Direction1D(dir));
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::set(Direction3D dir, Unit value) {
  IntervalImpl<IntervalData> ivl(get(Orientation3D(dir)));
  ivl.set(Direction1D(dir), value);
  return set(Orientation3D(dir), ivl);
}
    
template<class T> template<class T2, class T3>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::setPoints(const Point3DImpl<T2>& p1,
                            const Point3DImpl<T3>& p2) {
  mimicRectangle().setPoints(p1.mimicConstPoint(),
                             p2.mimicConstPoint());
  Unit z1 = p1.z();
  Unit z2 = p2.z();
  predicated_swap(z2 < z1, z1, z2);
  proximal(IntervalImpl<IntervalData>(z1, z2));
  return *this;
}

template<class T>
inline IntervalImpl<IntervalData> 
RectPrismImpl<T>::horizontal() const {
  return get(HORIZONTAL);
}

template<class T>
inline IntervalImpl<IntervalData> 
RectPrismImpl<T>::vertical() const {
  return get(VERTICAL);
}

template<class T>
inline IntervalImpl<IntervalData> 
RectPrismImpl<T>::proximal() const {
  return get(PROXIMAL);
}

template<class T> template<class T2>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::horizontal(const IntervalImpl<T2>& v) {
  return set(HORIZONTAL, v);
}

template<class T> template<class T2>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::vertical(const IntervalImpl<T2>& v) {
  return set(VERTICAL, v);
}

template<class T> template<class T2>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::proximal(const IntervalImpl<T2>& v) {
  return set(PROXIMAL, v);
}

template<class T>
inline UnsignedUnit 
RectPrismImpl<T>::delta(Orientation3D orient) const {
  return get(orient).delta();
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::move(Orientation3D orient, Unit delta) {
  return set(orient, get(orient).move(delta));
}


template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::transform(const AxisTransform& atr) {
  //transform two points
  Point3DImpl<Point3DData> llpt(horizontal().low(),
                                vertical().low(),
                                proximal().low());
  Point3DImpl<Point3DData> urpt(horizontal().high(),
                                vertical().high(),
                                proximal().high());
  llpt.transform(atr);
  urpt.transform(atr);
  return setPoints(llpt, urpt);
}
    
template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::transform(const Transform& tr) {
  //transform two points
  Point3DImpl<Point3DData> llpt(horizontal().low(),
                                vertical().low(),
                                proximal().low());
  Point3DImpl<Point3DData> urpt(horizontal().high(),
                                vertical().high(),
                                proximal().high());
  llpt.transform(tr);
  urpt.transform(tr);
  return setPoints(llpt, urpt);
}

template<class T>
inline UnsignedLongUnit 
RectPrismImpl<T>::volume() const {
  return ((UnsignedLongUnit)delta(HORIZONTAL)) * delta(VERTICAL)
    * delta(PROXIMAL);
}

template<class T>
inline UnsignedLongUnit 
RectPrismImpl<T>::area() const {
  //multiply by two 
  return (((UnsignedLongUnit)delta(HORIZONTAL)) * delta(VERTICAL) +
          ((UnsignedLongUnit)delta(HORIZONTAL)) * delta(PROXIMAL) +
          ((UnsignedLongUnit)delta(PROXIMAL)) * delta(VERTICAL)) << 1;
}

template<class T>
inline UnsignedLongUnit 
RectPrismImpl<T>::sumDeltas() const {
  return ((UnsignedLongUnit)delta(HORIZONTAL)) + delta(VERTICAL) +
    delta(PROXIMAL);
}
   
template<class T>
inline UnsignedLongUnit 
RectPrismImpl<T>::halfPerimeter() const {
  //multiply by two
  return sumDeltas() << 1;
}

template<class T>
inline UnsignedLongUnit 
RectPrismImpl<T>::perimeter() const {
  //multiply by four
  return sumDeltas() << 2;
}

template <class T> template <class T2>
inline double
RectPrismImpl<T>::euclidianDistance(const Point3DImpl<T2> & p) const {
  return sqrt(mimicConstRectangle().euclidianDistance(p.mimicConstPoint()) +
    distance(p, PROXIMAL));
}

template <class T> template <class T2>
inline double
RectPrismImpl<T>::manhattanDistance(const Point3DImpl<T2> & p) const {
  return distance(p, HORIZONTAL) + distance(p, VERTICAL) + distance(p, PROXIMAL);
}

template <class T> 
inline Unit 
RectPrismImpl<T>::distance(Unit u, Orientation3D o) const {
  return get(o).distance(u);
}

template <class T> template <class T2>
inline Unit 
RectPrismImpl<T>::distance(const Point3DImpl<T2> & p, Orientation3D o) const {
  return get(o).distance(p.get(o));
}

template <class T> template <class T2>
inline Unit 
RectPrismImpl<T>::distance(const RectPrismImpl<T2> & r2, Orientation3D o) const {
  return get(o).distance(r2.get(o));
}

template <class T> template <class T2>
inline double 
RectPrismImpl<T>::euclidianDistance(const RectPrismImpl<T2> & r2) const {
  return sqrt(distance(r2, PROXIMAL) +
              mimicConstRectangle().euclidianDistance(r2.mimicConstRectangle()));
}

template <class T> template <class T2>
inline Unit 
RectPrismImpl<T>::manhattanDistance(const RectPrismImpl<T2> & r2) const {
  return mimicConstRectangle().manhattanDistance(r2.mimicConstRectangle()) +
    proximal().distance(r2.proximal());
}

template <class T> template <class T2>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::getDeltas(const RectPrismImpl<T2> & r2,
                            Unit& deltax, Unit& deltay, Unit& deltaz) const {
  deltaz = proximal().distance(r2.proximal());
  mimicConstRectangle().getDeltas(r2.mimicConstRectangle(), deltax, deltay);
  return *this;
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::contains(const RectPrismImpl<T2>& b, 
                           bool considerTouch) const {
  return horizontal().contains(b.horizontal(), considerTouch)&
    vertical().contains(b.vertical(), considerTouch)&
    proximal().contains(b.proximal(), considerTouch);
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::contains(const LayeredRectImpl<T2>& b, 
                           bool considerTouch) const {
  return horizontal().contains(b.horizontal(), considerTouch)&
    vertical().contains(b.vertical(), considerTouch)&
    proximal().contains(b.getLayer(), considerTouch);
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::contains(const Segment3DImpl<T2>& s, 
                           bool considerTouch) const {
  return contains(s.low(), considerTouch) & 
    contains(s.high(), considerTouch);
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::contains(const Point3DImpl<T2>& p, 
                           bool considerTouch) const {
  return horizontal().contains(p.x(), considerTouch)&
    vertical().contains(p.x(), considerTouch)&
    proximal().contains(p.x(), considerTouch);
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::inside(const RectPrismImpl<T2>& b, 
                         bool considerTouch) const {
  return b.contains(*this, considerTouch);
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::intersects(const RectPrismImpl<T2>& b, 
                             bool considerTouch) const {
  if (considerTouch) {
    return horizontal().intersects(b.horizontal(), true) &
      vertical().intersects(b.vertical(), true)&
      proximal().intersects(b.proximal(), true);        
  } else {
    return horizontal().intersects(b.horizontal(), false) &
      vertical().intersects(b.vertical(), false)&
      proximal().intersects(b.proximal(), false);        
  }
}

/// Check if boundaries of RectPrism b and `this` RectPrism intersect
/// if considerTouch is true a boundary in common is considered intersection
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::boundariesIntersect(const RectPrismImpl<T2>& b, 
                                      bool considerTouch) const {
  return (intersects(b, considerTouch) &
          !(contains(b, !considerTouch)) &
          !(inside(b, !considerTouch)));
}
    
/// check if they are touching on a side at the high or low direction of
/// orientation orient
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::abuts(const RectPrismImpl<T2>& b, Direction3D dir) const {
  Orientation3D o1, o2;
  Orientation3D(dir).getNormalPlane(o1, o2);
  return get(Orientation3D(dir)).
    abuts(b.get(Orientation3D(dir)), Direction1D(dir)) &
    get(o1).intersects(b.get(o2)) &     
    get(o2).intersects(b.get(o2));      
}

/// check if they are touching on a side at the high or low direction of
/// orientation orient
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::abuts(const RectPrismImpl<T2>& b, 
                        Orientation3D orient) const {
  Orientation3D o1, o2;
  orient.getNormalPlane(o1, o2);
  return get(orient).
    abuts(b.get(orient)) &
    get(o1).intersects(b.get(o2)) &     
    get(o2).intersects(b.get(o2));      
}

template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::abuts(const RectPrismImpl<T2>& b) const {
  return abuts(b, HORIZONTAL) | abuts(b, VERTICAL)| abuts(b, PROXIMAL);
} 

/// set the range of 'this' specified by orient to between its
/// intersection with Interval b
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::intersectRange(const IntervalImpl<T2>& b, 
                                 Orientation3D orient, 
                                 bool considerTouch) {
  IntervalImpl<IntervalData> ivl(get(orient));
  bool retval = ivl.intersect(b, considerTouch);
  set(orient, ivl);
  return index;
}

/// clip `this` RectPrism to the specified Rectangle
/// if considerTouch is true will clip to a zero volume RectPrism if 
/// appropriate
/// if 'this' does not intersect b, leave 'this' unchanged and return false
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::intersect(const RectPrismImpl<T2>& b, bool considerTouch) {
  IntervalImpl<IntervalData> hr = horizontal();
  IntervalImpl<IntervalData> vr = vertical();
  IntervalImpl<IntervalData> pr = proximal();
  bool result = hr.intersect(b.horizontal(), considerTouch);
  result &= vr.intersect(b.vertical(), considerTouch);
  result &= pr.intersect(b.proximal(), considerTouch);
  horizontal(predicated_value(result, hr, horizontal()));
  vertical(predicated_value(result, vr, vertical()));
  proximal(predicated_value(result, pr, proximal()));
  return result;
}

/// set `this` RectPrism to the intersection between b1 and b2
/// if such and intersection exists, else set 'this' to b1 and return false
template<class T> template<class T2, class T3>
inline bool 
RectPrismImpl<T>::intersection(const RectPrismImpl<T2>& b1, 
                               const RectPrismImpl<T3>& b2,
                               bool considerTouch) {
  *this = b1;
  return intersect(b2, considerTouch);
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::bloat(Orientation3D orient, UnsignedUnit bloating) { 
  IntervalImpl<IntervalData> ivl = get(orient);
  ivl.bloat(bloating);
  set(orient, ivl);   
  return *this;
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::bloat(UnsignedUnit bloating) {
  bloat(VERTICAL, bloating);
  bloat(HORIZONTAL, bloating);
  bloat(PROXIMAL, bloating);
  return *this;
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::bloat(Direction3D dir, UnsignedUnit bloating) { 
  IntervalImpl<IntervalData> ivl = get(Orientation3D(dir));
  ivl.bloat(Direction1D(dir), bloating);
  set(Orientation3D(dir), ivl);
  return *this;
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::shrink(Orientation3D orient, UnsignedUnit shrinking) {
  IntervalImpl<IntervalData> ivl = get(orient);
  ivl.shrink(shrinking);
  set(orient, ivl);
  return *this;
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::shrink(UnsignedUnit shrinking) {
  shrink(VERTICAL, shrinking);
  shrink(HORIZONTAL, shrinking);
  shrink(PROXIMAL, shrinking);
  return *this;
}

template<class T>
inline RectPrismImpl<T>& 
RectPrismImpl<T>::shrink(Direction3D dir, UnsignedUnit shrinking) { 
  IntervalImpl<IntervalData> ivl = get(Orientation3D(dir));
  ivl.shrink(Direction1D(dir), shrinking);
  set(Orientation3D(dir), ivl);
  return *this;
}

/// enlarge 'this' RectPrism to encompass the Interval b on the
/// orientation orient
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::encompass(const IntervalImpl<T2>& b,
                            Orientation3D orient) {
  IntervalImpl<IntervalData> ivl = get(orient);
  bool retval = ivl.encompass(b);
  set(orient, predicated_value(retval, ivl, get(orient)));
  return retval;
}

/// enlarge `this` RectPrism to encompass the RectPrism b
/// return true of the enlargement happened at all
template<class T> template<class T2>
inline bool 
RectPrismImpl<T>::encompass(const RectPrismImpl<T2>& b) {
  bool retval = encompass(b.horizontal(), HORIZONTAL);
  retval |= encompass(b.vertical(), VERTICAL);
  retval |= encompass(b.proximal(), PROXIMAL);
  return retval;
}    


//private functions
template<class T>
inline IntervalImpl<IntervalData> 
RectPrismImpl<T>::get_(Orientation3D orient) const {
  return RectPrismInterface<T>::RectPrismGet(*this, orient);
}
template<class T>
inline void 
RectPrismImpl<T>::set_(Orientation3D orient, 
                       const IntervalImpl<IntervalData>& value) {
  RectPrismInterface<T>::RectPrismSet(*this, orient, value.yieldConst());
}
template<class T>
inline T 
RectPrismImpl<T>::construct_(const IntervalImpl<IntervalData>& hrange, 
                             const IntervalImpl<IntervalData>& vrange,
                             const IntervalImpl<IntervalData>& prange) {
  return RectPrismInterface<T>::RectPrismConstruct(hrange.yieldConst(), 
                                                   vrange.yieldConst(), 
                                                   prange.yieldConst());
} 


template <class T>
std::ostream& operator<< (std::ostream& o, const RectPrismImpl<T>& rp)
{
  o << rp.horizontal() << GTL_SEP << rp.vertical() << GTL_SEP << rp.proximal();
  return o;
}

template <class T>
std::istream& operator>> (std::istream& i, RectPrismImpl<T>& rp)
{
  Interval h, v, p;
  i >> h >> v >> p;
  rp.horizontal(h);
  rp.vertical(v);
  rp.proximal(p);
  return i;
}

