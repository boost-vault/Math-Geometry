/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
inline int andRectPair(std::vector<RectangleImpl<RectangleData> >& retRects, 
                       const RectangleImpl<RectangleData> & rect1,
                       const RectangleImpl<RectangleData> & rect2,
                       Orientation2D orient) {
  RectangleImpl<RectangleData> retRect(rect1);
  if(retRect.intersect(rect2, false)){
    retRects.push_back(retRect);
    return 1;
  }
  return 0;
}
    
using namespace std;
//This guy didn't work for some reason I don't understand

inline void 
quickErase(std::vector<Unit>* vec, std::vector<Unit>::iterator itr){
  *itr = vec->back();
  vec->pop_back();
}
    
template <class pT, class rT>
inline int pointsInRects(std::vector<PointImpl<pT> >& retPoints,
                         const std::vector<PointImpl<pT> >& inputPoints,
                         const std::vector<RectangleImpl<rT> >& rects,
                         Orientation2D orient,
                         bool internal,
                         bool considerTouch)
{
  //      std::cout << "pointsInRects " << orient << ", internal: " << internal << std::endl;
  std::vector<Rectangle> lrects, rrects, retRects;
  lrects.reserve(rects.size());
  for (size_t i = 0; i < rects.size(); ++i) {
    lrects.push_back(rects[i]); //convert data since algo is not templated
  }
  orRectVecs(retRects, lrects, rrects, orient);
  size_t left  = 0; 
  size_t right = 0;
  for(size_t i = 0; i < inputPoints.size(); ++i) {
    //        std::cout << "point: " << inputPoints[i] << std::endl;
    while (left < retRects.size() &&
           retRects[left].get(orient.getPositiveDirection()) < inputPoints[i].get(orient)) {
      //          std::cout << "left: " << left << ", rectangle: " << retRects[left] << std::endl;
      ++left;
    }
    right = left;
    bool found = false;
    while (right < retRects.size() &&
           retRects[right].get(orient.getNegativeDirection()) <= inputPoints[i].get(orient)) {
      //          std::cout << "right: " << right << ", rectangle: " << retRects[right] << std::endl;
      if (retRects[right].contains(inputPoints[i], considerTouch)) {
        found = true;
        break;
      }
      ++right;
    }
    if (found ^ !internal) { //if found and internal or not found and not internal
      //          std::cout << "found" << std::endl;
      retPoints.push_back(inputPoints[i]);
    }
  }
  return retPoints.size();
}

template <class CT, class ST, class T> inline CT& 
processEdge_(CT& rectangles, ST& scanData, const Interval& edge, 
             bool& haveCurrentRect, RectangleImpl<T>& currentRect, Unit currentCoordinate, Orientation2D orient) 
{
  typedef RectangleImpl<T> RType;
  bool edgeProcessed = false;
  if(!scanData.empty()) {

    //process all rectangles in the scanData that touch the edge
    typename ST::iterator dataIter = scanData.lower_bound(RType(edge, edge));
    //decrement beginIter until its low is less than edge's low
    while((dataIter == scanData.end() || (*dataIter).get(orient).get(LOW) > edge.get(LOW)) && 
          dataIter != scanData.begin())
      {
        --dataIter;
      }
    //process each rectangle until the low end of the rectangle 
    //is greater than the high end of the edge
    while(dataIter != scanData.end() &&
          (*dataIter).get(orient).get(LOW) <= edge.get(HIGH)) 
      {
        const RType& rect = *dataIter;
        //if the rectangle data intersects the edge at all
        if(rect.get(orient).get(HIGH) >= edge.get(LOW)) {
          if(rect.get(orient).contains(edge, true)) {
            //this is a closing edge
            //we need to write out the intersecting rectangle and
            //insert between 0 and 2 rectangles into the scanData
            //write out rectangle
            RType tmpRect = rect;

            if(rect.get(orient.getPerpendicular().getDirection(LOW)) < currentCoordinate) {
              //set the high coordinate perpedicular to slicing orientation
              //to the current coordinate of the scan event
              tmpRect.set(orient.getPerpendicular().getDirection(HIGH),
                          currentCoordinate);
              rectangles.insert(rectangles.end(), tmpRect);
            }
            //erase the rectangle from the scan data
            typename ST::iterator nextIter = dataIter;
            ++nextIter;
            scanData.erase(dataIter);
            if(tmpRect.get(orient).get(LOW) < edge.get(LOW)) {
              //insert a rectangle for the overhang of the bottom
              //of the rectangle back into scan data
              RType lowRect(tmpRect);
              lowRect.set(orient.getPerpendicular(), Interval(currentCoordinate,
                                                              currentCoordinate));
              lowRect.set(orient.getDirection(HIGH), edge.get(LOW));
              scanData.insert(nextIter, lowRect);
            }
            if(tmpRect.get(orient).get(HIGH) > edge.get(HIGH)) {
              //insert a rectangle for the overhang of the top
              //of the rectangle back into scan data
              RType highRect(tmpRect);
              highRect.set(orient.getPerpendicular(), Interval(currentCoordinate,
                                                               currentCoordinate));
              highRect.set(orient.getDirection(LOW), edge.get(HIGH));
              scanData.insert(nextIter, highRect);
            }
            //we are done with this edge
            edgeProcessed = true;                 
            break;
          } else {
            //it must be an opening edge
            //assert that rect does not overlap the edge but only touches
            //write out rectangle
            RType tmpRect = rect;
            //set the high coordinate perpedicular to slicing orientation
            //to the current coordinate of the scan event
            if(tmpRect.get(orient.getPerpendicular().getDirection(LOW)) < currentCoordinate) {
              tmpRect.set(orient.getPerpendicular().getDirection(HIGH),
                          currentCoordinate);
              rectangles.insert(rectangles.end(), tmpRect);
            }
            //erase the rectangle from the scan data
            typename ST::iterator nextIter = dataIter;
            ++nextIter;
            scanData.erase(dataIter);
            dataIter = nextIter;
            if(haveCurrentRect) {
              if(currentRect.get(orient).get(HIGH) >= edge.get(LOW)){
                if(!edgeProcessed && currentRect.get(orient.getDirection(HIGH)) > edge.get(LOW)){
                  RType tmpRect2(currentRect);
                  tmpRect2.set(orient.getDirection(HIGH), edge.get(LOW));
                  scanData.insert(nextIter, tmpRect2);
                  if(currentRect.get(orient.getDirection(HIGH)) > edge.get(HIGH)) {
                    currentRect.set(orient, Interval(edge.get(HIGH), currentRect.get(orient.getDirection(HIGH))));
                  } else {
                    haveCurrentRect = false;
                  }
                } else {
                  //extend the top of current rect
                  currentRect.set(orient.getDirection(HIGH), 
                                  max(edge.get(HIGH), 
                                      tmpRect.get(orient.getDirection(HIGH))));
                }
              } else {
                //insert current rect into the scanData
                scanData.insert(nextIter, currentRect);
                //create a new current rect
                currentRect.set(orient.getPerpendicular(), Interval(currentCoordinate,
                                                                    currentCoordinate));
                currentRect.set(orient, Interval(min(tmpRect.get(orient).get(LOW), 
                                                     edge.get(LOW)),
                                                 max(tmpRect.get(orient).get(HIGH),
                                                     edge.get(HIGH))));
              }
            } else {
              haveCurrentRect = true;
              currentRect.set(orient.getPerpendicular(), Interval(currentCoordinate,
                                                                  currentCoordinate));
              currentRect.set(orient, Interval(min(tmpRect.get(orient).get(LOW), 
                                                   edge.get(LOW)),
                                               max(tmpRect.get(orient).get(HIGH),
                                                   edge.get(HIGH))));
            }
            //skip to nextIter position
            edgeProcessed = true;
            continue;
          }
          edgeProcessed = true;
        }
        ++dataIter;
      } //end while edge intersects rectangle data 

  }
  if(!edgeProcessed) {
    if(haveCurrentRect) {
      if(currentRect.get(orient.getPerpendicular().getDirection(HIGH)) 
         == currentCoordinate &&
         currentRect.get(orient.getDirection(HIGH)) >= edge.get(LOW)) 
        {
          if(currentRect.get(orient.getDirection(HIGH)) > edge.get(LOW)){
            RType tmpRect(currentRect);
            tmpRect.set(orient.getDirection(HIGH), edge.get(LOW));
            scanData.insert(scanData.end(), tmpRect);
            if(currentRect.get(orient.getDirection(HIGH)) > edge.get(HIGH)) {
              currentRect.set(orient, 
                              Interval(edge.get(HIGH), 
                                       currentRect.get(orient.getDirection(HIGH))));
              return rectangles;
            } else {
              haveCurrentRect = false;
              return rectangles;
            }
          }
          //extend current rect
          currentRect.set(orient.getDirection(HIGH), edge.get(HIGH));
          return rectangles;
        }
      scanData.insert(scanData.end(), currentRect);
      haveCurrentRect = false;
    } 
    RType tmpRect(currentRect);
    tmpRect.set(orient.getPerpendicular(), Interval(currentCoordinate,
                                                    currentCoordinate));
    tmpRect.set(orient, edge);
    scanData.insert(tmpRect);
    return rectangles;
  }
  return rectangles;
  
}
template <class CT, class T> inline 
ScanLineToRects<CT, T>& ScanLineToRects<CT, T>::processEdge(CT& rectangles, const Interval& edge) 
{
  processEdge_(rectangles, scanData_, edge, haveCurrentRect_, currentRect_, currentCoordinate_, orient_);
  return *this;
}

typedef std::multiset<Interval> EdgeSet;
typedef std::map<Unit, EdgeSet> EdgeMap;

//iterate over coordinates and populate edge map
//first coordinate is assumed to be an x value
template <class iT>
void populateEdgeMap(EdgeMap& edgeMap, iT iterBegin, iT iterEnd, Orientation2D orient) {
  if(iterBegin == iterEnd) return;
  Unit firstX = *iterBegin;
  ++iterBegin;
  if(iterBegin == iterEnd) return;
  Unit firstY = *iterBegin;
  ++iterBegin;
  Orientation2D curOrient = VERTICAL;
  Unit currentX = firstX;
  Unit currentY = firstY;
  Unit previousX = firstX;
  Unit previousY = firstY;
  for( ; iterBegin != iterEnd; ++iterBegin) {
    curOrient = curOrient.getPerpendicular();
    if(curOrient == HORIZONTAL) {
      currentX = *iterBegin;
      if(orient == HORIZONTAL) {
        edgeMap[currentY].insert(predicated_value(previousX < currentX,
                                                  Interval(previousX, currentX),
                                                  Interval(currentX, previousX)));
        previousX = currentX;
      }
    } else {
      currentY = *iterBegin;
      if(orient == VERTICAL) {
        edgeMap[currentX].insert(predicated_value(previousY < currentY,
                                                  Interval(previousY, currentY),
                                                  Interval(currentY, previousY)));
        previousY = currentY;
      }
    }
  }
  //after the loop executes we have one more edge to add
  if(orient == VERTICAL) {
    edgeMap[firstX].insert(predicated_value(firstY < currentY,
                                            Interval(firstY, currentY),
                                            Interval(currentY, firstY)));
  } else {
    edgeMap[currentY].insert(predicated_value(firstX < currentX,
                                              Interval(firstX, currentX),
                                              Interval(currentX, firstX)));
  }
}

typedef std::pair<Unit, Interval> EdgeVectorElement;
typedef std::vector<EdgeVectorElement> EdgeVector;

class lessEdgeVectorElement : public std::binary_function<const EdgeVectorElement&, const EdgeVectorElement&, bool> {
public:
   inline lessEdgeVectorElement() {}
   inline bool operator () (const EdgeVectorElement& elem1, const EdgeVectorElement& elem2) const {
      return elem1.first < elem2.first || (elem1.first == elem2.first &&
                                           elem1.second < elem2.second);
  }
};

inline void sortEdgeVector(EdgeVector& ev) {
   std::sort(ev.begin(), ev.end(), lessEdgeVectorElement());
}

typedef std::pair<Unit, std::pair<Unit, int> > VertexCount;
typedef std::vector<VertexCount> VertexCountVector;

class lessVertexCount : public std::binary_function<const VertexCount&, const VertexCount&, bool> {
public:
   inline lessVertexCount() {}
   inline bool operator () (const VertexCount& elem1, const VertexCount& elem2) const {
      return elem1.first < elem2.first || (elem1.first == elem2.first &&
                                           elem1.second.first < elem2.second.first);
  }
};

inline void sortVertexCountVector(VertexCountVector& vcv) {
   std::sort(vcv.begin(), vcv.end(), lessVertexCount());
}

inline void sanitizeVertexCountVector(EdgeVector& ev, const VertexCountVector& vcv) {
   ev.reserve(ev.size() + vcv.size());
   int count = 0;
   VertexCountVector::const_iterator itr = vcv.begin();
   if(itr == vcv.end()) return;
   Unit coord = (*itr).first;
   Unit low = (*itr).second.first;
   count = (*itr).second.second;
   for(++itr; itr != vcv.end(); ++itr){
      Unit high = (*itr).second.first;
      if((*itr).first != coord) {
         coord = (*itr).first;
         count = (*itr).second.second;
      } else {
         //if the count is odd output an edge from low to high at the coord
         if(count & 1) {
            EdgeVectorElement eve;
            eve.first = coord;
            eve.second = Interval(low, high);
            ev.push_back(eve);
         }
         count += (*itr).second.second;
      }
      low = high;
   }
}

template <class iT>
inline void populateVertexCountVector(VertexCountVector& vcv, iT iterBegin, iT iterEnd, Orientation2D orient) {
  if(iterBegin == iterEnd) return;
  Unit firstX = *iterBegin;
  ++iterBegin;
  if(iterBegin == iterEnd) return;
  Unit firstY = *iterBegin;
  ++iterBegin;
  Orientation2D curOrient = VERTICAL;
  Unit currentX = firstX;
  Unit currentY = firstY;
  Unit previousX = firstX;
  Unit previousY = firstY;
  for( ; iterBegin != iterEnd; ++iterBegin) {
    curOrient = curOrient.getPerpendicular();
    if(curOrient == HORIZONTAL) {
      currentX = *iterBegin;
      if(orient == HORIZONTAL) {
         VertexCount vc;
         vc.first = currentY;
         vc.second.first = min(previousX, currentX);
         vc.second.second = 1;
         vcv.push_back(vc);
         vc.second.first = max(previousX, currentX);
         vc.second.second = -1;
         vcv.push_back(vc);
         previousX = currentX;
      }
    } else {
      currentY = *iterBegin;
      if(orient == VERTICAL) {
         VertexCount vc;
         vc.first = currentX;
         vc.second.first = min(previousY, currentY);
         vc.second.second = 1;
         vcv.push_back(vc);
         vc.second.first = max(previousY, currentY);
         vc.second.second = -1;
         vcv.push_back(vc);
         previousY = currentY;
      }
    }
  }
  //after the loop executes we have one more edge to add
  if(orient == VERTICAL) {
     VertexCount vc;
     vc.first = firstX;
     vc.second.first = min(firstY, currentY);
     vc.second.second = 1;
     vcv.push_back(vc);
     vc.second.first = max(firstY, currentY);
     vc.second.second = -1;
     vcv.push_back(vc);
  } else {
     VertexCount vc;
     vc.first = currentY;
     vc.second.first = min(firstX, currentX);
     vc.second.second = 1;
     vcv.push_back(vc);
     vc.second.first = max(firstX, currentX);
     vc.second.second = -1;
     vcv.push_back(vc);
  }
}


inline void sanitizeEdgeSet(EdgeSet& edgeSet) {
  std::vector<Interval> tmpVec;
  for(EdgeSet::iterator iter = edgeSet.begin(); iter != edgeSet.end(); ++iter) {
    tmpVec.clear();
    EdgeSet::iterator nextIter = iter;
    Unit prevHigh = UnitMax;
    for(++nextIter; nextIter != edgeSet.end() && (*nextIter).low() < (*iter).high(); ++nextIter) {
      if(tmpVec.empty()) {
        tmpVec.push_back(Interval((*iter).low(), (*nextIter).low()));
        prevHigh = (*nextIter).high();
      } else {
        tmpVec.push_back(Interval(prevHigh, (*nextIter).low()));
      }
      prevHigh = (*nextIter).high();
      if(prevHigh > (*iter).high()) {
        tmpVec.push_back(Interval((*iter).high(), prevHigh));
      }
    }
    if((*iter).high() > prevHigh) {
      tmpVec.push_back(Interval(prevHigh, (*iter).high()));
    }
    if(!tmpVec.empty()) {
      edgeSet.erase(iter, nextIter);
      edgeSet.insert(tmpVec.begin(), tmpVec.end());
      iter = nextIter;
    }
  }
}

inline void sanitizeEdgeMap(EdgeMap& edgeMap) {
  for(EdgeMap::iterator iter = edgeMap.begin(); iter != edgeMap.end(); ++iter) {
    sanitizeEdgeSet((*iter).second);
  }
}

template <class iT, class T> iT sanitizeEdge(iT iter, T& edges) {
  iT nextIter = iter;
  ++nextIter;
  if(nextIter == edges.end()) return iter;
  if((*nextIter).get(LOW) >= (*iter).get(HIGH)) return iter;
  Interval edge2 = *nextIter;
  Interval edge1 = *iter;
  edges.erase(iter);
  iT retIter;
  Interval addIvls[2];
  unsigned int cnt = 0;
  if(edge1.get(LOW) < edge2.get(LOW)) {
    addIvls[cnt] = Interval(edge1.get(LOW), edge2.get(LOW));
    ++cnt;
  }
  if(edge1.get(HIGH) != edge2.get(HIGH)) {
    addIvls[cnt] = predicated_value(edge1.get(HIGH) < edge2.get(HIGH),
                                    Interval(edge1.get(HIGH), edge2.get(HIGH)),
                                    Interval(edge2.get(HIGH), edge1.get(HIGH)));
    ++cnt;
  }
  if(cnt == 0) {
    retIter = nextIter;
    ++retIter;
    edges.erase(nextIter);
    if(retIter == edges.end()) return retIter;
  } else if(cnt == 1) {
    retIter = edges.insert(nextIter, addIvls[0]);
    edges.erase(nextIter);
  } else {
    retIter = edges.insert(nextIter, addIvls[0]);
    edges.erase(nextIter);
    edges.insert(retIter, addIvls[1]);
  }
  iT prevIter = retIter;
  while(retIter != edges.begin() && (*(--prevIter)).low() == (*retIter).low()) 
    retIter = prevIter;
  return sanitizeEdge(retIter, edges);
}

template <class CT, class T> inline CT& edgeMapToRectangles(CT& rectangles,
                                                            EdgeMap& edgeMap, Orientation2D orient, RectangleImpl<T> model) 
{
  ScanLineToRects<CT, T> scanlineToRects(orient, model);
  typedef RectangleImpl<T> RType;
  //typedef std::set<RectangleImpl<T>, lessRectangle<T, T> > ScanData;
  //ScanData scanData(predicated_value(orient.toInt(), AxisTransform(), AxisTransform(AxisTransform::SWAP_XY)));
  for(EdgeMap::iterator scanIter = edgeMap.begin(); scanIter != edgeMap.end(); ++scanIter){
    EdgeSet& scanEvent = (*scanIter).second;
    Unit currentCoordinate = (*scanIter).first;
    scanlineToRects.nextMajorCoordinate(currentCoordinate);
    RType currentRect(model);
    bool haveCurrentRect = false;
    for(EdgeSet::iterator eventIter = scanEvent.begin();
        eventIter != scanEvent.end(); ++eventIter) 
      {
        eventIter = sanitizeEdge(eventIter, scanEvent);
        if(eventIter == scanEvent.end()) break;
        const Interval& edge = *eventIter;
        scanlineToRects.processEdge(rectangles, edge);
      } //end for each edge
  } //end for each scan event

  return rectangles;
}

inline int notRectPair(std::vector<RectangleImpl<RectangleData> >& retRects, 
                       const RectangleImpl<RectangleData>& rect1,
                       const RectangleImpl<RectangleData>& rect2, 
                       Orientation2D orient) {
  //get the overlapping box
  RectangleImpl<RectangleData> clipRect(rect1);
  if(!clipRect.intersect(rect2, false)){
    //rectangles may touch, but do not overlap
    retRects.push_back(rect1);
    return 1; //added one rect to return set
  }
  //we know the rectangles intersect
  //from now on we only care about rect1 and clipRect
  //I will try to write it completely isotropic
  //note that they come out in sorted order by major then minor coordinate

  Orientation2D porient = orient.getPerpendicular();
  int numRects = 0;

  //  |-----------|
  //  |           |
  //  |-----------|
  //  |   |   |   |
  //  |___|___|___|
  //  |     X     |
  //  |___________|
  if(clipRect.getLowerBoundary(porient) > rect1.getLowerBoundary(porient)){
    RectangleImpl<RectangleData> retRect(rect1);
    retRect.setUpperBoundary(porient, clipRect.getLowerBoundary(porient));
    retRects.push_back(retRect);
    ++numRects;
  }
  //  |-----------|
  //  |           |
  //  |-----------|
  //  | X |   |   |
  //  |___|___|___|
  //  |           |
  //  |___________|
  if(clipRect.getLowerBoundary(orient) > rect1.getLowerBoundary(orient)){
    RectangleImpl<RectangleData> retRect(rect1);
    retRect.setUpperBoundary(orient, clipRect.getLowerBoundary(orient));
    retRect.setLowerBoundary(porient, clipRect.getLowerBoundary(porient));
    retRect.setUpperBoundary(porient, clipRect.getUpperBoundary(porient));
    retRects.push_back(retRect);
    ++numRects;
  }
  //  |-----------|
  //  |           |
  //  |-----------|
  //  |   |   | X |
  //  |___|___|___|
  //  |           |
  //  |___________|
  if(clipRect.getUpperBoundary(orient) < rect1.getUpperBoundary(orient)){
    RectangleImpl<RectangleData> retRect(rect1);
    retRect.setLowerBoundary(orient, clipRect.getUpperBoundary(orient));
    retRect.setLowerBoundary(porient, clipRect.getLowerBoundary(porient));
    retRect.setUpperBoundary(porient, clipRect.getUpperBoundary(porient));
    retRects.push_back(retRect);
    ++numRects;
  }
  //  |-----------|
  //  |     X     |
  //  |-----------|
  //  |   |   |   |
  //  |___|___|___|
  //  |           |
  //  |___________|
  if(clipRect.getUpperBoundary(porient) < rect1.getUpperBoundary(porient)){
    RectangleImpl<RectangleData> retRect(rect1);
    retRect.setLowerBoundary(porient, clipRect.getUpperBoundary(porient));
    retRects.push_back(retRect);
    ++numRects;
  }
  return numRects;
}


inline int orRectPair(std::vector<RectangleImpl<RectangleData> >& retRects, 
                      const RectangleImpl<RectangleData> & rect1,
                      const RectangleImpl<RectangleData> & rect2,
                      Orientation2D orient) {
  if(rect1.contains(rect2, true)) {
    retRects.push_back(rect1);
    return 1;
  }
  if(rect2.contains(rect1, true)) {
    retRects.push_back(rect2);
    return 1;
  }
  
  //sort input rects
  const RectangleImpl<RectangleData> * lowRectp = &rect1;
  const RectangleImpl<RectangleData> * highRectp = &rect2;
  if(!lessRectPair(rect1,rect2,orient)){
    lowRectp = &rect2;
    highRectp = &rect1;
  }
  const RectangleImpl<RectangleData> & lowRect = *lowRectp;
  const RectangleImpl<RectangleData> & highRect = *highRectp;

  //no overlap or major boundaries touch
  if(!rect1.intersects(rect2, true) || 
     (
      lowRect.getUpperBoundary(orient.getPerpendicular()) ==
      highRect.getLowerBoundary(orient.getPerpendicular()) &&
      (lowRect.getUpperBoundary(orient) != 
       highRect.getUpperBoundary(orient) ||
       lowRect.getLowerBoundary(orient) != 
       highRect.getLowerBoundary(orient)
       )      
      )
     ){
    //append them to ret
    retRects.push_back(lowRect);
    retRects.push_back(highRect);
    return 2;
  } 

  RectangleImpl<RectangleData> retRect(lowRect);
  
  Unit lxl = lowRect.getLowerBoundary(orient.getPerpendicular());
  Unit lxh = lowRect.getUpperBoundary(orient.getPerpendicular());
  Unit lyl = lowRect.getLowerBoundary(orient);
  Unit lyh = lowRect.getUpperBoundary(orient);
  Unit hxl = highRect.getLowerBoundary(orient.getPerpendicular());
  Unit hxh = highRect.getUpperBoundary(orient.getPerpendicular());
  Unit hyl = highRect.getLowerBoundary(orient);
  Unit hyh = highRect.getUpperBoundary(orient);

  //Two special cases where the rectangles merge
  //top and bottom are equal
  //
  // |------|--|
  // |   |  |  |
  // |   |  |  |
  // |___|__|__|
  //
  if(lyl == hyl && lyh == hyh){
    //merge the two rectangles
    //there is no containment so hxh > lxh
    retRect.setUpperBoundary(orient.getPerpendicular(),hxh);
    retRects.push_back(retRect);
    return 1;
  }
  //Similar to above but other orientation
  if(lxl == hxl && lxh == hxh){
    if(hyh > lyh){
      retRect.setUpperBoundary(orient,hyh);
    }
    else if(hyl < lyl){
      retRect.setUpperBoundary(orient,hyl);
    }
    retRects.push_back(retRect);
    return 1;
  }

  //all other casees
  RectangleImpl<RectangleData> clipRect(lowRect);
  clipRect.intersect(highRect, true);
  Unit cxl = clipRect.getLowerBoundary(orient.getPerpendicular());
  Unit cxh = clipRect.getUpperBoundary(orient.getPerpendicular());
  Unit cyl = clipRect.getLowerBoundary(orient);
  Unit cyh = clipRect.getUpperBoundary(orient);
  int retnum = 0;
  if(lxl < cxl){
    retRect.setUpperBoundary(orient.getPerpendicular(), cxl);
    retRects.push_back(retRect);
    ++retnum;
  }
  retRect = clipRect;
  if(lyl < cyl){
    retRect.setLowerBoundary(orient, lyl);
  }
  if(hyl < cyl){
    retRect.setLowerBoundary(orient, hyl);
  }
  if(hyh > cyh){
    retRect.setUpperBoundary(orient, hyh);
  }
  if(lyh > cyh){
    retRect.setUpperBoundary(orient, lyh);
  }
  retRects.push_back(retRect);
  ++retnum;
 
  if(hxh > cxh){
    retRect = highRect;
    retRect.setLowerBoundary(orient.getPerpendicular(), cxh);
    retRects.push_back(retRect);
    ++retnum;
  } else if(lxh > cxh){
    retRect = lowRect;
    retRect.setLowerBoundary(orient.getPerpendicular(), cxh);
    retRects.push_back(retRect);
    ++retnum;
  }
  return retnum;
}

// inline void sortElement(std::vector<RectangleImpl<RectangleData> >& vec, std::vector<RectangleImpl<RectangleData> >::iterator itr, 
//                                  Orientation2D orient){
//   std::vector<RectangleImpl<RectangleData> >::iterator searchitr;
//   searchitr = itr;
//   ++searchitr;
//   while(searchitr != vec.end() && lessRectPair(*searchitr, *itr, orient)){
//     RectangleImpl<RectangleData> tmpRect(*itr);
//     *itr = *searchitr;
//     *searchitr = tmpRect;
//     itr = searchitr;
//     ++searchitr;
//   }
//   searchitr = itr;
//   --searchitr;
//   while(itr != vec.begin() && !lessRectPair(*searchitr, *itr, orient)){
//     RectangleImpl<RectangleData> tmpRect(*itr);
//     *itr = *searchitr;
//     *searchitr = tmpRect;
//     itr = searchitr;
//     --searchitr;
//   }
// }

// inline std::vector<RectangleImpl<RectangleData> >::iterator findElement(std::vector<RectangleImpl<RectangleData> > vec, RectangleImpl<RectangleData> rect){
//   std::vector<RectangleImpl<RectangleData> >::iterator itr = vec.begin();
//   while(itr != vec.end() && *itr != rect){
//     ++itr;
//   }
//   return itr;
// };

// inline bool mergeNeeded(const RectangleImpl<RectangleData> & lrect,
//                         const RectangleImpl<RectangleData> & rrect,
//                         Orientation2D orient){
//   if(!lrect.intersects(rrect, true) || 
//      ((
//        lrect.getUpperBoundary(orient.getPerpendicular()) ==
//        rrect.getLowerBoundary(orient.getPerpendicular()) ||
//        rrect.getUpperBoundary(orient.getPerpendicular()) ==
//        lrect.getLowerBoundary(orient.getPerpendicular()) 
//        ) &&
//       (lrect.getUpperBoundary(orient) != 
//        rrect.getUpperBoundary(orient) ||
//        lrect.getLowerBoundary(orient) != 
//        rrect.getLowerBoundary(orient)
//        )      
//       )
//      ){
//     return false;
//   }
//   return true;
// }

inline int notRectVecs(std::vector<RectangleImpl<RectangleData> >& retRects, 
                       const std::vector<RectangleImpl<RectangleData> >& lrects,
                       const std::vector<RectangleImpl<RectangleData> >& rrects,
                       Orientation2D orient){
   //begin new code
   PolygonSetData input;
   PolygonSetData input2;
   populatePolygonSetDataWithRectangles(input, lrects.begin(), lrects.end(), orient);
   populatePolygonSetDataWithRectangles(input2, rrects.begin(), rrects.end(), orient);
   applyBooleanBinaryOp(input, input2, BinaryCount<BinaryNot>());
   Rectangle model;
   ScanLineToRects<std::vector<Rectangle>, RectangleData> scanlineToRects(orient, model);
   std::vector<Interval> leftEdges;
   std::vector<Interval> rightEdges;
   PolygonSetData::iterator itr = input.begin();
   for( ; itr != input.end(); ++ itr) {
      leftEdges.clear();
      rightEdges.clear();
      for(ScanEvent::iterator eventItr = (*itr).second.begin();
          eventItr != (*itr).second.end(); ++eventItr) {
         std::pair<Interval, int> element = (*eventItr);
         if(element.second == 1) {
            if(leftEdges.size() && leftEdges.back().high() == element.first.low()) {
               leftEdges.back().encompass(element.first);
            } else {
               leftEdges.push_back(element.first);
            }
         } else {
            if(rightEdges.size() && rightEdges.back().high() == element.first.low()) {
               rightEdges.back().encompass(element.first);
            } else {
               rightEdges.push_back(element.first);
            }
         }
      }
      scanlineToRects.nextMajorCoordinate(itr->first);
      std::vector<Interval>::iterator edgeItr_left = leftEdges.begin();
      std::vector<Interval>::iterator edgeItr_right = rightEdges.begin();
      while (edgeItr_left != leftEdges.end() || edgeItr_right != rightEdges.end()) {
         while (edgeItr_left != leftEdges.end() && (edgeItr_right == rightEdges.end() || ((*edgeItr_left) <= (*edgeItr_right)))) {
            scanlineToRects.processEdge(retRects, *edgeItr_left);
            edgeItr_left++;
         }
         while (edgeItr_right != rightEdges.end() && (edgeItr_left == leftEdges.end() || ((*edgeItr_right) <= (*edgeItr_left)))) {
            scanlineToRects.processEdge(retRects, *edgeItr_right);
            edgeItr_right++;
         }
      }
   }
   return retRects.size();
}

inline int andRectVecs(std::vector<RectangleImpl<RectangleData> >& retRects, 
                       const std::vector<RectangleImpl<RectangleData> >& lrects,
                       const std::vector<RectangleImpl<RectangleData> >& rrects,
                       Orientation2D orient){
   //begin new code
   PolygonSetData input;
   PolygonSetData input2;
   populatePolygonSetDataWithRectangles(input, lrects.begin(), lrects.end(), orient);
   populatePolygonSetDataWithRectangles(input2, rrects.begin(), rrects.end(), orient);
   applyBooleanBinaryOp(input, input2, BinaryCount<BinaryAnd>());
   Rectangle model;
   ScanLineToRects<std::vector<Rectangle>, RectangleData> scanlineToRects(orient, model);
   std::vector<Interval> leftEdges;
   std::vector<Interval> rightEdges;
   PolygonSetData::iterator itr = input.begin();
   for( ; itr != input.end(); ++ itr) {
      leftEdges.clear();
      rightEdges.clear();
      for(ScanEvent::iterator eventItr = (*itr).second.begin();
          eventItr != (*itr).second.end(); ++eventItr) {
         std::pair<Interval, int> element = (*eventItr);
         if(element.second == 1) {
            if(leftEdges.size() && leftEdges.back().high() == element.first.low()) {
               leftEdges.back().encompass(element.first);
            } else {
               leftEdges.push_back(element.first);
            }
         } else {
            if(rightEdges.size() && rightEdges.back().high() == element.first.low()) {
               rightEdges.back().encompass(element.first);
            } else {
               rightEdges.push_back(element.first);
            }
         }
      }
      scanlineToRects.nextMajorCoordinate(itr->first);
      std::vector<Interval>::iterator edgeItr_left = leftEdges.begin();
      std::vector<Interval>::iterator edgeItr_right = rightEdges.begin();
      while (edgeItr_left != leftEdges.end() || edgeItr_right != rightEdges.end()) {
         while (edgeItr_left != leftEdges.end() && (edgeItr_right == rightEdges.end() || ((*edgeItr_left) <= (*edgeItr_right)))) {
            scanlineToRects.processEdge(retRects, *edgeItr_left);
            edgeItr_left++;
         }
         while (edgeItr_right != rightEdges.end() && (edgeItr_left == leftEdges.end() || ((*edgeItr_right) <= (*edgeItr_left)))) {
            scanlineToRects.processEdge(retRects, *edgeItr_right);
            edgeItr_right++;
         }
      }
   }
   return retRects.size();
}

//     class scanLine {
//     public:
//       enum OP {
//         AND = 0,
//         OR = 1,
//         NOT = 2,
//         XOR = 3
//       };
//       scanLine(const std::vector<RectangleImpl<RectangleData>& lval,
//                const std::vector<RectangleImpl<RectangleData>& rval,
//                OP op;
//                Orientation2D o): lnum(left_num), rnum(right_num),
//                  workingRects(lval.begin(),
//                               lval.end(),
//                               orient.getPerpendicular().getNegativeDirection()),
//                  argRects(lval.begin(),
//                           lval.end(),
//                           orient.getPerpendicular().getNegativeDirection()),
//                  currentRects(orient.getPerpendicular().getPositiveDirection())
//       {
//         orient = o;
//         porient = orient.getPerpendicular();
//         lowDir = porient.getNegativeDirection();
//         highDir = porient.getPositiveDirection();
//       }

//       bool finished() const {
//         //bitwise & because empty() is constant time inline operation
//         return (!argRects.empty()) & (!workingRects.empty()) &
//           (!currentRects.empty());
//       }

//       int getResult(std::vector<RectangleImpl<RectangleData>& retBuff,
//                     std::vector<int>& nums) {
//         int rnum = 1;
//         int lnum = 0;
//         while((!argRects.empty()) & (!workingRects.empty())){
//           bool argLess = argRects.front().get(lowDir()) < 
//             workingRects.front().get(lowDir);
//           RectangleImpl<RectangleData> currentRect = 
//             predicated_value(argLess, argRects.top(), workingRects.top());
//           int num = predicated_value(argLess, rnum, lnum);
//           processRect(retBuff, nums, currentRect, num);
//         }
        
//         while(!argRects.empty()) {
//           RectangleImpl<RectangleData> currentRect = argRects.top();
//           int num = rnum;
//           processRect(retBuff, nums, currentRect, num);
//         }

//         while(!workingRects.empty()) {
//           RectangleImpl<RectangleData> currentRect = workingRects.top();
//           int num = lnum;
//           processRect(retBuff, nums, currentRect, num);
//         }
//       }

//       void processRect(std::vector<RectangleImpl<RectangleData>& retBuff,
//                        std::vector<int>& nums,
//                        const RectangleImpl<RectangleData>& currentRect,
//                        int num) {
//         if(num == 0) {
//           if(op != OR){
//             currentRects.push(currentRect);
//           } else {
//             std::set<RectangleImpl<RectangleData>, lessRect> rectSet(orient);
//             while(!currentRects.empty() &&
//                   currentRects.top().get(highDir) >= currentRect.get(lowDir)) {
//               rectSet.insert(currentRects.top());
//               currentRects.pop();
//             }
//             std::vector<RectangleImpl<RectangleData> > rectBuff;
//             rectSet.insert(currentRect);
//             for(std::set<RectangleImpl<RectangleData>, lessRect>::iterator searchItr
//                   = rectSet.begin(); searchItr != rectSet.end(); ++searchItr){
//               rectBuff.clear();
//               searchRect = *searchItr;
//               if(workingRect.intersects(searchRect, false) || 
//                workingRect.getUpperBoundary(orient) ==
//                searchRect.getLowerBoundary(orient) ||
//                workingRect.getLowerBoundary(orient) ==
//                searchRect.getUpperBoundary(orient) ){
//               //not just touch along orient edge
//               workingRects.erase(itr);
//               workingRects.erase(searchitr);
//               std::vector<RectangleImpl<RectangleData> > tempvec;
//               orRectPair(tempvec, workingRect, searchRect, orient);
//               for(RectVec::iterator tempitr = tempvec.begin();
//                   tempitr != tempvec.end(); ++tempitr){
//                 workingRects.insert(*tempitr);
//               }
//               nextitr = workingRects.find(tempvec.front());
//               break;
//             }

//               std::vector<RectangleImpl<Rect
//             }
//           }
//         } else {
          
//         }
//       }

//     private:
//       int lnum, rnum;
//       int cutline;
//       Orientation2D orient;
//       Orientation2D porient;
//       Direction2D lowDir;
//       Direction2D highDir;
//       priority_queue<RectangleImpl<RectangleData>, 
//                      std::vector<RectangleImpl<RectangleData> >, 
//                      lessRectEnds> workingRects;
//       priority_queue<RectangleImpl<RectangleData>, 
//                      std::vector<RectangleImpl<RectangleData> >, 
//                      lessRectEnds> argRects;
//       priority_queue<RectangleImpl<RectangleData>, 
//                      std::vector<RectangleImpl<RectangleData> >, 
//                      lessRectEnds> currentRects;
//     };

//     void ivlMapInsert(map<Interval, int>& ivlMap, Interval ivl) {
//       map<Interval,std::vector<int> >::iterator lbitr = ivlMap.lower_bound(ivl);
//       if(lbitr != ivlMap.begin()){
//         Interval,int>::iterator previtr = lbitr;
//         --previtr;
//         if(*previtr.first().high() > ivl.low()) {
          
//         } else if(*previtr.first().high() == ivl.low()) {

//         }
//       }
//     }
    
template <class iT>
inline void populatePolygonSetDataWithRectangles(PolygonSetData& setData,
                                                 iT begin, iT end, Orientation2D orient){
   Orientation2D porient = orient.getPerpendicular();
   for( ; begin != end; ++begin) {
      const Rectangle& rect = *begin;
      setData[rect.get(porient).low()].insert(std::pair<Interval, int>(rect.get(orient), 1));
      setData[rect.get(porient).high()].insert(std::pair<Interval, int>(rect.get(orient), -1));
   }
}

inline int orRectVecs(std::vector<RectangleImpl<RectangleData> >& retRects, 
                      const std::vector<RectangleImpl<RectangleData> >& lrects,
                      const std::vector<RectangleImpl<RectangleData> >& rrects,
                      Orientation2D orient){
   //begin new code
   PolygonSetData input;
   populatePolygonSetDataWithRectangles(input, lrects.begin(), lrects.end(), orient);
   populatePolygonSetDataWithRectangles(input, rrects.begin(), rrects.end(), orient);
   BooleanOr booleanOr;
   Rectangle model;
   ScanLineToRects<std::vector<Rectangle>, RectangleData> scanlineToRects(orient, model);
   std::vector<Interval> leftEdges;
   std::vector<Interval> rightEdges;
   std::vector<std::pair<Interval, int> > container;
   for(PolygonSetData::iterator itr = input.begin();
       itr != input.end(); ++ itr) {
      booleanOr.advanceScan();
      leftEdges.clear();
      rightEdges.clear();
      for(ScanEvent::iterator eventItr = (*itr).second.begin();
          eventItr != (*itr).second.end(); ++eventItr) {
         container.clear();
         booleanOr.processInterval(container, (*eventItr).first, (*eventItr).second);
         for(unsigned int i = 0; i < container.size(); ++i) {
            std::pair<Interval, int>& element = container[i];
            if(element.second == 1) {
               if(leftEdges.size() && leftEdges.back().high() == element.first.low()) {
                  leftEdges.back().encompass(element.first);
               } else {
                  leftEdges.push_back(element.first);
               }
            } else {
               if(rightEdges.size() && rightEdges.back().high() == element.first.low()) {
                  rightEdges.back().encompass(element.first);
               } else {
                  rightEdges.push_back(element.first);
               }
            }
         }
      }
      leftEdges.insert(leftEdges.end(), rightEdges.begin(), rightEdges.end());
      sort(leftEdges.begin(), leftEdges.end());
      scanlineToRects.nextMajorCoordinate(itr->first);
      for(std::vector<Interval>::iterator edgeItr = leftEdges.begin();
          edgeItr != leftEdges.end(); ++edgeItr) {
         scanlineToRects.processEdge(retRects, *edgeItr);
      }
   }
   return retRects.size();
}
    
//namespace LR {
//  double PolyNode::maxArea = 0;
//  Unit PolyNode::rightMost = 0;
//  Unit PolyNode::left = 0;
//  Rectangle PolyNode::maxRect = Rectangle(0,0,10,10);
//  std::vector<PolyNode>* PolyNode::nodes = NULL;
//    
//  //DFS function
//  inline void 
//  LR::PolyNode::PolyNodeDFS(int top, int bottom){
//    //exit condition
//    if(yl() > top || yh() < bottom)
//      return;
//    if(color == 1)
//      return;  //do not process black colored sub branches
//    if(yh() <= top && yl() >= bottom)
//      color = 1; //color it black
//      
//    //update boundaries
//    if(yh() < top)
//      top = yh();
//    if(yl() > bottom)
//      bottom = yl();
//      
//    //add additional termination condition to check if
//    //(right most - left) * (top - bottom) < maxArea
//    if((rightMost - left) * (float)(top - bottom) < maxArea)
//      return;
//      
//    if((top-bottom)*(float)(xh()-left) > maxArea) {
//      //new largest rectangle found
//      maxRect = Rectangle(left, bottom, xh(), top);
//      maxArea = maxRect.area();
//    }
//    for(unsigned int i = 0; i < children.size(); i++){
//      (*nodes)[children[i]].PolyNodeDFS(top, bottom);
//    }
//  }
//}
  
