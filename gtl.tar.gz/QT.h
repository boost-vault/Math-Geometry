namespace query {

// EmptyLockingPolicy
//
// Implements a locking policy ensuring no thread safety.
// Used instead of an actual locking policy when no thread safety  is desired.

class EmptyLockingPolicy {
  struct lock_type
  {
    lock_type (const EmptyLockingPolicy *) {};
  };
  struct dual_lock_type
  {
    dual_lock_type (const EmptyLockingPolicy *, const EmptyLockingPolicy *) {};
  };

public:
  // basic read lock
  typedef lock_type read_lock_type;

  // basic write lock
  typedef lock_type write_lock_type;

  // read lock types for operator== and the such
  typedef dual_lock_type dual_read_lock_type;
};

template <class Fruit> class Node; // forward declaration
template <class Fruit, class LockingPolicy> class QTOLD;

static const size_t INIT_CAPACITY = 8;

// Template magic to get bbox from various classes
template<class T>
struct QTResolveBBox
{
  static RectangleImpl<T>& getBBox(T *t)
  {
    return RectangleImpl<T>::mimic(*t);
  }
};

// Specialization for Rectangle itself
template<>
struct QTResolveBBox<Rectangle>
{
  static Rectangle& getBBox(Rectangle *t)
  {
    return *t;
  }
};

template<class Fruit>
  class Node
  {

  public:

    typedef Node* NPtr;
    typedef Fruit* FPtr;


    // POD Plain old data type, no ct, no dt
    class NOFP {  // Node or fruit pointer
      bool flag_;
      char filler1_, filler2_, filler3_; // to get rid of UMR's
      void* vp_; // this is the placeholder that will host either Node* or Fruit*
      // flag == 0  Node pointer
      // flag == 1  Fruit pointer
      inline bool getFlag_(void) const;
      inline void setFlag_(bool f);
    public:
      // gets a Node pointer. If self indeed is a node pointer, then it returns it
      // otherwise returns an invalid node pointer (which you can test against == 0)
      NOFP() :
        flag_(false), filler1_(0), filler2_(0), filler3_(0), vp_(0)
        { }
      inline NPtr getNodePointer(void) const;
      // sets self to node pointer
      inline void setNodePointer(const NPtr& np);
      // similar to above for fruit
      inline FPtr getFruitPointer(void) const;
      inline void setFruitPointer(const FPtr& fp);

      void print(std::ostream& o) const;
      void read(std::istream& i);

      inline bool operator ==(const NOFP& n) const {
        return (vp_ == n.vp_ && flag_ == n.flag_);
      }

    };

  public:
    NOFP l_, m_, r_; // left middle and right pointers that can point to either Node or Fruit

  public:
    // set all three to null Node pointers
    Node() { NPtr n = 0; l_.setNodePointer(n); m_.setNodePointer(n); r_.setNodePointer(n); }
    //friend class QTOLD<class Fruit>; // HP takes this, but g++ doesn't, hence I have to have l_ m_ r_ public
  };


template <class Fruit>
  void Node<Fruit>::NOFP::print(std::ostream& o) const
  {
    if(getFlag_() == false) // this is now a Node pointer
      o << "n," << getNodePointer();
    else
      o << "f," << getFruitPointer();
  }


template <class Fruit>
  void Node<Fruit>::NOFP::read(std::istream& i)
  {
    char c, comma;
    i >> c >> comma;
    if(c == 'n'){
      NPtr np;
      i >> np;
      setNodePointer(np);
    }
    else{
      FPtr fp;
      i >> fp;
      setFruitPointer(fp);
    }
  }


template<class Fruit>
  bool Node<Fruit>::NOFP::getFlag_(void) const
  {
    return flag_;
  }


template<class Fruit>
  void Node<Fruit>::NOFP::setFlag_(bool f)
  {
    flag_ = f;
  }


template<class Fruit>
  void Node<Fruit>::NOFP::setNodePointer(const NPtr& np)
  {
    setFlag_(false);
    vp_ = np;
  }


template<class Fruit>
  typename Node<Fruit>::NPtr Node<Fruit>::NOFP::getNodePointer(void) const
  {
    if(getFlag_()) return  0; // it's not a node pointer, return null
    return (typename Node<Fruit>::NPtr)vp_;
  }


template<class Fruit>
  void Node<Fruit>::NOFP::setFruitPointer(const FPtr& fp)
  {
    setFlag_(true);
    vp_ = fp;
  }


template<class Fruit>
  typename Node<Fruit>::FPtr Node<Fruit>::NOFP::getFruitPointer(void) const
  {

    if(!getFlag_()) return 0; // not a fruit pointer, return null
    return (FPtr)vp_;

  }


template<class Fruit>
  std::ostream& operator << (std::ostream& o, const Node<Fruit>& rs)
  {
    //return o << rs.l_ << "," << rs.m_ << "," << rs.r_;
    rs.l_.print(o);
    o << ",";
    rs.m_.print(o);
    o << ",";
    rs.r_.print(o);
    return o;
  }


template<class Fruit>
  std::istream& operator >> (std::istream& i, Node<Fruit>& rs)
  {
    char c;
    //i >> rs.l_ >> c >> rs.m_ >> c >> rs.r_;
    rs.l_.read(i);
    i >> c;
    rs.m_.read(i);
    i >> c;
    rs.r_.read(i);
    return i;
  }



//////////////////////////////////////////////////////////////

template <class T>
struct function_to_iterator {
  T t_;
  function_to_iterator(T& t) : t_(t) {}
  function_to_iterator& operator*() { return *this; }
  template <class U>
  function_to_iterator& operator=(U& u) { t_(u); return *this;}
};


template<class InsertIterator>
class QTOLD_QueryParameters {
private:
  QTOLD_QueryParameters(const QTOLD_QueryParameters&);
public:
  QTOLD_QueryParameters(const Rectangle& r, Unit xl, Unit yl, Unit xh, Unit yh, bool ct, InsertIterator& i) :
    qbox(r), xli(xl), yli(yl), xhi(xh), yhi(yh), considerTouch(ct), inserter(i) {} ;

  // box in which query takes place
  const Rectangle& qbox;

  // search params
  Unit xli;
  Unit yli;
  Unit xhi;
  Unit yhi;

  // touching ok?
  bool considerTouch;

  // result list
  InsertIterator& inserter;
};


//
// _QT_iterator
//
// Provide ability to iterate over all elements in QT.
// The class should *not* be used directly,
// but instead use the the typedef provided in the QT class.
//
// e.g. do this:
//
//   QT<int>::iterator iter;
//
//      not this:
//
//   _QT_iterator<int> iter;
//
//
// How does this class work?
// The iterator keeps track of:
//          the QT (obviously)
//          current element in the QT
//          path from root of QT to current element in QT
//
// To move from one element to another is done by incr()
// How is this done?
// some notation:
//
// front(path) = NPtr   (except in degenerate case when tree has no NPtrs)
//
// Find which (of l, m, r) portion of front(path) is equal to current
//
// if (l), current = m
// if (m), current = r
// if (r), current = upParentPath()
//
// if (current is a NPtr), current = getLeftMostFruit(current)
// if (current is null) current = upParentPath()
//
// this is just a depth first search, traversing left to right
//
// Multithreading:
// The iterator does *NOT* lock the query tree.
// Not sure to how to handle it.
// If a process had a lock b/c of the QT iterator
// and then tried adding an object to that QT, it'd
// try to get two locks - and potentially deadlock.
// The QTs do not (currently) have recursive mutexes.
//
// Plus, holding a lock for the duration of an iterator
// is far too long.  Additionally, multiple iterators in
// the same thread would all have locks on the same mutex.
//  - if it's a vanilla mutex (pthread), you can't have multiple
//    locks in the same thread
//  - if it's a rwmutex (defined in Qbase) things should work out ok
//    but that's assumes we use our own rwmutex, new ones might not
//    behave the same way
//
//
template<class Fruit, class LockingPolicy>
class _QT_iterator {
private:
  typedef typename Node<Fruit>::NPtr NPtr;
  typedef typename Node<Fruit>::FPtr FPtr;

public:
  typedef _QT_iterator<Fruit, LockingPolicy> iterator;
  typedef _QT_iterator<Fruit, LockingPolicy> _Self;

  // constructors/assignment
  _QT_iterator() : current_(0), qt_(NULL){}
  _QT_iterator(const iterator& rhs)
    : current_(rhs.current_), qt_(rhs.qt_), path_to_current_(rhs.path_to_current_) {}

  _Self& operator=(const iterator& rhs) {
    if (this != &rhs) {
      current_ = rhs.current_;
      qt_ = rhs.qt_;
      path_to_current_ = rhs.path_to_current_;
    }
    return *this;
  }

  ~_QT_iterator() {}

  // real work here
  _Self& operator++()
  {
    this->incr();
    return *this;
  }

private:
  // this turns out to be too costly, so prevent its use
  // don't want to change the semantics b/c that could be misleading
  _Self operator++(int)
  {
    _Self temp = *this;
    this->incr();
    return temp;
  }

public:
  // want const b/c we can't allow them to modify the fruit, how to do?
  FPtr& operator*() {return current_;}
  // want const b/c we can't allow them to modify the fruit
  FPtr* operator->() {return &current_;}

  // in/equality
  bool operator==(const iterator& rhs) const
  {
    return (qt_ == rhs.qt_ && current_ == rhs.current_);
  }
  bool operator!=(const iterator& rhs) const
  {
    return !(*this == rhs);
  }

private:
  // actual state
  FPtr current_;
  const QTOLD<Fruit, LockingPolicy>* qt_;
  std::vector<NPtr> path_to_current_;

private:
  // allow QTOLD to define end(), and to set up begin()
  friend class QTOLD<Fruit, LockingPolicy>;
  _QT_iterator(const QTOLD<Fruit, LockingPolicy>* qt) : current_(0), qt_(const_cast<QTOLD<Fruit, LockingPolicy>*>(qt)) {path_to_current_.reserve(INIT_CAPACITY);}
  _QT_iterator(FPtr fptr, const QTOLD<Fruit, LockingPolicy>* qt, const std::vector<NPtr>& path)
    : current_(fptr), qt_(const_cast<QTOLD<Fruit, LockingPolicy>*>(qt))
    {
      path_to_current_.clear();
      path_to_current_.insert(path_to_current_.begin(), path.begin(), path.end());
    }

private:
  // increment operator
  //
  // find next fruit pointer from the current
  // basic idea:
  // let P be the node that points to current
  // if P.r == c, need to find a fruit up the parent path
  // if P.m == c, try P.r
  // if P.l == c, try P.m
  //
  // Now, if the next one to try is empty, then go up the parent path.
  // If the next one to try is a Node (not a fruit), take the leftmost
  // fruit pointer beneath that node.
  void incr()
  {
    if (! ((bool)qt_ && (bool)current_)) {
      return;
    }

    // if there's no path to current_
    // current is by itself (tree has one element)
    // the next is null
    if (path_to_current_.empty()) {
      current_ = 0;
      return;
    }

    NPtr parent = path_to_current_.back();
    NPtr n;
    FPtr l, m, r;

    // try P.r
    if ((bool)(r = parent->r_.getFruitPointer()) && r == current_) {
      // if currently pointing to the right
      // need to go up the path
      path_to_current_.pop_back();
      current_ = upParentPath(parent, path_to_current_);
      return;
    }

    // try P.m
    if ((bool)(m = parent->m_.getFruitPointer()) && m == current_) {
      // if currently pointing to middle
      // try right as a fruit pointer
      if (r) {
        current_ = r;
        return;
      }
      // try P.r as a node
      if ((n = parent->r_.getNodePointer())) {
        current_ = qt_->getLeftMostFruit(n, path_to_current_);
        return;
      }
      // have to go up the tree
      path_to_current_.pop_back();
      current_ = upParentPath(parent, path_to_current_);
      return;
    }

    // current must be in the left pointer
    l = parent->l_.getFruitPointer();

    // try finding next pointer in middle as a fruit pointer
    if (m) {
      current_ = m;
      return;
    }
    // try middle as a node pointer
    if ((n = parent->m_.getNodePointer())) {
      current_ = qt_->getLeftMostFruit(n, path_to_current_);
      return;
    }
    // middle is not possible, check right as fruit
    if (r) {
      current_ = r;
      return;
    }
    // if right is a node, get leftmost fruit
    if ((n = parent->r_.getNodePointer())) {
      current_ = qt_->getLeftMostFruit(n, path_to_current_);
      return;
    }

    // at this point we need to backtrack up the path
    path_to_current_.pop_back();
    current_ = upParentPath(parent, path_to_current_);
    return;
  }

  // upParentPath
  //
  // This is called when we need to find the next fruit pointer
  // and all the fruit pointers in node p have already been
  // visited.  So, we need to find the next node pointer along
  // the path that got us here.
  //
  // Once we find the next node in sequence, get the left most
  // fruit pointer under it.
  //
  // very similar to the incr() routine above
  //
  // return the fruit pointer that is found
  FPtr upParentPath(NPtr p, std::vector<NPtr>& path)
  {
    // no path, must be done
    if (path.empty()) {
      return 0;
    }
    NPtr parent = path.back();
    NPtr l, m, r;
    FPtr f;

    if ((bool)(r = parent->r_.getNodePointer()) && r == p) {
      // if currently coming from right branch
      // need to go up the path again
      path.pop_back();
      return upParentPath(parent, path);
    }

    if ((bool)(m = parent->m_.getNodePointer()) && m == p) {
      // if currently coming from middle branch
      // if right is a node get left-most from right
      if (r) {
        return qt_->getLeftMostFruit(r, path);
      }
      // perhaps right is a fruit
      if ((f = parent->r_.getFruitPointer())) {
        return f;
      }
      // no right to traverse, go up
      path.pop_back();
      return upParentPath(parent, path);
    }

    l = parent->l_.getNodePointer();

    // traverse middle to get leftmost if possible
    if (m) {
      return qt_->getLeftMostFruit(m, path);
    }
    // perhaps middle is a fruit
    if ((f = parent->m_.getFruitPointer())) {
      return f;
    }
    // traverse right to get leftmost if possible
    if (r) {
      return qt_->getLeftMostFruit(r, path);
    }
    // perhaps right is a fruit
    if ((f = parent->r_.getFruitPointer())) {
      return f;
    }
    // all else failed, got to continue up
    path.pop_back();
    return upParentPath(parent, path);
  }

};

static const unsigned int HALF_MAX_UI = std::numeric_limits<unsigned int>::max()/2;

// rounds up n to nearest power of two
// valid arguments are 1 to half the max of the type
inline unsigned int roundUpToNearestPowerOfTwo(unsigned int n)
  {
    unsigned int n1;
    int shiftCount = 1;
    --n;
    do{
      n1 = n;
      n = n1 | (n1 >> shiftCount);
      shiftCount *= 2;
    }while(n != n1);
    return n+1;
  }


template<class Fruit, typename LockingPolicy = EmptyLockingPolicy>
class QTOLD : public LockingPolicy {
public:
  typedef typename Node<Fruit>::NPtr NPtr;
  typedef typename Node<Fruit>::FPtr FPtr;
  typedef typename Node<Fruit>::NOFP NOFP;

  // iterator stuff
  typedef _QT_iterator<Fruit, LockingPolicy> iterator;
  typedef _QT_iterator<Fruit, LockingPolicy> const_iterator;

private:
  NOFP root_; // the root of the tree, either null, or points to one fruit, or to a node
  Rectangle box_; // the box of the query tree, it is always kept at such
  // that its sides are both power of 2 values (so that they're half-e-able)

  // functions

  static bool isItAHorizontalRectangleOrASquare_(const Unit xli, const Unit yli, const Unit xhi, const Unit yhi)
  {
    return ((xhi - xli) >= (yhi - yli));
  }


  static bool isItAHorizontalRectangleOrASquare_(const Rectangle& r)
  {
    return ((r.xh() - r.xl()) >= (r.yh() - r.yl()));
  }


  void upsizeBBoxToPowerOfTwoOnBothSides_(void)
  {
    Unit dx = roundUpToNearestPowerOfTwo(box_.delta(HORIZONTAL));
    //std::cout << "roundUp dx " << std::hex << box_.delta(HORIZONTAL) << " ==> " << dx << std::endl;
    Unit dy = roundUpToNearestPowerOfTwo(box_.delta(VERTICAL));
    //std::cout << "roundUp dy " << std::hex << box_.delta(VERTICAL) << " ==> " << dy << std::endl;
    Unit xl = box_.xl() - (dx - box_.delta(HORIZONTAL)) / 2;
    Unit yl = box_.yl() - (dy - box_.delta(VERTICAL)) / 2;
    //std::cout << "box modified from : " << std::dec << box_ << " to " << Rectangle(xl, yl, xl+dx, yl+dy) << std::endl;
    box_ = Rectangle(xl, yl, xl+dx, yl+dy);

  }


  void upsizeAndRepopulate(const FPtr& f)
  {
    std::vector<FPtr> v; v.reserve(INIT_CAPACITY);

    // delete the tree, put all fruit pointers into list l
    deleteTree_(root_, v);
    root_.setNodePointer(0); // set root_ to null

    // enlarget box to encompass new fruit
    Rectangle temp(QTResolveBBox<Fruit>::getBBox(f));
    temp.bloat(1); // if f is a point, we need to upsize to 1 larger than that so that we can insert  a  point on the boundary
    box_.encompass(temp);
    // upsize box to have sides on power of 2
    upsizeBBoxToPowerOfTwoOnBothSides_();

    // re-insert all previous fruits
    for(typename std::vector<FPtr>::iterator vit = v.begin(); vit  != v.end(); ++vit){
      insert(*vit);
    }
  }


  void insert_(const FPtr& f, NOFP& p,
                    Unit xli, Unit yli,
                    Unit xhi, Unit yhi, int mode);

  void insert0_(const FPtr& f, NOFP& p);

  template <class InsertIterator>
  void query2_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const;
  template <class InsertIterator>
  void query2_v_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const;
  template <class InsertIterator>
  void query2_h_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const;
  template <class InsertIterator>
  void query1_v_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const;
  template <class InsertIterator>
  void query1_h_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const;
  template <class InsertIterator>
  void query0_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const;

  template <class InsertIterator>
  int query2remove_(NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp);
  template <class InsertIterator>
  int query1remove_(NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp);
  template <class InsertIterator>
  int query0remove_(NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp);

  int handleSimpleCase(int sum, NOFP& p);
  int cleanUpRemoval_(NOFP& p, int left, int midd, int rite);

    // returns true if indeed inserted

  bool insertFruitIntoNodeIfNodeHasNoChildrenNodes_(
                 const FPtr& f, NPtr& n, Unit xli, Unit yli,
                 Unit xhi, Unit yhi, int mainMode);

  bool insertFruitIntoNodeIfNodeHasNoChildrenNodes0_(
                                                     const FPtr& f, NPtr& n);

  static void getMiddleCoord_(Unit li, Unit hi, Unit& mi, Unit& mri)
    {
      if (hi - li == 1) {
        mi = li;
        mri = hi;
      } else {
        mi = (li + hi)/2;
        mri = mi;
      }
    }


  //void createGlvView_(const std::vector<std::strstream*>& strmvec, const NPtr& np,
  //                    const Point3D& p, double dx, double dy, int mode) const;

public:

  template <class T2>
  explicit QTOLD(const RectangleImpl<T2>& box) : box_(box)
    {
      NPtr n = 0; root_.setNodePointer(n); // set root to point to null


      // we don't allow line thin boxes for the query tree
      box_.bloat(1); // we need to make sure we can insert points on the boundaries
      upsizeBBoxToPowerOfTwoOnBothSides_(); // box_ is now modified to have sides of power of 2
    }

  QTOLD(const QTOLD& rhs) : box_(rhs.box_)
    {
      // TJ not thread safe because iterator is not thread safe
      // should we just do an entire QTOLD query instead?
      NPtr n = 0;
      root_.setNodePointer(n);
      for(const_iterator qit = rhs.begin_(); qit != rhs.end(); ++qit) {
        insert(*qit);
      }
    }

  ~QTOLD() { deleteTree_(root_); NPtr n = 0;
    root_.setNodePointer(n);}

private:
  struct FourFruit
  {
    enum FourFruitNumber { MaxNumberFruit = 4 };

    FourFruit() : count(0) {};
    unsigned count;
    FPtr fruit[MaxNumberFruit];
    // return the number of fruit now in the InsertIterator
    int push(FPtr f)
    {
      if (count < MaxNumberFruit) {
        fruit[count++] = f;
        return count;
      }
      throw 0;
    }
    bool empty() const
    {
      return count == 0;
    }

    FPtr pop()
    {
      if (count > 0) {
        return fruit[--count];
      }

      throw 0;
    }
  };

public:

  // return true iff there is data in the tree
  bool empty() const {
    return ! (root_.getNodePointer() || root_.getFruitPointer());
  }

  const Rectangle& getBBox(void) const { return box_; }
  void insert(const FPtr& f);

  bool query(const FPtr& f) const
  {

    if(!f) return false;

    // do easy check first
    if (! (f->intersects(box_))) {
      return false;
    }

    std::vector<const NOFP*> dontcareList; dontcareList.reserve(INIT_CAPACITY);
    bool dontcareBool;
    return findFPtrInNode21_(f, root_, dontcareList, dontcareBool, box_);
  }

  template <class InsertIterator, class T2>
  void query(InsertIterator i, const RectangleImpl<T2>& qbox, bool considerTouch = true) const
  {
    QTOLD_QueryParameters<InsertIterator> qp(qbox,
                                     box_.xl(),
                                     box_.yl(),
                                     box_.xh(),
                                     box_.yh(),
                                     considerTouch, i);
    query2_(root_, qp); // go down the root
  }

  template <class T2>
  void query(std::vector<FPtr>& l, const RectangleImpl<T2>& qbox, bool considerTouch = true) const
  {
    std::insert_iterator<std::vector<FPtr> > li(l, l.end());
    query(li, qbox, considerTouch);
  }

  // remove the fruit pointer from the query tree (if it exists)
  void remove(const FPtr& f);

  // removes fruits that are in bbox
  // appends their pointers to removedFruits list
  template <class InsertIterator, class T2>
  void removeInBBox(InsertIterator removedFruits, const RectangleImpl<T2>& bbox, bool considerTouch = true);

  template<class T2>
  void removeInBBox(std::vector<FPtr>& removedFruits, const RectangleImpl<T2>& bbox, bool considerTouch = true);


  // finds first fruit pointer in bbox, returns it
  // or null if nothing found
  template <class T2>
  typename Node<Fruit>::FPtr
  findFirstInBBox(const RectangleImpl<T2>& bbox, bool considerTouch) const;

  // reset tree to be empty (delete all memory associated with it)
  // do not reset parameters
  void clear();

  // return depth of tree (longest path to a leaf)
  int depth() const {
    return depth_(root_);
  };

  // return size of tree (number of entries in tree)
  unsigned int size() const {
    return size_(root_);
  };

  // deletes tree, populates vector with fruit pointers
  void deleteTree(std::vector<FPtr>& fruitVector)
  {
    deleteTree_(root_, fruitVector);
    NPtr n = 0; root_.setNodePointer(n);
  }

  // removes first fptr in bbox from query tree
  // does not delete it from memory
  // returns the victim or null
  template <class T2>
  FPtr removeFirstInBBox(const RectangleImpl<T2>& bbox, bool considerTouch);

  //  void createGlvView(std::ofstream& o) const;

  template<class Fruit2, class LockingPolicy2> friend std::ostream& operator << (std::ostream& o, const QTOLD<Fruit2, LockingPolicy2>& rs);
  template<class Fruit2, class LockingPolicy2> friend std::istream& operator >> (std::istream& i, QTOLD<Fruit2, LockingPolicy2>& rs);

private:
  // find a fruit pointer in the tree, searching all branches,
  // storing the nodes along the path in pathToRoot
  // set foundInNode0 = true when at least one node in pathToRoot is a node0
  // return true when node is found
  bool findFPtrInNode0_(const FPtr& f, NOFP& tree, std::vector<const NOFP*>& pathToRoot, bool& foundInNode0) const;

FPtr findFirstFPtrInNode0_(const Rectangle& bbox, NOFP& tree,
                           std::vector<const NOFP*>& pathToRoot, bool& foundInNode0, bool considerTouch) const;

  // find a fruit pointer in the tree, searching branches geometrically,
  // storing the nodes along the path in pathToRoot
  // set foundInNode0 = true when at least one node in pathToRoot is a node0
  // return true when node is found
  bool findFPtrInNode21_(const FPtr& f, const NOFP& tree, std::vector<const NOFP*>& pathToRoot, bool& foundInNode0, const Rectangle& view) const;

  FPtr findFirstFPtrInNode21_(const Rectangle& bbox, const NOFP& tree,
                              std::vector<const NOFP*>& pathToRoot, bool& foundInNode0,
                              const Rectangle& currentView, bool considerTouch) const;

  // return true if tree has at least four fruit pointers
  // store fruit pointers (up to 4) in the fruitList
  // fruitList is sed when hasAtLeast4Fruit_ returns false
  bool hasAtLeast4Fruit_(const NOFP& tree, FourFruit& fruitList) const;

  // consolidate node pointers in tree (cleaning up after a remove)
  // third argument is a flag indicating that the pointer was removed from
  // a node of type 0 - which needs its own special care
  void cleanUpTree_(const NOFP& tree, std::vector<const NOFP*>& pathToRoot, bool pointerRemovedFromNode0);

  // consolidate node pointers in tree when it is a node0 pointer
  void cleanUpNode0_(NPtr& tree);

  // remove the given fruit pointer from the tree
  // pathToRoot contains the set of nodes from the node containing the
  // fruit pointer to the root of the tree
  void removeFPtrInTree_(const FPtr& f, std::vector<const NOFP*>& pathToRoot, bool fptrInNode0);

  // delete all nodes in the tree, does not delete fruits (because it does not own them)
  void deleteTree_(NOFP& tree);

  // delete all nodes in tree, populate vector with the fruit pointers
  void deleteTree_(NOFP& tree, std::vector<FPtr>& fruitVector);

  // return depth of tree (longest path to a leaf)
  int depth_(const NOFP& nofp) const;

  // return size of tree (number of entries stored)
  unsigned int size_(const NOFP& nofp) const;

  // internal iterator access
  iterator begin_() const
  {
    // return iterator to beginning
    std::vector<NPtr> initial; initial.reserve(INIT_CAPACITY);
    NPtr n = root_.getNodePointer();
    FPtr f = root_.getFruitPointer();
    if (n) {
      // leftmost fruit in tree
      f = getLeftMostFruit(n, initial);
    }
    if (f) {
      return iterator(f, this, initial);
    }
    else {
      return end_();
    }
  }

  // the end is always the same
  iterator end_() const
  {
    return iterator(this);
  }

public:
  // iterator access
  iterator begin() const
  {
    return begin_();
  }

  iterator end() const { return end_(); }  // no need to lock, not doing anything

  iterator lazy_query(const Rectangle& qbox, bool considerTouch = true)
  {
    return end_();
  }

private:
  friend class _QT_iterator<Fruit, LockingPolicy>;

  FPtr
  getLeftMostFruit(NPtr root, std::vector<NPtr>& path_to_root) const
  {
    // should always be passed valid nptr
    //        assert(n);
    if (! root) {
      std::cerr << "getLeftMostFruit passed a null NPtr, bad bad bad." << std::endl;
      return 0;
    }

    path_to_root.push_back(root);

    // try left first
    FPtr f;
    NPtr n;
    if ((f = root->l_.getFruitPointer())) {
      return f;
    }
    if ((n = root->l_.getNodePointer())) {
      return getLeftMostFruit(n, path_to_root);
    }

    // nothing on left, try middle
    if ((f = root->m_.getFruitPointer())) {
      return f;
    }
    if ((n = root->m_.getNodePointer())) {
      return getLeftMostFruit(n, path_to_root);
    }
    // nothing on middle, try right
    // yes, it is possible b/c everything could
    // be clustered on right half of QTOLD
    if ((n = root->r_.getNodePointer())) {
      return getLeftMostFruit(n, path_to_root);
    }
    // should never get here because
    // if there were no nodes in l/m/r
    // there should have been fruit
    std::cerr <<"No nodes, should have had some fruit somewhere" << std::endl;
    //        assert(0);
    return 0;
  }
};


template<class Fruit, class LockingPolicy>
  std::ostream& operator << (std::ostream& o, const QTOLD<Fruit, LockingPolicy>& rs)
  {
    //      o << rs.box_ << "," << rs.x_ << "," << rs.y_;
    rs.root_.print(o);
    o << "\n" << rs.box_; // <--- add this line to QT.h
    return o << "\n";
  }


template<class Fruit, class LockingPolicy>
  std::istream& operator >> (std::istream& i, QTOLD<Fruit, LockingPolicy>& rs)
  {
    char c;
    //  i >> rs.box_ >> c >> rs.x_ >> c >> rs.y_;
    rs.root_.read(i);
    i >> c >> rs.box_;
    //i.eatwhite();  // for some reason compiler doesn't like this call
    return i;
  }


template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::insert(const FPtr& f)
  {
    // typename LockingPolicy::write_lock_type lock(this);

    Rectangle fbox(QTResolveBBox<Fruit>::getBBox(f));
    if(!(box_.contains(fbox))) {
      upsizeAndRepopulate(f); // need to upsize because box_ of QTOLD does not fully contain the fbox
    }

    insert_(f, root_,
            box_.xl(),
            box_.yl(),
            box_.xh(),
            box_.yh(),
            2);

  }

// finds first fruit pointer in bbox
// returns pointer to found fruit, or null otherwise
template<class Fruit, class LockingPolicy>
template<class T2>
  typename Node<Fruit>::FPtr
  QTOLD<Fruit, LockingPolicy>::findFirstInBBox(const RectangleImpl<T2>& bbox, bool considerTouch) const {
    std::vector<const NOFP*> nodesAboveFruit; nodesAboveFruit.reserve(INIT_CAPACITY);
    bool foundInNode0 = false;
    FPtr retval =
      findFirstFPtrInNode21_(bbox,  root_, nodesAboveFruit, foundInNode0, box_, considerTouch);
    return retval;
  }


// finds the first fruit in bbox
// removes it from tree
// returns pointer to fruit
// returns null if no fruit found in bbox
template<class Fruit, class LockingPolicy>
template<class T2>
  typename Node<Fruit>::FPtr QTOLD<Fruit, LockingPolicy>::removeFirstInBBox(const RectangleImpl<T2>& bbox, bool considerTouch)
  {
    std::vector<const NOFP*> nodesAboveFruit; nodesAboveFruit.reserve(INIT_CAPACITY);
    bool foundInNode0 = false;
    FPtr retval = findFirstFPtrInNode21_(bbox,  root_, nodesAboveFruit, foundInNode0, box_, considerTouch);
    if(retval) { // found one fruit in bbox
      if(root_.getFruitPointer()) {
        // trying to delete a fruit at the root
        // easy enough, just zero out
        root_.setNodePointer(0);
      }
      else {

        // we have some node
        // so remove f from tree

        removeFPtrInTree_(retval, nodesAboveFruit, foundInNode0);
      }
    }
    return retval;
  }


template<class Fruit, class LockingPolicy>
template<class InsertIterator, class T2>
  void QTOLD<Fruit, LockingPolicy>::removeInBBox(InsertIterator removedFruits, const RectangleImpl<T2>& bbox, bool considerTouch)
  {
    //    typename LockingPolicy::read_lock_type lock(this);

    QTOLD_QueryParameters<InsertIterator> qp(bbox,
                                     box_.xl(),
                                     box_.yl(),
                                     box_.xh(),
                                     box_.yh(),
                                     considerTouch,
                                     removedFruits);

    query2remove_(root_, qp);
  }


template<class Fruit, class LockingPolicy>
template<class T2>
  void QTOLD<Fruit, LockingPolicy>::removeInBBox(std::vector<FPtr>& removedFruits, const RectangleImpl<T2>& bbox, bool considerTouch)
  {
    std::insert_iterator<std::vector<FPtr> > li(removedFruits, removedFruits.end());
    removeInBBox(li, bbox, considerTouch);
  }


template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::remove(const FPtr& f)
  {
    if(!f) return;

    std::vector<const NOFP*> nodesAboveFruit; nodesAboveFruit.reserve(INIT_CAPACITY);

    bool foundInNode0 = false;
    if (findFPtrInNode21_(f, root_, nodesAboveFruit, foundInNode0, box_)) {
      if (root_.getFruitPointer()) {
        // trying to delete a fruit at the root
        // easy enough, just zero out
        root_.setNodePointer(0);
      }
      else {
        //              NOFP handle;
        //              handle.setNodePointer(root_.getNodePointer());
        //              nodesAboveFruit.push_back(handle);
        //              removeFPtrInTree_(f, nodesAboveFruit, foundInNode0);

        // we have some node
        // so remove f from tree

        removeFPtrInTree_(f, nodesAboveFruit, foundInNode0);
      }
    }
  }

template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::clear()
  {
    deleteTree_(root_);
    root_.setNodePointer(0);
  }

// return the depth of the tree
template<class Fruit, class LockingPolicy>
  int QTOLD<Fruit, LockingPolicy>::depth_(const NOFP& nofp) const
  {
    NPtr n = nofp.getNodePointer();
    FPtr f = nofp.getFruitPointer();
    if (!n && !f) {
      return 0;
    }
    if (f) {
      return 1;
    }
    int l = depth_(n->l_);
    int m = depth_(n->m_);
    int r = depth_(n->r_);
    int max = (l > m) ? l : m;
    max = (r > max) ? r : max;

    return max+1;
  }

// return the size of the tree
template<class Fruit, class LockingPolicy>
  unsigned int QTOLD<Fruit, LockingPolicy>::size_(const NOFP& nofp) const
  {
    NPtr n = nofp.getNodePointer();
    FPtr f = nofp.getFruitPointer();
    if (!n && !f) {
      return 0;
    }
    if (f) {
      return 1;
    }
    int l = size_(n->l_);
    int m = size_(n->m_);
    int r = size_(n->r_);
    return l+m+r;
  }


// #if 0
  // strmvec[0] for nodes of mode 0 (point mode)
  // strmvec[1] for nodes of mode 1 (cut node)
  // strmvec[2] for nodes of mode 2 (regular node)
//   template<class Fruit, class LockingPolicy>
//     void QTOLD<Fruit, LockingPolicy>::createGlvView_(const std::vector<std::strstream*>& strmvec,
//                                    const NPtr& np,
//                                    const Point3D& p, double dx, double dy, int mode) const
//     {
//       if(!np) return;

//       assert(mode <= 2);
//       *(strmvec[mode]) << p << "\n";

//       const int ELEM_ = 3;
//       const int NULLP_ = 4;

//       // now let's look at the three pointers of this node:
//       FPtr lf = np->l_.getFruitPointer();
//       FPtr mf = np->m_.getFruitPointer();
//       FPtr rf = np->r_.getFruitPointer();
//       NPtr ln = np->l_.getNodePointer();
//       NPtr mn = np->m_.getNodePointer();
//       NPtr rn = np->r_.getNodePointer();

//       static const int FF = 5;

//       dx /= 2.1;
//       dy /= 2.1;

//       if(ln){
//         createGlvView_(strmvec, ln, (p + Point3D((int)-dx, (int)-dy, 0)), dx, dy, mode);
//       }
//       else{ // pointer is null
//         *(strmvec[lf ? ELEM_ : NULLP_]) << (p + Point3D(-FF, -FF, 0)) << "\n";
//       }


//       if(mn){
//         // goes down the middle pointer, from node to node
//         // mode2 becomes mode1, mode1 becomes mode0
//         // mode0 stays mode0

//         double new_dx = dx, new_dy = dy;
//         if(mode >= 1){
//           // means we are switching from mainmode to cut mode, cut the dx by 4
//           new_dx = dx/2.;
//           new_dy = dy/2.;

//         }
//         createGlvView_(strmvec, mn, (p + Point3D(0, (int)-new_dy, 0)), new_dx, new_dy, ((mode > 0) ? (mode-1) : 0));
//       }
//       else{ // middle pointer null or points to fruit
//         *(strmvec[mf ? ELEM_ : NULLP_])  << (p + Point3D(0, -FF, 0)) << "\n";
//       }



//       if(rn){ // yes right pointer points to node
//         createGlvView_(strmvec, rn, (p + Point3D((int)dx, (int)-dy, 0)), dx, dy, mode);
//       }
//       else{ // right pointer null
//         *(strmvec[rf ? ELEM_ : NULLP_]) <<  (p + Point3D(FF, -FF, 0)) << "\n";
//       }

//     }



//   template<class Fruit, class LockingPolicy>
//     void QTOLD<Fruit, LockingPolicy>::createGlvView(std::ofstream& o) const
//     {
//       int dx = 10000000, dy = 10000000;
//       Point3D rt(dx, dx, 0);
//       std::vector<std::strstream*> strmvec;
 //      strmvec.push_back(new std::strstream);
//       strmvec.push_back(new std::strstream);
//       strmvec.push_back(new std::strstream);
//       strmvec.push_back(new std::strstream);
//       strmvec.push_back(new std::strstream);



//       createGlvView_(strmvec, root_.getNodePointer(), rt, dx, dy, 2);

//       for(int k = 0; k < 5; k++){
//         int nl = strmvec[k]->rdbuf()->pcount();
//         char* cp;
//         int i = 0;
//         if(nl > 0){
//           switch (k) {
//           case 0 : o << "(ELEMENT \"/PointNodes\"\n(POINTSIZE 2.0)\n(C 1,0,1)\n(V\n"; break;
//           case 1 : o << "(ELEMENT \"/CutNodes\"\n(POINTSIZE 3.0)\n(C 0,1,1)\n(V\n"; break;
//           case 2 : o << "(ELEMENT \"/Nodes\"\n(POINTSIZE 4.0)\n(C 0,1,0)\n(V\n"; break;
//           case 3 : o << "(ELEMENT \"/Elements\"\n(POINTSIZE 3.0)\n(C 1,0,0)\n(V\n"; break;
//           case 4 : o << "(ELEMENT \"/NullPointers\"\n(POINTSIZE 2.0)\n(C 1,1,0)\n(V\n"; break;
//           }
//           for(cp = strmvec[k]->str(); i < nl; i++, ++cp){
//             o << *cp;
//           }

//           o << "))\n";
//         }
//       }
//       o <<  std::endl;

//     }

// #endif

template<class Fruit, class LockingPolicy>
  bool QTOLD<Fruit, LockingPolicy>::
  insertFruitIntoNodeIfNodeHasNoChildrenNodes_(
                                               const FPtr& f, NPtr& n,
                                               Unit xli, Unit yli,
                                               Unit xhi, Unit yhi ,
                                               int mode)
  {

    // here we have n pointing to a node, and this node has no node children.
    FPtr fl, fm, fr;
    // we want to keep fruits sorted, but this is not a stable sort at this time
    // it depends on l < m < r; if any 2 members are equal (i.e. !(a<b) & !(b<a) )
    // then they are still kept depending on insertion order
    // needs more thinking to remove this dependency if required!

    // if middle is available, stick in middle
    fm = n->m_.getFruitPointer();
    if(!fm) { n->m_.setFruitPointer(f); return true; }
    // middle is unavailable, so check if left (<) or right (>=) is available
    if (QTResolveBBox<Fruit>::getBBox(f) <
        QTResolveBBox<Fruit>::getBBox(fm)) { // f is less than middle
      fl = n->l_.getFruitPointer();
      if(!fl) { n->l_.setFruitPointer(f); return true; }
      // left is occupied, so shift middle to right (if available) and compare f against left
      fr = n->r_.getFruitPointer();
      if (!fr) {
        n->r_.setFruitPointer(fm);
        if (QTResolveBBox<Fruit>::getBBox(fl) < QTResolveBBox<Fruit>::getBBox(f)){
          // f is more than left => f goes to middle
          n->m_.setFruitPointer(f);
          return true;
        }
        // f is less than left => left goes to middle, f goes to left
        n->m_.setFruitPointer(fl);
        n->l_.setFruitPointer(f);
        return true;
      }
    }
    else { // f is not less than middle
      fr = n->r_.getFruitPointer();
      if(!fr) { n->r_.setFruitPointer(f); return true; }
      // right is occupied, so shift middle to left (if available) and compare f against right
      fl = n->l_.getFruitPointer();
      if (!fl) {
        n->l_.setFruitPointer(fm);
        if (QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(fr)){
          // f is less than right => f goes to middle
          n->m_.setFruitPointer(f);
          return true;
        }
        // f is not less than right => right goes to middle, f goes to right
        n->m_.setFruitPointer(fr);
        n->r_.setFruitPointer(f);
        return true;
      }
    }

    // Here all three fruit  pointers are taken

    if(mode >= 1){

      FPtr fpv[4] = {f, fl, fm, fr};
      // delete the pointers from the node
      n->l_.setNodePointer(0);
      n->m_.setNodePointer(0);
      n->r_.setNodePointer(0);

      for(int j = 0; j < 4; j++){
        FPtr fff = fpv[j];

        if(isItAHorizontalRectangleOrASquare_(xli, yli, xhi, yhi)){
          //if(getXDelta_(xli, xhi) >= getYDelta_(yli, yhi)){
          // vertical cutline

          Unit mxi, mrxi;
          getMiddleCoord_(xli, xhi, mxi, mrxi);

          Rectangle fffbb(QTResolveBBox<Fruit>::getBBox(fff));
          if(fffbb.xh() < mxi) { // needs to go left
            insert_(fff, n->l_, xli, yli, mxi, yhi, mode);
          }
          else if(fffbb.xl() > mxi) { // needs to go right
            insert_(fff, n->r_, mrxi, yli, xhi, yhi, mode);
          }
          else { // means vertical cutline cut the bbox of f
            insert_(fff, n->m_, mxi, yli, mxi, yhi, mode-1);
          }
        }

        else{ // cutline is horizontal

          Unit myi, mryi;
          getMiddleCoord_(yli, yhi, myi, mryi);

          Rectangle fffbb(QTResolveBBox<Fruit>::getBBox(fff));
          if(fffbb.yh() < myi) { // needs to go left
            insert_(fff, n->l_, xli, yli, xhi, myi, mode);
          }
          else if(fffbb.yl() > myi){ // needs to go right
            insert_(fff, n->r_, xli, mryi, xhi, yhi, mode);
          }
          else { // means vertical cutline cut the bbox of f
            insert_(fff, n->m_, xli, myi, xhi, myi, mode-1);
          }
        }

      }
    }

    else { // this is mode 0, just insert it left or right of the one in the middle

      //assert((bool)fm); // there should be a middle pointer pointing to a fruit! or else this node should not have been created

      if(QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(fm)){
        insert0_(f, n->l_);
      }
      else{ // insert on right branch
        insert0_(f, n->r_);
      }
    }

    return true;
  }


template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::insert0_(const FPtr& f, NOFP& p)
  {
    NPtr n = p.getNodePointer();
    FPtr ff = p.getFruitPointer();
    //std::cout << "insert0 " << n << std::endl;

    if(!n){ // either points to nothing or one fruit only
      if(!ff){
        p.setFruitPointer(f);
      }
      else{ // yes ff, is a fruit pointer

        //std::cout << "yes, creating node here" << std::endl;
        // create a new node here

        p.setNodePointer(new Node<Fruit>);
        n = p.getNodePointer();

        // now stick in f and ff sorted to left and middle pointers

        n->m_.setFruitPointer(ff);
        if (QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(ff))
          n->l_.setFruitPointer(f);
        else
          n->r_.setFruitPointer(f);

      }
      return;
    }

    // here we have a valid node pointer n
    if(insertFruitIntoNodeIfNodeHasNoChildrenNodes0_(f, n)) return;

    // we are in mode 0, must have middle pointer
    // not true: if we've deleted, we do not ensure this any longer
    if (! n->m_.getFruitPointer()) {
      n->m_.setFruitPointer(f);
      return;
    }

    if(QTResolveBBox<Fruit>::getBBox(f) <
       QTResolveBBox<Fruit>::getBBox(n->m_.getFruitPointer())){
      insert0_(f, n->l_);
    }
    else{ // insert on right branch
      insert0_(f, n->r_);
    }

  }

template<class Fruit, class LockingPolicy>
  bool QTOLD<Fruit, LockingPolicy>::insertFruitIntoNodeIfNodeHasNoChildrenNodes0_(
                                                                const FPtr& f, NPtr& n)
  {
    //std::cout << "ifinifnhnchn0" << std::endl;
    //assert((bool)n); // n should be valid node pointer
    
    if((bool)n->l_.getNodePointer() ||
       (bool)n->m_.getNodePointer() ||
       (bool)n->r_.getNodePointer()){
      // any of the child pointers points to a node
      return false; // it's not this functions' respons. to insert it here
    }

    // here we have n pointing to a node, and this node has no node children.
    FPtr fl, fm, fr;
    // we want to keep fruits sorted, but this is not a stable sort at this time
    // it depends on l < m < r; if any 2 members are equal (i.e. !(a<b) & !(b<a) )
    // then they are still kept depending on insertion order
    // needs more thinking to remove this dependency if required!

    // if middle is available, stick in middle
    fm = n->m_.getFruitPointer();
    if(!fm) { n->m_.setFruitPointer(f); return true; }
    // middle is unavailable, so check if left (<) or right (>=) is available
     if (QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(fm)) { // f is less than middle
      fl = n->l_.getFruitPointer();
      if(!fl) { n->l_.setFruitPointer(f); return true; }
      // left is occupied, so shift middle to right (if available) and compare f against left
      fr = n->r_.getFruitPointer();
      if (!fr) {
        n->r_.setFruitPointer(fm);
        if (QTResolveBBox<Fruit>::getBBox(fl) < QTResolveBBox<Fruit>::getBBox(f)){
          // f is more than left => f goes to middle
          n->m_.setFruitPointer(f);
          return true;
        }
        // f is less than left => left goes to middle, f goes to left
        n->m_.setFruitPointer(fl);
        n->l_.setFruitPointer(f);
        return true;
      }
    }
    else { // f is not less than middle
      fr = n->r_.getFruitPointer();
      if(!fr) { n->r_.setFruitPointer(f); return true; }
      // right is occupied, so shift middle to left (if available) and compare f against right
      fl = n->l_.getFruitPointer();
      if (!fl) {
        n->l_.setFruitPointer(fm);
        if (QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(fr)){
          // f is less than right => f goes to middle
          n->m_.setFruitPointer(f);
          return true;
        }
        // f is not less than right => right goes to middle, f goes to right
        n->m_.setFruitPointer(fr);
        n->r_.setFruitPointer(f);
        return true;
      }
    }

    // Here all three fruit  pointers are taken

    //assert((bool)fm); // there should be a middle pointer pointing to a fruit! or else this node should not have been created

    if(QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(fm)){
      insert0_(f, n->l_);
    }
    else{ // insert on right branch
      insert0_(f, n->r_);
    }


    return true;
  }

// findFPtrInNode0_
//
// given a fruit pointer and a tree that's at the node0 level
// traverse *all* the children (b/c no geometry at kept here)
// return true if the fruit pointer is in the tree
// and fill up the pathToRoot with pointers to the nodes along the
// path from root to fruit
// set foundInNode0 = true when at least one node in pathToRoot is a node0
template<class Fruit, class LockingPolicy>
  bool QTOLD<Fruit, LockingPolicy>::findFPtrInNode0_(const FPtr& f, NOFP& tree,
                                   std::vector<const NOFP*>& pathToRoot, bool& foundInNode0) const
  {
    NPtr n = tree.getNodePointer();

    if (!n) {
      // empty tree or fruit pointer
      // just check to see if pointers are the same
      // will produce correct results when ff is NULL or a valid FPtr
      return (tree.getFruitPointer() == f);
    }

    // we've got a node pointer with some number of entries
    // push back the current tree pointer
    pathToRoot.push_back(& tree);
    // node 0 is on the pathToRoot
    foundInNode0 = true;

    if (findFPtrInNode0_(f, n->l_, pathToRoot, foundInNode0)) {return true;}
    if (findFPtrInNode0_(f, n->m_, pathToRoot, foundInNode0)) {return true;}
    if (findFPtrInNode0_(f, n->r_, pathToRoot, foundInNode0)) {return true;}

    // couldn't find the node, clean up pathToRoot and return

    // Trey don't we need this line?
    //foundInNode0 = false;
    // ????


    pathToRoot.pop_back();
    return false;
  }

/////////////
// findFirstFPtrInNode0_
//
// given a bbox and a tree that's at the node0 level
// traverse *all* the children (b/c no geometry at kept here)
// return the first fruit pointer that is within the bbox
// and fill up the pathToRoot with pointers to the nodes along the
// path from root to fruit
// set foundInNode0 = true when at least one node in pathToRoot is a node0
template<class Fruit, class LockingPolicy>
  typename Node<Fruit>::FPtr QTOLD<Fruit, LockingPolicy>::findFirstFPtrInNode0_(const Rectangle& bbox, NOFP& tree, std::vector<const NOFP*>& pathToRoot, bool& foundInNode0, bool considerTouch) const
  {
    NPtr n = tree.getNodePointer();

    if (!n) {
      // empty tree or fruit pointer
      // just check to see if pointers are the same
      // will produce correct results when ff is NULL or a valid FPtr
      FPtr ff = tree.getFruitPointer();
      if(ff && QTResolveBBox<Fruit>::getBBox(ff).intersects(bbox, considerTouch)){
        return ff;
      }
      return 0;
    }

    // we've got a node pointer with some number of entries
    // push back the current tree pointer
    pathToRoot.push_back(& tree);
    // node 0 is on the pathToRoot
    foundInNode0 = true;

    FPtr retval;
    if (retval = findFirstFPtrInNode0_(bbox, n->l_, pathToRoot, foundInNode0, considerTouch)) {return retval;}
    if (retval = findFirstFPtrInNode0_(bbox, n->m_, pathToRoot, foundInNode0, considerTouch)) {return retval;}
    if (retval = findFirstFPtrInNode0_(bbox, n->r_, pathToRoot, foundInNode0, considerTouch)) {return retval;}


    // couldn't find the node, clean up pathToRoot and return
    // foundInNode0 doesn't need to be set b/c it only applies when we've found something
    pathToRoot.pop_back();
    return 0;
  }

inline void
getWestHalf(Rectangle& ret, const Rectangle& r)
{
  ret = Rectangle(r.xl(),
                  r.yl(),
                  (r.xl() + r.xh())/2,
                  r.yh());
}
inline 
void
getNorthHalf(Rectangle& ret, const Rectangle& r)
{
  ret = Rectangle(r.xl(),
                (r.yh() + r.yl())/2,
                r.xh(),
                r.yh());
}

inline 
void
getSouthHalf(Rectangle& ret, const Rectangle& r)
{
  ret = Rectangle(r.xl(),
                r.yl(),
                r.xh(),
                (r.yh() + r.yl())/2);
}

inline 
void
getEastHalf(Rectangle& ret, const Rectangle& r)
{
  ret = Rectangle((r.xl() + r.xh())/2,
                r.yl(),
                r.xh(),
                r.yh());
}

inline void
getCutline(Rectangle& ret, const Rectangle& r, Orientation2D o)
{
  Point center = r.center();
  if (o == VERTICAL) {
    ret = Rectangle(center.x(), r.yl(), center.x(), r.yh());
  } else { // o == HORIZONTAL
    ret = Rectangle(r.xl(), center.y(), r.xh(), center.y());
  }
}


inline Orientation2D
getTwoHalvesAndShorterCutline(const Rectangle& R,
                              Rectangle& A, Rectangle& C, Rectangle& B)
{
  if (R.delta(HORIZONTAL) >= R.delta(VERTICAL)) {
    getWestHalf(A, R);
    getCutline(C, R, VERTICAL);
    getEastHalf(B, R);
    return VERTICAL;
  }
  getSouthHalf(A, R);
  getCutline(C, R, HORIZONTAL);
  getNorthHalf(B, R);
  return HORIZONTAL;
}


////////////
// findFPtrInNode21_
//
// given a fruit pointer, a tree
// fill the list of NOFPs with the path of NOFPs in the tree to the
// fruit pointer and return true if the pointer is found, false
// otherwise.   currentView is used to keep track of the current
// bounding box we're searching in.
// set foundInNode0 = true when at least one node in pathToRoot is a node0
template<class Fruit, class LockingPolicy>
  bool QTOLD<Fruit, LockingPolicy>::findFPtrInNode21_(const FPtr& f, const NOFP& tree,
                                    std::vector<const NOFP*>& pathToRoot, bool& foundInNode0,
                                    const Rectangle& currentView) const
  {
    NPtr n = tree.getNodePointer();
    foundInNode0 = false;

    if (!n) {
      // empty tree or fruit pointer
      // just check to see if pointers are the same
      // will produce correct results when ff is NULL or a valid FPtr
      return (tree.getFruitPointer() == f);
    }

    // we've got a node pointer with some number of entries
    // push back the current tree pointer
    pathToRoot.push_back(& tree);

    // check to see if one of the l/m/r are a node
    if ((bool)n->l_.getNodePointer() || (bool)n->m_.getNodePointer()
        || (bool)n->r_.getNodePointer()) {
      // we have at least one node, so only need to check one of
      // left/right/center we can use geometry to prune down the choices
      // which is it?
      Rectangle left, centerline, right;
      Orientation2D cutLineOrientation = getTwoHalvesAndShorterCutline(currentView, left, centerline, right);
      Rectangle fBox(QTResolveBBox<Fruit>::getBBox(f));


      bool goLeft = false, goRight = false, centerlineIsPoint = false;

      if (cutLineOrientation == VERTICAL) {
        Unit mxi = centerline.xl();
        goLeft = (fBox.xh() < mxi);
        goRight = (fBox.xl() > mxi);
        centerlineIsPoint = (centerline.yl() == centerline.yh());
      }
      else{
        // cutline is HORIZONTAL
        Unit myi = centerline.yl();
        goLeft  = (fBox.yh() < myi);
        goRight = (fBox.yl() > myi);
        centerlineIsPoint = (centerline.xl() == centerline.xh());
      }

      if(goLeft)  return findFPtrInNode21_(f, n->l_, pathToRoot, foundInNode0, left);
      if(goRight) return findFPtrInNode21_(f, n->r_, pathToRoot, foundInNode0, right);
      if(centerlineIsPoint) return findFPtrInNode0_(f, n->m_, pathToRoot, foundInNode0);
      return findFPtrInNode21_(f, n->m_, pathToRoot, foundInNode0, centerline);

    }


    // there were no node pointers
    // so just check fruit pointers
    if (n->l_.getFruitPointer() == f) {return true;}
    if (n->m_.getFruitPointer() == f) {return true;}
    if (n->r_.getFruitPointer() == f) {return true;}
    return false;
  }


////////////////////
// findFirstFPtrInNode21_
//
// given a bbox, a tree
// fill the list of NOFPs with the path of NOFPs in the tree to the
// first fruit pointer found in bbox and return the pointer to the fruit found, false
// otherwise.   currentView is used to keep track of the current
// bounding box we're searching in.
// set foundInNode0 = true when at least one node in pathToRoot is a node0
template<class Fruit, class LockingPolicy>
  typename Node<Fruit>::FPtr QTOLD<Fruit, LockingPolicy>::findFirstFPtrInNode21_(const Rectangle& bbox, const NOFP& tree, std::vector<const NOFP*>& pathToRoot, bool& foundInNode0, const Rectangle& currentView, bool considerTouch) const
  {
    NPtr n = tree.getNodePointer();
    foundInNode0 = false;

    if (!n) {
      FPtr ff = tree.getFruitPointer();
      // the tree has only one fruit pointer
      if(ff && QTResolveBBox<Fruit>::getBBox(ff).intersects(bbox, considerTouch)){
        // ff is in bbox
        return ff;
      }
      return 0; //
    }

    // we've got a node pointer with some number of entries
    // push back the current tree pointer
    pathToRoot.push_back(& tree);

    FPtr retval;
    // check to see if one of the l/m/r are a node
    if ((bool)n->l_.getNodePointer() || (bool)n->m_.getNodePointer()
        || (bool)n->r_.getNodePointer()) {
      // we have at least one node, so only need to check one of
      // left/right/center we can use geometry to prune down the choices
      // which is it?
      Rectangle left, centerline, right;
      Orientation2D cutlineOrientation = getTwoHalvesAndShorterCutline(currentView, left, centerline, right);

      bool goRight, goLeft, cutlineIsAPoint;

      if (cutlineOrientation == VERTICAL) {

        Unit mxi = centerline.xl();
        goRight = (bbox.xh() > mxi);
        goLeft  = (bbox.xl() < mxi);
        cutlineIsAPoint = (currentView.yh() == currentView.yl());
      }
      else{
        // cutline horizontal
        Unit myi = centerline.yl();
        goRight = (bbox.yh() > myi);
        goLeft  = (bbox.yl() < myi);
        cutlineIsAPoint = (currentView.xl() == currentView.xh());
      }

      // we go center first (always needed)
      // Center
      //typename std::vector<const NOFP*>::iterator lit = pathToRoot.rbegin();

      size_t origSize = pathToRoot.size(); // original size

      if(cutlineIsAPoint){
        retval = findFirstFPtrInNode0_(bbox, n->m_, pathToRoot, foundInNode0, considerTouch);
        if(retval) return retval;
      }
      else{
        retval = findFirstFPtrInNode21_(bbox, n->m_, pathToRoot, foundInNode0, centerline, considerTouch);
        if(retval) return retval;
      }

      // Left (West Half)
      if(goLeft){
        // remove from the front of list any "garbage" path segment, added by previous step
        //pathToRoot.erase(pathToRoot.rbegin(), lit);
        pathToRoot.resize(origSize);
        retval = findFirstFPtrInNode21_(bbox, n->l_, pathToRoot, foundInNode0, left, considerTouch);
        if(retval) return retval;
      }

      // Right (East Half)
      if(goRight){
        // remove from the front of list any "garbage" path segment, added by previous step
        //pathToRoot.erase(pathToRoot.rbegin(), lit);
        pathToRoot.resize(origSize);
        retval =  findFirstFPtrInNode21_(bbox, n->r_, pathToRoot, foundInNode0, right, considerTouch);
        if(retval) return retval;
      }
    }

    else{

      // there were no node pointers
      // so just check fruit pointers
      retval = n->l_.getFruitPointer();
      if(retval && retval->intersects(bbox, considerTouch)) return retval;

      retval = n->m_.getFruitPointer();
      if(retval && retval->intersects(bbox, considerTouch)) return retval;

      retval = n->r_.getFruitPointer();
      if(retval && retval->intersects(bbox, considerTouch)) return retval;
    }

    // nothing found
    return 0;
  }

//////////////////////
// removeFPtrInTree_
//
// Given a NOFP, and a list of the parent NOFPs in a tree, and flag indicating fptr is in node0
// zero out the NOFP, and clean up the tree.
template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::removeFPtrInTree_(const FPtr& f, std::vector<const NOFP*>& pathToRoot, bool fptrInNode0)
  {
    // pathToRoot is a list of parents of f, starting at most recent all
    // the way to the root



    // get parent
    const NOFP& parent = *(pathToRoot.back());
    NPtr n = parent.getNodePointer();

    pathToRoot.pop_back();

    NOFP fNOFP;
    fNOFP.setFruitPointer(f);
    // find which of the l/m/r pointers it is and zero out
    if (n->l_ == fNOFP) {
      n->l_.setNodePointer(0);
    }
    else if (n->m_ == fNOFP) {
      n->m_.setNodePointer(0);
    }
    else if (n->r_ == fNOFP) {
      n->r_.setNodePointer(0);
    }
    else {

    }

    cleanUpTree_(parent, pathToRoot, fptrInNode0);
  }


// recursively delete nodes in tree, does not delete fruits
template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::deleteTree_(NOFP& tree)
  {
    NPtr n = tree.getNodePointer();
    if (n) {
      deleteTree_(n->l_);
      deleteTree_(n->m_);
      deleteTree_(n->r_);
      delete n;
    }
    return;
  }

// recursively delete nodes, fill vector with fruit pointers
template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::deleteTree_(NOFP& tree, std::vector<FPtr>& fruitVector)
  {
    FPtr f = tree.getFruitPointer();
    if(f){
      fruitVector.push_back(f);
      return;
    }

    NPtr n = tree.getNodePointer();
    if (n) {
      deleteTree_(n->l_, fruitVector);
      deleteTree_(n->m_, fruitVector);
      deleteTree_(n->r_, fruitVector);
      delete n;
    }
    return;
  }

// hasAtLeast4Fruit_
//
// given a tree, return true if that tree has at least four fruit
// pointers as children.  fill the fruitList with up to the first
// four children found (no specific order).  stop as soon as we've
// found 4.
template<class Fruit, class LockingPolicy>
  bool QTOLD<Fruit, LockingPolicy>::hasAtLeast4Fruit_(const NOFP& tree,
                                                   FourFruit& fruitList) const
  {

    FPtr f = tree.getFruitPointer();
    if (f) {
      if (fruitList.push(f) >= 4) {
        return true;
      }
      return false;
    }

    // try each of the children
    // remember, we're accumulating the FPtr's as we go
    NPtr n = tree.getNodePointer();
    if (! n) {
      // no node here
      return false;
    }

    if (hasAtLeast4Fruit_(n->l_, fruitList)) {return true;}
    if (hasAtLeast4Fruit_(n->m_, fruitList)) {return true;}
    if (hasAtLeast4Fruit_(n->r_, fruitList)) {return true;}

    // after traversing children, still don't have 4
    return false;
  }


// cleanUpNode0_
//
// given a node0 pointer
// check to see if middle pointer is missing
// and iff so, manipulate tree so that node0 properties are preserved
template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::cleanUpNode0_(NPtr& tree)
  {
    if (! tree) {
      // tree is empty, that's ok
      return;
    }

    if ((bool)tree->m_.getFruitPointer() || !tree->l_.getNodePointer() && !tree->r_.getNodePointer()) {
      // we either have a fruit pointer in the middle
      // or we don't have nodes on the left & right
      //
      // means no work needs to be done at this level
      return;
    }

    // we have a tree w/out a middle pointer, but with a node pointer
    // clean house
    std::vector<FPtr> ourFruit; ourFruit.reserve(INIT_CAPACITY);
    NOFP treeNOFP;
    treeNOFP.setNodePointer(tree);
    deleteTree_(tree->r_, ourFruit);
    deleteTree_(tree->l_, ourFruit);
    // do the right first so that the list potentially has
    // a fruit that'd be useful as a middle point
    tree->r_.setNodePointer(0);
    tree->l_.setNodePointer(0);

    // now re-insert everything
    for (typename std::vector<FPtr>::const_iterator fruitIter = ourFruit.begin();
         fruitIter != ourFruit.end();
         ++fruitIter) {
      insert0_(*fruitIter, treeNOFP);
    }

    return;
  }


// cleanUpTree_
//
// given a pointer to a *node* in the tree, and a list of the pointers
// to the parents of that node remove any unecessary nodes in the
// tree.  for example, if the tree passed in is a NPtr that has only
// one fruit, then the node should be deleted, and the NPtr should
// be changed to a FPtr.
// NOTE: this routine assumes only *one* FPtr has been deleted, and does
// not clean up all the sub trees, just the first level.  it then recurses
// by going to the parent if necessary.  do not expect to clean up a huge
// tree by passing in a pointer to the root of it.
template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::cleanUpTree_(const NOFP& tree, std::vector<const NOFP*>& pathToRoot, bool pointerRemovedFromNode0)
  {
    NPtr treeNPtr;
    treeNPtr = tree.getNodePointer();

    FourFruit fruitList;
    if (hasAtLeast4Fruit_(tree, fruitList)) {
      // node0 is a special case, the fruit below this
      // node need to be sorted based on the middle fruit pointer
      // so do special clean up

      if (pointerRemovedFromNode0) {
        cleanUpNode0_(treeNPtr);
        // tree is now clean
      }

      // node2&1 don't need a middle fruit, and we've got at least 4
      // fruit below, so no more cleaning can be done.
      return;
    }

    // fruit list should have something
    // why?  nodes *always* have 2 or more fruit
    // if one was deleted, we have at least one left, that we need to turn into a fruit pointer
    // because nodes should be fruit pointers if there's only one
    if (fruitList.empty()) {

      // now, it's possible that the parent of this tree
      // only points to this node, so try to clean up the parent
      const NOFP& parent = *(pathToRoot.back());

      pathToRoot.pop_back();
      // third argument is false b/c we only care about
      // node0 cleanup when we've deleted the middle pointer
      // and the parent of a node0 node can never be another node0
      // pointer b/c node0.m_ is always an FPtr
      cleanUpTree_(parent, pathToRoot, false);
      return;
    }

    // have between 1 and 3 fruit, all stored in fruitList
    // delete nodes, zero pointers, and insert fruit

    // because we're starting at the leaf level
    // we're assured that there can only be (at most)
    // one level of node pointers below treeNPtr
    NPtr n;
    if ((n = treeNPtr->l_.getNodePointer())) {delete n;}
    if ((n = treeNPtr->m_.getNodePointer())) {delete n;}
    if ((n = treeNPtr->r_.getNodePointer())) {delete n;}
    treeNPtr->l_.setNodePointer(0);
    treeNPtr->m_.setNodePointer(0);
    treeNPtr->r_.setNodePointer(0);

    // if only one fruit, get rid of node at tree
    // and set tree to be the fruit pointer
    if (fruitList.count == 1) {
      delete treeNPtr;

      //tree.setFruitPointer(fruitList.front());
      // trying to cast away the const (Try can you pls double-check this? Gy
      ((NOFP*)(&tree))->setFruitPointer(fruitList.pop());
    }
    else {
      // have more than one fruit, need to maintain node here
      // set left
      if (!fruitList.empty()) {
        treeNPtr->l_.setFruitPointer(fruitList.pop());
      }

      // set middle
      if (!fruitList.empty()) {
        treeNPtr->m_.setFruitPointer(fruitList.pop());
      }

      // set right
      if (!fruitList.empty()) {
        treeNPtr->r_.setFruitPointer(fruitList.pop());
      }
    }

    if (pathToRoot.empty()) {
      // tree must be the root
      // so, no need to try to clean the parent
      return;
    }

    // now, it's possible that the parent of this tree
    // only points to this node, so try to clean up the parent
    const NOFP& parent = *(pathToRoot.back());

    pathToRoot.pop_back();
    // third argument is false b/c we only care about
    // node0 cleanup when we've deleted the middle pointer
    // and the parent of a node0 node can never be another node0
    // pointer b/c node0.m_ is always an FPtr
    cleanUpTree_(parent, pathToRoot, false);
  }


template<class Fruit, class LockingPolicy>
  void QTOLD<Fruit, LockingPolicy>::insert_(const FPtr& f, NOFP& p,
                               Unit xli, Unit yli,
                               Unit xhi, Unit yhi,
                               int mode)
  {
    //std::cout << "insert_ " << xli << "," << yli << "," << xhi << "," << yhi << "," << mode << std::endl;

    NPtr n = p.getNodePointer();
    FPtr ff = p.getFruitPointer();
    //std::cout << "insert_ " << n << std::endl;

    if(!n){ // either points to nothing or one fruit only
      if(!ff){
        p.setFruitPointer(f);
      }
      else{ // yes ff, is a fruit pointer

        //std::cout << "yes, creating node here" << std::endl;
        // create a new node here

        p.setNodePointer(new Node<Fruit>);
        n = p.getNodePointer();

        // now stick in f and ff sorted to left and middle pointers

        n->m_.setFruitPointer(ff);
        if (QTResolveBBox<Fruit>::getBBox(f) < QTResolveBBox<Fruit>::getBBox(ff))
          n->l_.setFruitPointer(f);
        else
          n->r_.setFruitPointer(f);

      }
      return;
    }

    if(!(n->l_.getNodePointer()) &&
       !(n->r_.getNodePointer()) &&
       !(n->m_.getNodePointer())){

      // here we have a node n that has no other node children

      // if it can insert it here than return
      // this function will always return true
      insertFruitIntoNodeIfNodeHasNoChildrenNodes_(f, n, xli, yli, xhi, yhi, mode);
      return;
    }

    // here we have a valid node pointer n
    //if(insertFruitIntoNodeIfNodeHasNoChildrenNodes_(f, n, xli, yli, xhi, yhi, mode)) return;


    // here we have a node pointer n for sure, and the node does have other nodes as children
    if(mode >= 1){

      // here yes there is at least a node below this, just be conservative now

      if(isItAHorizontalRectangleOrASquare_(xli, yli, xhi, yhi)){
        //if(getXDelta_(xli, xhi) >= getYDelta_(yli, yhi)){

        // cutline is vertical
        Unit mxi, mrxi;
        getMiddleCoord_(xli, xhi, mxi, mrxi);


        if(QTResolveBBox<Fruit>::getBBox(f).xh() < mxi) { // needs to go left
          insert_(f, n->l_, xli, yli, mxi, yhi, mode);
        }
        else if(QTResolveBBox<Fruit>::getBBox(f).xl() > mxi){ // needs to go right
          insert_(f, n->r_, mrxi, yli, xhi, yhi, mode);
        }
        else { // means vertical cutline cut the bbox of f
          insert_(f, n->m_, mxi, yli, mxi, yhi, mode-1);
        }
      }

      else{ // cutline is horizontal
        Unit myi, mryi;
        getMiddleCoord_(yli, yhi, myi, mryi);


        if(QTResolveBBox<Fruit>::getBBox(f).yh() < myi) { // needs to go left
          insert_(f, n->l_, xli, yli, xhi, myi, mode);
        }
        else if(QTResolveBBox<Fruit>::getBBox(f).yl() > myi) { // needs to go right
          insert_(f, n->r_, xli, mryi, xhi, yhi, mode);
        }
        else { // means vertical cutline cut the bbox of f
          insert_(f, n->m_, xli, myi, xhi, myi, mode-1);
        }
      }

    }
    else{
      // we are in mode 0, must have middle pointer

      if(QTResolveBBox<Fruit>::getBBox(f) <
         QTResolveBBox<Fruit>::getBBox(n->m_.getFruitPointer())) {
        insert0_(f, n->l_);
      }
      else{ // insert on right branch
        insert0_(f, n->r_);
      }

    }
  }

template<class Fruit, class LockingPolicy>
template<class InsertIterator>
  void QTOLD<Fruit, LockingPolicy>:: query0_(const NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp) const
  {
    FPtr ff = p.getFruitPointer();
    if(ff){
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
      }
      return;
    }
    NPtr n = p.getNodePointer();
    if (n) {
      query0_(n->l_, qp); // go recursively left
      query0_(n->m_, qp); // go recursively middle
      query0_(n->r_, qp); // go recursively right
      return;
    }
  }

  template<class Fruit, class LockingPolicy>
  template<class InsertIterator>
  void QTOLD<Fruit, LockingPolicy>:: query2_(const NOFP& p,
                                             QTOLD_QueryParameters<InsertIterator>& qp) const
  {
    NPtr n = p.getNodePointer();
    if(n){
      // here we have a valid node pointer n

      const Rectangle treeSectionRect(qp.xli, qp.yli, qp.xhi, qp.yhi);
      if(!(qp.qbox.intersects(treeSectionRect, qp.considerTouch))) return;

      const Unit xDelta = treeSectionRect.delta(HORIZONTAL);
      const Unit yDelta = treeSectionRect.delta(VERTICAL);
      if (isItAHorizontalRectangleOrASquare_(treeSectionRect)) {
        // cutline is vertical
        if (xDelta < (yDelta<<1)) {
          // Call the alternating query2's starting with a vertical cutline
          query2_v_(p, qp);
          return;
        }

        const Unit xli = qp.xli;
        const Unit xhi = qp.xhi;
        Unit mxi, mrxi;
        getMiddleCoord_(xli, xhi, mxi, mrxi);

        qp.xhi = mxi;
        query2_(n->l_, qp); // go recursively left
        qp.xli = mxi;
        query1_v_(n->m_, qp); // go recursively middle
        qp.xhi = xhi;
        qp.xli = mrxi;
        query2_(n->r_, qp); // go recursively right
        qp.xli = xli;
      } else {
        // cutline is horizontal
        if (yDelta < (xDelta<<1)) {
          // Call the alternating query2's starting with a horizontal cutline
          query2_h_(p, qp);
          return;
        }

        const Unit yli = qp.yli;
        const Unit yhi = qp.yhi;
        Unit myi, mryi;
        getMiddleCoord_(yli, yhi, myi, mryi);

        qp.yhi = myi;
        query2_(n->l_, qp); // go recursively left
        qp.yli = myi;
        query1_h_(n->m_, qp); // go recursively middle
        qp.yhi = yhi;
        qp.yli = mryi;
        query2_(n->r_, qp); // go recursively right
        qp.yli = yli;
      }
      return;
    }

    FPtr ff = p.getFruitPointer();
    if(ff){
      // here we have a valid fruit pointer ff
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
      }
      return;
    }
  }

  template<class Fruit, class LockingPolicy>
  template<class InsertIterator>
  void QTOLD<Fruit, LockingPolicy>:: query2_h_(const NOFP& p,
                                               QTOLD_QueryParameters<InsertIterator>& qp) const
  {
    NPtr n = p.getNodePointer();
    if(n){
      // cutline is horizontal
      const Rectangle treeSectionRect(qp.xli, qp.yli, qp.xhi, qp.yhi);

      if(!(qp.qbox.intersects(treeSectionRect, qp.considerTouch))) return;

      const Unit yli = qp.yli;
      const Unit yhi = qp.yhi;
      Unit myi, mryi;
      getMiddleCoord_(yli, yhi, myi, mryi);

      qp.yhi = myi;
      query2_v_(n->l_, qp); // go recursively left with alternate cutline orientation
      qp.yli = myi;
      query1_h_(n->m_, qp); // go recursively middle
      qp.yhi = yhi;
      qp.yli = mryi;
      query2_v_(n->r_, qp); // go recursively right with alternate cutline orientation
      qp.yli = yli;
      return;
    }

    FPtr ff = p.getFruitPointer();
    if(ff){
      // here we have a valid fruit pointer ff
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
      }
      return;
    }
  }

  template<class Fruit, class LockingPolicy>
  template<class InsertIterator>
  void QTOLD<Fruit, LockingPolicy>:: query2_v_(const NOFP& p,
                                               QTOLD_QueryParameters<InsertIterator>& qp) const
  {
    NPtr n = p.getNodePointer();
    if(n){
      // cutline is vertical
      const Rectangle treeSectionRect(qp.xli, qp.yli, qp.xhi, qp.yhi);

      if(!(qp.qbox.intersects(treeSectionRect, qp.considerTouch))) return;

      const Unit xli = qp.xli;
      const Unit xhi = qp.xhi;
      Unit mxi, mrxi;
      getMiddleCoord_(xli, xhi, mxi, mrxi);

      qp.xhi = mxi;
      query2_h_(n->l_, qp); // go recursively left with alternate cutline orientation
      qp.xli = mxi;
      query1_v_(n->m_, qp); // go recursively middle
      qp.xhi = xhi;
      qp.xli = mrxi;
      query2_h_(n->r_, qp); // go recursively right with alternate cutline orientation
      qp.xli = xli;
      return;
    }

    FPtr ff = p.getFruitPointer();
    if(ff){
      // here we have a valid fruit pointer ff
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
      }
      return;
    }
  }


  template<class Fruit, class LockingPolicy>
  template<class InsertIterator>
  void QTOLD<Fruit, LockingPolicy>:: query1_v_(const NOFP& p,
                                               QTOLD_QueryParameters<InsertIterator>& qp) const
  {
    NPtr n = p.getNodePointer();
    if (n) {
      if(qp.considerTouch){
        if (qp.qbox.yh() < qp.yli || qp.qbox.yl() > qp.yhi ) {
          return; // query box doesn't fall in horiz range range if this vertical  line
      }
    } else { // do not consider touch
      if (qp.qbox.yh() <= qp.yli || qp.qbox.yl() >= qp.yhi) {
        return; // query box doesn't intersect this one
    }
  }
  const Unit yli = qp.yli;
  const Unit yhi = qp.yhi;
  Unit myi, mryi;
  getMiddleCoord_(yli, yhi, myi, mryi);

  qp.yhi = myi;
  query1_v_(n->l_, qp); // go recursively left
  query0_(n->m_, qp);   // go recursively middle
  qp.yhi = yhi;
  qp.yli = mryi;
  query1_v_(n->r_, qp); // go recursively right
  qp.yli = yli;
  return;
}

FPtr ff = p.getFruitPointer();
if(ff){
  if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
    *(qp.inserter) = ff;
  }
  return;
}
}

  template<class Fruit, class LockingPolicy>
  template<class InsertIterator>
  void QTOLD<Fruit, LockingPolicy>:: query1_h_(const NOFP& p,
                                               QTOLD_QueryParameters<InsertIterator>& qp) const
  {
    NPtr n = p.getNodePointer();
    if (n) {
      if (qp.considerTouch) {
        if (qp.qbox.xh() < qp.xli || qp.qbox.xl() > qp.xhi ) {
          return; // query box doesn't fall in vertical range of this horizontal line
        }
      } else { // do not consider touch
        if (qp.qbox.xh() <= qp.xli || qp.qbox.xl() >= qp.xhi) {
          return; // query box doesn't intersect this one
        }
      }
      const Unit xli = qp.xli;
      const Unit xhi = qp.xhi;
      Unit mxi, mrxi;
      getMiddleCoord_(xli, xhi, mxi, mrxi);

      qp.xhi = mxi;
      query1_h_(n->l_, qp); // go recursively left
      query0_(n->m_, qp);   // go recursively middle
      qp.xhi = xhi;
      qp.xli = mrxi;
      query1_h_(n->r_, qp); // go recursively right
      qp.xli = xli;
      return;
    }

    FPtr ff = p.getFruitPointer();
    if(ff){
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
      }
      return;
    }
  }

  template<class Fruit, class LockingPolicy>
  template<class InsertIterator>
  int QTOLD<Fruit, LockingPolicy>:: query2remove_(NOFP& p,
                                               QTOLD_QueryParameters<InsertIterator>& qp)
  {
    NPtr n = p.getNodePointer();
    if (n) {
      // here we have a valid node pointer n

      if (!(qp.qbox.intersects(Rectangle(qp.xli, qp.yli, qp.xhi, qp.yhi), qp.considerTouch))) return -1;

      if (isItAHorizontalRectangleOrASquare_(qp.xli, qp.yli, qp.xhi, qp.yhi)) {
        Unit xli = qp.xli;
        Unit xhi = qp.xhi;

        // cutline is vertical
        Unit mxi, mrxi;
        getMiddleCoord_(xli, xhi, mxi, mrxi);

        qp.xhi = mxi;
        int left = query2remove_(n->l_, qp); // go recursively left
        qp.xli = mxi;
        int midd = query1remove_(n->m_, qp); // go recursively middle
        qp.xhi = xhi;
        qp.xli = mrxi;
        int rite = query2remove_(n->r_, qp); // go recursively right
        qp.xli = xli;

        return cleanUpRemoval_(p, left, midd, rite);
      }
      else { // cutline is horizontal
        Unit yli = qp.yli;
        Unit yhi = qp.yhi;

        Unit myi, mryi;
        getMiddleCoord_(yli, yhi, myi, mryi);

        qp.yhi = myi;
        int left = query2remove_(n->l_, qp); // go recursively left
        qp.yli = myi;
        int midd = query1remove_(n->m_, qp); // go recursively middle
        qp.yhi = yhi;
        qp.yli = mryi;
        int rite = query2remove_(n->r_, qp); // go recursively right
        qp.yli = yli;

        return cleanUpRemoval_(p, left, midd, rite);
      }
      assert(0);
      return -1;
    }

    FPtr ff = p.getFruitPointer();
    if (ff) {
      // here we have a valid fruit pointer ff
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
        p.setFruitPointer(0);
        return 0;
      }
      return -1;
    }

    // means both node and fruit pointers are null
    return 0;
  }


template<class Fruit, class LockingPolicy>
template<class InsertIterator>
  int QTOLD<Fruit, LockingPolicy>:: query1remove_(NOFP& p,
                                             QTOLD_QueryParameters<InsertIterator>& qp)
  {
    NPtr n = p.getNodePointer();
    FPtr ff = p.getFruitPointer();

    if (!n && !ff) return 0; // p is null pointer, get out

    if (ff) {
      //std::cout << "query1remove_ trying: " << ff->getBBox() << std::endl;
      if (QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)) {
        *(qp.inserter) = ff;
        p.setFruitPointer(0);
        return 0;
      }
      return 1;
    }

    // here we have a valid node pointer n
    if (qp.yli == qp.yhi) { // self node is a horizontal line

      if (qp.considerTouch) {
        if (qp.qbox.xh() < qp.xli ||
            qp.qbox.xl() > qp.xhi)
          return -1; // query box doesn't fall in vertical range of this horizontal line
      }
      else { // do not consider touch
        if (qp.qbox.xh() <= qp.xli ||
            qp.qbox.xl() >= qp.xhi) return -1; // query box doesn't intersect this one
      }
      Unit xli = qp.xli;
      Unit xhi = qp.xhi;
      Unit mxi, mrxi;
      getMiddleCoord_(xli, xhi, mxi, mrxi);

      qp.xhi = mxi;
      int left = query1remove_(n->l_, qp); // go recursively left
      int midd = query0remove_(n->m_, qp); // go recursively middle
      qp.xhi = xhi;
      qp.xli = mrxi;
      int rite = query1remove_(n->r_, qp); // go recursively right
      qp.xli = xli;

      return cleanUpRemoval_(p, left, midd, rite);
    }
    else if(qp.xli == qp.xhi){ // self node is a vertical line
      if(qp.considerTouch){
        if(qp.qbox.yh() < qp.yli ||
           qp.qbox.yl() > qp.yhi)
          return -1; // query box doesn't fall in horiz range range if this vertical  line
      }
      else { // do not consider touch
        if(qp.qbox.yh() <= qp.yli ||
           qp.qbox.yl() >= qp.yhi) return -1; // query box doesn't intersect this one
      }
      Unit yli = qp.yli;
      Unit yhi = qp.yhi;
      Unit myi, mryi;
      getMiddleCoord_(yli, yhi, myi, mryi);

      qp.yhi = myi;
      int left = query1remove_(n->l_, qp); // go recursively left
      int midd = query0remove_(n->m_, qp); // go recursively middle
      qp.yhi = yhi;
      qp.yli = mryi;
      int rite = query1remove_(n->r_, qp); // go recursively right
      qp.yli = yli;

      return cleanUpRemoval_(p, left, midd, rite);
    }
    else{ //
      std::cout << "Ooops, something wrong with the area of the Node1\n";
      assert(0);
      return -1;
    }
  }


template<class Fruit, class LockingPolicy>
template<class InsertIterator>
  int QTOLD<Fruit, LockingPolicy>:: query0remove_(NOFP& p, QTOLD_QueryParameters<InsertIterator>& qp)

  {
    NPtr n = p.getNodePointer();
    FPtr ff = p.getFruitPointer();
    if(!n && !ff) return 0; // p is null pointer, get out

    if (ff) {
      //std::cout << "query0remove_ trying: " << ff->getBBox() << std::endl;
      if(QTResolveBBox<Fruit>::getBBox(ff).intersects(qp.qbox, qp.considerTouch)){
        *(qp.inserter) = ff;
        p.setFruitPointer(0);
        return 0;
      }
      return 1;
    }
    int left = query0remove_(n->l_, qp); // go recursively left
    int midd = query0remove_(n->m_, qp); // go recursively middle
    int rite = query0remove_(n->r_, qp); // go recursively right
    // query0's only return numbers >= 0
    return cleanUpRemoval_(p, left, midd, rite);
  }


template<class Fruit, class LockingPolicy>
  int QTOLD<Fruit, LockingPolicy>::handleSimpleCase(int sum, NOFP& p)
  {
    NPtr n = p.getNodePointer();
    if (sum == 0) {
      // free the node pointer
      // and set it to 0
      delete n;
      p.setNodePointer(0);
      return 0;
    }

    if (sum == 1) {
      FPtr f;
      if (! (f = n->l_.getFruitPointer())) {
        if (! (f = n->m_.getFruitPointer())) {
          f = n->r_.getFruitPointer();
        }
      }

      p.setFruitPointer(f);
      delete n;
      return 1;
    }

    return -1;
  }


template<class Fruit, class LockingPolicy>
  int QTOLD<Fruit, LockingPolicy>:: cleanUpRemoval_(NOFP& p, int left, int midd, int rite)
  {
    // use the max of the number and 0, want to ignore the -1 for right now
    int sum = std::max(left, 0) + std::max(midd, 0) + std::max(rite, 0);
    if (sum >= 4) {
      // at least 4 fruit below this node, return that fact
      return sum;
    }

    int anyNegatives = std::min(left, std::min(midd, rite));
    if (anyNegatives >=  0) {
      int ret = handleSimpleCase(sum, p);
      if (ret != -1) {
        return ret;
      }
    }

    FourFruit fruitList;
    if (hasAtLeast4Fruit_(p, fruitList)) {
      return 4;
    }

    sum = fruitList.count;
    NPtr n = p.getNodePointer();
    if (sum == 0) {
      // free the node pointer
      // and set it to 0
      delete n;
      p.setNodePointer(0);
      return 0;
    }

    if (sum == 1) {
      delete n;
      p.setFruitPointer(fruitList.pop());
      return 1;
    }


    // only 2 cases left: sum == 2, 3
    // in either case, we want this node pointer 'n' to just point to fruit
    FPtr null(0);
    n->l_.setFruitPointer((fruitList.empty()) ? null : fruitList.pop());
    n->m_.setFruitPointer((fruitList.empty()) ? null : fruitList.pop());
    n->r_.setFruitPointer((fruitList.empty()) ? null : fruitList.pop());


    return sum;
  }


}; //end namespace query
