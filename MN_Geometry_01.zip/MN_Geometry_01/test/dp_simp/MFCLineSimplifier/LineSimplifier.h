// LineSimplifier.h
//

#pragma once
#include "resource.h"		

class CLineSimplifierApp : public CWinApp
{
public:
	virtual BOOL InitInstance();
};

extern CLineSimplifierApp theApp;
