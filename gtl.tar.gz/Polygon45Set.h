/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
//polygon45set class

typedef std::vector<Vertex45Compact> Polygon45VectorData;

class Polygon45Set {
public:

  /// default constructor
  Polygon45Set();

  /// constructor from an iterator pair over polygons
  template <class T>
  Polygon45Set(T inputBegin, T inputEnd);

  /// constructor from a Polygon
  template <class T>
  Polygon45Set(const Polygon45Impl<T>& polygon);

  /// constructor from a PolygonWithHoles
  template <class T>
  Polygon45Set(const Polygon45WithHolesImpl<T>& polyWithHoles);
   
  /// constructor from a Rectangle
  template <class T>
  Polygon45Set(const RectangleImpl<T>& rect);
   
  /// copy constructor
  Polygon45Set(const Polygon45Set& that);

  /// destructor
  ~Polygon45Set();

  /// assignement operator
  Polygon45Set& operator=(const Polygon45Set& that);

  /// equivilence operator 
  bool operator==(const Polygon45Set& p) const;

  /// inequivilence operator 
  bool operator!=(const Polygon45Set& p) const;

  /// append to the container cT 
  template <class cT>
  unsigned int get(cT& container, bool fractureHoles = false) const;

  /// append to the container cT with polygons (holes will be fractured along orientation)
  template <class cT>
  unsigned int getPolygons(cT& container) const;

  /// append to the container cT with PolygonWithHoles objects
  template <class cT>
  unsigned int getPolygonsWithHoles(cT& container) const;

  /// append to the container cT with polygons of three or four verticies
  template <class cT>
  unsigned int getTrapezoids(cT& container) const;

  /// clear the contents of the Polygon45Set
  void clear() { data_.clear(); dirty_ = unsorted_ = false; }

  /// find out if Polygon set is empty
  bool empty() const { return data_.empty(); }

  /// insert polygons
  template <class T>
  Polygon45Set& insert(T inputBegin, T inputEnd); 

  /// insert holes
  template <class T>
  Polygon45Set& insertHoles(T inputBegin, T inputEnd); 

  /// insert polygon
  template <class T>
  Polygon45Set& insert(const Polygon45Impl<T>& poly, bool isHole = false);

  /// insert hole
  template <class T>
  Polygon45Set& insertHole(const Polygon45Impl<T>& hole); 

  /// insert polygon with holes
  template <class T>
  Polygon45Set& insert(const Polygon45WithHolesImpl<T>& polyWithHoles);

  /// insert polygon set
  Polygon45Set& insert(const Polygon45Set& polygonSet);

  /// insert vertex sequence
  template <class iT>
  Polygon45Set& insertVertexSequence(iT beginVertex, iT endVertex,
                                     Direction1D winding, bool isHole = false);

  /// get the external boundary rectangle
  Rectangle extents() const;

  /// snap verticies of set to even,even or odd,odd coordinates
  const Polygon45Set& snap() const;

  /// | & + * - ^ binary operators
  Polygon45Set operator|(const Polygon45Set& b) const;
  Polygon45Set operator&(const Polygon45Set& b) const;
  Polygon45Set operator+(const Polygon45Set& b) const;
  Polygon45Set operator*(const Polygon45Set& b) const;
  Polygon45Set operator-(const Polygon45Set& b) const;
  Polygon45Set operator^(const Polygon45Set& b) const;

  /// |= &= += *= -= ^= binary operators
  Polygon45Set& operator|=(const Polygon45Set& b);
  Polygon45Set& operator&=(const Polygon45Set& b);
  Polygon45Set& operator+=(const Polygon45Set& b);
  Polygon45Set& operator*=(const Polygon45Set& b);
  Polygon45Set& operator-=(const Polygon45Set& b);
  Polygon45Set& operator^=(const Polygon45Set& b);

  /// | & + * - ^ binary operators
  template <class T2>
  Polygon45Set operator|(const Polygon45Impl<T2>& b) const;
  template <class T2>
  Polygon45Set operator&(const Polygon45Impl<T2>& b) const;
  template <class T2>
  Polygon45Set operator+(const Polygon45Impl<T2>& b) const;
  template <class T2>
  Polygon45Set operator*(const Polygon45Impl<T2>& b) const;
  template <class T2>
  Polygon45Set operator-(const Polygon45Impl<T2>& b) const;
  template <class T2>
  Polygon45Set operator^(const Polygon45Impl<T2>& b) const;

  /// |= &= += *= -= ^= binary operators
  template <class T2>
  Polygon45Set& operator|=(const Polygon45Impl<T2>& b);
  template <class T2>
  Polygon45Set& operator&=(const Polygon45Impl<T2>& b);
  template <class T2>
  Polygon45Set& operator+=(const Polygon45Impl<T2>& b);
  template <class T2>
  Polygon45Set& operator*=(const Polygon45Impl<T2>& b);
  template <class T2>
  Polygon45Set& operator-=(const Polygon45Impl<T2>& b);
  template <class T2>
  Polygon45Set& operator^=(const Polygon45Impl<T2>& b);

  /// | & + * - ^ binary operators
  template <class T2>
  Polygon45Set operator|(const Polygon45WithHolesImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator&(const Polygon45WithHolesImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator+(const Polygon45WithHolesImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator*(const Polygon45WithHolesImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator-(const Polygon45WithHolesImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator^(const Polygon45WithHolesImpl<T2>& b) const;

  /// |= &= += *= -= ^= binary operators
  template <class T2>
  Polygon45Set& operator|=(const Polygon45WithHolesImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator&=(const Polygon45WithHolesImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator+=(const Polygon45WithHolesImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator*=(const Polygon45WithHolesImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator-=(const Polygon45WithHolesImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator^=(const Polygon45WithHolesImpl<T2>& b);

  /// | & + * - ^ binary operators
  template <class T2>
  Polygon45Set operator|(const RectangleImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator&(const RectangleImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator+(const RectangleImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator*(const RectangleImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator-(const RectangleImpl<T2>& b) const;
  template <class T2>
  Polygon45Set operator^(const RectangleImpl<T2>& b) const;

  /// |= &= += *= -= ^= binary operators
  template <class T2>
  Polygon45Set& operator|=(const RectangleImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator&=(const RectangleImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator+=(const RectangleImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator*=(const RectangleImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator-=(const RectangleImpl<T2>& b);
  template <class T2>
  Polygon45Set& operator^=(const RectangleImpl<T2>& b);

   /// resizing operations
   Polygon45Set operator+(Unit delta) const;
   Polygon45Set& operator+=(Unit delta);
   Polygon45Set operator-(Unit delta) const;
   Polygon45Set& operator-=(Unit delta);

  enum RoundingOption { CLOSEST = 0, OVERSIZE = 1, UNDERSIZE = 2, SQRT2 = 3 };
  enum CornerOption { INTERSECTION = 0, ORTHOGINAL = 1 };

  /// shrink the Polygon45Set by shrinking
  Polygon45Set& resize(Unit resizing, RoundingOption rounding = CLOSEST,
                       CornerOption corner = INTERSECTION);

  /// shrink the Polygon45Set by shrinking
  Polygon45Set& shrink(UnsignedUnit shrinking, RoundingOption rounding = CLOSEST,
                       CornerOption corner = INTERSECTION);

   /// bloat the Polygon45Set by bloating
  Polygon45Set& bloat(UnsignedUnit bloating, RoundingOption rounding = CLOSEST,
                      CornerOption corner = INTERSECTION);

  /// get the area of the set 
  double area() const;

  /// transform set
  Polygon45Set& transform(const AxisTransform& atr);
    
  /// transform set
  Polygon45Set& transform(const Transform& tr);

  /// scale set
  Polygon45Set& scaleUp(UnsignedUnit factor);
  Polygon45Set& scaleDown(UnsignedUnit factor);

  /// accumulate the bloated polygon
  template <class T2>
  Polygon45Set& insertWithResize(const Polygon45Impl<T2>& poly,
                                Unit resizing, RoundingOption rounding = CLOSEST,
                                CornerOption corner = INTERSECTION,
                                bool hole = false);

  /// accumulate the bloated polygon with holes
  template <class T2>
  Polygon45Set& insertWithResize(const Polygon45WithHolesImpl<T2>& poly,
                                Unit resizing, RoundingOption rounding = CLOSEST,
                                CornerOption corner = INTERSECTION);

private:
   mutable Polygon45VectorData data_;
   mutable bool dirty_;
   mutable bool unsorted_;

private:
   void clean_() const;
   void sort_() const;
   // 0 for OR, 1 for AND, 2 for subtract and 3 for xor
   void applyBoolean_(int op, Polygon45VectorData& rvalue) const;
   void applyBoolean_(Polygon45VectorData& result, int op, 
                      Polygon45VectorData& rvalue) const;
   void applyBooleanException_(Polygon45VectorData& result, int op, 
                               Polygon45VectorData& rvalue) const;
   /// append to the container cT with PolygonWithHoles objects

   friend std::ostream& operator<<(std::ostream& o, const Polygon45Set& p);
   friend std::istream& operator>>(std::istream& i, Polygon45Set& p);

};

std::ostream& operator<< (std::ostream& o, const Polygon45Set& p);

std::istream& operator>> (std::istream& i, Polygon45Set& p);
