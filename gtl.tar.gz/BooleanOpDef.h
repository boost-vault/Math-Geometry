/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
using std::string;
using std::cout;
using std::cerr;
using std::endl;
using std::flush;

inline ScanEvent::iterator& ScanEvent::iterator::operator=(const iterator& that) {
   itr_ = that.itr_;
   prevPos_ = that.prevPos_;
   count_ = that.count_;
   return *this;
}

inline ScanEvent::iterator& ScanEvent::iterator::operator++() {
   prevPos_ = itr_->first;
   count_ += itr_->second;
   ++itr_;
   return *this;
}

inline ScanEvent::iterator ScanEvent::iterator::operator++(int) {
   iterator tmpItr(*this);
   ++(*this);
   return tmpItr;
}

inline std::pair<Interval, int> ScanEvent::iterator::operator*() {
   if(count_ == 0) ++(*this);
   return std::pair<Interval, int>(Interval(prevPos_, itr_->first), count_);
}

template<class iT>
inline ScanEvent::ScanEvent(iT begin, iT end) {
   for( ; begin != end; ++begin){
      insert(*begin);
   }
}

inline ScanEvent& ScanEvent::operator=(const ScanEvent& that) {
   eventData_ = that.eventData_;
   return *this;
}

inline void ScanEvent::insert(const std::pair<Interval, int>& intervalCount) {
   insert(intervalCount.first.low(), intervalCount.second);
   insert(intervalCount.first.high(), -intervalCount.second);
}

inline void ScanEvent::insert(Unit pos, int count) {
   EventData::iterator lb = eventData_.lower_bound(pos);
   if(lb != eventData_.end() && lb->first == pos) {
      lb->second += count;
      if(lb->second == 0)
         eventData_.erase(lb);
   } else {
      eventData_.insert(lb, std::pair<Unit, int>(pos, count));
   }
}

inline void ScanEvent::insert(const ScanEvent& that) {
   EventData::const_iterator itr;
   for(itr = that.eventData_.begin(); itr != that.eventData_.end(); ++itr) {
      insert((*itr).first, (*itr).second);
   }
}

inline ScanEvent::iterator ScanEvent::begin() const {
   if(eventData_.empty()) return end();
   EventData::const_iterator itr = eventData_.begin();
   Unit prevPos = itr->first;
   int count = itr->second;
   ++itr;
   return iterator(itr, prevPos, count);
}

inline ScanEvent::iterator ScanEvent::end() const {
   return iterator(eventData_.end(), 0, 0);
}

//self contained unit test of ScanEvent class (not comprehensive)
inline bool testBoolean1DMerge() {
   ScanEvent scanEvent;
   scanEvent.insert(std::pair<Interval, int>(Interval(0, 10), 1));
   for(ScanEvent::iterator begin = scanEvent.begin(); begin != scanEvent.end(); ++begin) {
      if(*begin != std::pair<Interval, int>(Interval(0, 10), 1)){
         cout << "Merge 1 interval failed\n";
         cout << (*begin).first << " " << (*begin).second << endl;
      }
   }
   scanEvent.insert(std::pair<Interval, int>(Interval(5, 15), -1));
   ScanEvent::iterator begin = scanEvent.begin(); 
   if(begin == scanEvent.end()) cout << "No output\n";
   if(*begin != std::pair<Interval, int>(Interval(0, 5), 1)) {
      cout << "Wrong first output\n";
      cout << (*begin).first << " " << (*begin).second << endl;
   }
   ++begin;
   if(begin == scanEvent.end()) cout << "Not engouh output\n";
   if(*begin != std::pair<Interval, int>(Interval(10, 15), -1)) {
      cout << "Wrong second output\n";
      cout << (*begin).first << " " << (*begin).second << endl;
   }
   
   scanEvent.insert(std::pair<Interval, int>(Interval(10, 20), 1));

   begin = scanEvent.begin(); 
   if(begin == scanEvent.end()) cout << "No output\n";
   if(*begin != std::pair<Interval, int>(Interval(0, 5), 1)) {
      cout << "Wrong repeat first output\n";
      cout << (*begin).first << " " << (*begin).second << endl;
   }
   ++begin;
   if(begin == scanEvent.end()) cout << "Not engouh output\n";
   if(*begin != std::pair<Interval, int>(Interval(15, 20), 1)) {
      cout << "Wrong third output\n";
      cout << (*begin).first << " " << (*begin).second << endl;
   }
   scanEvent.insert(std::pair<Interval, int>(Interval(5, 15), 1));
   begin = scanEvent.begin(); 
   if(begin == scanEvent.end()) cout << "No output\n";
   if(*begin != std::pair<Interval, int>(Interval(0, 20), 1)) {
      cout << "Wrong last output\n";
      cout << (*begin).first << " " << (*begin).second << endl;
   }
   return true;
}

template <class T>
inline BooleanOp<T>& BooleanOp<T>::operator=(const BooleanOp& that) { 
   scanData_ = that.scanData_; 
   nextItr_ = scanData_.begin();
   nullT_ = that.nullT_;
   return *this;
}
   
//appends output edges to cT
template <class T>
template <class cT>
inline void BooleanOp<T>::processInterval(cT& outputContainer, Interval ivl, T deltaCount) {
   typename ScanData::iterator lowItr = lookup_(ivl.low());
   typename ScanData::iterator highItr = lookup_(ivl.high());
   //add interval to scan data if it is past the end
   if(lowItr == scanData_.end()) {
      lowItr = insert_(ivl.low(), deltaCount);
      highItr = insert_(ivl.high(), nullT_);
      evaluateInterval_(outputContainer, ivl, nullT_, deltaCount);
      return;
   }
   //ensure that highItr points to the end of the ivl
   if(highItr == scanData_.end() || (*highItr).first > ivl.high()) {
      T value = nullT_;
      if(highItr != scanData_.begin()) {
         --highItr;
         value = highItr->second;
      }
      nextItr_ = highItr;
      highItr = insert_(ivl.high(), value);
   }
   //split the low interval if needed
   if(lowItr->first > ivl.low()) {
      if(lowItr != scanData_.begin()) {
         --lowItr;
         nextItr_ = lowItr;
         lowItr = insert_(ivl.low(), lowItr->second);
      } else {
         nextItr_ = lowItr;
         lowItr = insert_(ivl.low(), nullT_);
      }
   }
   //process scan data intersecting interval
   for(typename ScanData::iterator itr = lowItr; itr != highItr; ){
      T beforeCount = itr->second;
      T afterCount = itr->second += deltaCount;
      Unit low = itr->first;
      ++itr;
      Unit high = itr->first;
      evaluateInterval_(outputContainer, Interval(low, high), beforeCount, afterCount);
   }
   //merge the bottom interval with the one below if they have the same count
   if(lowItr != scanData_.begin()){
      typename ScanData::iterator belowLowItr = lowItr;
      --belowLowItr;
      if(belowLowItr->second == lowItr->second) {
         scanData_.erase(lowItr);
      }
   }
   //merge the top interval with the one above if they have the same count
   if(highItr != scanData_.begin()) {
      typename ScanData::iterator beforeHighItr = highItr;
      --beforeHighItr;
      if(beforeHighItr->second == highItr->second) {
         scanData_.erase(highItr);
         highItr = beforeHighItr;
         ++highItr;
      }
   }
   nextItr_ = highItr;
}

template <class T>
template <class cT>
inline void BooleanOp<T>::evaluateInterval_(cT& outputContainer, Interval ivl, 
                                            T beforeCount, T afterCount) {
   bool before = (int)beforeCount > 0;
   bool after = (int)afterCount > 0;
   int value =  (!before & after) - (before & !after);
      if(value) {
         outputContainer.insert(outputContainer.end(), std::pair<Interval, int>(ivl, value));
      }
}

template <class T>
inline BinaryCount<T>& BinaryCount<T>::operator=(const BinaryCount<T>& that) { 
   counts_[0] = that.counts_[0];
   counts_[1] = that.counts_[1];
   return *this;
}
template <class T>
inline bool BinaryCount<T>::operator==(const BinaryCount<T>& that) const { 
   return counts_[0] == that.counts_[0] &&
      counts_[1] == that.counts_[1];
}
template <class T>
inline BinaryCount<T>& BinaryCount<T>::operator+=(const BinaryCount<T>& that) {
   counts_[0] += that.counts_[0];
   counts_[1] += that.counts_[1];
   return *this;
}
template <class T>
inline BinaryCount<T>& BinaryCount<T>::operator-=(const BinaryCount<T>& that) {
   counts_[0] += that.counts_[0];
   counts_[1] += that.counts_[1];
   return *this;
}
template <class T>
inline BinaryCount<T> BinaryCount<T>::operator+(const BinaryCount<T>& that) const {
   BinaryCount retVal(*this);
   retVal += that;
   return retVal;
}
template <class T>
inline BinaryCount<T> BinaryCount<T>::operator-(const BinaryCount<T>& that) const {
   BinaryCount retVal(*this);
   retVal -= that;
   return retVal;
}
template <class T>
inline BinaryCount<T> BinaryCount<T>::operator-() const {
   return BinaryCount<T>() - *this;
}



   
template <class T>
inline ScanEventMergeIterator<T>::ScanEventMergeIterator(ScanEvent::iterator* itrs, 
                                                         ScanEvent::iterator* itrEnds) {
   for(int i = 0; i < 2; ++i) {
      itrs_[i] = itrs[i];
      itrEnds_[i] = itrEnds[i];
   }
   Unit low = getFirstPos_();
   element_.first = Interval(low, UnitMax);
   increment_();
}
template <class T>
inline ScanEventMergeIterator<T>& 
ScanEventMergeIterator<T>::operator=(const ScanEventMergeIterator<T>& that) {
   element_ = that.element_;
   for(int i = 0; i < 2; ++i) {
      itrs_[i] = that.itrs_[i];
      itrEnds_[i] = that.itrEnds_[i];
   }
   return *this;
}
   
template <class T>
inline bool ScanEventMergeIterator<T>::operator==(const ScanEventMergeIterator<T>& that) {
   bool retval = true;
   for(int i = 0; i < 2; ++i) {
      retval &= (itrs_[i] == that.itrs_[i]);
   }
   return retval;
}
   
template <class T>
inline ScanEventMergeIterator<T>& ScanEventMergeIterator<T>::operator++() {
   element_.first = Interval(element_.first.high(), UnitMax);
   element_.second = T();
   increment_();
   return *this;
}
   
template <class T>
inline ScanEventMergeIterator<T> ScanEventMergeIterator<T>::operator++(int) {
   ScanEventMergeIterator<T> tmpItr(*this);
   ++(*this);
   return tmpItr;
}
   
template <class T>
inline Unit ScanEventMergeIterator<T>::getFirstPos_() {
   Unit retval = UnitMax;
   for(int i = 0; i < 2; ++i) {
      if(itrs_[i] != itrEnds_[i]) {
         Unit low = (*(itrs_[i])).first.low();
         if(low < retval) retval = low;
      }
   }
   return retval;
}

//this is the function that does all the actual work
template <class T>
inline void ScanEventMergeIterator<T>::increment_() {
   bool intersected = false;
   for(int outer = 0; outer < 2; ++outer) {
      Unit low = element_.first.low();
      for(int i = 0; i < 2; ++i) {
         if(itrs_[i] != itrEnds_[i]) {
            std::pair<Interval, int> value = *(itrs_[i]);
            if(value.first.low() > low) {
               if(value.first.low() < element_.first.high()) {
                  element_.first.high(value.first.low());
               }
               continue;
            }
            if(value.first.high() <= low) {
               ++(itrs_[i]);
               --i; //we need to redo this iteration
               continue;
            }
            intersected = true;
            //we know that this interval intersects the next output
            if(value.first.high() < element_.first.high()) {
               element_.first.high(value.first.high());
            }
            //accumulate count
            element_.second[i] += value.second;
         }
      }
      if(!intersected) {
         //if none of the next intervals intersect advance position
         element_.first = Interval(getFirstPos_(), UnitMax);
      } else {
         break;
      }
   }
}

//self contained unit test for BooleanOr algorithm
inline bool testBooleanOr() {
   BooleanOr booleanOr;
   //test one rectangle
   std::vector<std::pair<Interval, int> > container;
   booleanOr.processInterval(container, Interval(0, 10), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(0, 10), -1);
   if(container.size() != 2) { 
      cout << "Test one rectangle, wrong output size\n";
      return false;
   }
   if(container[0] != std::pair<Interval, int>(Interval(0, 10), 1)) {
      cout << "Test one rectangle, first output wrong: Interval(" <<
         container[0].first << "), " << container[0].second << endl;
   }
   if(container[1] != std::pair<Interval, int>(Interval(0, 10), -1)) {
      cout << "Test one rectangle, second output wrong: Interval(" <<
         container[1].first << "), " << container[1].second << endl;
   }

   //test two rectangles
   container.clear();
   booleanOr = BooleanOr();
   booleanOr.processInterval(container, Interval(0, 10), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(5, 15), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(0, 10), -1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(5, 15), -1);
   if(container.size() != 4) {
      cout << "Test two rectangles, wrong output size\n";
      for(unsigned int i = 0; i < container.size(); ++i){
         cout << container[i].first << "), " << container[i].second << endl;
      }
      return false;
   }
   if(container[0] != std::pair<Interval, int>(Interval(0, 10), 1)) {
      cout << "Test two rectangles, first output wrong: Interval(" <<
         container[0].first << "), " << container[0].second << endl;
   }
   if(container[1] != std::pair<Interval, int>(Interval(10, 15), 1)) {
      cout << "Test two rectangles, second output wrong: Interval(" <<
         container[1].first << "), " << container[1].second << endl;
   }
   if(container[2] != std::pair<Interval, int>(Interval(0, 5), -1)) {
      cout << "Test two rectangles, third output wrong: Interval(" <<
         container[2].first << "), " << container[2].second << endl;
   }
   if(container[3] != std::pair<Interval, int>(Interval(5, 15), -1)) {
      cout << "Test two rectangles, fourth output wrong: Interval(" <<
         container[3].first << "), " << container[3].second << endl;
   }

   //test two rectangles
   container.clear();
   booleanOr = BooleanOr();
   booleanOr.processInterval(container, Interval(5, 15), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(0, 10), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(5, 15), -1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(0, 10), -1);
   if(container.size() != 4) {
      cout << "Test other two rectangles, wrong output size\n";
      for(unsigned int i = 0; i < container.size(); ++i){
         cout << container[i].first << "), " << container[i].second << endl;
      }
      return false;
   }
   if(container[0] != std::pair<Interval, int>(Interval(5, 15), 1)) {
      cout << "Test other two rectangles, first output wrong: Interval(" <<
         container[0].first << "), " << container[0].second << endl;
   }
   if(container[1] != std::pair<Interval, int>(Interval(0, 5), 1)) {
      cout << "Test other two rectangles, second output wrong: Interval(" <<
         container[1].first << "), " << container[1].second << endl;
   }
   if(container[2] != std::pair<Interval, int>(Interval(10, 15), -1)) {
      cout << "Test other two rectangles, third output wrong: Interval(" <<
         container[2].first << "), " << container[2].second << endl;
   }
   if(container[3] != std::pair<Interval, int>(Interval(0, 10), -1)) {
      cout << "Test other two rectangles, fourth output wrong: Interval(" <<
         container[3].first << "), " << container[3].second << endl;
   }

   //test two nonoverlapping rectangles
   container.clear();
   booleanOr = BooleanOr();
   booleanOr.processInterval(container, Interval(0, 10), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(15, 25), 1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(0, 10), -1);
   booleanOr.advanceScan();
   booleanOr.processInterval(container, Interval(15, 25), -1);
   if(container.size() != 4) {
      cout << "Test two nonoverlapping rectangles, wrong output size\n";
      return false;
   }
   if(container[0] != std::pair<Interval, int>(Interval(0, 10), 1)) {
      cout << "Test two nonoverlapping rectangles, first output wrong: Interval(" <<
         container[0].first << "), " << container[0].second << endl;
   }
   if(container[1] != std::pair<Interval, int>(Interval(15, 25), 1)) {
      cout << "Test two nonoverlapping rectangles, second output wrong: Interval(" <<
         container[1].first << "), " << container[1].second << endl;
   }
   if(container[2] != std::pair<Interval, int>(Interval(0, 10), -1)) {
      cout << "Test two nonoverlapping rectangles, third output wrong: Interval(" <<
         container[2].first << "), " << container[2].second << endl;
   }
   if(container[3] != std::pair<Interval, int>(Interval(15, 25), -1)) {
      cout << "Test two nonoverlapping rectangles, fourth output wrong: Interval(" <<
         container[3].first << "), " << container[3].second << endl;
   }
   return true;
}

template <class T>
inline void applyBooleanBinaryOp(std::vector<std::pair<Unit, std::pair<Unit, int> > >& output,
                                 const std::vector<std::pair<Unit, std::pair<Unit, int> > >& input1,
                                 const std::vector<std::pair<Unit, std::pair<Unit, int> > >& input2,
                                 T defaultCount) {
   BooleanOp<T> boolean(defaultCount);
   std::vector<std::pair<Unit, std::pair<Unit, int> > >::const_iterator itr1 = input1.begin();
   std::vector<std::pair<Unit, std::pair<Unit, int> > >::const_iterator itr2 = input2.begin();
   std::vector<std::pair<Interval, int> > container;
   output.reserve(max(input1.size(), input2.size()));

   Unit prevCoord = UnitMax;
   Unit prevPosition = UnitMax;
   T count(defaultCount);
   //define the starting point
   if(itr1 != input1.end()) {
      prevCoord = (*itr1).first;
      prevPosition = (*itr1).second.first;
      count[0] += (*itr1).second.second;
   }
   if(itr2 != input2.end()) {
      if((*itr2).first < prevCoord || 
         ((*itr2).first == prevCoord && (*itr2).second.first < prevPosition)) {
         prevCoord = (*itr2).first;
         prevPosition = (*itr2).second.first;
         count = defaultCount;
         count[1] += (*itr2).second.second;
         ++itr2;
      } else if((*itr2).first == prevCoord && (*itr2).second.first == prevPosition) {
         count[1] += (*itr2).second.second;
         ++itr2;
         if(itr1 != input1.end())++itr1;
      } else {
         if(itr1 != input1.end())++itr1;
      }
   } else {
      if(itr1 != input1.end())++itr1;
   }
   
   while(itr1 != input1.end() || itr2 != input2.end()) {
      Unit curCoord = UnitMax;
      Unit curPosition = UnitMax;
      T curCount(defaultCount);
      if(itr1 != input1.end()) {
         curCoord = (*itr1).first;
         curPosition = (*itr1).second.first;
         curCount[0] += (*itr1).second.second;
      }
      if(itr2 != input2.end()) {
         if((*itr2).first < curCoord || 
            ((*itr2).first == curCoord && (*itr2).second.first < curPosition)) {
            curCoord = (*itr2).first;
            curPosition = (*itr2).second.first;
            curCount = defaultCount;
            curCount[1] += (*itr2).second.second;
            ++itr2;
         } else if((*itr2).first == curCoord && (*itr2).second.first == curPosition) {
            curCount[1] += (*itr2).second.second;
            ++itr2;
            if(itr1 != input1.end())++itr1;
         } else {
            if(itr1 != input1.end())++itr1;
         }
      } else {
         ++itr1;
      }

      if(prevCoord != curCoord) {
         boolean.advanceScan();
         prevCoord = curCoord;
         prevPosition = curPosition;
         count = curCount;
         continue;
      }
      if(curPosition != prevPosition && count != defaultCount) {
         Interval ivl(prevPosition, curPosition);
         container.clear();
         boolean.processInterval(container, ivl, count);
         for(unsigned int i = 0; i < container.size(); ++i) {
            std::pair<Interval, int>& element = container[i];
            if(!output.empty() && output.back().first == prevCoord && 
               output.back().second.first == element.first.low() &&
               output.back().second.second == element.second * -1) {
               output.pop_back();
            } else {
               output.push_back(std::pair<Unit, std::pair<Unit, int> >(prevCoord, std::pair<Unit, int>(element.first.low(), 
                                                                                                       element.second)));
            }
            output.push_back(std::pair<Unit, std::pair<Unit, int> >(prevCoord, std::pair<Unit, int>(element.first.high(), 
                                                                                                    element.second * -1)));
         }
      }
      prevPosition = curPosition;
      count += curCount;
   }
}

template <class T>
inline void applyBooleanBinaryOp(std::vector<std::pair<Unit, std::pair<Unit, int> > >& inputOutput,
                                 const std::vector<std::pair<Unit, std::pair<Unit, int> > >& input2,
                                 T defaultCount) {
   std::vector<std::pair<Unit, std::pair<Unit, int> > > output;
   applyBooleanBinaryOp(output, inputOutput, input2, defaultCount);
   if(output.size() < inputOutput.size() / 2) {
      inputOutput = std::vector<std::pair<Unit, std::pair<Unit, int> > >();
   } else {
      inputOutput.clear();
   }
   inputOutput.insert(inputOutput.end(), output.begin(), output.end());
}
 
//T is a BinaryCount type
template <class T>
inline void applyBooleanBinaryOp(PolygonSetData& output, const PolygonSetData& input1,
                                 const PolygonSetData& input2, T defaultCount) {
   BooleanOp<T> boolean(defaultCount);
   PolygonSetData::const_iterator itr1 = input1.begin();
   PolygonSetData::const_iterator itr2 = input2.begin();
   std::vector<std::pair<Interval, int> > container;
   while(itr1 != input1.end() || itr2 != input2.end()) {
      boolean.advanceScan();
      ScanEvent nullEvent;
      const ScanEvent* event1 = &nullEvent;
      const ScanEvent* event2 = &nullEvent;
      Unit coordinate = 0;
      if(itr1 != input1.end() && itr2 != input2.end()) {
         if((*itr1).first < (*itr2).first) {
            event1 = &((*itr1).second);
            coordinate = (*itr1).first;
            ++itr1;
         } else if((*itr2).first < (*itr1).first) {
            event2 = &((*itr2).second);
            coordinate = (*itr2).first;
            ++itr2;
         } else {
            event1 = &((*itr1).second);
            event2 = &((*itr2).second);
            coordinate = (*itr1).first;
            ++itr1;
            ++itr2;
         }
      } else if(itr1 != input1.end()) {
         event1 = &((*itr1).second);
         coordinate = (*itr1).first;
         ++itr1;
      } else {//itr2 != input2.end()
         event2 = &((*itr2).second);
         coordinate = (*itr2).first;
         ++itr2;
      }
      ScanEvent::iterator itrs[2] = {event1->begin(), event2->begin()};
      ScanEvent::iterator itrEnds[2] = {event1->end(), event2->end()};
      ScanEventMergeIterator<T> mergeItr(itrs, itrEnds);
      ScanEventMergeIterator<T> mergeItrEnd(itrEnds, itrEnds);
      container.clear();
      for( ; mergeItr != mergeItrEnd; ++mergeItr) {
         boolean.processInterval(container, (*mergeItr).first, (*mergeItr).second);
      }
      if(!container.empty()){
         ScanEvent& event = output[coordinate];
         for(unsigned int i = 0; i < container.size(); ++i) {
            std::pair<Interval, int>& element = container[i];
            event.insert(element);
         }
      }
   }
}
//T is a BinaryCount type
template <class T>
inline void applyBooleanBinaryOp(PolygonSetData& inputOutput,
                                 const PolygonSetData& input2, T defaultCount) {
   BooleanOp<T> boolean(defaultCount);
   PolygonSetData::iterator itr1 = inputOutput.begin();
   PolygonSetData::iterator prevItr1 = itr1;
   PolygonSetData::const_iterator itr2 = input2.begin();
   std::vector<std::pair<Interval, int> > container;
   while(itr1 != inputOutput.end() || itr2 != input2.end()) {
      boolean.advanceScan();
      ScanEvent nullEvent;
      ScanEvent* event1 = &nullEvent;
      const ScanEvent* event2 = &nullEvent;
      Unit coordinate = 0;
      bool atItr1 = false;
      if(itr1 != inputOutput.end() && itr2 != input2.end()) {
         if((*itr1).first < (*itr2).first) {
            event1 = &((*itr1).second);
            atItr1 = true;
            coordinate = (*itr1).first;
            ++itr1;
         } else if((*itr2).first < (*itr1).first) {
            event2 = &((*itr2).second);
            coordinate = (*itr2).first;
            ++itr2;
         } else {
            event1 = &((*itr1).second);
            event2 = &((*itr2).second);
            atItr1 = true;
            coordinate = (*itr1).first;
            ++itr1;
            ++itr2;
         }
      } else if(itr1 != inputOutput.end()) {
         event1 = &((*itr1).second);
         atItr1 = true;
         coordinate = (*itr1).first;
         ++itr1;
      } else {//itr2 != input2.end()
         event2 = &((*itr2).second);
         coordinate = (*itr2).first;
         ++itr2;
      }
      ScanEvent::iterator itrs[2] = {event1->begin(), event2->begin()};
      ScanEvent::iterator itrEnds[2] = {event1->end(), event2->end()};
      ScanEventMergeIterator<T> mergeItr(itrs, itrEnds);
      ScanEventMergeIterator<T> mergeItrEnd(itrEnds, itrEnds);
      container.clear();
      for( ; mergeItr != mergeItrEnd; ++mergeItr) {
         boolean.processInterval(container, (*mergeItr).first, (*mergeItr).second);
      }
      inputOutput.erase(prevItr1, itr1);
      if(!container.empty()){
         ScanEvent& event = inputOutput[coordinate];
         event.clear();
         for(unsigned int i = 0; i < container.size(); ++i) {
            std::pair<Interval, int>& element = container[i];
            event.insert(element);
         }
         prevItr1 = inputOutput.find(coordinate);
         ++prevItr1;
      } else {
         prevItr1 = itr1;
      }
   }
}

inline void applyBooleanOr(PolygonSetData& input) {
   BooleanOr booleanOr;
   std::vector<std::pair<Interval, int> > container;
   for(PolygonSetData::iterator itr = input.begin();
       itr != input.end(); ) {
      booleanOr.advanceScan();
      container.clear();
      for(ScanEvent::iterator eventItr = (*itr).second.begin();
          eventItr != (*itr).second.end(); ++eventItr) {
         booleanOr.processInterval(container, (*eventItr).first, (*eventItr).second);
      }
      if(container.empty()) {
         PolygonSetData::iterator itrNext = itr;
         ++itrNext;
         input.erase(itr);
         itr = itrNext;
         continue;
      }
      (*itr).second.clear();
      for(unsigned int i = 0; i < container.size(); ++i) {
         std::pair<Interval, int>& element = container[i];
         (*itr).second.insert(element);
      }
      ++itr;
   }
}

inline void applyBooleanOr(std::vector<std::pair<Unit, std::pair<Unit, int> > >& input) {
   BooleanOr booleanOr;
   std::vector<std::pair<Interval, int> > container;
   std::vector<std::pair<Unit, std::pair<Unit, int> > > output;
   output.reserve(input.size());
   Unit prevPos = UnitMax;
   Unit prevY = UnitMax;
   int count = 0;
   for(std::vector<std::pair<Unit, std::pair<Unit, int> > >::iterator itr = input.begin();
       itr != input.end(); ++itr) {
      Unit pos = (*itr).first;
      Unit y = (*itr).second.first;
      if(pos != prevPos) {
         booleanOr.advanceScan();
         prevPos = pos;
         prevY = y;
         count = (*itr).second.second;
         continue;
      }
      if(y != prevY && count != 0) {
         Interval ivl(prevY, y);
         container.clear();
         booleanOr.processInterval(container, ivl, count);
         for(unsigned int i = 0; i < container.size(); ++i) {
            std::pair<Interval, int>& element = container[i];
            if(!output.empty() && output.back().first == prevPos && 
               output.back().second.first == element.first.low() &&
               output.back().second.second == element.second * -1) {
               output.pop_back();
            } else {
               output.push_back(std::pair<Unit, std::pair<Unit, int> >(prevPos, std::pair<Unit, int>(element.first.low(), 
                                                                                                       element.second)));
            }
            output.push_back(std::pair<Unit, std::pair<Unit, int> >(prevPos, std::pair<Unit, int>(element.first.high(), 
                                                                                               element.second * -1)));
         }
      }
      prevY = y;
      count += (*itr).second.second;
   }
   if(output.size() < input.size() / 2) {
      input = std::vector<std::pair<Unit, std::pair<Unit, int> > >();
   } else {
      input.clear();
   } 
   input.insert(input.end(), output.begin(), output.end());
}
