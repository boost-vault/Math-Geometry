// LineSimplifierDlg.cpp
//

#include "stdafx.h"
#include "LineSimplifier.h"
#include "LineSimplifierDlg.h"

#include <geometry/dp_simp.hpp>
#include <boost/bind.hpp>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CLineSimplifierDlg::CLineSimplifierDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLineSimplifierDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

double CLineSimplifierDlg::GetTolerance()
{
	return m_ToleranceSlider.GetPos()/10.0;
}

void CLineSimplifierDlg::SetTolerance(double tolerance)
{
	m_ToleranceSlider.SetPos(int(tolerance*10.0));

	CString str;
	str.Format("%.1f", tolerance);
	SetDlgItemText(IDC_TOLERANCEEDIT, str);

	SimplifyPath();
}

void CLineSimplifierDlg::SimplifyPath()
{
	m_Simp.clear();
	geom::dp_simp(m_Points.begin(), m_Points.end(), std::back_inserter(m_Simp), GetTolerance());
	
	CString status;
	status.Format("Original: %d points.\tSimplified: %d points.", m_Points.size(), m_Simp.size());
	SetDlgItemText(IDC_STATUS, status);

	m_Canvas.Invalidate();
}


void CLineSimplifierDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TOLERANCESLIDER, m_ToleranceSlider);
	DDX_Control(pDX, IDC_CANVAS, m_Canvas);
}


BOOL CLineSimplifierDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	m_ToleranceSlider.SetRange(0, 200);
	SetTolerance(2.0);

	return TRUE;
}


BEGIN_MESSAGE_MAP(CLineSimplifierDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_HSCROLL()
END_MESSAGE_MAP()

void CLineSimplifierDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		dc.DrawIcon(x, y, m_hIcon);
	}
	else
		CDialog::OnPaint();
}

HCURSOR CLineSimplifierDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CLineSimplifierDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	// TODO: Add your message handler code here and/or call default
	if (nSBCode == SB_THUMBTRACK)
		SetTolerance(double(nPos)/10);
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}
