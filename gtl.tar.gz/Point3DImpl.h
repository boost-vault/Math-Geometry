/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// Point3DImpl implements all Point3D functions on top of 3D point type T

/// Point3DImpl inherits from 3D point type T and accesses the data owned
/// by T through the Point3DInterface<T> class
template <class T>
class Point3DImpl : public T {
public:

  /// get a reference of PointImpl type given a data object
  static Point3DImpl& mimic(T& t) { return static_cast<Point3DImpl&>(t); }

  /// get a const reference of PointImpl type given a data object
  static const Point3DImpl& mimicConst(const T& t) { 
    return static_cast<const Point3DImpl&>(t); 
  }

  /// construct a 3D point from x, y and z
  Point3DImpl(Unit x, Unit y, Unit z) {
    *this = construct_(x, y, z);
  }

  /// default constructor
  Point3DImpl() {
    *this = construct_(UnitMin,
                       UnitMin,
                       UnitMin);
  }

  /// assignment operator
  template <class T2>
  const Point3DImpl& operator=(const Point3DImpl<T2>& that) { 
    x(that.x()); y(that.y()); z(that.z());
    return *this;
  }

  /// assignment operator
  const Point3DImpl& operator=(const Point3DImpl& that) {
    static_cast<T&>(*this) = that;
    return *this;
  }
 
  /// assignment operator
  const Point3DImpl& operator=(const T& that) {
    static_cast<T&>(*this) = that;
    return *this;
  }

  /// copy constructor
  template <class T2>
  Point3DImpl(const Point3DImpl<T2>& that) { *this = that;}

  /// copy constructor
  Point3DImpl(const T& that) : T(that) {;}
    
  /// equivalence operator
  template <class T2>
  bool operator==(const Point3DImpl<T2>& b) const;

  /// inequivalence operator
  template <class T2>
  bool operator!=(const Point3DImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<(const Point3DImpl<T2>& b) const;

  /// comparison operator
  template <class T2>
  bool operator<=(const Point3DImpl<T2>& b) const { return !(*this > b); }

  /// comparison operator
  template <class T2>
  bool operator>(const Point3DImpl<T2>& b) const { return b < (*this); }

  /// comparison operator
  template <class T2>
  bool operator>=(const Point3DImpl<T2>& b) const { return !(*this < b); }

  /// addition operator (convolve two points)
  template <class T2>
  Point3DImpl& operator+=(const Point3DImpl<T2>& p);
    
  /// binary addtion operator (get the convolution of two points)
  template <class T2>
  Point3DImpl operator+(const Point3DImpl<T2>& p) const;

  /// subtraction operator (deconvolve two points)
  template <class T2>
  Point3DImpl& operator-=(const Point3DImpl<T2>& p);
    
  /// binary subtraction operator (get the deconvolution of two points)
  template <class T2>
  Point3DImpl operator-(const Point3DImpl<T2>& p) const;

  /// conversion to 2D point
  operator PointImpl<PointData>() const;

  /// convolve point with point
  template <class T2>
  Point3DImpl& convolve(const Point3DImpl<T2>& p);

  /// deconvolve point with point
  template <class T2>
  Point3DImpl& deconvolve(const Point3DImpl<T2>& p);

  /// yield const ref to payload
  const T& yieldConst() const { return *this; }
     
  /// yield payload
  T& yield() { return *this; }
     
  /// return a reference to 'this' PointImpl<T>
  PointImpl<T>& mimicPoint();

  /// return a const reference to 'this' PointImpl<T>
  const PointImpl<T>& mimicConstPoint() const;

  /// get the coordinate on the orientation orient
  Unit get(Orientation3D orient) const {return get_(orient);}

  /// set the coordinate on the orientation orient to value
  Point3DImpl& set(Orientation3D orient, Unit value) {
    set_(orient, value); return *this;
  }

  /// get x
  Unit x() const { return get(HORIZONTAL); }

  /// set x
  Point3DImpl& x(Unit value){ return set(HORIZONTAL, value); }

  /// get y
  Unit y() const { return get(VERTICAL); }

  /// set y
  Point3DImpl& y(Unit value){ return set(VERTICAL, value); }

  /// get z
  Unit z() const { return get(PROXIMAL); }

  /// set z
  Point3DImpl& z(Unit value){ return set(PROXIMAL, value); }

  /// transform point
  Point3DImpl& transform(const AxisTransform& atr);
    
  /// transform point
  Point3DImpl& transform(const Transform& tr);

  /// go a distance in a direction
  Point3DImpl& go(Direction3D dir, Unit dist);

  /// get the distance from 'this' 3D point to p along the orientation orient
  template <class T2>
  UnsignedUnit distance(const Point3DImpl<T2>& p, 
                               Orientation3D orient) const;

  /// get the manhattan distance between 'this' and p
  template <class T2>
  UnsignedLongUnit manhattanDistance(const Point3DImpl<T2>& p) const;

  /// get the euclidian distance between 'this' and p
  template <class T2>
  double euclidianDistance(const Point3DImpl<T2>& p) const;

  /// if 'this' and p are colinear, set dir to the direction from
  /// 'this' to p, else return false and leave dir unchanged
  template <class T2>
  bool toward(const Point3DImpl<T2>& p, Direction3D& dir) const;
    
  /// return true if 'this' and p differ only in the coordinate
  /// corresponding to orient
  template <class T2>
  bool aligned(const Point3DImpl<T2>& p, 
                      Orientation3D orient) const;

  /// return true if 'this' and p are aligned on the orientation cooresponding
  /// to dir and p is in dir direction from 'this', if considerTouch is true
  /// return true in the case that they are equal
  template <class T2>
  bool alignedAndToward(const Point3DImpl<T2>& p, Direction3D dir, 
                               bool considerTouch = true) const;

  /// return true if 'this' is between p1 and p2 and they are all aligned
  template <class T2, class T3>
  bool between(const Point3DImpl<T2>& p1, const Point3DImpl<T3>& p2) const;

private:
  //private functions
  Unit get_(Orientation3D orient) const {
    return Point3DInterface<T>::Point3DGet(*this, orient);
  }

  void set_(Orientation3D orient, Unit value) {
    Point3DInterface<T>::Point3DSet(*this, orient, value);
  }

  static T construct_(Unit x, Unit y, Unit z) {
    return Point3DInterface<T>::Point3DConstruct(x, y, z);
  }
};

typedef Point3DImpl<Point3DData> Point3D;

template <class T>
std::ostream& operator<< (std::ostream& o, const Point3DImpl<T>& p);

template <class T>
std::istream& operator>> (std::istream& i, Point3DImpl<T>& p);
