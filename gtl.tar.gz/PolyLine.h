/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/

//integer vector type (fill in allocator if we can't use default)
typedef std::vector<Unit> UnitVector;

//forward declare for typedef
class ActiveTail;
typedef std::vector<ActiveTail*> TailVector;

/**
 * @brief End has two states, HEAD and TAIL as is represented by a bool
 */
typedef bool End;

/**
 * @brief HEAD End is represented as false because it is the lesser state
 */
const End HEAD = false;

/**
 * @brief TAIL End is represented by true because TAIL comes after head and 1 after 0
 */
const End TAIL = true;
   
/**
 * @brief 2D turning direction, left and right sides (is a boolean value since it has two states.)
 */
typedef bool Side;
   
/**
 * @brief LEFT Side is 0 because we inuitively think left to right; left < right
 */
const Side LEFT = false;
   
/**
 * @brief RIGHT Side is 1 so that right > left
 */
const Side RIGHT = true;

/**
 * @brief The PolyLine class is data storage and services for building and representing partial polygons.  
 * As the polyline is added to it extends its storage to accomodate the data.
 * PolyLines can be joined head-to-head/head-to-tail when it is determined that two polylines are
 * part of the same polygon.
 * PolyLines keep state information about what orientation their incomplete head and tail geometry have,
 * which side of the polyline is solid and whether the polyline is joined head-to-head and tail-to-head.
 * PolyLines have nothing whatsoever to do with holes.
 * It may be valuable to collect a histogram of PolyLine lengths used by an algorithm on its typical data
 * sets and tune the allocation of the initial vector of coordinate data to be greater than or equal to
 * the mean, median, mode, or mean plus some number of standard deviation, or just generally large enough
 * to prevent too much unnecesary reallocations, but not too big that it wastes a lot of memory and degrades cache
 * performance.
 */
class PolyLine {
private:
  //data
     
  /**
   * @brief ptdata_ a vector of coordiantes
   * if VERTICAL_HEAD, first coordiante is an X
   * else first coordinate is a Y
   */
  UnitVector ptdata_;
   
  /**
   * @brief head and tail points to other polylines before and after this in a chain
   */
  PolyLine* headp_;
  PolyLine* tailp_;
   
  /**
   * @brief state bitmask
   * bit zero is orientation, 0 H, 1 V
   * bit 1 is head connectivity, 0 for head, 1 for tail
   * bit 2 is tail connectivity, 0 for head, 1 for tail
   * bit 3 is solid to left of PolyLine when 1, right when 0
   */
  int state_;
   
public:
  /**
   * @brief default constructor (for preallocation)
   */
  PolyLine();
   
  /**
   * @brief constructor that takes the orientation, coordiante and side to which there is solid
   */
  PolyLine(Orientation2D orient, Unit coord, Side side);
   
  //copy constructor
  PolyLine(const PolyLine& pline);
   
  //destructor
  ~PolyLine();
   
  //assignment operator
  PolyLine& operator=(const PolyLine& that);

  //equivilence operator
  bool operator==(const PolyLine& b) const;

  /**
   * @brief valid PolyLine (only default constructed polylines are invalid.)
   */
  bool isValid() const;

  /**
   * @brief Orientation of Head
   */
  Orientation2D headOrient() const;

  /**
   * @brief returns true if first coordinate is an X value (first segment is vertical)
   */
  bool verticalHead() const; 

  /**
   * @brief returns the Orientation2D fo the tail
   */
  Orientation2D tailOrient() const;
      
  /**
   * @brief returns true if last coordinate is an X value (last segment is vertical)
   */
  bool verticalTail() const;
     
  /**
   * @brief retrun true if PolyLine has odd number of coordiantes
   */
  bool oddLength() const;

  /**
   * @brief retrun the End of the other polyline that the specified end of this polyline is connected to
   */
  End endConnectivity(End end) const;

  /**
   * @brief retrun true if the head of this polyline is connect to the tail of a polyline
   */
  bool headToTail() const;
  /**
   * @brief retrun true if the head of this polyline is connect to the head of a polyline
   */
  bool headToHead() const;

  /**
   * @brief retrun true if the tail of this polyline is connect to the tail of a polyline
   */
  bool tailToTail() const;
  /**
   * @brief retrun true if the tail of this polyline is connect to the head of a polyline
   */
  bool tailToHead() const;
     
  /**
   * @brief retrun the side on which there is solid for this polyline
   */
  Side solidSide() const;

  /**
   * @brief retrun true if there is solid to the right of this polyline
   */
  bool solidToRight() const;

  /**
   * @brief returns true if the polyline tail is not connected
   */
  bool active() const;

  /**
   * @brief adds a coordinate value to the end of the polyline changing the tail orientation
   */
  PolyLine& pushCoordinate(Unit coord);
       
  /**
   * @brief removes a coordinate value at the end of the polyline changing the tail orientation
   */
  PolyLine& popCoordinate();
      
  /**
   * @brief extends the tail of the polyline to include the point, changing orientation if needed
   */
  PolyLine& pushPoint(const Point& point);

  /**
   * @brief changes the last coordinate of the tail of the polyline by the amount of the delta
   */
  PolyLine& extendTail(Unit delta);

  /**
   * @brief join thisEnd of this polyline to that polyline's end
   */
  PolyLine& joinTo(End thisEnd, PolyLine& that, End end);

  /**
   * @brief join an end of this polyline to the tail of that polyline
   */
  PolyLine& joinToTail(PolyLine& that, End end);

  /**
   * @brief join an end of this polyline to the head of that polyline
   */
  PolyLine& joinToHead(PolyLine& that, End end);

  /**
   * @brief join the head of this polyline to the head of that polyline
   */
  //join this to that in the given way
  PolyLine& joinHeadToHead(PolyLine& that);

  /**
   * @brief join the head of this polyline to the tail of that polyline
   */
  PolyLine& joinHeadToTail(PolyLine& that);

  /**
   * @brief join the tail of this polyline to the head of that polyline
   */
  PolyLine& joinTailToHead(PolyLine& that);

  /**
   * @brief join the tail of this polyline to the tail of that polyline
   */
  PolyLine& joinTailToTail(PolyLine& that);

  /**
   * @brief dissconnect the tail at the end of the polygon
   */
  PolyLine& disconnectTails();

  /**
   * @brief get the coordinate at one end of this polyline, by default the tail end
   */
  Unit getEndCoord(End end = TAIL) const;

  /**
   * @brief get the point on the polyline at the given index (polylines have the same number of coordinates as points
   */
  Point getPoint(unsigned int index) const;

  /**
   * @brief get the point on one end of the polyline, by default the tail
   */
  Point getEndPoint(End end = TAIL) const;

  /**
   * @brief get the orientation of a segment by index
   */
  Orientation2D segmentOrient(unsigned int index = 0) const;

  /**
   * @brief get a coordinate by index using the square bracket operator
   */
  Unit operator[] (unsigned int index) const;

  /**
   * @brief get the number of segments/points/coordinates in the polyline
   */
  unsigned int numSegments() const;

  /**
   * @brief get the pointer to the next polyline at one end of this
   */
  PolyLine* next(End end) const;

  /**
   * @brief write out coordinates of this and all attached polylines to a single vector
   */
  PolyLine* writeOut(UnitVector& outVec, End startEnd = TAIL) const;

private:
  //methods
  PolyLine& joinTo_(End thisEnd, PolyLine& that, End end);
};

//forward declaration
template<bool orientT>
class PolyLinePolygonData;

/**
 * @brief ActiveTail represents an edge of an incomplete polygon.
 *
 * An ActiveTail object is the active tail end of a polyline object, which may (should) be the attached to
 * a chain of polyline objects through a pointer.  The ActiveTail class provides an abstraction between
 * and algorithm that builds polygons and the PolyLine data representation of incomplete polygons that are
 * being built.  It does this by providing an iterface to access the information about the last edge at the
 * tail of the PolyLine it is associated with.  To a polygon constructing algorithm, an ActiveTail is a floating
 * edge of an incomplete polygon and has an orientation and coordinate value, as well as knowing which side of
 * that edge is supposed to be solid or space.  Any incomplete polygon will have two active tails.  Active tails
 * may be joined together to merge two incomplete polygons into a larger incomplete polygon.  If two active tails
 * that are to be merged are the oppositve ends of the same incomplete polygon that indicates that the polygon
 * has been closed and is complete.  The active tail keeps a pointer to the other active tail of its incomplete 
 * polygon so that it is easy to check this condition.  These pointers are updated when active tails are joined.
 * The active tail also keeps a list of pointers to active tail objects that serve as handles to closed holes.  In
 * this way a hole can be associated to another incomplete polygon, which will eventually be its enclosing shell,
 * or reassociate the hole to another incomplete polygon in the case that it become a hole itself.  Alternately,
 * the active tail may add a filiment to stitch a hole into a shell and "fracture" the hole out of the interior
 * of a polygon.  The active tail maintains a static output buffer to temporarily write polygon data to when
 * it outputs a figure so that outputting a polygon does not require the allocation of a temporary buffer.  This
 * static buffer should be destroyed whenever the program determines that it won't need it anymore and would prefer to
 * release the memory it has allocated back to the system.
 */
class ActiveTail {
private:
  //data
  PolyLine* tailp_; 
  ActiveTail *otherTailp_;
  std::list<ActiveTail*> holesList_;
public:

  /**
   * @brief iterator over coordinates of the figure
   */
  class iterator {
  private:
     const PolyLine* pLine_;
     const PolyLine* pLineEnd_;
     unsigned int index_;
     unsigned int indexEnd_;
     End startEnd_;
  public:
     inline iterator() : pLine_(0), index_(0) {}
     inline iterator(const ActiveTail* at, bool isHole, Orientation2D orient) {
        //if it is a hole and orientation is vertical or it is not a hole and orientation is horizontal
        //we want to use this active tail, otherwise we want to use the other active tail
        startEnd_ = TAIL;
        if(!isHole ^ (orient == HORIZONTAL)) {
           //switch winding direction
           at = at->getOtherActiveTail();
        }
        //now we have the right winding direction
        //if it is horizontal we need to skip the first element
        pLine_ = at->getTail();
        index_ = at->getTail()->numSegments() - 1;
        if(at->getOrient() == HORIZONTAL ^ (orient == HORIZONTAL)) {
           pLineEnd_ = at->getTail();
           indexEnd_ = pLineEnd_->numSegments() - 1;
           if(index_ == 0) {
              pLine_ = at->getTail()->next(HEAD);
              if(at->getTail()->endConnectivity(HEAD) == TAIL) {
                 index_ = pLine_->numSegments() -1;
              } else {
                 startEnd_ = HEAD;
                 index_ = 0;
              }
           } else { --index_; }
        } else {
           pLineEnd_ = at->getOtherActiveTail()->getTail();
           indexEnd_ = pLineEnd_->numSegments() - 1;
        }
        at->getTail()->joinTailToTail(*(at->getOtherActiveTail()->getTail()));
     }
     //use bitwise copy and assign provided by the compiler
     inline iterator& operator++() {
        if(pLine_ == pLineEnd_ && index_ == indexEnd_) {
           pLine_ = 0;
           index_ = 0;
           return *this;
        }
        if(startEnd_ == HEAD) {
           ++index_;
           if(index_ == pLine_->numSegments()) {
              End end = pLine_->endConnectivity(TAIL);
              pLine_ = pLine_->next(TAIL);
              if(end == TAIL) {
                 startEnd_ = TAIL;
                 index_ = pLine_->numSegments() -1;
              } else {
                 index_ = 0;
              }
           }
        } else {
           if(index_ == 0) {
              End end = pLine_->endConnectivity(HEAD);
              pLine_ = pLine_->next(HEAD);
              if(end == TAIL) {
                 index_ = pLine_->numSegments() -1;
              } else {
                 startEnd_ = HEAD;
                 index_ = 0;
              }
           } else {
              --index_;
           }
        }
        return *this;
     }
     inline iterator operator++(int) {
        iterator tmp(*this);
        ++(*this);
        return tmp;
     }
     inline bool operator==(const iterator& that) const {
        return pLine_ == that.pLine_ && index_ == that.index_;
     }
     inline bool operator!=(const iterator& that) const {
        return pLine_ != that.pLine_ || index_ != that.index_;
     }
     inline Unit operator*() { return (*pLine_)[index_]; }
  };

  /**
   * @brief iterator over holes contained within the figure
   */
  typedef std::list<ActiveTail*>::const_iterator iteratorHoles;

  //default constructor
  ActiveTail();

  //constructor
  ActiveTail(Orientation2D orient, Unit coord, Side solidToRight, ActiveTail* otherTailp);

  //constructor
  ActiveTail(PolyLine* active, ActiveTail* otherTailp);

  //copy constructor
  ActiveTail(const ActiveTail& that);

  //destructor
  ~ActiveTail();

  //assignment operator
  ActiveTail& operator=(const ActiveTail& that);

  //equivilence operator
  bool operator==(const ActiveTail& b) const;

  /**
   * @brief comparison operators, ActiveTail objects are sortable by geometry
   */
  bool operator<(const ActiveTail& b) const;
  bool operator<=(const ActiveTail& b) const;
  bool operator>(const ActiveTail& b) const;
  bool operator>=(const ActiveTail& b) const;

  /**
   * @brief get the pointer to the polyline that this is an active tail of
   */
  PolyLine* getTail() const;

  /**
   * @brief get the pointer to the polyline at the other end of the chain
   */
  PolyLine* getOtherTail() const;

  /**
   * @brief get the pointer to the activetail at the other end of the chain
   */
  ActiveTail* getOtherActiveTail() const;

  /**
   * @brief test if another active tail is the other end of the chain
   */
  bool isOtherTail(const ActiveTail& b);

  /**
   * @brief update this end of chain pointer to new polyline
   */
  ActiveTail& updateTail(PolyLine* newTail);

  /**
   * @brief associate a hole to this active tail by the specified policy
   */
  ActiveTail* addHole(ActiveTail* hole, bool fractureHoles);

  /**
   * @brief get the list of holes
   */
  const std::list<ActiveTail*>& getHoles() const;

  /**
   * @brief copy holes from that to this
   */
  void copyHoles(ActiveTail& that);

  /**
   * @brief find out if solid to right
   */
  bool solidToRight() const;

  /**
   * @brief get coordinate (getCoord and getCoordinate are aliases for eachother)
   */
  Unit getCoord() const;
  Unit getCoordinate() const;

  /**
   * @brief get the tail orientation
   */
  Orientation2D getOrient() const;

  /**
   * @brief add a coordinate to the polygon at this active tail end, properly handle degenerate edges by removing redundant coordinate
   */
  void pushCoordinate(Unit coord);

  /**
   * @brief write the figure that this active tail points to out to the temp buffer
   */
  void writeOutFigure(UnitVector& outVec, bool isHole = false) const;

  /**
   * @brief write the figure that this active tail points to out through iterators
   */
  void writeOutFigureItrs(iterator& beginOut, iterator& endOut, bool isHole = false, Orientation2D orient = VERTICAL) const;
  iterator begin(bool isHole, Orientation2D orient) const;
  iterator end() const;

  /**
   * @brief write the holes that this active tail points to out through iterators
   */
  void writeOutFigureHoleItrs(iteratorHoles& beginOut, iteratorHoles& endOut) const;
  iteratorHoles beginHoles() const;
  iteratorHoles endHoles() const;

  /**
   * @brief joins the two chains that the two active tail tails are ends of
   * checks for closure of figure and writes out polygons appropriately
   * returns a handle to a hole if one is closed
   */
  static ActiveTail* joinChains(ActiveTail* at1, ActiveTail* at2, bool solid, UnitVector& outBufferTmp);
  template <bool orientT>
  static ActiveTail* joinChains(ActiveTail* at1, ActiveTail* at2, bool solid, typename std::vector<PolyLinePolygonData<orientT> >& outBufferTmp);

  /**
   * @brief deallocate temp buffer
   */
  static void destroyOutBuffer();

  /**
   * @brief deallocate all polygon data this active tail points to (deep delete, call only from one of a pair of active tails)
   */
  void destroyContents();
};

/** @brief allocate a polyline object */
PolyLine* createPolyLine(Orientation2D orient, Unit coord, Side side);

/** @brief deallocate a polyline object */
void destroyPolyLine(PolyLine* pLine);

/** @brief allocate an activetail object */
ActiveTail* createActiveTail();

/** @brief deallocate an activetail object */
void destroyActiveTail(ActiveTail* aTail);
     

template<bool orientT>
class PolyLineHoleData {
private:
   ActiveTail* p_;
public:
   typedef ActiveTail::iterator iterator;
   inline PolyLineHoleData() : p_(0) {}
   inline PolyLineHoleData(ActiveTail* p) : p_(p) {}
   //use default copy and assign
   inline iterator begin() const { return p_->begin(true, predicated_value(orientT, VERTICAL, HORIZONTAL)); }
   inline iterator end() const { return p_->end(); }
   inline unsigned int size() const { return 0; }
   template<class iT>
   inline PolyLineHoleData& set(iT inputBegin, iT inputEnd) {
      return *this;
   }
   
};

template<bool orientT>
class PolyLinePolygonData {
private:
   ActiveTail* p_;
public:
   typedef ActiveTail::iterator iterator;
   typedef PolyLineHoleData<orientT> holeType;
   class iteratorHoles {
   private:
      ActiveTail::iteratorHoles itr_;
   public:
      inline iteratorHoles() {}
      inline iteratorHoles(ActiveTail::iteratorHoles itr) : itr_(itr) {}
      //use bitwise copy and assign provided by the compiler
      inline iteratorHoles& operator++() {
         ++itr_;
         return *this;
      }
      inline iteratorHoles operator++(int) {
         iterator tmp(*this);
         ++(*this);
         return tmp;
      }
      inline bool operator==(const iteratorHoles& that) const {
         return itr_ == that.itr_;
      }
      inline bool operator!=(const iteratorHoles& that) const {
         return itr_ != that.itr_;
      }
      inline PolyLineHoleData<orientT> operator*() { return PolyLineHoleData<orientT>(*itr_);}
   };
   
   inline PolyLinePolygonData() : p_(0) {}
   inline PolyLinePolygonData(ActiveTail* p) : p_(p) {}
   //use default copy and assign
   inline iterator begin() const { return p_->begin(false, predicated_value(orientT, VERTICAL, HORIZONTAL)); }
   inline iterator end() const { return p_->end(); }
   inline iteratorHoles beginHoles() const { return iteratorHoles(p_->beginHoles()); }
   inline iteratorHoles endHoles() const { return iteratorHoles(p_->endHoles()); }
   inline ActiveTail* yield() { return p_; }
   //stub out these four required functions that will not be used but are needed for the interface
   inline unsigned int sizeHoles() const { return 0; }
   inline unsigned int size() const { return 0; }
   template<class iT>
   inline PolyLinePolygonData& set(iT inputBegin, iT inputEnd) {
      return *this;
   }
   
   /// initialize a polygon from x,y values, it is assumed that the first is an x
   /// and that the input is a well behaved polygon
   template<class iT>
   inline PolyLinePolygonData& setHoles(iT inputBegin, iT inputEnd) {
      return *this;
   }
};


/**
 * @brief ScanLine does all the work of stitching together polygons from incoming vertical edges
 */
template <bool orientT>
class ScanLineToPolygonItrs {
private:
   /** @brief a map of horizontal edges of incomplete polygons by their y value coordinate */
   std::map<Unit, ActiveTail*> tailMap_;
   std::vector<PolyLinePolygonData<orientT> > outputPolygons_;
   bool fractureHoles_;
public:
   typedef typename std::vector<PolyLinePolygonData<orientT> >::iterator iterator; 
   inline ScanLineToPolygonItrs() {}
   /** @brief construct a scanline with the proper offsets, protocol and options */
   inline ScanLineToPolygonItrs(bool fractureHoles) : fractureHoles_(fractureHoles) {}
   
   ~ScanLineToPolygonItrs() { clearOutput_(); }
   
   /** @brief process all vertical edges, left and right, at a unique x coordinate, edges must be sorted low to high */
   void processEdges(iterator& beginOutput, iterator& endOutput, 
                     Unit currentX, std::vector<Interval>& leftEdges, 
                     std::vector<Interval>& rightEdges);
   
private:
   void clearOutput_();
};

/**
 * @brief ScanLine does all the work of stitching together polygons from incoming vertical edges
 */
class ScanLineToPolygons {
private:
   ScanLineToPolygonItrs<true> scanline_;
public:
   inline ScanLineToPolygons() : scanline_() {}
   /** @brief construct a scanline with the proper offsets, protocol and options */
   inline ScanLineToPolygons(bool fractureHoles) : scanline_(fractureHoles) {}
   
   /** @brief process all vertical edges, left and right, at a unique x coordinate, edges must be sorted low to high */
   inline void processEdges(UnitVector& outBufferTmp, Unit currentX, std::vector<Interval>& leftEdges, 
                            std::vector<Interval>& rightEdges) {
      ScanLineToPolygonItrs<true>::iterator itr, endItr;
      scanline_.processEdges(itr, endItr, currentX, leftEdges, rightEdges);
      //copy data into outBufferTmp
      while(itr != endItr) {
         PolyLinePolygonData<true>::iterator pditr;
         outBufferTmp.push_back(0);
         unsigned int sizeIndex = outBufferTmp.size() - 1;
         int count = 0;
         for(pditr = (*itr).begin(); pditr != (*itr).end(); ++pditr) {
            outBufferTmp.push_back(*pditr);
            ++count;
         }
         outBufferTmp[sizeIndex] = count;
         PolyLinePolygonData<true>::iteratorHoles pdHoleItr;
         for(pdHoleItr = (*itr).beginHoles(); pdHoleItr != (*itr).endHoles(); ++pdHoleItr) {
            outBufferTmp.push_back(0);
            unsigned int sizeIndex2 = outBufferTmp.size() - 1;
            int count2 = 0;
            for(pditr = (*pdHoleItr).begin(); pditr != (*pdHoleItr).end(); ++pditr) {
               outBufferTmp.push_back(*pditr);
               ++count2;
            }
            outBufferTmp[sizeIndex2] = -count;
         }
         ++itr;
      }
   }
};

