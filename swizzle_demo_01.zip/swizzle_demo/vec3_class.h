#ifndef VEC3_CLASS_H
#define VEC3_CLASS_H

#include "vec2_class.h"
#include "boost/static_assert.hpp"
#include "boost/type_traits.hpp"

namespace blas
{

template <typename X, typename Y = X, typename Z = Y>
struct vec3
{
	typedef vec3 &reference;
	typedef vec3 const &const_reference;
	typedef X x_type;
	typedef Y y_type;
	typedef Z z_type;

	x_type x;
	y_type y;
	z_type z;

	vec3() { }
	vec3(x_type vx, y_type vy, z_type vz) : x(vx), y(vy), z(vz) { }

	template <typename T>
	vec3(T d) : x(d), y(d), z(d) { }

	template <typename VX, typename VY, typename VZ>
	vec3(const vec3<VX, VY, VZ> &v) : x(v.x), y(v.y), z(v.z) { }

	template <typename VX, typename VY, typename VZ>
	reference operator=(const vec3<VX, VY, VZ> &v)
	{
		x = v.x;
		y = v.y;
		z = v.z;
		return *this;
	}

	typename boost::remove_reference<X>::type &operator[](size_t idx)
	{
		assert(idx < 3);
		return array()[idx];
	}

	BLAS_DECLARE_SWIZZLE(BLAS_VEC3D_SEQ)

	// array will only be enabled if x_type == y_type == z_type
	typename boost::remove_reference<X>::type *array(void)
	{
		BOOST_STATIC_ASSERT((boost::is_reference<X>::value == false));
		BOOST_STATIC_ASSERT((boost::is_reference<Y>::value == false));
		BOOST_STATIC_ASSERT((boost::is_reference<Z>::value == false));
		BOOST_STATIC_ASSERT((boost::is_same<X, Y>::value));
		BOOST_STATIC_ASSERT((boost::is_same<Y, Z>::value));
		return static_cast<X *>(&x);
	}
	typename boost::remove_reference<X>::type const *array(void) const
	{
		return const_cast<vec3 *>(this)->array();
	}
};

template <typename X, typename Y, typename Z>
inline std::ostream &operator<<(std::ostream &os, const vec3<X, Y, Z> &v)
{
	os << "[" << v.x << ", " << v.y << ", " << v.z << "]";
	return os;
}

typedef vec3<float> vec3f;
typedef vec3<double> vec3d;
typedef vec3f float3;
typedef vec3d double3;

BOOST_STATIC_ASSERT(sizeof(float3) == sizeof(float) * 3);
BOOST_STATIC_ASSERT(sizeof(double3) == sizeof(double) * 3);

}

#endif
