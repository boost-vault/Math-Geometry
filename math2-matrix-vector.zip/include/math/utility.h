#ifndef MATH2_UTILITY_H
#define MATH2_UTILITY_H

namespace math {

inline float sqr(float a) { return a*a; }

} // namespace math

#endif
