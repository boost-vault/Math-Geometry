/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
template<class T, class T2>
class lessInterval
  : public std::binary_function<const IntervalImpl<T>&, const IntervalImpl<T2>&, bool>
{
private:
  Direction1D dir_; // we want to compare along this orientation
public:
  inline lessInterval(Direction1D dir = HIGH) : dir_(dir) {;}
  inline bool operator () (const IntervalImpl<T>& a,
                           const IntervalImpl<T2>& b) const ;
};
  
template <class T, class T2>
inline bool 
lessInterval<T, T2>::operator () (const IntervalImpl<T>& a,
                                  const IntervalImpl<T2>& b) const {
  return predicated_value(dir_.toInt(),
                          (a.low() < b.low()) | ((a.low() == b.low()) & 
                                                 (a.high() < b.high())),
                          (a.high() > b.high()) | ((a.high() == b.high()) & 
                                                   (a.low() > b.low())));
}
  
template <class T> template <class T2>
inline bool 
IntervalImpl<T>::operator<(const IntervalImpl<T2>& b) const { 
  return lessInterval<T, T2>()(*this,b); }

template <class T>
inline IntervalImpl<T>::IntervalImpl(Unit low, Unit high) {
  *this = construct_(min(low, high), max(low, high));
}
  
template <class T>
inline IntervalImpl<T>::IntervalImpl(Unit x) {
  *this = construct_(x, x);
}
  
template <class T>
inline IntervalImpl<T>::IntervalImpl() {
  *this = construct_(UnitMin, 
                     UnitMin);
}
  
template <class T>
inline const IntervalImpl<T>& 
IntervalImpl<T>::operator=(const IntervalImpl<T>& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template <class T>
inline const IntervalImpl<T>& 
IntervalImpl<T>::operator=(const T& that) {
  static_cast<T&>(*this) = that;
  return *this;
}

template <class T> template<class T2>
inline bool 
IntervalImpl<T>::operator==(const IntervalImpl<T2>& b) const {
  return (low() == b.low()) & (high() == b.high());
}

template <class T> template<class T2>
inline bool 
IntervalImpl<T>::operator!=(const IntervalImpl<T2>& b) const {
  //apply Demorgans theorem in case compiler doesn't know how
  return (low() != b.low()) | (high() != b.high());
}

template <class T>
inline UnsignedUnit 
IntervalImpl<T>::delta() const {
  LongUnit highVal = high();
  return highVal - low();
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::flip(Unit axis) {
  Unit newLow  = axis - high();
  Unit newHigh = axis - low();
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::scale(double factor) {
  Unit newHigh = (Unit)(high() * factor);
  low((Unit)(low()*factor));
  high((Unit)(newHigh));
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::move(Unit delta) {
  Unit len = high() - low();
  low(low() + delta);
  high(low() + len);
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::convolve(Unit b) {
  Unit newLow  = low() + b;
  Unit newHigh = high() + b;
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::deconvolve(Unit b) {
  Unit newLow  = low()  - b;
  Unit newHigh = high() - b;
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T> template<class T2>
inline IntervalImpl<T>& 
IntervalImpl<T>::convolve(const IntervalImpl<T2>& b) {
  Unit newLow  = low()  + b.low();
  Unit newHigh = high() + b.high();
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T> template<class T2>
inline IntervalImpl<T>& 
IntervalImpl<T>::deconvolve(const IntervalImpl<T2>& b) {
  Unit newLow  = low()  - b.low();
  Unit newHigh = high() - b.high();
  sort2(newLow, newHigh);
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T> template<class T2>
inline IntervalImpl<T>& 
IntervalImpl<T>::reflectedConvolve(const IntervalImpl<T2>& b) {
  Unit newLow  = low()  - b.high();
  Unit newHigh = high() - b.low();
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T> template<class T2>
inline IntervalImpl<T>& 
IntervalImpl<T>::reflectedDeconvolve(const IntervalImpl<T2>& b) {
  Unit newLow  = low()  + b.high();
  Unit newHigh = high() + b.low();
  sort2(newLow, newHigh);
  low(newLow);
  high(newHigh);
  return *this;
}

template <class T>
inline Unit 
IntervalImpl<T>::distance(Unit position) const {
  Unit dist[3] = {0, low() - position, position - high()};
  return dist[ (dist[1] > 0) + ((dist[2] > 0) << 1) ];
}

template <class T> template <class T2>
inline Unit 
IntervalImpl<T>::distance(const IntervalImpl<T2>& b) const {
  Unit dist[3] = {0, low() - b.high(), b.low() - high()};
  return dist[ (dist[1] > 0) + ((dist[2] > 0) << 1) ];
}

/// contains returns true if b is inside this interval.
/// if considerTouch is true contains return true even if b touches the 
/// boundary of this interval and is not strictly contained
template <class T> template<class T2>
inline bool 
IntervalImpl<T>::contains(const IntervalImpl<T2>& b, 
                          bool considerTouch) const {
  return predicated_value(considerTouch, 
                          (low() <= b.low()) & (high() >= b.high()),
                          (low() < b.low()) & (high() > b.high()));
}

/// contains returns true if value is inside 'this' Interval
/// if considerTouch is true contains returns true if value is equal to
/// one of the end coordinates of 'this' Interval (open/closed semantic.)
template <class T>
inline bool 
IntervalImpl<T>::contains(Unit value, bool considerTouch) const {
  return predicated_value(considerTouch, 
                          (value >= low()) & (value <= high()),
                          (value > low()) & (value < high()));
}

/// inside is the dual of contains
/// if considerTouch is true inside returns true even if 'this' touches b 
template <class T> template<class T2>
inline bool 
IntervalImpl<T>::inside(const IntervalImpl<T2>& b, bool considerTouch) const {
  return b.contains(*this, considerTouch);
}

/// check if Interval b intersects `this` Interval
/// if considerTouch is true intersects returns true even if
/// the two intervals have only one coordinate value in common
template <class T> template<class T2>
inline bool 
IntervalImpl<T>::intersects(const IntervalImpl<T2>& b, 
                            bool considerTouch) const {
  return predicated_value(considerTouch, 
                          (low() <= b.high()) & (high() >= b.low()),
                          (low() < b.high()) & (high() > b.low()));
}

/// check if Interval b partially overlaps `this` Interval
/// if considerTouch is true a single coordinate value in common
/// is considered to be overlap
template <class T> template<class T2>
inline bool 
IntervalImpl<T>::boundariesIntersect(const IntervalImpl<T2>& b, 
                                     bool considerTouch) const {
  return (contains(b.low(), considerTouch) | 
          contains(b.high(), considerTouch)) &
    (b.contains(low(), considerTouch) | 
     b.contains(high(), considerTouch));
}
    
/// check if they are end to end and that b is on the end of 'this' interval
/// specified by the value of dir
template <class T> template<class T2>
inline bool 
IntervalImpl<T>::abuts(const IntervalImpl<T2>& b, Direction1D dir) const {
  return predicated_value(dir.toInt(),
                          b.low() == high(),
                          low() == b.high());
}

template <class T> template<class T2>
inline bool 
IntervalImpl<T>::abuts(const IntervalImpl<T2>& b) const {
  return abuts(b, HIGH) | abuts(b, LOW);
} 

/// set 'this' interval to the intersection of 'this' and b
/// if no intersection leave the value of 'this' unchanged
/// if considerTouch is true a single coordinate in common will be 
/// considerd to be intersection
template <class T> template<class T2>
inline bool 
IntervalImpl<T>::intersect(const IntervalImpl<T2>& b, bool considerTouch) {
  Unit lowVal = max(low(), b.low());
  Unit highVal = min(high(), b.high());
  bool valid = predicated_value(considerTouch,
                                lowVal <= highVal,
                                lowVal < highVal);
  low(predicated_value(valid, lowVal, low()));
  high(predicated_value(valid, highVal, high()));
  return valid;
}

/// set `this` Interval to the intersection between b1 and b2
/// if considerTouch is true, create intersection even if b1 touches b2
/// if no intersection between b1 and b2 set this to b1
template <class T> template<class T2, class T3>
inline bool 
IntervalImpl<T>::intersection(const IntervalImpl<T2>& b1, 
                              const IntervalImpl<T3>& b2,
                              bool considerTouch) {
  *this = b1;
  return intersect(b2, considerTouch);
}

template <class T> template<class T2>
inline IntervalImpl<T>&
IntervalImpl<T>::generalizedIntersect(const IntervalImpl<T2>& b) {
  Unit l1 = low();
  Unit h1 = high();
  Unit l2 = b.low();
  Unit h2 = b.high();
  sort4(l1,h1,l2,h2);
  low(h1);
  high(l2);
  return *this;
}

template <class T> template<class T2, class T3>
inline IntervalImpl<T>&
IntervalImpl<T>::generalizedIntersection(const IntervalImpl<T2>& b1, 
                                         const IntervalImpl<T3>& b2) {
  *this = b1;
  return generalizedIntersect(b2);
}

/// bloat the Interval
/// extends both ends of the interval by unisigned bloating value
template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::bloat(UnsignedUnit bloating) {
  low(low()-bloating);
  high(high()+bloating);
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::bloat(Direction1D dir, UnsignedUnit bloating) {
  set(dir, get(dir) + dir.getSign() * bloating);
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::shrink(UnsignedUnit shrinking) {
  Unit offset = min(shrinking, delta()/2);
  low(low()+offset);
  high(high()-offset);
  return *this;
}

template <class T>
inline IntervalImpl<T>& 
IntervalImpl<T>::shrink(Direction1D dir, UnsignedUnit shrinking) {
  Unit offset = min(shrinking, delta());
  set(dir, get(dir) - dir.getSign() * offset);
  return *this;
}

template <class T> template<class T2>
inline bool 
IntervalImpl<T>::encompass(const IntervalImpl<T2>& b) {
  bool retval = !contains(b, true);
  low(min(low(), b.low()));
  high(max(high(), b.high()));
  return retval;
}    

template <class T>
inline IntervalImpl<T>
IntervalImpl<T>::getHalf(Direction1D d1d) const
{
  Unit c = (get(LOW) + get(HIGH)) / 2;
  return IntervalImpl<T>(predicated_value((d1d == LOW), get(LOW), c),
                         predicated_value((d1d == LOW), c, get(HIGH)));
}

template <class T> template<class T2, class T3>
inline bool
IntervalImpl<T>::joinWith(IntervalImpl<T2> & newInterval, const IntervalImpl<T3> & i2) const
{
  if (high() == i2.low()) {
    newInterval = IntervalImpl<T>(low(), i2.high());
    return true;
  }
  if (i2.high() == low()) {
    newInterval = IntervalImpl<T>(i2.low(), high());
    return true;
  }
  return false;
}

//private functions
template <class T>
inline T 
IntervalImpl<T>::construct_(Unit low, Unit high) {
  return IntervalInterface<T>::IntervalConstruct(low, high);
}


template <class T>
std::ostream& operator << (std::ostream& o, const IntervalImpl<T>& i)
{
  return o << i.low() << GTL_SEP << i.high();
}

template <class T>
std::istream& operator >> (std::istream& i, IntervalImpl<T>& il)
{
  Unit l, h;
  i >> l >> h;
  il.low(l);
  il.high(h);
  return i;
}

