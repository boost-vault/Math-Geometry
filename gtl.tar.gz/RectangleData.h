/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// RectangleData is the default in memory representation of a rectangle

/// RectangleData has a c-style array of intervals indexed by the value
/// of an Orientation2D object.
/// This implementation was chosen for performance reasons because
/// the in memory representation is accessed directly by the value of
/// the orientation argument instead of using an if statement or 
/// branch free primitive such as predicated_value and predicated_assign.
/// Because the represenation chosen for the intervals is IntervalData
/// a rectangle is stored as a 2x2 array in memory, indexed first by
/// orientation to get an interval and then by direction through the interval
/// API to get a coordiante.

class RectangleData {
public:
  /// default constructor does not initialize
  inline RectangleData() {;} //do nothing default constructor

  /// construct a rectangle from horizontal range and vertical range
  inline RectangleData(const IntervalData& hrange,
                       const IntervalData& vrange) {
    ranges_[HORIZONTAL] = hrange;
    ranges_[VERTICAL] = vrange;
  }

   inline RectangleData(const RectangleData& that) {
      (*this) = that;
   }

  inline RectangleData& operator=(const RectangleData& that) {
     ranges_[0] = that.ranges_[0];
     ranges_[1] = that.ranges_[1];
     return *this;
  }

  /// get horizontal or vertical range depending on orient
  inline IntervalData get(Orientation2D orient) const {
    return ranges_[orient.toInt()];
  }
  /// set horizontal or vertical range depending on orient
  inline void set(Orientation2D orient, const IntervalData& value) {
    ranges_[orient.toInt()] = value;
  }

  IntervalData ranges_[2]; //to be indexed by orientation2d value
};

