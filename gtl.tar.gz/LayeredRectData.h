/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// LayeredRectData is the in memory representation of a layered rectangle

/// LayeredRectData has a rectangle and a layer coordinate.
/// Access to the rectangle happens by value.
class LayeredRectData {
public:
  /// default constructor does not initialize
  inline LayeredRectData(){;} //do nothing default constructor

  /// construct a layered rectangle from a rectangle and a layer
  inline LayeredRectData(const RectangleData& rect, Unit layer) : 
    rect_(rect), layer_(layer) {;}

  inline LayeredRectData(const LayeredRectData& that) {
     (*this) = that;
  }

  inline LayeredRectData& operator=(const LayeredRectData& that) {
     rect_ = that.rect_;
     layer_ = that.layer_;
     return *this;
  } 

  /// get the rectangle stored in the layered rectangle
  inline IntervalData get(Orientation2D orient) const {
    return rect_.get(orient);
  }

  /// set the rectangle stored in the layered rectangle
  inline void set(Orientation2D orient, const IntervalData& value) {
    rect_.set(orient, value);
  }

  /// get the layer of the layered rectangle
  inline Unit getLayer() const {
    return layer_;
  }

  /// set the layer of the layered rectangle
  inline void setLayer(const Unit& value) {
    layer_ = value;
  }

private:
  RectangleData rect_;
  Unit layer_;
};
