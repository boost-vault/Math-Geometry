#ifndef BOOST_GEOM_DETAIL_META_IF
#define BOOST_GEOM_DETAIL_META_IF

// Boost.Geom
// 
// Copyright (c) Anis Benyelloul 2005-2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

namespace boost { namespace geom {
	namespace detail {

		// Meta function that returns type1 if test is true otherwise
		// it returns type2
		//
		// Rational: Do not depend on some other implementation of it,
		// keep the library self contained.
		template<bool test, typename type1, typename type2>
			struct meta_if { typedef type1 type; };

		template<typename type1, typename type2>
			struct meta_if<false, type1, type2> { typedef type2 type; };

	} // namespace detail

} } // namespace boost::geom

#endif  // BOOST_GEOM_DETAIL_META_IF
