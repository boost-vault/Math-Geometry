#include "vec2_class.h"
#include "vec3_class.h"
#include "vec4_class.h"

#include <iostream>
#include <ostream>

int main()
{
	using namespace blas;

	float4 b(1, 2, 3, 4);
	float4 c(5, 6, 7, 8);

	float4 a = b.xxxx();
	std::cout << a << std::endl;

	a = b.wwwz();
	std::cout << a << std::endl;

	a = b.yzzw();
	std::cout << a << std::endl;

	a = b.wzyx();
	std::cout << a << std::endl;

	float4 d(10, 20, 30, 40);
	d.yz() = b.zy();
	std::cout << d << std::endl;

	float3 e = b.wzy();
	std::cout << e << std::endl;
}
