/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// default constructor
inline PolygonSet::PolygonSet(){}

/// default constructor
inline PolygonSet::PolygonSet(Orientation2D orient) : orient_(orient) {}

/// constructor from an iterator pair over polygons
template <class T>
inline PolygonSet::PolygonSet(Orientation2D orient, 
                              T inputBegin, T inputEnd) : orient_(orient) {
   insert(inputBegin, inputEnd);
}

/// constructor from a Rectangle
template <class T>
inline PolygonSet::PolygonSet(Orientation2D orient, const RectangleImpl<T>& rect) : orient_(orient) {
   insert(rect);
   dirty_ = false;
   unsorted_ = true;
}

/// constructor from a Polygon
template <class T>
inline PolygonSet::PolygonSet(Orientation2D orient, const PolygonImpl<T>& polygon) : orient_(orient) {
   insert(polygon);
   dirty_ = true;
   unsorted_ = true;
}

/// constructor from a PolygonWithHoles
template <class T>
inline PolygonSet::PolygonSet(Orientation2D orient, 
                              const PolygonWithHolesImpl<T>& polyWithHoles) : orient_(orient) {
   insert(polyWithHoles);
   dirty_ = true;
   unsorted_ = true;
}

/// copy constructor
inline PolygonSet::PolygonSet(const PolygonSet& that) : 
   orient_(that.orient_), data_(that.data_), dirty_(that.dirty_), unsorted_(that.unsorted_) {}

/// copy with orientation change
inline PolygonSet::PolygonSet(Orientation2D orient, const PolygonSet& that) {
   if(orient == that.orient_) {
      (*this) = that;
   } else {
      std::vector<Rectangle> rects;
      that.getRectangles(rects);
      orient_ = orient;
      std::vector<Rectangle>::iterator itr;
      for(itr = rects.begin(); itr != rects.end(); ++itr) {
         insert(*itr);
      }
      dirty_ = true;
      unsorted_ = true;
   }
}

/// destructor
inline PolygonSet::~PolygonSet() {}

/// assignement operator
inline PolygonSet& PolygonSet::operator=(const PolygonSet& that){
   if(this == &that) return *this;
   orient_ = that.orient_;
   data_ = that.data_;
   dirty_ = that.dirty_;
   unsorted_ = that.unsorted_;
   return *this;
}

/// equivilence operator
inline bool PolygonSet::operator== (const PolygonSet& p) const {
  clean_();
  p.clean_();
  return data_ == p.data_;
}

/// inequivilence operator
inline bool PolygonSet::operator!= (const PolygonSet& p) const {
  return !(p == (*this));
}

inline bool PolygonSet::operator<(const PolygonSet& b) const {
  if(orient_.toInt() < b.orient_.toInt()) return true;
  if(orient_.toInt() > b.orient_.toInt()) return false;
  clean_();
  b.clean_();
  std::size_t minsize = min(data_.size(), b.data_.size());
  for(std::size_t i = 0; i < minsize; ++i) {
    if(data_[i].first < b.data_[i].first) return true;
    if(data_[i].first > b.data_[i].first) return false;
    if(data_[i].second < b.data_[i].second) return true;
    if(data_[i].second > b.data_[i].second) return false;
    if(data_[i].second.first < b.data_[i].second.first) return true;
    if(data_[i].second.first > b.data_[i].second.first) return false;
  }
  return data_.size() < b.data_.size();
}

/// append to the container cT 
template <class cT>
unsigned int PolygonSet::get(cT& container, bool fractureHoles) const {
   clean_();
   unsigned int countPolygons = 0;
   ScanLineToPolygonItrs<true> scanlineToPolygonItrsV(fractureHoles);
   ScanLineToPolygonItrs<false> scanlineToPolygonItrsH(fractureHoles);
   std::vector<Interval> leftEdges;
   std::vector<Interval> rightEdges;
   Unit prevPos = UnitMax;
   Unit prevY = UnitMax;
   int count = 0;
   for(PolygonVectorData::iterator itr = data_.begin();
       itr != data_.end(); ++ itr) {
      Unit pos = (*itr).first;
      if(pos != prevPos) {
         if(orient_ == VERTICAL) {
            ScanLineToPolygonItrs<true>::iterator itrPoly, itrPolyEnd;
            scanlineToPolygonItrsV.processEdges(itrPoly, itrPolyEnd, prevPos, leftEdges, rightEdges);
            for( ; itrPoly != itrPolyEnd; ++ itrPoly) {
               ++countPolygons;
               PolygonWithHolesImpl<PolyLinePolygonData<true> >& poly
                  = PolygonWithHolesImpl<PolyLinePolygonData<true> >::mimic(*itrPoly);
               container.insert(container.end(), poly);
            }
         } else {
            ScanLineToPolygonItrs<false>::iterator itrPoly, itrPolyEnd;
            scanlineToPolygonItrsH.processEdges(itrPoly, itrPolyEnd, prevPos, leftEdges, rightEdges);
            for( ; itrPoly != itrPolyEnd; ++ itrPoly) {
               ++countPolygons;
               PolygonWithHolesImpl<PolyLinePolygonData<false> >& poly
                  = PolygonWithHolesImpl<PolyLinePolygonData<false> >::mimic(*itrPoly);
               container.insert(container.end(), poly);
            }
         }
         leftEdges.clear();
         rightEdges.clear();
         prevPos = pos;
         prevY = (*itr).second.first;
         count = (*itr).second.second;
         continue;
      }
      Unit y = (*itr).second.first;
      if(count != 0 && y != prevY) {
         std::pair<Interval, int> element(Interval(prevY, y), count);
         if(element.second == 1) {
            if(leftEdges.size() && leftEdges.back().high() == element.first.low()) {
               leftEdges.back().encompass(element.first);
            } else {
               leftEdges.push_back(element.first);
            }
         } else {
            if(rightEdges.size() && rightEdges.back().high() == element.first.low()) {
               rightEdges.back().encompass(element.first);
            } else {
               rightEdges.push_back(element.first);
            }
         }

      }
      prevY = y;
      count += (*itr).second.second;
   }
   if(orient_ == VERTICAL) {
      ScanLineToPolygonItrs<true>::iterator itrPoly, itrPolyEnd;
      scanlineToPolygonItrsV.processEdges(itrPoly, itrPolyEnd, prevPos, leftEdges, rightEdges);
      for( ; itrPoly != itrPolyEnd; ++ itrPoly) {
         ++countPolygons;
         PolygonWithHolesImpl<PolyLinePolygonData<true> >& poly
            = PolygonWithHolesImpl<PolyLinePolygonData<true> >::mimic(*itrPoly);
         container.insert(container.end(), poly);
      }
   } else {
      ScanLineToPolygonItrs<false>::iterator itrPoly, itrPolyEnd;
      scanlineToPolygonItrsH.processEdges(itrPoly, itrPolyEnd, prevPos, leftEdges, rightEdges);
      for( ; itrPoly != itrPolyEnd; ++ itrPoly) {
         ++countPolygons;
         PolygonWithHolesImpl<PolyLinePolygonData<false> >& poly
            = PolygonWithHolesImpl<PolyLinePolygonData<false> >::mimic(*itrPoly);
         container.insert(container.end(), poly);
      }
   }
   return countPolygons;
}


/// append to the container cT with polygons (holes will be fractured along orientation)
template <class cT>
inline unsigned int PolygonSet::getPolygons(cT& container) const{
   return get(container, true);
}

/// append to the container cT with PolygonWithHoles objects
template <class cT>
inline unsigned int PolygonSet::getPolygonsWithHoles(cT& container) const{
   return get(container, false);
}

/// append to the container cT with rectangles sliced along orientation
template <class cT>
inline unsigned int PolygonSet::getRectangles(cT& container) const{
   clean_();
   unsigned int inputsize = container.size();
   Rectangle model;
   Unit prevPos = UnitMax;
   ScanLineToRects<cT, RectangleData> scanlineToRects(orient_, model);
   for(PolygonVectorData::iterator itr = data_.begin();
       itr != data_.end(); ++ itr) {
     Unit pos = (*itr).first;
     if(pos != prevPos) {
        scanlineToRects.nextMajorCoordinate(pos);
        prevPos = pos;
     }
     Unit lowy = (*itr).second.first;
     ++itr;
     Unit highy = (*itr).second.first;
     scanlineToRects.processEdge(container, Interval(lowy, highy));
     if(abs((*itr).second.second) > 1) --itr; //next edge begins from this vertex
   }
   return container.size() - inputsize;
}

/// append to the container cT with max cover rectangles
template <class cT>
inline unsigned int PolygonSet::getMaxRectangles(cT& container) const{
   unsigned int inputsize = container.size();
   std::vector<Rectangle> rects;
   getRectangles(rects);
   MaxCover::getMaxCover(container, rects, orient());
   return container.size() - inputsize;
}

template <class rT, class gT, class cT>
bool computeRectGraphCoverage(unsigned int i, rT& rects, gT& graph, cT& colors) {
  PolygonSet ps(VERTICAL, rects[i]);
  for(std::set<int>::iterator itr = graph[i].begin(); itr != graph[i].end(); ++itr) {
    if(colors[*itr] < 2)
      ps -= rects[*itr];
  }	
  return ps.empty();
}

template <class cT, class gT, class rT>
unsigned int computeExactMinCover(cT& minColors, cT& colors, gT& graph, rT& rects, 
                                  unsigned int pivot, unsigned int best, unsigned int current) {
  while(pivot < colors.size()) {
    if(colors[pivot] == 0) {
      ++pivot;
      continue;
    }
    unsigned int degrees = 0;
    for(unsigned int i = pivot; i < colors.size(); ++i) {
      degrees += (colors[i] == 1);
    } 
    if(current - degrees >= best) {
      //early termination
      return best;
    }
    //color should be == 1
    //check if color can be set to 2
    if(computeRectGraphCoverage(pivot, rects, graph, colors)) {
      //recurse into this element
      colors[pivot] = 2;
      --current;
      if(current < best) {
        best = current;
        minColors = colors;
      }
      best = computeExactMinCover(minColors, colors, graph, rects, 
                                  pivot + 1, best, current);
      //recurse out of this element
      colors[pivot] = 1;
      ++current;
    }
    ++pivot;
  }

  //DEBUG
  //for(unsigned int i = 0; i < colors.size(); ++i) {std::cout << colors[i];} 
  //std::cout << ": " << current << std::endl;

  return best;
}

template <class T>
class lessRectArea : public std::binary_function<const RectangleImpl<T>&, 
                                                 const RectangleImpl<T>&, bool> {
public:
  lessRectArea() {}
  bool operator () (const RectangleImpl<T>& rect1, const RectangleImpl<T>& rect2) const {
    return rect1.area() < rect2.area();
  }
};

template <class cT>
unsigned int PolygonSet::getMinRectangles(cT& minRects,
                                          bool heuristic) const {
  //get the MaxRects
  std::vector<Rectangle> maxRects;
  getMaxRectangles(maxRects);
  lessRectArea<RectangleData> comparator;
  std::sort(maxRects.begin(), maxRects.end(), comparator);
  std::vector<std::set<int> > graph(maxRects.size());

  //extract connectivity graph of max rects
  //TODO: implement improved connectivity graph API used here
  ConnectivityExtraction ce;
  for(unsigned int i = 0; i < maxRects.size(); ++i)
    ce.insert(maxRects[i]);
  ce.extract(graph);

  std::vector<int> colors(graph.size(), 0);
  for(unsigned int i = 0; i < maxRects.size(); ++i) {
    bool covered = computeRectGraphCoverage(i, maxRects, graph, colors);
    colors[i] = covered;
    if(heuristic && covered) colors[i] = 2;
  }
	
  if(heuristic) {
    unsigned int count = 0;
    for(unsigned int i = 0; i < colors.size(); ++i) {
      if(colors[i] < 2) minRects.push_back(maxRects[i]);
      ++count;
    }
    return count;
  }	
  std::vector<int> minColors = colors;
  unsigned int count = computeExactMinCover(minColors, colors, graph, maxRects, 
                                            0, colors.size(), colors.size());
  for(unsigned int i = 0; i < minColors.size(); ++i) {
    if(minColors[i] < 2) minRects.push_back(maxRects[i]);
  }
  return count;
}

inline PolygonSet::iterator PolygonSet::begin() const {
  clean_();
  return data_.begin();
}

inline PolygonSet::iterator PolygonSet::end() const {
  clean_();
  return data_.end();
}

/// insert polygons
template <class T>
inline PolygonSet& PolygonSet::insert(T inputBegin, T inputEnd){
   while(inputBegin != inputEnd){
      insert(*inputBegin);
      ++inputBegin;
   }
   return *this;
} 

/// insert holes
template <class T>
inline PolygonSet& PolygonSet::insertHoles(T inputBegin, T inputEnd){
   while(inputBegin != inputEnd){
      insertHole(*inputBegin);
      ++inputBegin;
   }
   return *this;
} 

/// insert polygon
template <class T>
inline PolygonSet& PolygonSet::insert(const PolygonImpl<T>& poly, bool isHole){
   Direction1D wdir = poly.winding();
   //if winding is clockwise the multiplier is 1, else -1
   int multiplier = wdir == LOW ? 1 : -1;
   if(orient_ == VERTICAL) multiplier *= -1;
   if(isHole) multiplier *= -1;
   typename PolygonImpl<T>::iterator itr = poly.begin();
   if(itr == poly.end()) return *this;
   Unit firstx = *itr;
   ++itr;
   if(itr == poly.end()) return *this;
   Unit firsty = *itr;
   Point firstPt(firstx, firsty);
   Point pt(firstPt);
   Orientation2D orient = HORIZONTAL;
   ++itr;
   for( ; itr != poly.end(); ++itr) {
      if(orient == orient_) {
         std::pair<Interval, int> element(Interval(pt.get(orient_), *itr),
                                          predicated_value(pt.get(orient_) < *itr,
                                                           -1, 1) * multiplier);
         insert(pt.get(orient.getPerpendicular()), element);
      }
      pt.set(orient, *itr);
      orient = orient.getPerpendicular();
   }
   if(orient_ == VERTICAL) {
      std::pair<Interval, int> element(Interval(pt.y(), firstPt.y()),
                                       predicated_value(pt.y() < firstPt.y(),
                                                        -1, 1) * multiplier);
      insert(firstPt.x(), element);
   } else {
      std::pair<Interval, int> element(Interval(pt.x(), firstPt.x()),
                                       predicated_value(pt.x() < firstPt.x(),
                                                        -1, 1) * multiplier);
      insert(pt.y(), element);
   }
   return *this;
}

/// insert hole
template <class T>
inline PolygonSet& PolygonSet::insertHole(const PolygonImpl<T>& hole){
   insert(hole, true);
   return *this;
} 

/// insert polygon with holes
template <class T>
inline PolygonSet& PolygonSet::insert(const PolygonWithHolesImpl<T>& polyWithHoles){
   insert(PolygonImpl<T>::mimicConst(polyWithHoles.yieldConst()));
   typename PolygonWithHolesImpl<T>::iteratorHoles holeItr;
   for(holeItr = polyWithHoles.beginHoles(); holeItr != polyWithHoles.endHoles(); ++holeItr) {
      insertHole(PolygonImpl<typename PolygonWithHolesImpl<T>::holeType>::mimicConst(*holeItr));
   }
   return *this;
}

/// insert Rectangle
template <class T>
inline PolygonSet& PolygonSet::insert(const RectangleImpl<T>& rect){
   Orientation2D porient = orient_.getPerpendicular();
   insert(rect.get(porient).low(), std::pair<Interval, int>(rect.get(orient_), 1));
   insert(rect.get(porient).high(), std::pair<Interval, int>(rect.get(orient_), -1));
   return *this;
}

/// insert Rectangle Hole
template <class T>
inline PolygonSet& PolygonSet::insertHole(const RectangleImpl<T>& rect){
   Orientation2D porient = orient_.getPerpendicular();
   insert(rect.get(porient).low(), std::pair<Interval, int>(rect.get(orient_), -1));
   insert(rect.get(porient).high(), std::pair<Interval, int>(rect.get(orient_), 1));
   dirty_ = true;
   return *this;
}
  
/// insert edge
inline PolygonSet& PolygonSet::insert(Unit coordinate, const std::pair<Interval, int>& edge) {
   std::pair<Unit, std::pair<Unit, int> > element;
   element.first = coordinate;
   element.second.first = edge.first.low();
   element.second.second = edge.second;
   data_.push_back(element);
   element.second.first = edge.first.high();
   element.second.second = edge.second * -1;
   data_.push_back(element);
   dirty_ = true;
   unsorted_ = true;
   return *this;
}

/// insert polygon set
inline PolygonSet& PolygonSet::insert(const PolygonSet& polygonSet) {
   if(orient_ != polygonSet.orient_) {
     data_.reserve(data_.size() + polygonSet.data_.size());
     for(PolygonVectorData::const_iterator itr = polygonSet.data_.begin();
         itr != polygonSet.data_.end(); ++itr) {
       data_.push_back(std::pair<Unit, std::pair<Unit, int> >((*itr).second.first,
                                                              std::pair<Unit, int>((*itr).first,
                                                                                   (*itr).second.second)));
     }
     dirty_ = true;
     unsorted_ = true;
     return *this;
   }
   if(empty()) return (*this) = polygonSet;
   data_.insert(data_.end(), polygonSet.data_.begin(), polygonSet.data_.end());
   dirty_ = true;
   unsorted_ = true;
   return *this;
}

/// get the external boundary rectangle
inline Rectangle PolygonSet::extents() const{
   if(empty()) {
      return Rectangle();
   }
   clean_();
   Unit low = UnitMax;
   Unit high = UnitMin;
   IntervalData xivl(low, high); 
   IntervalData yivl(low, high);
   for(PolygonVectorData::const_iterator itr = data_.begin();
       itr != data_.end(); ++ itr) {
      if((*itr).first > xivl.get(HIGH))
         xivl.set(HIGH, (*itr).first);
      if((*itr).first < xivl.get(LOW))
         xivl.set(LOW, (*itr).first);
      if((*itr).second.first > yivl.get(HIGH))
         yivl.set(HIGH, (*itr).second.first);
      if((*itr).second.first < yivl.get(LOW))
         yivl.set(LOW, (*itr).second.first);
   }
   Rectangle box(Interval::mimic(xivl), Interval::mimic(xivl));
   box.set(orient_, Interval::mimic(yivl));
   return box;
}

/// | & + * - ^ binary operators
inline PolygonSet PolygonSet::operator|(const PolygonSet& b) const{
   PolygonSet retVal(*this);
   retVal |= b;
//    if(orient_ != b.orient_) {
//       PolygonSet tmp(orient_, b);
//       tmp.sort_();
//       sort_();
//       applyBooleanBinaryOp(retVal.data_, data_, tmp.data_, BinaryCount<BinaryOr>());
//    } else {
//       b.sort_();
//       sort_();
//       applyBooleanBinaryOp(retVal.data_, data_, b.data_, BinaryCount<BinaryOr>());
//    }
//    retVal.dirty_ = false;
//    retVal.unsorted_ = false;
   return retVal;
}
inline PolygonSet PolygonSet::operator&(const PolygonSet& b) const{
   PolygonSet retVal(orient_);
   if(orient_ != b.orient_) {
      PolygonSet tmp(orient_, b);
      tmp.sort_();
      sort_();
      applyBooleanBinaryOp(retVal.data_, data_, tmp.data_, BinaryCount<BinaryAnd>());
   } else {
      b.sort_();
      sort_();
      applyBooleanBinaryOp(retVal.data_, data_, b.data_, BinaryCount<BinaryAnd>());
   }
   retVal.dirty_ = false;
   retVal.unsorted_ = false;
   return retVal;
}
inline PolygonSet PolygonSet::operator+(const PolygonSet& b) const{
   return (*this) | b;
}
inline PolygonSet PolygonSet::operator*(const PolygonSet& b) const{
   return (*this) & b;
}
inline PolygonSet PolygonSet::operator-(const PolygonSet& b) const{
   PolygonSet retVal(orient_);
   if(orient_ != b.orient_) {
      PolygonSet tmp(orient_, b);
      tmp.sort_();
      sort_();
      applyBooleanBinaryOp(retVal.data_, data_, tmp.data_, BinaryCount<BinaryNot>());
   } else {
      b.sort_();
      sort_();
      applyBooleanBinaryOp(retVal.data_, data_, b.data_, BinaryCount<BinaryNot>());
   }
   retVal.dirty_ = false;
   retVal.unsorted_ = false;
   return retVal;
}
inline PolygonSet PolygonSet::operator^(const PolygonSet& b) const{
   PolygonSet retVal(orient_);
   if(orient_ != b.orient_) {
      PolygonSet tmp(orient_, b);
      tmp.sort_();
      sort_();
      applyBooleanBinaryOp(retVal.data_, data_, tmp.data_, BinaryCount<BinaryXor>());
   } else {
      b.sort_();
      sort_();
      applyBooleanBinaryOp(retVal.data_, data_, b.data_, BinaryCount<BinaryXor>());
   }
   retVal.dirty_ = false;
   retVal.unsorted_ = false;
   return retVal;
}

/// |= &= += *= -= ^= binary operators
inline PolygonSet& PolygonSet::operator|=(const PolygonSet& b){
   //    if(orient_ != b.orient_) {
   //       PolygonSet tmp(orient_, b);
   //       tmp.sort_();
   //       sort_();
   //       applyBooleanBinaryOp(data_, tmp.data_, BinaryCount<BinaryOr>());
   //    } else {
   //       b.sort_();
   //       sort_();
   //       applyBooleanBinaryOp(data_, b.data_, BinaryCount<BinaryOr>());
   //    }
   //    dirty_ = false;
   //    unsorted_ = false;
   insert(b);
   return *this;
}
inline PolygonSet& PolygonSet::operator&=(const PolygonSet& b){
   if(orient_ != b.orient_) {
      PolygonSet tmp(orient_, b);
      tmp.sort_();
      sort_();
      applyBooleanBinaryOp(data_, tmp.data_, BinaryCount<BinaryAnd>());
   } else {
      b.sort_();
      sort_();
      applyBooleanBinaryOp(data_, b.data_, BinaryCount<BinaryAnd>());
   }
   dirty_ = false;
   unsorted_ = false;
   return *this;
}
inline PolygonSet& PolygonSet::operator+=(const PolygonSet& b){
   return (*this) |= b;
}
inline PolygonSet& PolygonSet::operator*=(const PolygonSet& b){
   return (*this) &= b;
}
inline PolygonSet& PolygonSet::operator-=(const PolygonSet& b){
   if(orient_ != b.orient_) {
      PolygonSet tmp(orient_, b);
      tmp.sort_();
      sort_();
      applyBooleanBinaryOp(data_, tmp.data_, BinaryCount<BinaryNot>());
   } else {
      b.sort_();
      sort_();
      applyBooleanBinaryOp(data_, b.data_, BinaryCount<BinaryNot>());
   }
   dirty_ = false;
   unsorted_ = false;
   return *this;
}
inline PolygonSet& PolygonSet::operator^=(const PolygonSet& b){
   if(orient_ != b.orient_) {
      PolygonSet tmp(orient_, b);
      tmp.sort_();
      sort_();
      applyBooleanBinaryOp(data_, tmp.data_, BinaryCount<BinaryXor>());
   } else {
      b.sort_();
      sort_();
      applyBooleanBinaryOp(data_, b.data_, BinaryCount<BinaryXor>());
   }
   dirty_ = false;
   unsorted_ = false;
   return *this;
}

/// | & + * - ^ binary operators
template <class T2>
inline PolygonSet PolygonSet::operator|(const PolygonImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal |= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator&(const PolygonImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal &= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator+(const PolygonImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal += b;
}
template <class T2>
inline PolygonSet PolygonSet::operator*(const PolygonImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal *= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator-(const PolygonImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal -= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator^(const PolygonImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal ^= b;
}

/// |= &= += *= -= ^= binary operators
template <class T2>
inline PolygonSet& PolygonSet::operator|=(const PolygonImpl<T2>& b){
   return (*this) |= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator&=(const PolygonImpl<T2>& b){
   return (*this) &= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator+=(const PolygonImpl<T2>& b){
   return (*this) += PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator*=(const PolygonImpl<T2>& b){
   return (*this) *= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator-=(const PolygonImpl<T2>& b){
   return (*this) -= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator^=(const PolygonImpl<T2>& b){
   return (*this) ^= PolygonSet(orient_, b);
}

//   /// | & + * - ^ binary operators
//   template <class T2>
//   inline PolygonSet PolygonSet::operator|(const PolygonWithHolesImpl<T2>& b) const{
//      PolygonSet retVal(*this);
//      return retVal |= b;
//   }
//   template <class T2>
//   inline PolygonSet PolygonSet::operator&(const PolygonWithHolesImpl<T2>& b) const{
//      PolygonSet retVal(*this);
//      return retVal &= b;
//   }
//   template <class T2>
//   inline PolygonSet PolygonSet::operator+(const PolygonWithHolesImpl<T2>& b) const{
//      PolygonSet retVal(*this);
//      return retVal += b;
//   }
//   template <class T2>
//   inline PolygonSet PolygonSet::operator*(const PolygonWithHolesImpl<T2>& b) const{
//      PolygonSet retVal(*this);
//      return retVal *= b;
//   }
//   template <class T2>
//   inline PolygonSet PolygonSet::operator-(const PolygonWithHolesImpl<T2>& b) const{
//      PolygonSet retVal(*this);
//      return retVal -= b;
//   }
//   template <class T2>
//   inline PolygonSet PolygonSet::operator^(const PolygonWithHolesImpl<T2>& b) const{
//      PolygonSet retVal(*this);
//      return retVal ^= b;
//   }

//   /// |= &= += *= -= ^= binary operators
//   template <class T2>
//   inline PolygonSet& PolygonSet::operator|=(const PolygonWithHolesImpl<T2>& b){
//      return (*this) |= PolygonSet(b);
//   }
//   template <class T2>
//   inline PolygonSet& PolygonSet::operator&=(const PolygonWithHolesImpl<T2>& b){
//      return (*this) &= PolygonSet(b);
//   }
//   template <class T2>
//   inline PolygonSet& PolygonSet::operator+=(const PolygonWithHolesImpl<T2>& b){
//      return (*this) += PolygonSet(b);
//   }
//   template <class T2>
//   inline PolygonSet& PolygonSet::operator*=(const PolygonWithHolesImpl<T2>& b){
//      return (*this) *= PolygonSet(b);
//   }
//   template <class T2>
//   inline PolygonSet& PolygonSet::operator-=(const PolygonWithHolesImpl<T2>& b){
//      return (*this) -= PolygonSet(b);
//   }
//   template <class T2>
//   inline PolygonSet& PolygonSet::operator^=(const PolygonWithHolesImpl<T2>& b){
//      return (*this) ^= PolygonSet(b);
//   }

/// | & + * - ^ binary operators
template <class T2>
inline PolygonSet PolygonSet::operator|(const RectangleImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal |= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator&(const RectangleImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal &= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator+(const RectangleImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal += b;
}
template <class T2>
inline PolygonSet PolygonSet::operator*(const RectangleImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal *= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator-(const RectangleImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal -= b;
}
template <class T2>
inline PolygonSet PolygonSet::operator^(const RectangleImpl<T2>& b) const{
   PolygonSet retVal(orient_, *this);
   return retVal ^= b;
}

/// |= &= += *= -= ^= binary operators
template <class T2>
inline PolygonSet& PolygonSet::operator|=(const RectangleImpl<T2>& b){
   return (*this) |= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator&=(const RectangleImpl<T2>& b){
   return (*this) &= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator+=(const RectangleImpl<T2>& b){
   return (*this) += PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator*=(const RectangleImpl<T2>& b){
   return (*this) *= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator-=(const RectangleImpl<T2>& b){
   return (*this) -= PolygonSet(orient_, b);
}
template <class T2>
inline PolygonSet& PolygonSet::operator^=(const RectangleImpl<T2>& b){
   return (*this) ^= PolygonSet(orient_, b);
}

/// resizing operations
inline PolygonSet PolygonSet::operator+(Unit delta) const{
   PolygonSet retVal(*this);
   return retVal += delta;
}
inline PolygonSet& PolygonSet::operator+=(Unit delta){
   if(delta > 0)
      return bloat(delta, delta, delta, delta);
   return shrink(-delta, -delta, -delta, -delta); 
}
inline PolygonSet PolygonSet::operator-(Unit delta) const{
   PolygonSet retVal(*this);
   return retVal -= delta;

}
inline PolygonSet& PolygonSet::operator-=(Unit delta){
   return (*this) += -delta;
}

/// shrink the PolygonSet specified by orient by shrinking amount
inline PolygonSet& PolygonSet::shrink(Orientation2D orient, UnsignedUnit shrinking){
   return shrink(orient, shrinking, shrinking);
}

/// shrink the PolygonSet specified by orient by low and high delta values
inline PolygonSet& PolygonSet::shrink(Orientation2D orient, UnsignedUnit lowDelta,
                                      UnsignedUnit highDelta){
   if(orient == HORIZONTAL) {
      return shrink(lowDelta, highDelta, 0, 0);
   }
   return shrink(0, 0, lowDelta, highDelta);
}

/// shrink the PolygonSet by shrinking
inline PolygonSet& PolygonSet::shrink(UnsignedUnit shrinking){
   return shrink(shrinking, shrinking, shrinking, shrinking);
}

/// shrink the PolygonSet cooresponding by bloating in dir direction
inline PolygonSet& PolygonSet::shrink(Direction2D dir, UnsignedUnit shrinking){
   if(dir == WEST) return shrink(shrinking, 0, 0, 0);
   if(dir == EAST) return shrink(0, shrinking, 0, 0);
   if(dir == SOUTH) return shrink(0, 0, shrinking, 0);
   return shrink(0, 0, 0, shrinking);
}

/// shrink the PolygonSet cooresponding directional values
inline PolygonSet& PolygonSet::shrink(UnsignedUnit westDelta,
                                      UnsignedUnit eastDelta,
                                      UnsignedUnit southDelta,
                                      UnsignedUnit northDelta){
   clean_();
   if(empty()) return *this;
   std::vector<Rectangle> rects;
   rects.reserve(data_.size());
   Rectangle externalBoundary(extents());
   externalBoundary.bloat(10); //bloat by diferential ammount
   insert(externalBoundary); //note that the set is in a dirty state now
   dirty_ = false; //prevent getRectangles from cleaning data
   getRectangles(rects); //gets the inverse
   clear();
   Orientation2D porient = orient_.getPerpendicular();
   Rectangle convolutionRectangle(Interval(-((Unit)eastDelta), westDelta),
                                  Interval(-((Unit)northDelta), southDelta));
   
   for(unsigned int i = 0; i < rects.size(); ++i) {
      Rectangle& rect = rects[i];
      rect.convolve(convolutionRectangle);
      insertHole(rect);
      //insert(rect.get(porient).low(), std::pair<Interval, int>(rect.get(orient_), -1));
      //insert(rect.get(porient).high(), std::pair<Interval, int>(rect.get(orient_), 1));
   }
   externalBoundary.convolve(convolutionRectangle);
   insert(externalBoundary);
   dirty_ = true;
   unsorted_ = true;
   clean_();
   return *this;
}

/// bloat the PolygonSet specified by orient by bloating amount
inline PolygonSet& PolygonSet::bloat(Orientation2D orient, UnsignedUnit bloating){
   if(orient == HORIZONTAL) {
      return bloat(bloating, bloating, 0, 0);
   }
   return bloat(0, 0, bloating, bloating);
}

/// bloat the PolygonSet specified by orient by low and high delta values
inline PolygonSet& PolygonSet::bloat(Orientation2D orient, UnsignedUnit lowDelta,
                                     UnsignedUnit highDelta){
   if(orient == HORIZONTAL) {
      return bloat(lowDelta, highDelta, 0, 0);
   }
   return bloat(0, 0, lowDelta, highDelta);
}

/// bloat the PolygonSet by bloating
inline PolygonSet& PolygonSet::bloat(UnsignedUnit bloating){
   return bloat(bloating, bloating, bloating, bloating);
}

/// bloat the PolygonSet cooresponding by bloating in dir direction
inline PolygonSet& PolygonSet::bloat(Direction2D dir, UnsignedUnit bloating){
   if(dir == WEST) return bloat(bloating, 0, 0, 0);
   if(dir == EAST) return bloat(0, bloating, 0, 0);
   if(dir == SOUTH) return bloat(0, 0, bloating, 0);
   return bloat(0, 0, 0, bloating);
}

/// bloat the PolygonSet cooresponding directional values
inline PolygonSet& PolygonSet::bloat(UnsignedUnit westDelta,
                                     UnsignedUnit eastDelta,
                                     UnsignedUnit southDelta,
                                     UnsignedUnit northDelta){
   clean_();
   std::vector<Rectangle> rects;
   rects.reserve(data_.size());
   getRectangles(rects);
   Rectangle convolutionRectangle(Interval(-((Unit)westDelta), eastDelta),
                                  Interval(-((Unit)southDelta), northDelta));
   for(std::vector<Rectangle>::iterator itr = rects.begin();
       itr != rects.end(); ++itr) {
      (*itr).convolve(convolutionRectangle);
   }
   clear();
   insert(rects.begin(), rects.end());
   return *this;
}

/// get the area of the set 
inline UnsignedLongUnit PolygonSet::area() const {
   clean_();
   std::vector<Rectangle> rects;
   rects.reserve(data_.size());
   getRectangles(rects);
   UnsignedLongUnit retVal = 0;
   for(std::vector<Rectangle>::iterator itr = rects.begin();
       itr != rects.end(); ++itr) {
      retVal += (*itr).area();
   }
   return retVal;
}

/// transform set
inline PolygonSet& PolygonSet::transform(const AxisTransform& atr){
  Direction2D dir1, dir2;
  atr.getDirections(dir1, dir2);
  int sign = dir1.getSign() * dir2.getSign();
  for(PolygonVectorData::iterator itr = data_.begin();
      itr != data_.end(); ++ itr) {
    if(orient() == VERTICAL)
      atr.transform2D((*itr).first, (*itr).second.first);
    else
      atr.transform2D((*itr).second.first, (*itr).first);
    (*itr).second.second *= sign;
  }
  unsorted_ = true;
  return *this;
}
    
/// transform set
inline PolygonSet& PolygonSet::transform(const Transform& tr){
   Direction2D dir1, dir2;
   tr.getAxisTransform().getDirections(dir1, dir2);
   int sign = dir1.getSign() * dir2.getSign();
   for(PolygonVectorData::iterator itr = data_.begin();
       itr != data_.end(); ++ itr) {
     if(orient() == VERTICAL)
       tr.transform2D((*itr).first, (*itr).second.first);
     else
       tr.transform2D((*itr).second.first, (*itr).first);
     (*itr).second.second *= sign;
   }
   unsorted_ = true;
   return *this;
}

/// scale set
inline PolygonSet& PolygonSet::scaleUp(UnsignedUnit factor) {
  Unit unitFactor = factor;
  for(PolygonVectorData::iterator itr = data_.begin();
      itr != data_.end(); ++ itr) {
    (*itr).first *= unitFactor;
    (*itr).second.first *= unitFactor;
  }
  //sorting order and clean/unclean state unchanced by scaling up
  return *this;
}
    
/// scale set
inline PolygonSet& PolygonSet::scaleDown(UnsignedUnit factor) {
  double dFactor = factor;
  for(PolygonVectorData::iterator itr = data_.begin();
      itr != data_.end(); ++ itr) {
    (*itr).first = (Unit)lround((double)((*itr).first) / dFactor);
    (*itr).second.first = (Unit)lround((double)((*itr).second.first) / dFactor);
  }
  //truncation may change sorting order
  unsorted_ = true;
  //an or operation is needed to eliminate degenerate data caused by truncation
  dirty_ = true;
  return *this;
}
 
inline PolygonSet& PolygonSet::growAnd(UnsignedUnit westDelta,
                                       UnsignedUnit eastDelta,
                                       UnsignedUnit southDelta,
                                       UnsignedUnit northDelta) {
   std::vector<Polygon> polys;
   getPolygons(polys);
   clear();
   for(unsigned int i = 0; i < polys.size(); ++i) {
      PolygonSet tmpPs(orient_, polys[i]);
      tmpPs.bloat(westDelta, eastDelta, southDelta, northDelta);
      tmpPs.clean_(); //apply implicit OR on tmp polygon set
      insert(tmpPs);
   }
   return selfIntersect();
}

inline PolygonSet& PolygonSet::growAnd(Direction2D dir, UnsignedUnit bloating) {
   if(dir == WEST) return growAnd(bloating, 0, 0, 0);
   if(dir == EAST) return growAnd(0, bloating, 0, 0);
   if(dir == SOUTH) return growAnd(0, 0, bloating, 0);
   return growAnd(0, 0, 0, bloating);
}

inline PolygonSet& PolygonSet::growAnd(UnsignedUnit bloating) {
   return growAnd(bloating, bloating, bloating, bloating);
}

inline PolygonSet& PolygonSet::growAnd(Orientation2D orient, UnsignedUnit lowDelta,
                                       UnsignedUnit highDelta) {
   if(orient == HORIZONTAL) {
      return growAnd(lowDelta, highDelta, 0, 0);
   }
   return growAnd(0, 0, lowDelta, highDelta);
}

inline PolygonSet& PolygonSet::growAnd(Orientation2D orient, UnsignedUnit bloating) {
   if(orient == HORIZONTAL) {
      return growAnd(bloating, bloating, 0, 0);
   }
   return growAnd(0, 0, bloating, bloating);
}

inline PolygonSet& PolygonSet::interact(const PolygonSet& that) {
   if(that.dirty_) that.clean_();
   TouchSetData tsd;
   populateTouchSetData(tsd, that.data_, 0);
   std::vector<Polygon> polys;
   getPolygons(polys);
   std::vector<std::set<int> > graph(polys.size()+1, std::set<int>());
   for(unsigned int i = 0; i < polys.size(); ++i){
      PolygonSet psTmp(that.orient_, polys[i]);
      psTmp.clean_();
      populateTouchSetData(tsd, psTmp.data_, i+1);
   }
   performTouch(graph, tsd);
   clear();
   for(std::set<int>::iterator itr = graph[0].begin(); itr != graph[0].end(); ++itr){
      insert(polys[(*itr)-1]);
   }
   dirty_ = false;
   return *this;
}

inline PolygonSet PolygonSet::interaction(const PolygonSet& that) {
   PolygonSet tmp = (*this);
   return tmp.interact(that);
}

inline PolygonSet& PolygonSet::selfIntersect() {
  insertHole(Rectangle(UnitMin, UnitMin, UnitMax, UnitMax));
  clean_(); //apply implicit OR on polygon set with effect of performing self intersection
  return *this;
}

inline PolygonSet PolygonSet::selfIntersection() {
   PolygonSet tmp(*this);
   return tmp.selfIntersect();
}

inline PolygonSet& PolygonSet::keep(UnsignedLongUnit minArea, UnsignedLongUnit maxArea, 
                                    UnsignedUnit minWidth, UnsignedUnit maxWidth, 
                                    UnsignedUnit minHeight, UnsignedUnit maxHeight) {
   std::list<Polygon> polys;
   getPolygons(polys);
   clear();
   for(std::list<Polygon>::iterator itr = polys.begin(); itr != polys.end(); ++itr){
      Rectangle bbox = (*itr).boundingBox();
      UnsignedUnit pwidth = bbox.delta(HORIZONTAL);
      if(pwidth > minWidth && pwidth <= maxWidth){
         UnsignedUnit pheight = bbox.delta(VERTICAL);
         if(pheight > minHeight && pheight <= maxHeight){
            UnsignedLongUnit parea = (*itr).area();
            if(parea <= maxArea && parea >= minArea) {
               insert(*itr);
            }
         }
      }
   }
   return *this;
}

inline void PolygonSet::sort_() const {
   if(unsorted_) {
      std::sort(data_.begin(), data_.end(), lessVertexCount());
      unsorted_ = false;
   }
}

inline void PolygonSet::clean_() const {
   if(unsorted_) sort_();
   if(dirty_) {
      applyBooleanOr(data_);
      dirty_ = false;
   }
}

inline std::ostream& operator<< (std::ostream& o, const PolygonSet& p) {
   o << "PolygonSet ";
   o << p.orient_ << " " << p.unsorted_ << " " << p.dirty_ << " { ";
   for(PolygonSet::PolygonVectorData::iterator itr = p.data_.begin();
       itr != p.data_.end(); ++itr) {
      o << (*itr).first << " " << (*itr).second.first << " " << (*itr).second.second << " ";
   }
   o << "} ";
   return o;
}

inline std::istream& operator>> (std::istream& i, PolygonSet& p) {
  char name[12];
  char spc;
  i.get(spc);
  while(spc == ' ') {
    i.get(spc);
  }
  i.unget();
  i.get(name, 11);
  std::string namestr(name);
  i >> p.orient_ >> p.unsorted_ >> p.dirty_;
  std::stringstream strstr;
  i.get(*(strstr.rdbuf()), '}');
  char openbrace;
  do {
    strstr.get(openbrace);
  } while (openbrace != '{');
  char lastchar;
  strstr.get(lastchar);
  while(strstr.good()) {
    if(lastchar != ' ') {
      strstr.unget();
      std::pair<int, std::pair<int, int> > element;
      strstr >> element.first >> element.second.first >> element.second.second;
      p.data_.push_back(element);
    }
    strstr.get(lastchar);
  }
  char closebrace;
  i.get(closebrace);
  return i;
}

inline int testPolygonSetStreams() {
  PolygonSet ps(HORIZONTAL, Rectangle(10,20,30,40));
  PolygonSet ps2(VERTICAL, Rectangle(11,21,31,41));
  std::stringstream strstr;
  strstr << ps << " " << ps2;
  std::string mystring;
  mystring = strstr.str();
  PolygonSet tmp, tmp2;
  strstr >> tmp;
  strstr >> tmp2;
  if(ps != tmp) {
    return 1;
  }
  if(ps2 != tmp2) {
    return 2;
  }
  return 0;
}

inline int testPolygonSetCompare() {
  PolygonSet ps(HORIZONTAL, Rectangle(10,20,30,40));
  PolygonSet ps2(HORIZONTAL, Rectangle(11,21,31,41));
  return !(ps < ps2 && !(ps2 < ps)); 
}
