/*
    Copyright 2008 Intel Corporation
 
    Use, modification and distribution are subject to the Boost Software License,
    Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
*/
/// RectPrismInterface provides glue to bind RectPrismImpl to T

/// RectPrismInterface provides access the the data class T through
/// the constructor, get and set API, which are minimal and sufficient in 
/// combination with the interval API.
template <class T>
class RectPrismInterface {
public:
  /// get an interval of the rect prism t depending on orient
  static inline IntervalData RectPrismGet(const T& t, Orientation3D orient);

  /// get an interval of the rect prism t depending on orient
  static inline void RectPrismSet(T& t, Orientation3D orient, const IntervalData& value);

  /// construct a rect prism of type T from horizontal, vertical 
  /// and proximal ranges
  static inline T RectPrismConstruct(const IntervalData& hrange, 
                                     const IntervalData& vrange,
                                     const IntervalData& prange);
private:
  //disallow construction
  RectPrismInterface();
};
  
/// partial specialization of RectPrismInterface for T of type RectPrismData
template <>
class RectPrismInterface<RectPrismData> {
public:
  static inline IntervalData RectPrismGet(const RectPrismData& t, 
                                          Orientation3D orient) {
    return t.get(orient);
  }
  static inline void RectPrismSet(RectPrismData& t, 
                                  Orientation3D orient,
                                  const IntervalData& value){
    t.set(orient, value);
  }
  static inline RectPrismData RectPrismConstruct(const IntervalData& hrange, 
                                                 const IntervalData& vrange,
                                                 const IntervalData& prange) {
    return RectPrismData(hrange, vrange, prange);
  }

private:
  //disallow construction
  RectPrismInterface(){;}
};
